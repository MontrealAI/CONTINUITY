"""Record one post-review qualification command without hiding failed output."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

REPO = Path('/workspace/scratch/b1d5891eb025/economy-post-review-source')
ROOT = Path('/workspace/scratch/b1d5891eb025/economy-review-repair')
OUT = ROOT / 'qualification'
PREFIX = [sys.executable, '-m', 'continuity_economy']
JOBS = {
    'full-regression': ([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py', '-v'], 0),
    'complete-replay': (PREFIX + ['--language', 'en', 'experiment', '--out', str(OUT / 'complete-replay-1')], 0),
    'fresh-replay': (PREFIX + ['--language', 'fr', 'verify-suite', '--in-dir', str(OUT / 'complete-replay-1')], 0),
    'fresh-original': (PREFIX + ['--language', 'en', 'verify-suite', '--in-dir', '/workspace/scratch/b1d5891eb025/economy-downloaded-evidence/qualification/complete-attempt-1'], 0),
    'refuse-demo': (PREFIX + ['--language', 'en', 'verify-suite', '--in-dir', str(ROOT / 'before/inputs/experiment-roles-alias-base-demo')], 2),
    'refuse-comparison': (PREFIX + ['--language', 'fr', 'verify-suite', '--in-dir', str(ROOT / 'before/inputs/experiment-roles-alias-base-comparison')], 2),
}

name = sys.argv[1]
args, expected_exit = JOBS[name]
record_path = OUT / 'logs' / (name + '.execution.json')
stdout_path = OUT / 'logs' / (name + '.stdout.log')
stderr_path = OUT / 'logs' / (name + '.stderr.log')
assert not any(p.exists() for p in (record_path, stdout_path, stderr_path))
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True)
assert head == 'f9e56c7dd9627b322406e05c53b4f6537d434262' and not status
started = time.monotonic_ns()
with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
    result = subprocess.run(args, cwd=REPO, stdout=stdout, stderr=stderr, timeout=600)
record = {
    'schema': 'continuity-economy/post-review-command/v1',
    'name': name,
    'argv': args,
    'cwd': str(REPO),
    'source_commit': head,
    'source_clean': not status,
    'suite_source_sha256': hashlib.sha256((REPO / 'continuity_economy/suite.py').read_bytes()).hexdigest(),
    'exit_code': result.returncode,
    'expected_exit_code': expected_exit,
    'wall_ns': time.monotonic_ns() - started,
    'stdout_sha256': hashlib.sha256(stdout_path.read_bytes()).hexdigest(),
    'stderr_sha256': hashlib.sha256(stderr_path.read_bytes()).hexdigest(),
    'test_assertion': 'PASSED' if result.returncode == expected_exit else 'FAILED',
}
if expected_exit == 2 and result.returncode == 2:
    refusal = json.loads(stderr_path.read_text())
    record['target_verdict'] = refusal['code']
    if refusal['code'] != 'SUITE_COVERAGE': record['test_assertion'] = 'FAILED'
elif name != 'full-regression' and result.returncode == 0:
    value = json.loads(stdout_path.read_text())
    record['target_verdict'] = value['test_assertion']
    if value['test_assertion'] != 'PASSED': record['test_assertion'] = 'FAILED'
record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(record, ensure_ascii=False, indent=2))
raise SystemExit(0 if record['test_assertion'] == 'PASSED' else 1)
