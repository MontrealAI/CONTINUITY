# CONTINUITÉ Ω — Économie de la continuité

**Expérience de produit numérique · version 0.2.0**

Préserver un engagement grâce à une solution de continuité viable et volontairement acceptée.

**Portée : processus locaux jetables et produit numérique spécifié. Les politiques, consentements, valeurs, financements et flux SMU synthétiques sont des hypothèses et observations du modèle. Ils n’établissent ni contrats réels, ni demande, paiements, ventes, biens imprimés, apparence rendue ou qualité d’impression.**

Ce passeport présente l’évaluation consignée. Une vérification fraîche doit inspecter l’autorité conservée, le résultat durable réel et les preuves du destinataire ; ce document ne constitue jamais son oracle.

<!-- structured-result-sha256: 8855f13b3448fe88744cdc894259b1a856d06aaf0ec93130835390b04c5ccb98 -->

## Trois affirmations distinctes

| Affirmation | État consigné |
| --- | --- |
| Travail numérique requis accepté dans les conditions figées | Non établi (`NOT_ESTABLISHED`) |
| Faisabilité du service selon le modèle synthétique défini | Non établi (`NOT_ESTABLISHED`) |
| Avantage de méthode face à des solutions compétentes | Non établi (`NOT_ESTABLISHED`) |
| Sûreté dans le modèle de défaillance éprouvé | Non établi (`NOT_ESTABLISHED`) |

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

## Champs d’évaluation distincts

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | Échec (`FAILED`) |
| Verdict du composant | Erreur d’exécution (`ERROR`) |
| Stade de preuve | Tentative de vérification (`VERIFICATION_ATTEMPT`) |
| État de l’affirmation évaluée | Non établi (`NOT_ESTABLISHED`) |

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

## Identité, autorité et versions

| Champ | Valeur consignée |
| --- | --- |
| État des preuves d’autorité · `authority_status` | Établi uniquement pour l’exercice synthétique (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Valeur commerciale réelle · `commercial_value` | Non établi (`NOT_ESTABLISHED`) |
| Identité du contrat · `contract_id` | DIGITAL-003 |
| SHA-256 du contrat conservé · `contract_sha256` | f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1 |
| Authenticité d’un client réel · `real_customer_authenticity` | Non établi (`NOT_ESTABLISHED`) |
| Empreinte externe de référence · `reference_sha256` | 3515001b3305413676901422f8c6395fa915673f7d62833397fab94b9680718a |
| Identité de l’exécution · `run_id` | constructed-continuity.conventional.f189246caf |
| Schéma · `schema` | continuity-economy/verification/v1 |
| État d’achèvement de la vérification · `verification_status` | Vérification incomplète (`INCOMPLETE`) |
| Version du vérificateur · `verifier_version` | 0.2.0 |

## Exécution et acceptation par obligation

Les quantités décrivent le stade consigné. Les tentatives refusées et corrigées restent distinctes. Une unité produite ou reçue n’est pas automatiquement acceptée. Les mesures absentes ne sont pas présentées comme nulles.

| Obligation | Destinataire | Révision | Requis | Produit | Reçu | Refusé | Accepté selon le contrat | Résultat |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 0 | 0 | 0 | 0 | Non résolu (`UNRESOLVED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 0 | 0 | 0 | 0 | Non résolu (`UNRESOLVED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Non résolu (`UNRESOLVED`) |

### Obligation `DL-100`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 1100 |
| Identité de l’obligation · `obligation_id` | DL-100 |
| Résultat · `outcome` | Non résolu (`UNRESOLVED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 1100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-A |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 1100 |
| Révision · `revision` | 2 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

### Obligation `DL-200`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 800 |
| Identité de l’obligation · `obligation_id` | DL-200 |
| Résultat · `outcome` | Non résolu (`UNRESOLVED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 800 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-B |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 800 |
| Révision · `revision` | 1 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

### Obligation `DL-300`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-300 |
| Résultat · `outcome` | Non résolu (`UNRESOLVED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-C |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 0 |
| Révision · `revision` | 1 |
| État consigné · `status` | Annulé (`CANCELLED`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

## Propositions, décisions modélisées et solutions

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

Aucun enregistrement de solution n’est présent. Cette absence ne prouve ni accord accepté ni viabilité économique.

## Transferts, coûts, responsabilités et options externes modélisés

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

| Champ | Valeur consignée |
| --- | --- |
| `accounting` | Aucune entrée |
| Obligations acceptées · `totals.accepted_obligations` | 0 |
| Quantité acceptée selon le contrat · `totals.accepted_quantity` | 0 |
| Tentatives de livraison · `totals.delivery_attempts` | 0 |
| Unités acceptées en double · `totals.duplicate_acceptances` | 0 |
| Quantité tardive · `totals.late_quantity` | 0 |
| Quantité manquante · `totals.missing_quantity` | 1900 |
| Quantité produite · `totals.produced_quantity` | 0 |
| Tentatives de production durables · `totals.production_attempts` | 0 |
| Quantité reçue · `totals.received_quantity` | 0 |
| Unités acceptées par le composant destinataire · `totals.recipient_accepted_quantity` | 0 |
| Quantité refusée · `totals.rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `totals.rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `totals.rejection_count` | 0 |
| Obligations actives requises · `totals.required_obligations` | 2 |
| Quantité requise · `totals.required_quantity` | 1900 |
| Unités sémantiquement correctes observées à temps · `totals.timely_semantic_quantity` | 0 |
| Engagements non sûrs ou non autorisés · `totals.unsafe_or_unsupported_commitments` | 0 |

## Ressources mesurées et lacunes de comptabilisation

Les ressources de processus mesurées et les montants synthétiques configurés ont des significations différentes. Les efforts de préparation, d’intégration, d’adaptation, de vérification ou d’intervention non consignés restent inconnus. Les catégories absentes ne permettent aucune conclusion de coût complet ou de méthode moins coûteuse.

| Champ | Valeur consignée |
| --- | --- |
| Lacunes de comptabilisation · `accounting_gaps[0]` | Le travail de préparation n’a pas été mesuré (`PREPARATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[1]` | Le travail d’intégration n’a pas été mesuré (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[2]` | Le travail d’adaptation n’a pas été mesuré (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[3]` | Le travail humain de vérification n’a pas été mesuré (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[4]` | Les tarifs monétaires n’ont pas été mesurés (`MONETARY_RATES_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Travail d’adaptation (secondes ; inconnu si absent) · `resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `resources.authority_storage_bytes_before_seal` | 30468 |
| Redémarrages du candidat · `resources.candidate_restarts` | 1 |
| Processus enfants lancés · `resources.child_processes` | 10 |
| Processeur système du contrôleur (ns) · `resources.controller_cpu_system_ns` | 37726999 |
| Processeur utilisateur du contrôleur (ns) · `resources.controller_cpu_user_ns` | 163732000 |
| Processeur système (ns) · `resources.cpu_system_ns` | 99530000 |
| Processeur utilisateur (ns) · `resources.cpu_user_ns` | 694082000 |
| Interventions humaines · `resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `resources.requests` | 37 |
| Nouvelles tentatives · `resources.retries` | 0 |
| Requêtes internes aux services · `resources.service_requests` | 180 |
| Stockage consigné (octets) · `resources.storage_bytes` | 8476603 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `resources.wall_ns` | 1184171770 |
| Redémarrages des services · `resources.worker_restarts` | 1 |
| Temps processeur (ns) · `verification_resources.cpu_ns` | 21265985 |
| Fichiers de preuve examinés · `verification_resources.evidence_files_read` | 6 |
| Durée écoulée (ns) · `verification_resources.wall_ns` | 21298894 |

## Échecs et contre-exemples observés

Aucune entrée d’échec n’a été consignée dans cette évaluation. Il s’agit de preuves bornées, non d’une démonstration générale.

## Preuves absentes et affirmations non établies

| Code stable | Portée | Obligation | Solution | Interprétation | Repère technique original |
| --- | --- | --- | --- | --- | --- |
| `EXECUTION_INCOMPLETE` | outcome | Non consigné | Non consigné | Une preuve ou mesure requise manque ; cette entrée n’établit pas une affirmation favorable. | `` |
| `VERIFICATION_EVIDENCE_MISSING` | integrity | Non consigné | Non consigné | Une preuve ou mesure requise manque ; cette entrée n’établit pas une affirmation favorable. | `MISSING_FILE:COMPAT-A.W0.sqlite` |

## Références des preuves et intégrité des octets

Les empreintes identifient les octets. Elles n’authentifient pas les instructions réelles d’un client, n’établissent pas l’exhaustivité des sources et ne remplacent pas une empreinte de référence conservée séparément.

| Champ | Valeur consignée |
| --- | --- |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 7a7ac2e80dde7705f93dc901ee9edb8397b9590215fcaf923ed09aadf5e6a451 |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.closing` | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | 017cbc7ba188053893d674c36ec6eb4612ecf73f6878aed769cd286a6b751db8 |
| `evidence_sha256.evidence/participants.sqlite` | c22d2cb5ec0be6b97a98254830f9449870ff0fcd1c6892986a7ed659727ee044 |
| `evidence_sha256.evidence/producer.sqlite` | 436abecf8e4d3a4f0beb7c022ebfaf4774ef30592b497474c849d5e73745442b |
| `evidence_sha256.evidence/receiver.sqlite` | a924e23206c1be61bc93278c5404c51d69242b912b74ac31f1c381299c5e13cf |
| SHA-256 du résultat structuré · `structured_result_sha256` | 8855f13b3448fe88744cdc894259b1a856d06aaf0ec93130835390b04c5ccb98 |

## Exécution, pannes, commandes et provenance consignées

Les identifiants stables, commandes exactes, chemins et diagnostics machine originaux sont conservés littéralement. Ce sont des données, non des preuves d’acceptation supplémentaires. La confiance dans les sources et l’hôte est explicitée dans l’architecture et le modèle de menace.

| Champ | Valeur consignée |
| --- | --- |
| `authority_dir` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1/base/authorities/constructed-continuity.conventional |
| Cohorte d’expérience · `cohort` | base |
| `contract.allow_split` | Oui |
| `contract.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | PRIMARY-HOST |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Cohorte d’expérience · `contract.cohort` | base |
| Identité du contrat · `contract.contract_id` | DIGITAL-003 |
| `contract.cutoff_sequence` | 5 |
| Échéance logique · `contract.deadline_tick` | 500 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-001 |
| Événement consigné · `contract.fault_schedule[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `contract.fault_schedule[0].occurrence` | 1 |
| Cible de la panne · `contract.fault_schedule[0].target` | BACKUP |
| Opération déclenchante · `contract.fault_schedule[0].trigger` | reserve |
| Valeur configurée · `contract.fault_schedule[0].value` | 0 |
| Événement consigné · `contract.fault_schedule[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `contract.fault_schedule[1].occurrence` | 1 |
| Cible de la panne · `contract.fault_schedule[1].target` | ANY |
| Opération déclenchante · `contract.fault_schedule[1].trigger` | inspect |
| Valeur configurée · `contract.fault_schedule[1].value` | 0 |
| Événement consigné · `contract.fault_schedule[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `contract.fault_schedule[2].occurrence` | 1 |
| Cible de la panne · `contract.fault_schedule[2].target` | ANY |
| Opération déclenchante · `contract.fault_schedule[2].trigger` | inspect |
| Valeur configurée · `contract.fault_schedule[2].value` | 0 |
| Identité du cas préenregistré · `contract.fixture_id` | constructed-continuity |
| `contract.lease_ticks` | 20 |
| `contract.lot_size` | 500 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Échéance logique · `contract.obligations[0].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[0].obligation_id` | DL-100 |
| Quantité requise · `contract.obligations[0].quantity` | 1100 |
| Destinataire · `contract.obligations[0].recipient` | RECIPIENT-A |
| Révision · `contract.obligations[0].revision` | 2 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[0].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[0].spec.lot` | BATCH-20261106 |
| `contract.obligations[0].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[0].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[0].spec.serial_prefix` | DL-100- |
| `contract.obligations[0].spec.sku` | KIT-DL-100 |
| État consigné · `contract.obligations[0].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[1].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[1].obligation_id` | DL-200 |
| Quantité requise · `contract.obligations[1].quantity` | 800 |
| Destinataire · `contract.obligations[1].recipient` | RECIPIENT-B |
| Révision · `contract.obligations[1].revision` | 1 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[1].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[1].spec.lot` | BATCH-20261106 |
| `contract.obligations[1].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[1].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[1].spec.serial_prefix` | DL-200- |
| `contract.obligations[1].spec.sku` | KIT-DL-200 |
| État consigné · `contract.obligations[1].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[2].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[2].obligation_id` | DL-300 |
| Quantité requise · `contract.obligations[2].quantity` | 100 |
| Destinataire · `contract.obligations[2].recipient` | RECIPIENT-C |
| Révision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[2].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[2].spec.lot` | BATCH-20261106 |
| `contract.obligations[2].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[2].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[2].spec.serial_prefix` | DL-300- |
| `contract.obligations[2].spec.sku` | KIT-DL-300 |
| État consigné · `contract.obligations[2].status` | Annulé (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 800 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | PRIMARY-HOST |
| `contract.providers[0].permissions.disclosure` | Oui |
| `contract.providers[0].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[0].provider_id` | PRIMARY |
| Rôle · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 2400 |
| `contract.providers[0].windows[0].end` | 800 |
| `contract.providers[0].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[0].windows[0].window_id` | W0 |
| `contract.providers[1].dependency` | BACKUP-HOST |
| `contract.providers[1].permissions.disclosure` | Oui |
| `contract.providers[1].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[1].provider_id` | BACKUP |
| Rôle · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 2400 |
| `contract.providers[1].windows[0].end` | 800 |
| `contract.providers[1].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[1].windows[0].window_id` | W0 |
| `contract.providers[2].dependency` | COMPAT-A-HOST |
| `contract.providers[2].permissions.disclosure` | Oui |
| `contract.providers[2].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[2].provider_id` | COMPAT-A |
| Rôle · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 1200 |
| `contract.providers[2].windows[0].end` | 800 |
| `contract.providers[2].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[2].windows[0].window_id` | W0 |
| `contract.providers[3].dependency` | COMPAT-B-HOST |
| `contract.providers[3].permissions.disclosure` | Oui |
| `contract.providers[3].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[3].provider_id` | COMPAT-B |
| Rôle · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 1100 |
| `contract.providers[3].windows[0].end` | 800 |
| `contract.providers[3].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[3].windows[0].window_id` | W0 |
| Révision · `contract.revision` | 1 |
| `contract.revocations` | Aucune entrée |
| Identité de l’exécution · `contract.run_id` | constructed-continuity.conventional.f189246caf |
| Schéma · `contract.schema` | continuity-economy/contract/v1 |
| Graine consignée · `contract.seed` | 703 |
| `contract.source_complete` | Oui |
| Échéance logique · `contract.source_events[0].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[0].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[0].obligation.quantity` | 1000 |
| Destinataire · `contract.source_events[0].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Obsolete instruction. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Instruction périmée. |
| `contract.source_events[0].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[0].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[0].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[0].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[0].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[0].obligation_id` | DL-100 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Échéance logique · `contract.source_events[1].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[1].obligation.obligation_id` | DL-200 |
| Quantité requise · `contract.source_events[1].obligation.quantity` | 800 |
| Destinataire · `contract.source_events[1].obligation.recipient` | RECIPIENT-B |
| Révision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[1].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[1].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[1].obligation.spec.serial_prefix` | DL-200- |
| `contract.source_events[1].obligation.spec.sku` | KIT-DL-200 |
| État consigné · `contract.source_events[1].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[1].obligation_id` | DL-200 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Échéance logique · `contract.source_events[2].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[2].obligation.obligation_id` | DL-300 |
| Quantité requise · `contract.source_events[2].obligation.quantity` | 100 |
| Destinataire · `contract.source_events[2].obligation.recipient` | RECIPIENT-C |
| Révision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[2].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[2].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[2].obligation.spec.serial_prefix` | DL-300- |
| `contract.source_events[2].obligation.spec.sku` | KIT-DL-300 |
| État consigné · `contract.source_events[2].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[2].obligation_id` | DL-300 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Échéance logique · `contract.source_events[3].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[3].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[3].obligation.quantity` | 1100 |
| Destinataire · `contract.source_events[3].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[3].obligation.revision` | 2 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[3].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[3].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[3].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[3].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[3].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[3].obligation_id` | DL-100 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | AMEND |
| Identité de l’obligation · `contract.source_events[4].obligation_id` | DL-300 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | CANCEL |
| `contract.source_id` | AUTHORED-DIGITAL-EVENTS |
| Empreintes des octets sources · `contract.source_sha256` | 8d6a71fd1c26021120a5283bd7cf3eb7812b5c34ae6a4da3eec94dceaf8f7b81 |
| Horloge de départ (ns) · `contract.start_ns` | 40081184923685 |
| Échéance en temps écoulé (ms) · `contract.wall_deadline_ms` | 60000 |
| `controller.capacity_databases[0].path` | evidence/capacity/PRIMARY.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[0].provider_id` | PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Identité de la fenêtre de capacité · `controller.capacity_databases[0].window_id` | W0 |
| `controller.capacity_databases[1].path` | evidence/capacity/BACKUP.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[1].provider_id` | BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[1].window_id` | W0 |
| `controller.capacity_databases[2].path` | evidence/capacity/COMPAT-A.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[2].provider_id` | COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[2].window_id` | W0 |
| `controller.capacity_databases[3].path` | evidence/capacity/COMPAT-B.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[3].provider_id` | COMPAT-B |
| `controller.capacity_databases[3].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[3].window_id` | W0 |
| `controller.clock_tick` | 38 |
| Cohorte d’expérience · `controller.cohort` | base |
| SHA-256 du contrat conservé · `controller.contract_sha256` | f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1 |
| `controller.db_snapshots.evidence/capacity/BACKUP.W0.sqlite` | 5920e3a7af1cbdda19c506d53227b4a9b4801ed0f2e58c1daea969cf83a5eb49 |
| `controller.db_snapshots.evidence/capacity/COMPAT-A.W0.sqlite` | a12ec277cbc3cb40e2c9d6d6175d5bcfe145cd0112c3dcadb36e40d38a03f56a |
| `controller.db_snapshots.evidence/capacity/COMPAT-B.W0.sqlite` | af5a5d3cf39dabbe9b4a8606376010b3d3fee73e2ae48a0e012ce9445d9c6699 |
| `controller.db_snapshots.evidence/capacity/PRIMARY.W0.sqlite` | 898556b4d98676cbe68aa8d9617c6d9da70d5307905d4780cf158edc89956a42 |
| `controller.db_snapshots.evidence/participants.sqlite` | d953c96c6a6c62b51de997f33ad0a5e210504523b2256ae04d8e799062876a51 |
| `controller.db_snapshots.evidence/producer.sqlite` | b964dc2b2c9865f0c4927b8ffb2c9831503f8fcfc80d476221d6414365045928 |
| `controller.db_snapshots.evidence/receiver.sqlite` | 2bd2414d3269f4f7a8c058b263ca782b07410f9c4374d8d2ec2136401ddf6c7e |
| Code stable · `controller.errors[0].code` | DATABASE_STATE_CHANGED |
| `controller.errors[0].detail` | DATABASE_STATE_CHANGED: /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1/base/runs/constructed-continuity.conventional/runtime/capacity/COMPAT-A.W0.sqlite |
| `controller.errors[0].message` | Le contenu durable de la base a changé après son instantané conservé. |
| `controller.events[0].detail.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| Empreinte externe de référence · `controller.events[0].detail.reference_sha256` | 3515001b3305413676901422f8c6395fa915673f7d62833397fab94b9680718a |
| Graine consignée · `controller.events[0].detail.seed` | 703 |
| Événement consigné · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 40081205395819 |
| Instant logique · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 75 |
| `controller.events[1].detail.restart` | Non |
| `controller.events[1].detail.service` | participants |
| Événement consigné · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 40081255562787 |
| Instant logique · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 76 |
| `controller.events[2].detail.restart` | Non |
| `controller.events[2].detail.service` | producer |
| Événement consigné · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 40081298704627 |
| Instant logique · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 77 |
| `controller.events[3].detail.restart` | Non |
| `controller.events[3].detail.service` | receiver |
| Événement consigné · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 40081340276613 |
| Instant logique · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 78 |
| Identité du fournisseur · `controller.events[4].detail.provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[4].detail.window_id` | W0 |
| Événement consigné · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 40081388786556 |
| Instant logique · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 79 |
| Identité du fournisseur · `controller.events[5].detail.provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[5].detail.window_id` | W0 |
| Événement consigné · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 40081440163063 |
| Instant logique · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 80 |
| Identité du fournisseur · `controller.events[6].detail.provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[6].detail.window_id` | W0 |
| Événement consigné · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 40081482395808 |
| Instant logique · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 81 |
| Identité du fournisseur · `controller.events[7].detail.provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[7].detail.window_id` | W0 |
| Événement consigné · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 40081519746875 |
| Instant logique · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.affected[0]` | PRIMARY.W0 |
| `controller.events[8].detail.dependency` | PRIMARY-HOST |
| Événement consigné · `controller.events[8].event` | DEPENDENCY_DISABLED |
| `controller.events[8].monotonic_ns` | 40081520744503 |
| Instant logique · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.isolation.applied` | Oui |
| `controller.events[9].detail.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.events[9].detail.isolation.probe.authority_open_denied` | Oui |
| `controller.events[9].detail.isolation.probe.network_denied` | Oui |
| `controller.events[9].detail.isolation.probe.process_inspection_denied` | Oui |
| `controller.events[9].detail.isolation.probe.spawn_denied` | Oui |
| `controller.events[9].detail.isolation.probe.workspace_open_denied` | Oui |
| `controller.events[9].detail.pid` | 82 |
| `controller.events[9].detail.restart` | Non |
| Événement consigné · `controller.events[9].event` | CANDIDATE_STARTED |
| `controller.events[9].monotonic_ns` | 40081560149824 |
| Instant logique · `controller.events[9].tick` | 0 |
| `controller.events[10].detail.args` | Aucune entrée |
| `controller.events[10].detail.op` | status |
| Événement consigné · `controller.events[10].event` | BROKER_REQUEST |
| `controller.events[10].monotonic_ns` | 40081561807069 |
| Instant logique · `controller.events[10].tick` | 1 |
| `controller.events[11].detail.measurement_kind` | Mesure déclarée par le candidat (`CANDIDATE_REPORTED`) |
| `controller.events[11].detail.pid` | 82 |
| `controller.events[11].detail.report.assignment_domain` | 243 |
| `controller.events[11].detail.report.candidate_elapsed_ns` | 10082530 |
| `controller.events[11].detail.report.capacity_prunes` | 54 |
| `controller.events[11].detail.report.complete_assignments_observed` | 243 |
| `controller.events[11].detail.report.exhaustive_within_declared_domain` | Oui |
| `controller.events[11].detail.report.feasible_assignments` | 189 |
| `controller.events[11].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Procédure candidate · `controller.events[11].detail.report.method` | conventional |
| `controller.events[11].detail.report.partial_nodes_observed` | 0 |
| `controller.events[11].detail.report.participant_prunes` | 0 |
| `controller.events[11].detail.report.price_prunes` | 0 |
| Événement consigné · `controller.events[11].event` | CANDIDATE_PLANNING |
| `controller.events[11].monotonic_ns` | 40081578344145 |
| Instant logique · `controller.events[11].tick` | 1 |
| Premier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[0].last_unit` | 500 |
| Identité du lot fixe · `controller.events[12].detail.args.proposal.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `controller.events[12].detail.args.proposal.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.allocations[0].pay_minor` | 4200 |
| Identité du fournisseur · `controller.events[12].detail.args.proposal.allocations[0].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[12].detail.args.proposal.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[1].first_unit` | 501 |
| Dernier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[1].last_unit` | 1000 |
| Identité du lot fixe · `controller.events[12].detail.args.proposal.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `controller.events[12].detail.args.proposal.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[12].detail.args.proposal.allocations[1].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[12].detail.args.proposal.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[2].first_unit` | 1001 |
| Dernier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[2].last_unit` | 1100 |
| Identité du lot fixe · `controller.events[12].detail.args.proposal.allocations[2].lot_id` | DL-100.L003 |
| Identité de l’obligation · `controller.events[12].detail.args.proposal.allocations[2].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[12].detail.args.proposal.allocations[2].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[12].detail.args.proposal.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[3].last_unit` | 500 |
| Identité du lot fixe · `controller.events[12].detail.args.proposal.allocations[3].lot_id` | DL-200.L001 |
| Identité de l’obligation · `controller.events[12].detail.args.proposal.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[12].detail.args.proposal.allocations[3].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[12].detail.args.proposal.allocations[3].window_id` | W0 |
| Premier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[4].first_unit` | 501 |
| Dernier ordinal inclus · `controller.events[12].detail.args.proposal.allocations[4].last_unit` | 800 |
| Identité du lot fixe · `controller.events[12].detail.args.proposal.allocations[4].lot_id` | DL-200.L002 |
| Identité de l’obligation · `controller.events[12].detail.args.proposal.allocations[4].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[12].detail.args.proposal.allocations[4].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[12].detail.args.proposal.allocations[4].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.buyer_price_minor` | 4500 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `controller.events[12].detail.args.proposal.contract_sha256` | f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1 |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.coordinator_fee_minor` | 300 |
| Instant exclusif d’expiration · `controller.events[12].detail.args.proposal.expires_tick` | 500 |
| Révision des politiques · `controller.events[12].detail.args.proposal.policy_revision` | 1 |
| Identité de la proposition · `controller.events[12].detail.args.proposal.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `controller.events[12].detail.args.proposal.rework_budget_minor` | 2050 |
| Schéma · `controller.events[12].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[12].detail.op` | propose |
| Événement consigné · `controller.events[12].event` | BROKER_REQUEST |
| `controller.events[12].monotonic_ns` | 40081578505099 |
| Instant logique · `controller.events[12].tick` | 2 |
| Identité de la proposition · `controller.events[13].detail.args.proposal_id` | proposal-001 |
| `controller.events[13].detail.op` | decide |
| Événement consigné · `controller.events[13].event` | BROKER_REQUEST |
| `controller.events[13].monotonic_ns` | 40081584136120 |
| Instant logique · `controller.events[13].tick` | 3 |
| `controller.events[14].detail.args` | Aucune entrée |
| `controller.events[14].detail.op` | status |
| Événement consigné · `controller.events[14].event` | BROKER_REQUEST |
| `controller.events[14].monotonic_ns` | 40081589099502 |
| Instant logique · `controller.events[14].tick` | 4 |
| Identité de l’accord · `controller.events[15].detail.args.agreement_id` | proposal-001 |
| `controller.events[15].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[15].detail.args.lot_id` | DL-100.L001 |
| `controller.events[15].detail.op` | reserve |
| Événement consigné · `controller.events[15].event` | BROKER_REQUEST |
| `controller.events[15].monotonic_ns` | 40081595733960 |
| Instant logique · `controller.events[15].tick` | 5 |
| `controller.events[16].detail.affected[0]` | BACKUP.W0 |
| `controller.events[16].detail.dependency` | BACKUP-HOST |
| Événement consigné · `controller.events[16].event` | DEPENDENCY_DISABLED |
| `controller.events[16].monotonic_ns` | 40081599041089 |
| Instant logique · `controller.events[16].tick` | 5 |
| `controller.events[17].detail.dependency` | BACKUP-HOST |
| Événement consigné · `controller.events[17].detail.schedule.event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `controller.events[17].detail.schedule.occurrence` | 1 |
| Cible de la panne · `controller.events[17].detail.schedule.target` | BACKUP |
| Opération déclenchante · `controller.events[17].detail.schedule.trigger` | reserve |
| Valeur configurée · `controller.events[17].detail.schedule.value` | 0 |
| Événement consigné · `controller.events[17].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| `controller.events[17].monotonic_ns` | 40081599056653 |
| Instant logique · `controller.events[17].tick` | 5 |
| Code stable · `controller.events[18].detail.code` | DEPENDENCY_UNAVAILABLE |
| `controller.events[18].detail.detail` | BACKUP |
| `controller.events[18].detail.op` | reserve |
| Événement consigné · `controller.events[18].event` | BROKER_REFUSED |
| `controller.events[18].monotonic_ns` | 40081601147533 |
| Instant logique · `controller.events[18].tick` | 5 |
| Identité de l’accord · `controller.events[19].detail.args.agreement_id` | proposal-001 |
| Motif consigné · `controller.events[19].detail.args.reason` | DEPENDENCY_UNAVAILABLE |
| `controller.events[19].detail.op` | cancel |
| Événement consigné · `controller.events[19].event` | BROKER_REQUEST |
| `controller.events[19].monotonic_ns` | 40081601357080 |
| Instant logique · `controller.events[19].tick` | 6 |
| Identité de l’accord · `controller.events[20].detail.agreement_id` | proposal-001 |
| Motif consigné · `controller.events[20].detail.reason` | DEPENDENCY_UNAVAILABLE |
| Événement consigné · `controller.events[20].event` | ARRANGEMENT_CANCELLED |
| `controller.events[20].monotonic_ns` | 40081606589658 |
| Instant logique · `controller.events[20].tick` | 6 |
| `controller.events[21].detail.args` | Aucune entrée |
| `controller.events[21].detail.op` | status |
| Événement consigné · `controller.events[21].event` | BROKER_REQUEST |
| `controller.events[21].monotonic_ns` | 40081606954630 |
| Instant logique · `controller.events[21].tick` | 7 |
| `controller.events[22].detail.measurement_kind` | Mesure déclarée par le candidat (`CANDIDATE_REPORTED`) |
| `controller.events[22].detail.pid` | 82 |
| `controller.events[22].detail.report.assignment_domain` | 32 |
| `controller.events[22].detail.report.candidate_elapsed_ns` | 2345365 |
| `controller.events[22].detail.report.capacity_prunes` | 20 |
| `controller.events[22].detail.report.complete_assignments_observed` | 32 |
| `controller.events[22].detail.report.exhaustive_within_declared_domain` | Oui |
| `controller.events[22].detail.report.feasible_assignments` | 12 |
| `controller.events[22].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Procédure candidate · `controller.events[22].detail.report.method` | conventional |
| `controller.events[22].detail.report.partial_nodes_observed` | 0 |
| `controller.events[22].detail.report.participant_prunes` | 0 |
| `controller.events[22].detail.report.price_prunes` | 0 |
| Événement consigné · `controller.events[22].event` | CANDIDATE_PLANNING |
| `controller.events[22].monotonic_ns` | 40081615859780 |
| Instant logique · `controller.events[22].tick` | 7 |
| Premier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[0].last_unit` | 500 |
| Identité du lot fixe · `controller.events[23].detail.args.proposal.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `controller.events[23].detail.args.proposal.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.allocations[0].pay_minor` | 2700 |
| Identité du fournisseur · `controller.events[23].detail.args.proposal.allocations[0].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[23].detail.args.proposal.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[1].first_unit` | 501 |
| Dernier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[1].last_unit` | 1000 |
| Identité du lot fixe · `controller.events[23].detail.args.proposal.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `controller.events[23].detail.args.proposal.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[23].detail.args.proposal.allocations[1].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[23].detail.args.proposal.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[2].first_unit` | 1001 |
| Dernier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[2].last_unit` | 1100 |
| Identité du lot fixe · `controller.events[23].detail.args.proposal.allocations[2].lot_id` | DL-100.L003 |
| Identité de l’obligation · `controller.events[23].detail.args.proposal.allocations[2].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[23].detail.args.proposal.allocations[2].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[23].detail.args.proposal.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[3].last_unit` | 500 |
| Identité du lot fixe · `controller.events[23].detail.args.proposal.allocations[3].lot_id` | DL-200.L001 |
| Identité de l’obligation · `controller.events[23].detail.args.proposal.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.allocations[3].pay_minor` | 2300 |
| Identité du fournisseur · `controller.events[23].detail.args.proposal.allocations[3].provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[23].detail.args.proposal.allocations[3].window_id` | W0 |
| Premier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[4].first_unit` | 501 |
| Dernier ordinal inclus · `controller.events[23].detail.args.proposal.allocations[4].last_unit` | 800 |
| Identité du lot fixe · `controller.events[23].detail.args.proposal.allocations[4].lot_id` | DL-200.L002 |
| Identité de l’obligation · `controller.events[23].detail.args.proposal.allocations[4].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[23].detail.args.proposal.allocations[4].provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[23].detail.args.proposal.allocations[4].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.buyer_price_minor` | 5500 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `controller.events[23].detail.args.proposal.contract_sha256` | f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1 |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.coordinator_fee_minor` | 500 |
| Instant exclusif d’expiration · `controller.events[23].detail.args.proposal.expires_tick` | 500 |
| Révision des politiques · `controller.events[23].detail.args.proposal.policy_revision` | 1 |
| Identité de la proposition · `controller.events[23].detail.args.proposal.proposal_id` | proposal-002 |
| Réserve de correction (unités mineures SMU synthétiques) · `controller.events[23].detail.args.proposal.rework_budget_minor` | 2400 |
| Schéma · `controller.events[23].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[23].detail.op` | propose |
| Événement consigné · `controller.events[23].event` | BROKER_REQUEST |
| `controller.events[23].monotonic_ns` | 40081616875826 |
| Instant logique · `controller.events[23].tick` | 8 |
| Identité de la proposition · `controller.events[24].detail.args.proposal_id` | proposal-002 |
| `controller.events[24].detail.op` | decide |
| Événement consigné · `controller.events[24].event` | BROKER_REQUEST |
| `controller.events[24].monotonic_ns` | 40081622037598 |
| Instant logique · `controller.events[24].tick` | 9 |
| `controller.events[25].detail.args` | Aucune entrée |
| `controller.events[25].detail.op` | status |
| Événement consigné · `controller.events[25].event` | BROKER_REQUEST |
| `controller.events[25].monotonic_ns` | 40081626412781 |
| Instant logique · `controller.events[25].tick` | 10 |
| Identité de l’accord · `controller.events[26].detail.args.agreement_id` | proposal-002 |
| `controller.events[26].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[26].detail.args.lot_id` | DL-100.L001 |
| `controller.events[26].detail.op` | reserve |
| Événement consigné · `controller.events[26].event` | BROKER_REQUEST |
| `controller.events[26].monotonic_ns` | 40081634594789 |
| Instant logique · `controller.events[26].tick` | 11 |
| `controller.events[27].detail.key` | proposal-002.DL-100.L001.A1 |
| `controller.events[27].detail.slot` | COMPAT-A.W0 |
| État consigné · `controller.events[27].detail.status` | RESERVED |
| Événement consigné · `controller.events[27].event` | CAPACITY_RESERVED |
| `controller.events[27].monotonic_ns` | 40081643884400 |
| Instant logique · `controller.events[27].tick` | 11 |
| Identité de l’accord · `controller.events[28].detail.args.agreement_id` | proposal-002 |
| `controller.events[28].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[28].detail.args.lot_id` | DL-100.L001 |
| `controller.events[28].detail.args.supersedes` | Non consigné |
| `controller.events[28].detail.op` | produce |
| Événement consigné · `controller.events[28].event` | BROKER_REQUEST |
| `controller.events[28].monotonic_ns` | 40081644268621 |
| Instant logique · `controller.events[28].tick` | 12 |
| `controller.events[29].detail.byte_count` | 195960 |
| `controller.events[29].detail.payload_sha256` | 8b2e981858a849886d72c5a804a477d34b69eb345cac6f875ca9a44a304327ae |
| `controller.events[29].detail.production_id` | proposal-002.DL-100.L001.A1 |
| Quantité requise · `controller.events[29].detail.quantity` | 500 |
| Événement consigné · `controller.events[29].event` | PRODUCT_MATERIALIZED |
| `controller.events[29].monotonic_ns` | 40081682099503 |
| Instant logique · `controller.events[29].tick` | 12 |
| `controller.events[30].detail.args.production_id` | proposal-002.DL-100.L001.A1 |
| `controller.events[30].detail.op` | transfer |
| Événement consigné · `controller.events[30].event` | BROKER_REQUEST |
| `controller.events[30].monotonic_ns` | 40081682600059 |
| Instant logique · `controller.events[30].tick` | 13 |
| `controller.events[31].detail.byte_count` | 195960 |
| `controller.events[31].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[31].detail.produced_sha256` | 8b2e981858a849886d72c5a804a477d34b69eb345cac6f875ca9a44a304327ae |
| `controller.events[31].detail.production_id` | proposal-002.DL-100.L001.A1 |
| `controller.events[31].detail.received_sha256` | 8b2e981858a849886d72c5a804a477d34b69eb345cac6f875ca9a44a304327ae |
| Événement consigné · `controller.events[31].event` | PRODUCT_TRANSFERRED |
| `controller.events[31].monotonic_ns` | 40081692145297 |
| Instant logique · `controller.events[31].tick` | 13 |
| `controller.events[32].detail.args.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[32].detail.op` | inspect |
| Événement consigné · `controller.events[32].event` | BROKER_REQUEST |
| `controller.events[32].monotonic_ns` | 40081692465631 |
| Instant logique · `controller.events[32].tick` | 14 |
| `controller.events[33].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[33].detail.hook` | inspect.after_observation |
| Événement consigné · `controller.events[33].detail.schedule.event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.events[33].detail.schedule.occurrence` | 1 |
| Cible de la panne · `controller.events[33].detail.schedule.target` | ANY |
| Opération déclenchante · `controller.events[33].detail.schedule.trigger` | inspect |
| Valeur configurée · `controller.events[33].detail.schedule.value` | 0 |
| Événement consigné · `controller.events[33].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| `controller.events[33].monotonic_ns` | 40081730044932 |
| Instant logique · `controller.events[33].tick` | 14 |
| `controller.events[34].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[34].detail.hook` | inspect.after_observation |
| Événement consigné · `controller.events[34].detail.schedule.event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.events[34].detail.schedule.occurrence` | 1 |
| Cible de la panne · `controller.events[34].detail.schedule.target` | ANY |
| Opération déclenchante · `controller.events[34].detail.schedule.trigger` | inspect |
| Valeur configurée · `controller.events[34].detail.schedule.value` | 0 |
| Événement consigné · `controller.events[34].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| `controller.events[34].monotonic_ns` | 40081730053005 |
| Instant logique · `controller.events[34].tick` | 14 |
| `controller.events[35].detail.pid` | 77 |
| `controller.events[35].detail.service` | receiver |
| Événement consigné · `controller.events[35].event` | SERVICE_TERMINATED |
| `controller.events[35].monotonic_ns` | 40081731229583 |
| Instant logique · `controller.events[35].tick` | 14 |
| `controller.events[36].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[36].detail.pid` | 82 |
| Événement consigné · `controller.events[36].event` | CANDIDATE_TERMINATED |
| `controller.events[36].monotonic_ns` | 40081732396547 |
| Instant logique · `controller.events[36].tick` | 14 |
| `controller.events[37].detail.pid` | 83 |
| `controller.events[37].detail.restart` | Oui |
| `controller.events[37].detail.service` | receiver |
| Événement consigné · `controller.events[37].event` | SERVICE_STARTED |
| `controller.events[37].monotonic_ns` | 40081767236338 |
| Instant logique · `controller.events[37].tick` | 14 |
| `controller.events[38].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| Événement consigné · `controller.events[38].event` | ACKNOWLEDGMENT_UNCERTAIN |
| `controller.events[38].monotonic_ns` | 40081767245682 |
| Instant logique · `controller.events[38].tick` | 14 |
| `controller.events[39].detail.isolation.applied` | Oui |
| `controller.events[39].detail.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.events[39].detail.isolation.probe.authority_open_denied` | Oui |
| `controller.events[39].detail.isolation.probe.network_denied` | Oui |
| `controller.events[39].detail.isolation.probe.process_inspection_denied` | Oui |
| `controller.events[39].detail.isolation.probe.spawn_denied` | Oui |
| `controller.events[39].detail.isolation.probe.workspace_open_denied` | Oui |
| `controller.events[39].detail.pid` | 84 |
| `controller.events[39].detail.restart` | Oui |
| Événement consigné · `controller.events[39].event` | CANDIDATE_STARTED |
| `controller.events[39].monotonic_ns` | 40081805560796 |
| Instant logique · `controller.events[39].tick` | 15 |
| `controller.events[40].detail.args` | Aucune entrée |
| `controller.events[40].detail.op` | status |
| Événement consigné · `controller.events[40].event` | BROKER_REQUEST |
| `controller.events[40].monotonic_ns` | 40081807136467 |
| Instant logique · `controller.events[40].tick` | 16 |
| `controller.events[41].detail.args` | Aucune entrée |
| `controller.events[41].detail.op` | status |
| Événement consigné · `controller.events[41].event` | BROKER_REQUEST |
| `controller.events[41].monotonic_ns` | 40081814989708 |
| Instant logique · `controller.events[41].tick` | 17 |
| `controller.events[42].detail.args` | Aucune entrée |
| `controller.events[42].detail.op` | status |
| Événement consigné · `controller.events[42].event` | BROKER_REQUEST |
| `controller.events[42].monotonic_ns` | 40081822668484 |
| Instant logique · `controller.events[42].tick` | 18 |
| Identité de l’accord · `controller.events[43].detail.args.agreement_id` | proposal-002 |
| `controller.events[43].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[43].detail.args.lot_id` | DL-100.L002 |
| `controller.events[43].detail.op` | reserve |
| Événement consigné · `controller.events[43].event` | BROKER_REQUEST |
| `controller.events[43].monotonic_ns` | 40081829118073 |
| Instant logique · `controller.events[43].tick` | 19 |
| `controller.events[44].detail.key` | proposal-002.DL-100.L002.A1 |
| `controller.events[44].detail.slot` | COMPAT-A.W0 |
| État consigné · `controller.events[44].detail.status` | RESERVED |
| Événement consigné · `controller.events[44].event` | CAPACITY_RESERVED |
| `controller.events[44].monotonic_ns` | 40081841107245 |
| Instant logique · `controller.events[44].tick` | 19 |
| Identité de l’accord · `controller.events[45].detail.args.agreement_id` | proposal-002 |
| `controller.events[45].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[45].detail.args.lot_id` | DL-100.L002 |
| `controller.events[45].detail.args.supersedes` | Non consigné |
| `controller.events[45].detail.op` | produce |
| Événement consigné · `controller.events[45].event` | BROKER_REQUEST |
| `controller.events[45].monotonic_ns` | 40081841588292 |
| Instant logique · `controller.events[45].tick` | 20 |
| `controller.events[46].detail.byte_count` | 196072 |
| `controller.events[46].detail.payload_sha256` | 2e63a949e801d0e6be8a30ba8f2b0865827f6bd6886001ffc580419e4b6b6709 |
| `controller.events[46].detail.production_id` | proposal-002.DL-100.L002.A1 |
| Quantité requise · `controller.events[46].detail.quantity` | 500 |
| Événement consigné · `controller.events[46].event` | PRODUCT_MATERIALIZED |
| `controller.events[46].monotonic_ns` | 40081879525044 |
| Instant logique · `controller.events[46].tick` | 20 |
| `controller.events[47].detail.args.production_id` | proposal-002.DL-100.L002.A1 |
| `controller.events[47].detail.op` | transfer |
| Événement consigné · `controller.events[47].event` | BROKER_REQUEST |
| `controller.events[47].monotonic_ns` | 40081880087364 |
| Instant logique · `controller.events[47].tick` | 21 |
| `controller.events[48].detail.byte_count` | 196072 |
| `controller.events[48].detail.delivery_id` | proposal-002.DL-100.L002.A1.D |
| `controller.events[48].detail.produced_sha256` | 2e63a949e801d0e6be8a30ba8f2b0865827f6bd6886001ffc580419e4b6b6709 |
| `controller.events[48].detail.production_id` | proposal-002.DL-100.L002.A1 |
| `controller.events[48].detail.received_sha256` | 2e63a949e801d0e6be8a30ba8f2b0865827f6bd6886001ffc580419e4b6b6709 |
| Événement consigné · `controller.events[48].event` | PRODUCT_TRANSFERRED |
| `controller.events[48].monotonic_ns` | 40081889233939 |
| Instant logique · `controller.events[48].tick` | 21 |
| `controller.events[49].detail.args.delivery_id` | proposal-002.DL-100.L002.A1.D |
| `controller.events[49].detail.op` | inspect |
| Événement consigné · `controller.events[49].event` | BROKER_REQUEST |
| `controller.events[49].monotonic_ns` | 40081889542024 |
| Instant logique · `controller.events[49].tick` | 22 |
| `controller.events[50].detail.accepted_units` | 500 |
| `controller.events[50].detail.delivery_id` | proposal-002.DL-100.L002.A1.D |
| État consigné · `controller.events[50].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[50].detail.timely` | Oui |
| Événement consigné · `controller.events[50].event` | RECIPIENT_INSPECTED |
| `controller.events[50].monotonic_ns` | 40081925545264 |
| Instant logique · `controller.events[50].tick` | 22 |
| `controller.events[51].detail.args` | Aucune entrée |
| `controller.events[51].detail.op` | status |
| Événement consigné · `controller.events[51].event` | BROKER_REQUEST |
| `controller.events[51].monotonic_ns` | 40081926041624 |
| Instant logique · `controller.events[51].tick` | 23 |
| Identité de l’accord · `controller.events[52].detail.args.agreement_id` | proposal-002 |
| `controller.events[52].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[52].detail.args.lot_id` | DL-100.L003 |
| `controller.events[52].detail.op` | reserve |
| Événement consigné · `controller.events[52].event` | BROKER_REQUEST |
| `controller.events[52].monotonic_ns` | 40081935691380 |
| Instant logique · `controller.events[52].tick` | 24 |
| `controller.events[53].detail.key` | proposal-002.DL-100.L003.A1 |
| `controller.events[53].detail.slot` | COMPAT-A.W0 |
| État consigné · `controller.events[53].detail.status` | RESERVED |
| Événement consigné · `controller.events[53].event` | CAPACITY_RESERVED |
| `controller.events[53].monotonic_ns` | 40081947152754 |
| Instant logique · `controller.events[53].tick` | 24 |
| Identité de l’accord · `controller.events[54].detail.args.agreement_id` | proposal-002 |
| `controller.events[54].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[54].detail.args.lot_id` | DL-100.L003 |
| `controller.events[54].detail.args.supersedes` | Non consigné |
| `controller.events[54].detail.op` | produce |
| Événement consigné · `controller.events[54].event` | BROKER_REQUEST |
| `controller.events[54].monotonic_ns` | 40081947562363 |
| Instant logique · `controller.events[54].tick` | 25 |
| `controller.events[55].detail.byte_count` | 39772 |
| `controller.events[55].detail.payload_sha256` | 0441a60722a81619d368744c6724e3c089fd7ae9c5fdcefdfcf868acafc2518a |
| `controller.events[55].detail.production_id` | proposal-002.DL-100.L003.A1 |
| Quantité requise · `controller.events[55].detail.quantity` | 100 |
| Événement consigné · `controller.events[55].event` | PRODUCT_MATERIALIZED |
| `controller.events[55].monotonic_ns` | 40081975843370 |
| Instant logique · `controller.events[55].tick` | 25 |
| `controller.events[56].detail.args.production_id` | proposal-002.DL-100.L003.A1 |
| `controller.events[56].detail.op` | transfer |
| Événement consigné · `controller.events[56].event` | BROKER_REQUEST |
| `controller.events[56].monotonic_ns` | 40081976343356 |
| Instant logique · `controller.events[56].tick` | 26 |
| `controller.events[57].detail.byte_count` | 39772 |
| `controller.events[57].detail.delivery_id` | proposal-002.DL-100.L003.A1.D |
| `controller.events[57].detail.produced_sha256` | 0441a60722a81619d368744c6724e3c089fd7ae9c5fdcefdfcf868acafc2518a |
| `controller.events[57].detail.production_id` | proposal-002.DL-100.L003.A1 |
| `controller.events[57].detail.received_sha256` | 0441a60722a81619d368744c6724e3c089fd7ae9c5fdcefdfcf868acafc2518a |
| Événement consigné · `controller.events[57].event` | PRODUCT_TRANSFERRED |
| `controller.events[57].monotonic_ns` | 40081989484844 |
| Instant logique · `controller.events[57].tick` | 26 |
| `controller.events[58].detail.args.delivery_id` | proposal-002.DL-100.L003.A1.D |
| `controller.events[58].detail.op` | inspect |
| Événement consigné · `controller.events[58].event` | BROKER_REQUEST |
| `controller.events[58].monotonic_ns` | 40081989822355 |
| Instant logique · `controller.events[58].tick` | 27 |
| `controller.events[59].detail.accepted_units` | 100 |
| `controller.events[59].detail.delivery_id` | proposal-002.DL-100.L003.A1.D |
| État consigné · `controller.events[59].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[59].detail.timely` | Oui |
| Événement consigné · `controller.events[59].event` | RECIPIENT_INSPECTED |
| `controller.events[59].monotonic_ns` | 40082000515718 |
| Instant logique · `controller.events[59].tick` | 27 |
| `controller.events[60].detail.args` | Aucune entrée |
| `controller.events[60].detail.op` | status |
| Événement consigné · `controller.events[60].event` | BROKER_REQUEST |
| `controller.events[60].monotonic_ns` | 40082001053551 |
| Instant logique · `controller.events[60].tick` | 28 |
| Identité de l’accord · `controller.events[61].detail.args.agreement_id` | proposal-002 |
| `controller.events[61].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[61].detail.args.lot_id` | DL-200.L001 |
| `controller.events[61].detail.op` | reserve |
| Événement consigné · `controller.events[61].event` | BROKER_REQUEST |
| `controller.events[61].monotonic_ns` | 40082009711778 |
| Instant logique · `controller.events[61].tick` | 29 |
| `controller.events[62].detail.key` | proposal-002.DL-200.L001.A1 |
| `controller.events[62].detail.slot` | COMPAT-B.W0 |
| État consigné · `controller.events[62].detail.status` | RESERVED |
| Événement consigné · `controller.events[62].event` | CAPACITY_RESERVED |
| `controller.events[62].monotonic_ns` | 40082017792542 |
| Instant logique · `controller.events[62].tick` | 29 |
| Identité de l’accord · `controller.events[63].detail.args.agreement_id` | proposal-002 |
| `controller.events[63].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[63].detail.args.lot_id` | DL-200.L001 |
| `controller.events[63].detail.args.supersedes` | Non consigné |
| `controller.events[63].detail.op` | produce |
| Événement consigné · `controller.events[63].event` | BROKER_REQUEST |
| `controller.events[63].monotonic_ns` | 40082018161510 |
| Instant logique · `controller.events[63].tick` | 30 |
| `controller.events[64].detail.byte_count` | 195960 |
| `controller.events[64].detail.payload_sha256` | 465cacbd8119033bdcc2f3b7011489bedbac51510cd46ce8bae8de45fe96ca83 |
| `controller.events[64].detail.production_id` | proposal-002.DL-200.L001.A1 |
| Quantité requise · `controller.events[64].detail.quantity` | 500 |
| Événement consigné · `controller.events[64].event` | PRODUCT_MATERIALIZED |
| `controller.events[64].monotonic_ns` | 40082047212430 |
| Instant logique · `controller.events[64].tick` | 30 |
| `controller.events[65].detail.args.production_id` | proposal-002.DL-200.L001.A1 |
| `controller.events[65].detail.op` | transfer |
| Événement consigné · `controller.events[65].event` | BROKER_REQUEST |
| `controller.events[65].monotonic_ns` | 40082047653527 |
| Instant logique · `controller.events[65].tick` | 31 |
| `controller.events[66].detail.byte_count` | 195960 |
| `controller.events[66].detail.delivery_id` | proposal-002.DL-200.L001.A1.D |
| `controller.events[66].detail.produced_sha256` | 465cacbd8119033bdcc2f3b7011489bedbac51510cd46ce8bae8de45fe96ca83 |
| `controller.events[66].detail.production_id` | proposal-002.DL-200.L001.A1 |
| `controller.events[66].detail.received_sha256` | 465cacbd8119033bdcc2f3b7011489bedbac51510cd46ce8bae8de45fe96ca83 |
| Événement consigné · `controller.events[66].event` | PRODUCT_TRANSFERRED |
| `controller.events[66].monotonic_ns` | 40082058001469 |
| Instant logique · `controller.events[66].tick` | 31 |
| `controller.events[67].detail.args.delivery_id` | proposal-002.DL-200.L001.A1.D |
| `controller.events[67].detail.op` | inspect |
| Événement consigné · `controller.events[67].event` | BROKER_REQUEST |
| `controller.events[67].monotonic_ns` | 40082058311658 |
| Instant logique · `controller.events[67].tick` | 32 |
| `controller.events[68].detail.accepted_units` | 500 |
| `controller.events[68].detail.delivery_id` | proposal-002.DL-200.L001.A1.D |
| État consigné · `controller.events[68].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[68].detail.timely` | Oui |
| Événement consigné · `controller.events[68].event` | RECIPIENT_INSPECTED |
| `controller.events[68].monotonic_ns` | 40082093353213 |
| Instant logique · `controller.events[68].tick` | 32 |
| `controller.events[69].detail.args` | Aucune entrée |
| `controller.events[69].detail.op` | status |
| Événement consigné · `controller.events[69].event` | BROKER_REQUEST |
| `controller.events[69].monotonic_ns` | 40082093771726 |
| Instant logique · `controller.events[69].tick` | 33 |
| Identité de l’accord · `controller.events[70].detail.args.agreement_id` | proposal-002 |
| `controller.events[70].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[70].detail.args.lot_id` | DL-200.L002 |
| `controller.events[70].detail.op` | reserve |
| Événement consigné · `controller.events[70].event` | BROKER_REQUEST |
| `controller.events[70].monotonic_ns` | 40082104103943 |
| Instant logique · `controller.events[70].tick` | 34 |
| `controller.events[71].detail.key` | proposal-002.DL-200.L002.A1 |
| `controller.events[71].detail.slot` | COMPAT-B.W0 |
| État consigné · `controller.events[71].detail.status` | RESERVED |
| Événement consigné · `controller.events[71].event` | CAPACITY_RESERVED |
| `controller.events[71].monotonic_ns` | 40082112914891 |
| Instant logique · `controller.events[71].tick` | 34 |
| Identité de l’accord · `controller.events[72].detail.args.agreement_id` | proposal-002 |
| `controller.events[72].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[72].detail.args.lot_id` | DL-200.L002 |
| `controller.events[72].detail.args.supersedes` | Non consigné |
| `controller.events[72].detail.op` | produce |
| Événement consigné · `controller.events[72].event` | BROKER_REQUEST |
| `controller.events[72].monotonic_ns` | 40082113241394 |
| Instant logique · `controller.events[72].tick` | 35 |
| `controller.events[73].detail.byte_count` | 117870 |
| `controller.events[73].detail.payload_sha256` | e630c235085dbdb18af91f8171e5f73e37acaa9a538f097fdf10778cde9840dc |
| `controller.events[73].detail.production_id` | proposal-002.DL-200.L002.A1 |
| Quantité requise · `controller.events[73].detail.quantity` | 300 |
| Événement consigné · `controller.events[73].event` | PRODUCT_MATERIALIZED |
| `controller.events[73].monotonic_ns` | 40082136714189 |
| Instant logique · `controller.events[73].tick` | 35 |
| `controller.events[74].detail.args.production_id` | proposal-002.DL-200.L002.A1 |
| `controller.events[74].detail.op` | transfer |
| Événement consigné · `controller.events[74].event` | BROKER_REQUEST |
| `controller.events[74].monotonic_ns` | 40082137109776 |
| Instant logique · `controller.events[74].tick` | 36 |
| `controller.events[75].detail.byte_count` | 117870 |
| `controller.events[75].detail.delivery_id` | proposal-002.DL-200.L002.A1.D |
| `controller.events[75].detail.produced_sha256` | e630c235085dbdb18af91f8171e5f73e37acaa9a538f097fdf10778cde9840dc |
| `controller.events[75].detail.production_id` | proposal-002.DL-200.L002.A1 |
| `controller.events[75].detail.received_sha256` | e630c235085dbdb18af91f8171e5f73e37acaa9a538f097fdf10778cde9840dc |
| Événement consigné · `controller.events[75].event` | PRODUCT_TRANSFERRED |
| `controller.events[75].monotonic_ns` | 40082144628861 |
| Instant logique · `controller.events[75].tick` | 36 |
| `controller.events[76].detail.args.delivery_id` | proposal-002.DL-200.L002.A1.D |
| `controller.events[76].detail.op` | inspect |
| Événement consigné · `controller.events[76].event` | BROKER_REQUEST |
| `controller.events[76].monotonic_ns` | 40082144929946 |
| Instant logique · `controller.events[76].tick` | 37 |
| `controller.events[77].detail.accepted_units` | 300 |
| `controller.events[77].detail.delivery_id` | proposal-002.DL-200.L002.A1.D |
| État consigné · `controller.events[77].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[77].detail.timely` | Oui |
| Événement consigné · `controller.events[77].event` | RECIPIENT_INSPECTED |
| `controller.events[77].monotonic_ns` | 40082166712571 |
| Instant logique · `controller.events[77].tick` | 37 |
| Identité de l’accord · `controller.events[78].detail.args.agreement_id` | proposal-002 |
| `controller.events[78].detail.op` | settle |
| Événement consigné · `controller.events[78].event` | BROKER_REQUEST |
| `controller.events[78].monotonic_ns` | 40082167181129 |
| Instant logique · `controller.events[78].tick` | 38 |
| Références d’acceptation · `controller.events[79].detail.acceptance_ids[0]` | proposal-002.DL-100.L001.A1.D |
| Références d’acceptation · `controller.events[79].detail.acceptance_ids[1]` | proposal-002.DL-100.L002.A1.D |
| Références d’acceptation · `controller.events[79].detail.acceptance_ids[2]` | proposal-002.DL-100.L003.A1.D |
| Références d’acceptation · `controller.events[79].detail.acceptance_ids[3]` | proposal-002.DL-200.L001.A1.D |
| Références d’acceptation · `controller.events[79].detail.acceptance_ids[4]` | proposal-002.DL-200.L002.A1.D |
| Identité de l’accord · `controller.events[79].detail.agreement_id` | proposal-002 |
| Événement consigné · `controller.events[79].event` | ARRANGEMENT_SETTLED |
| `controller.events[79].monotonic_ns` | 40082173457606 |
| Instant logique · `controller.events[79].tick` | 38 |
| Interventions consignées · `controller.events[80].detail.interventions` | Aucune entrée |
| Motif consigné · `controller.events[80].detail.reason` | DIGITAL_PRODUCT_ACCEPTED |
| `controller.events[80].detail.searches` | Aucune entrée |
| Verdict du composant · `controller.events[80].detail.verdict` | Réalisé (`COMPLETED`) |
| Événement consigné · `controller.events[80].event` | CANDIDATE_DONE |
| `controller.events[80].monotonic_ns` | 40082174266920 |
| Instant logique · `controller.events[80].tick` | 38 |
| `controller.events[81].detail.database` | participants |
| `controller.events[81].detail.sqlite[0]` | 0 |
| `controller.events[81].detail.sqlite[1]` | 0 |
| `controller.events[81].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[81].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[81].event` | DATABASE_CHECKPOINT |
| `controller.events[81].monotonic_ns` | 40082208428561 |
| Instant logique · `controller.events[81].tick` | 38 |
| `controller.events[82].detail.database` | producer |
| `controller.events[82].detail.sqlite[0]` | 0 |
| `controller.events[82].detail.sqlite[1]` | 0 |
| `controller.events[82].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[82].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[82].event` | DATABASE_CHECKPOINT |
| `controller.events[82].monotonic_ns` | 40082210472470 |
| Instant logique · `controller.events[82].tick` | 38 |
| `controller.events[83].detail.database` | receiver |
| `controller.events[83].detail.sqlite[0]` | 0 |
| `controller.events[83].detail.sqlite[1]` | 0 |
| `controller.events[83].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[83].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[83].event` | DATABASE_CHECKPOINT |
| `controller.events[83].monotonic_ns` | 40082213268657 |
| Instant logique · `controller.events[83].tick` | 38 |
| `controller.events[84].detail.database` | PRIMARY.W0 |
| `controller.events[84].detail.sqlite[0]` | 0 |
| `controller.events[84].detail.sqlite[1]` | 0 |
| `controller.events[84].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[84].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[84].event` | DATABASE_CHECKPOINT |
| `controller.events[84].monotonic_ns` | 40082214302650 |
| Instant logique · `controller.events[84].tick` | 38 |
| `controller.events[85].detail.database` | BACKUP.W0 |
| `controller.events[85].detail.sqlite[0]` | 0 |
| `controller.events[85].detail.sqlite[1]` | 0 |
| `controller.events[85].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[85].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[85].event` | DATABASE_CHECKPOINT |
| `controller.events[85].monotonic_ns` | 40082220600029 |
| Instant logique · `controller.events[85].tick` | 38 |
| `controller.events[86].detail.database` | COMPAT-A.W0 |
| `controller.events[86].detail.sqlite[0]` | 0 |
| `controller.events[86].detail.sqlite[1]` | 0 |
| `controller.events[86].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[86].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[86].event` | DATABASE_CHECKPOINT |
| `controller.events[86].monotonic_ns` | 40082225165569 |
| Instant logique · `controller.events[86].tick` | 38 |
| `controller.events[87].detail.database` | COMPAT-B.W0 |
| `controller.events[87].detail.sqlite[0]` | 0 |
| `controller.events[87].detail.sqlite[1]` | 0 |
| `controller.events[87].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[87].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[87].event` | DATABASE_CHECKPOINT |
| `controller.events[87].monotonic_ns` | 40082226180132 |
| Instant logique · `controller.events[87].tick` | 38 |
| Code stable · `controller.events[88].detail.code` | DATABASE_STATE_CHANGED |
| `controller.events[88].detail.detail` | DATABASE_STATE_CHANGED: /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1/base/runs/constructed-continuity.conventional/runtime/capacity/COMPAT-A.W0.sqlite |
| `controller.events[88].detail.message` | Le contenu durable de la base a changé après son instantané conservé. |
| Événement consigné · `controller.events[88].event` | EXECUTION_ERROR |
| `controller.events[88].monotonic_ns` | 40082369122155 |
| Instant logique · `controller.events[88].tick` | 38 |
| Événement consigné · `controller.fault_schedule[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `controller.fault_schedule[0].occurrence` | 1 |
| Cible de la panne · `controller.fault_schedule[0].target` | BACKUP |
| Opération déclenchante · `controller.fault_schedule[0].trigger` | reserve |
| Valeur configurée · `controller.fault_schedule[0].value` | 0 |
| Événement consigné · `controller.fault_schedule[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.fault_schedule[1].occurrence` | 1 |
| Cible de la panne · `controller.fault_schedule[1].target` | ANY |
| Opération déclenchante · `controller.fault_schedule[1].trigger` | inspect |
| Valeur configurée · `controller.fault_schedule[1].value` | 0 |
| Événement consigné · `controller.fault_schedule[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.fault_schedule[2].occurrence` | 1 |
| Cible de la panne · `controller.fault_schedule[2].target` | ANY |
| Opération déclenchante · `controller.fault_schedule[2].trigger` | inspect |
| Valeur configurée · `controller.fault_schedule[2].value` | 0 |
| Événement consigné · `controller.faults_observed[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `controller.faults_observed[0].occurrence` | 1 |
| Cible de la panne · `controller.faults_observed[0].target` | BACKUP |
| Opération déclenchante · `controller.faults_observed[0].trigger` | reserve |
| Valeur configurée · `controller.faults_observed[0].value` | 0 |
| Événement consigné · `controller.faults_observed[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.faults_observed[1].occurrence` | 1 |
| Cible de la panne · `controller.faults_observed[1].target` | ANY |
| Opération déclenchante · `controller.faults_observed[1].trigger` | inspect |
| Valeur configurée · `controller.faults_observed[1].value` | 0 |
| Événement consigné · `controller.faults_observed[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.faults_observed[2].occurrence` | 1 |
| Cible de la panne · `controller.faults_observed[2].target` | ANY |
| Opération déclenchante · `controller.faults_observed[2].trigger` | inspect |
| Valeur configurée · `controller.faults_observed[2].value` | 0 |
| `controller.finished_monotonic_ns` | 40082369125981 |
| Identité du cas préenregistré · `controller.fixture_id` | constructed-continuity |
| Modifications sources non consignées présentes · `controller.implementation.dirty` | Non |
| Arguments exacts du processus · `controller.implementation.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Arguments exacts du processus · `controller.implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `controller.implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `controller.implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `controller.implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `controller.implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `controller.implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `controller.implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Plateforme d’exécution · `controller.implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `controller.implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `controller.implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `controller.implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `controller.implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Oui |
| `controller.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Oui |
| `controller.isolation.probe.network_denied` | Oui |
| `controller.isolation.probe.process_inspection_denied` | Oui |
| `controller.isolation.probe.spawn_denied` | Oui |
| `controller.isolation.probe.workspace_open_denied` | Oui |
| Procédure candidate · `controller.method` | conventional |
| `controller.policies_sha256` | fc701f004c83a9d4a45bc185a65c39b19b509d3ee059c10de93650513f48fae4 |
| Travail d’adaptation (secondes ; inconnu si absent) · `controller.resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `controller.resources.authority_storage_bytes_before_seal` | 30468 |
| Redémarrages du candidat · `controller.resources.candidate_restarts` | 1 |
| Processus enfants lancés · `controller.resources.child_processes` | 10 |
| Processeur système du contrôleur (ns) · `controller.resources.controller_cpu_system_ns` | 37726999 |
| Processeur utilisateur du contrôleur (ns) · `controller.resources.controller_cpu_user_ns` | 163732000 |
| Processeur système (ns) · `controller.resources.cpu_system_ns` | 99530000 |
| Processeur utilisateur (ns) · `controller.resources.cpu_user_ns` | 694082000 |
| Interventions humaines · `controller.resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `controller.resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `controller.resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `controller.resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `controller.resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `controller.resources.requests` | 37 |
| Nouvelles tentatives · `controller.resources.retries` | 0 |
| Requêtes internes aux services · `controller.resources.service_requests` | 180 |
| Stockage consigné (octets) · `controller.resources.storage_bytes` | 8476603 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `controller.resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `controller.resources.wall_ns` | 1184171770 |
| Redémarrages des services · `controller.resources.worker_restarts` | 1 |
| Identité de l’exécution · `controller.run_id` | constructed-continuity.conventional.f189246caf |
| Schéma · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 40081184954211 |
| `controller.started_utc` | 2026-11-07T00:44:43.300100+00:00 |
| `controller.state` | Erreur d’exécution (`ERROR`) |
| Verdict du composant · `controller.target_verdict` | Erreur d’exécution (`ERROR`) |
| Événement consigné · `fault_schedule[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `fault_schedule[0].occurrence` | 1 |
| Cible de la panne · `fault_schedule[0].target` | BACKUP |
| Opération déclenchante · `fault_schedule[0].trigger` | reserve |
| Valeur configurée · `fault_schedule[0].value` | 0 |
| Événement consigné · `fault_schedule[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `fault_schedule[1].occurrence` | 1 |
| Cible de la panne · `fault_schedule[1].target` | ANY |
| Opération déclenchante · `fault_schedule[1].trigger` | inspect |
| Valeur configurée · `fault_schedule[1].value` | 0 |
| Événement consigné · `fault_schedule[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `fault_schedule[2].occurrence` | 1 |
| Cible de la panne · `fault_schedule[2].target` | ANY |
| Opération déclenchante · `fault_schedule[2].trigger` | inspect |
| Valeur configurée · `fault_schedule[2].value` | 0 |
| Événement consigné · `faults_observed[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `faults_observed[0].occurrence` | 1 |
| Cible de la panne · `faults_observed[0].target` | BACKUP |
| Opération déclenchante · `faults_observed[0].trigger` | reserve |
| Valeur configurée · `faults_observed[0].value` | 0 |
| Événement consigné · `faults_observed[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `faults_observed[1].occurrence` | 1 |
| Cible de la panne · `faults_observed[1].target` | ANY |
| Opération déclenchante · `faults_observed[1].trigger` | inspect |
| Valeur configurée · `faults_observed[1].value` | 0 |
| Événement consigné · `faults_observed[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `faults_observed[2].occurrence` | 1 |
| Cible de la panne · `faults_observed[2].target` | ANY |
| Opération déclenchante · `faults_observed[2].trigger` | inspect |
| Valeur configurée · `faults_observed[2].value` | 0 |
| Identité du cas préenregistré · `fixture_id` | constructed-continuity |
| Modifications sources non consignées présentes · `implementation.dirty` | Non |
| Arguments exacts du processus · `implementation.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Arguments exacts du processus · `implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Plateforme d’exécution · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `implementation.version` | 0.2.0 |
| Procédure candidate · `method` | conventional |
| Solde (unités mineures SMU synthétiques) · `policies.buyer.balance_minor` | 30000 |
| `policies.buyer.consent_until_tick` | 800 |
| `policies.buyer.max_price_minor` | 25000 |
| Utilité d’option externe définie (unités mineures SMU synthétiques) · `policies.buyer.outside_utility_minor` | 2000 |
| Identité du participant · `policies.buyer.party_id` | BUYER |
| Borne supérieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_max_minor` | 30000 |
| Borne inférieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_min_minor` | 30000 |
| Solde (unités mineures SMU synthétiques) · `policies.coordinator.balance_minor` | 10000 |
| `policies.coordinator.consent_until_tick` | 800 |
| `policies.coordinator.liability_limit_minor` | 10000 |
| `policies.coordinator.min_profit_minor` | 100 |
| `policies.coordinator.operating_cost_minor` | 200 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.coordinator.outside_profit_minor` | 100 |
| Identité du participant · `policies.coordinator.party_id` | COORDINATOR |
| `policies.coordinator.technical_control_allowed` | Oui |
| Unité de compte synthétique · `policies.currency` | SMU |
| Solde (unités mineures SMU synthétiques) · `policies.providers[0].balance_minor` | 40000 |
| `policies.providers[0].consent_until_tick` | 800 |
| `policies.providers[0].liability_limit_minor` | 40000 |
| `policies.providers[0].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[0].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[0].party_id` | PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 100 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 100 |
| `policies.providers[0].technical_control_allowed` | Oui |
| `policies.providers[0].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[1].balance_minor` | 40000 |
| `policies.providers[1].consent_until_tick` | 800 |
| `policies.providers[1].liability_limit_minor` | 40000 |
| `policies.providers[1].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[1].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[1].party_id` | BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 150 |
| `policies.providers[1].rework_unit_cost_minor` | 1 |
| `policies.providers[1].setup_cost_minor` | 150 |
| `policies.providers[1].technical_control_allowed` | Oui |
| `policies.providers[1].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[2].balance_minor` | 40000 |
| `policies.providers[2].consent_until_tick` | 800 |
| `policies.providers[2].liability_limit_minor` | 40000 |
| `policies.providers[2].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[2].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[2].party_id` | COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 200 |
| `policies.providers[2].rework_unit_cost_minor` | 1 |
| `policies.providers[2].setup_cost_minor` | 200 |
| `policies.providers[2].technical_control_allowed` | Oui |
| `policies.providers[2].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[3].balance_minor` | 40000 |
| `policies.providers[3].consent_until_tick` | 800 |
| `policies.providers[3].liability_limit_minor` | 40000 |
| `policies.providers[3].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[3].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[3].party_id` | COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 300 |
| `policies.providers[3].rework_unit_cost_minor` | 1 |
| `policies.providers[3].setup_cost_minor` | 300 |
| `policies.providers[3].technical_control_allowed` | Oui |
| `policies.providers[3].unit_cost_minor` | 1 |
| Révision · `policies.revision` | 1 |
| Schéma · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Oui |
| Solde (unités mineures SMU synthétiques) · `policies.technical_sponsor.balance_minor` | 60000 |
| Identité du participant · `policies.technical_sponsor.party_id` | TECHNICAL-SPONSOR |
| Empreinte externe de référence · `reference_sha256` | 3515001b3305413676901422f8c6395fa915673f7d62833397fab94b9680718a |
| `registered_assertion.expected.accepted_units` | 1900 |
| Résultat · `registered_assertion.expected.outcome` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `registered_assertion.expected.service_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `registered_assertion.observed.accepted_units` | 0 |
| Résultat · `registered_assertion.observed.outcome` | Non établi (`NOT_ESTABLISHED`) |
| `registered_assertion.observed.service_feasibility` | Non établi (`NOT_ESTABLISHED`) |
| Portée de l’évaluation · `registered_assertion.scope` | Assertion d’évaluation préenregistrée ; elle n’affirme ni résultat favorable ni transaction acceptable. |
| État consigné · `registered_assertion.status` | Échec (`FAILED`) |
| Modifications sources non consignées présentes · `source_version.dirty` | Non |
| Arguments exacts du processus · `source_version.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Arguments exacts du processus · `source_version.environment.argv[1]` | -m |
| Arguments exacts du processus · `source_version.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `source_version.environment.argv[3]` | --language |
| Arguments exacts du processus · `source_version.environment.argv[4]` | en |
| Arguments exacts du processus · `source_version.environment.argv[5]` | experiment |
| Arguments exacts du processus · `source_version.environment.argv[6]` | --out |
| Arguments exacts du processus · `source_version.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Plateforme d’exécution · `source_version.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `source_version.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `source_version.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `source_version.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `source_version.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `source_version.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `source_version.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `source_version.version` | 0.2.0 |
| Hypothèses de confiance explicites · `trust_assumptions[0]` | Hôte, noyau, contrôleur et horloge de confiance (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Hypothèses de confiance explicites · `trust_assumptions[1]` | Autorité synthétique conservée de confiance (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Hypothèses de confiance explicites · `trust_assumptions[2]` | Auteur commun ; aucune certification par un tiers (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Hypothèses de confiance explicites · `trust_assumptions[3]` | Contenu numérique sémantique uniquement ; livraison physique non éprouvée (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Pannes préenregistrées non déclenchées · `untriggered_faults` | Aucune entrée |

## Enregistrement structuré complet de vérification

Le même enregistrement structuré génère les deux versions linguistiques. Les clés machine, codes d’état et valeurs littérales des preuves restent inchangés ; les sections localisées ci-dessus expliquent leur sens. Aucun résultat sauvegardé n’est réutilisé comme preuve fraîche.

```json
{
  "accounting": {},
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "NOT_ESTABLISHED",
    "evidence_stage": "VERIFICATION_ATTEMPT",
    "target_verdict": "ERROR",
    "test_assertion": "FAILED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "NOT_ESTABLISHED",
    "service_feasibility": "NOT_ESTABLISHED"
  },
  "cohort": "base",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1",
  "evidence_sha256": {
    "evidence/capacity/BACKUP.W0.sqlite": "7a7ac2e80dde7705f93dc901ee9edb8397b9590215fcaf923ed09aadf5e6a451",
    "evidence/capacity/COMPAT-A.W0.closing": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "evidence/capacity/PRIMARY.W0.sqlite": "017cbc7ba188053893d674c36ec6eb4612ecf73f6878aed769cd286a6b751db8",
    "evidence/participants.sqlite": "c22d2cb5ec0be6b97a98254830f9449870ff0fcd1c6892986a7ed659727ee044",
    "evidence/producer.sqlite": "436abecf8e4d3a4f0beb7c022ebfaf4774ef30592b497474c849d5e73745442b",
    "evidence/receiver.sqlite": "a924e23206c1be61bc93278c5404c51d69242b912b74ac31f1c381299c5e13cf"
  },
  "failures": [],
  "fault_schedule": [
    {
      "event": "BACKUP_FAIL_BEFORE_RESERVE",
      "occurrence": 1,
      "target": "BACKUP",
      "trigger": "reserve",
      "value": 0
    },
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    },
    {
      "event": "CANDIDATE_RESTART_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "faults_observed": [
    {
      "event": "BACKUP_FAIL_BEFORE_RESERVE",
      "occurrence": 1,
      "target": "BACKUP",
      "trigger": "reserve",
      "value": 0
    },
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    },
    {
      "event": "CANDIDATE_RESTART_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "fixture_id": "constructed-continuity",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-post-review-source"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "method": "conventional",
  "per_arrangement": [],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "UNRESOLVED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNRESOLVED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "UNRESOLVED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "3515001b3305413676901422f8c6395fa915673f7d62833397fab94b9680718a",
  "registered_assertion": {
    "expected": {
      "accepted_units": 1900,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "observed": {
      "accepted_units": 0,
      "outcome": "NOT_ESTABLISHED",
      "service_feasibility": "NOT_ESTABLISHED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "FAILED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30468,
    "candidate_restarts": 1,
    "child_processes": 10,
    "controller_cpu_system_ns": 37726999,
    "controller_cpu_user_ns": 163732000,
    "cpu_system_ns": 99530000,
    "cpu_user_ns": 694082000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 37,
    "retries": 0,
    "service_requests": 180,
    "storage_bytes": 8476603,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 1184171770,
    "worker_restarts": 1
  },
  "run_id": "constructed-continuity.conventional.f189246caf",
  "safety_status": "NOT_ESTABLISHED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-post-review-source"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 0,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 0,
    "production_attempts": 0,
    "received_quantity": 0,
    "recipient_accepted_quantity": 0,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 0,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [
    {
      "code": "EXECUTION_INCOMPLETE",
      "detail": "",
      "scope": "outcome"
    },
    {
      "code": "VERIFICATION_EVIDENCE_MISSING",
      "detail": "MISSING_FILE:COMPAT-A.W0.sqlite",
      "scope": "integrity"
    }
  ],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 21265985,
    "evidence_files_read": 6,
    "wall_ns": 21298894
  },
  "verification_status": "INCOMPLETE",
  "verification_wall_ns": 21384843,
  "verifier_version": "0.2.0"
}
```
