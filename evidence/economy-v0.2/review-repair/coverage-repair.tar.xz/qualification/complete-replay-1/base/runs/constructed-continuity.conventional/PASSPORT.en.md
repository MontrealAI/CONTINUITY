# CONTINUITY Ω Harness — Economy of continuity

**Digital-product experiment · version 0.2.0**

Preserve a promise through a viable, voluntarily accepted continuity arrangement.

**Scope: disposable local processes and a specified digital product. Authored synthetic policies, consent, values, funding and SMU cash flows are model inputs and observations. They do not establish real contracts, demand, payments, sales, printed goods, rendered appearance or print quality.**

This Passport presents the recorded assessment. Fresh verification must inspect retained authority, actual durable output and recipient evidence; this document is never its oracle.

<!-- structured-result-sha256: 8855f13b3448fe88744cdc894259b1a856d06aaf0ec93130835390b04c5ccb98 -->

## Three distinct claims

| Claim | Recorded status |
| --- | --- |
| Required digital work accepted within the frozen conditions | Not established (`NOT_ESTABLISHED`) |
| Service feasibility under the authored synthetic model | Not established (`NOT_ESTABLISHED`) |
| Method advantage over competent alternatives | Not established (`NOT_ESTABLISHED`) |
| Safety within the exercised failure model | Not established (`NOT_ESTABLISHED`) |

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

## Assessment fields kept separate

| Field | Recorded value |
| --- | --- |
| Test assertion | Failed (`FAILED`) |
| Component verdict | Execution error (`ERROR`) |
| Evidence stage | Verification attempt (`VERIFICATION_ATTEMPT`) |
| Assessed claim status | Not established (`NOT_ESTABLISHED`) |

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

## Identity, authority and versions

| Field | Recorded value |
| --- | --- |
| Authority evidence status · `authority_status` | Established for the synthetic exercise only (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Real commercial value · `commercial_value` | Not established (`NOT_ESTABLISHED`) |
| Contract identity · `contract_id` | DIGITAL-003 |
| Retained contract SHA-256 · `contract_sha256` | f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1 |
| Real customer authenticity · `real_customer_authenticity` | Not established (`NOT_ESTABLISHED`) |
| External reference pin · `reference_sha256` | 3515001b3305413676901422f8c6395fa915673f7d62833397fab94b9680718a |
| Run identity · `run_id` | constructed-continuity.conventional.f189246caf |
| Schema · `schema` | continuity-economy/verification/v1 |
| Verification completion status · `verification_status` | Incomplete verification (`INCOMPLETE`) |
| Verifier version · `verifier_version` | 0.2.0 |

## Per-obligation execution and acceptance

Counts describe the recorded stage. Rejected and corrected attempts remain distinct. A produced or received unit is not automatically accepted. Missing measurements are not displayed as zero.

| Obligation | Recipient | Revision | Required | Produced | Received | Rejected | Accepted within contract | Outcome |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 0 | 0 | 0 | 0 | Unresolved (`UNRESOLVED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 0 | 0 | 0 | 0 | Unresolved (`UNRESOLVED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Unresolved (`UNRESOLVED`) |

### Obligation `DL-100`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 1100 |
| Obligation identity · `obligation_id` | DL-100 |
| Outcome · `outcome` | Unresolved (`UNRESOLVED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 1100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-A |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 1100 |
| Revision · `revision` | 2 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

### Obligation `DL-200`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 800 |
| Obligation identity · `obligation_id` | DL-200 |
| Outcome · `outcome` | Unresolved (`UNRESOLVED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 800 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-B |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 800 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

### Obligation `DL-300`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | DL-300 |
| Outcome · `outcome` | Unresolved (`UNRESOLVED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-C |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 0 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Cancelled (`CANCELLED`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

## Proposals, modeled decisions and arrangements

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

No arrangement record is present. This absence is not evidence of an accepted or economically viable deal.

## Modeled transfers, costs, liabilities and outside options

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

| Field | Recorded value |
| --- | --- |
| `accounting` | No entries |
| Accepted obligations · `totals.accepted_obligations` | 0 |
| Accepted quantity within contract · `totals.accepted_quantity` | 0 |
| Delivery attempts · `totals.delivery_attempts` | 0 |
| Duplicate accepted units · `totals.duplicate_acceptances` | 0 |
| Late quantity · `totals.late_quantity` | 0 |
| Missing quantity · `totals.missing_quantity` | 1900 |
| Produced quantity · `totals.produced_quantity` | 0 |
| Durable production attempts · `totals.production_attempts` | 0 |
| Received quantity · `totals.received_quantity` | 0 |
| Units accepted by the recipient component · `totals.recipient_accepted_quantity` | 0 |
| Rejected quantity · `totals.rejected_quantity` | 0 |
| Requested units in rejected deliveries · `totals.rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `totals.rejection_count` | 0 |
| Required active obligations · `totals.required_obligations` | 2 |
| Required quantity · `totals.required_quantity` | 1900 |
| Semantically correct units observed in time · `totals.timely_semantic_quantity` | 0 |
| Unsafe or unsupported commitments · `totals.unsafe_or_unsupported_commitments` | 0 |

## Measured resources and accounting gaps

Measured process resources and configured synthetic amounts have different meanings. Unrecorded preparation, integration, adaptation, verification or intervention effort remains unknown. Missing categories cannot support a complete-cost or cheaper-method conclusion.

| Field | Recorded value |
| --- | --- |
| Accounting gaps · `accounting_gaps[0]` | Preparation labor was not measured (`PREPARATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[1]` | Integration labor was not measured (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[2]` | Adaptation labor was not measured (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[3]` | Human verification labor was not measured (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[4]` | Monetary rates were not measured (`MONETARY_RATES_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Adaptation labor (seconds; unknown if absent) · `resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `resources.authority_storage_bytes_before_seal` | 30468 |
| Candidate restarts · `resources.candidate_restarts` | 1 |
| Launched child processes · `resources.child_processes` | 10 |
| Controller system CPU (ns) · `resources.controller_cpu_system_ns` | 37726999 |
| Controller user CPU (ns) · `resources.controller_cpu_user_ns` | 163732000 |
| System CPU (ns) · `resources.cpu_system_ns` | 99530000 |
| User CPU (ns) · `resources.cpu_user_ns` | 694082000 |
| Human interventions · `resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `resources.preparation_labor_seconds` | Not recorded |
| Requests · `resources.requests` | 37 |
| Retries · `resources.retries` | 0 |
| Internal service requests · `resources.service_requests` | 180 |
| Recorded storage (bytes) · `resources.storage_bytes` | 8476603 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `resources.wall_ns` | 1184171770 |
| Worker restarts · `resources.worker_restarts` | 1 |
| Process CPU (ns) · `verification_resources.cpu_ns` | 21265985 |
| Evidence files inspected · `verification_resources.evidence_files_read` | 6 |
| Wall duration (ns) · `verification_resources.wall_ns` | 21298894 |

## Observed failures and counterexamples

No failure entry was recorded in this assessment. This is bounded evidence, not a general proof.

## Missing evidence and unresolved claims

| Stable code | Scope | Obligation | Arrangement | Interpretation | Original technical locator |
| --- | --- | --- | --- | --- | --- |
| `EXECUTION_INCOMPLETE` | outcome | Not recorded | Not recorded | Required evidence or measurement is missing; a favorable claim is not established by this entry. | `` |
| `VERIFICATION_EVIDENCE_MISSING` | integrity | Not recorded | Not recorded | Required evidence or measurement is missing; a favorable claim is not established by this entry. | `MISSING_FILE:COMPAT-A.W0.sqlite` |

## Evidence references and byte integrity

Hashes identify bytes. They do not authenticate real customer instructions, establish source completeness, or replace an externally retained reference pin.

| Field | Recorded value |
| --- | --- |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 7a7ac2e80dde7705f93dc901ee9edb8397b9590215fcaf923ed09aadf5e6a451 |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.closing` | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | 017cbc7ba188053893d674c36ec6eb4612ecf73f6878aed769cd286a6b751db8 |
| `evidence_sha256.evidence/participants.sqlite` | c22d2cb5ec0be6b97a98254830f9449870ff0fcd1c6892986a7ed659727ee044 |
| `evidence_sha256.evidence/producer.sqlite` | 436abecf8e4d3a4f0beb7c022ebfaf4774ef30592b497474c849d5e73745442b |
| `evidence_sha256.evidence/receiver.sqlite` | a924e23206c1be61bc93278c5404c51d69242b912b74ac31f1c381299c5e13cf |
| Structured result SHA-256 · `structured_result_sha256` | 8855f13b3448fe88744cdc894259b1a856d06aaf0ec93130835390b04c5ccb98 |

## Recorded execution, faults, commands and provenance

Stable identifiers, exact commands, paths and original machine diagnostics are retained literally. They are data, not additional acceptance evidence. Source and host trust remain explicit in the architecture and threat model.

| Field | Recorded value |
| --- | --- |
| `authority_dir` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1/base/authorities/constructed-continuity.conventional |
| Experiment cohort · `cohort` | base |
| `contract.allow_split` | Yes |
| `contract.authority_kind` | Synthetic exercise authority (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | PRIMARY-HOST |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Experiment cohort · `contract.cohort` | base |
| Contract identity · `contract.contract_id` | DIGITAL-003 |
| `contract.cutoff_sequence` | 5 |
| Logical deadline · `contract.deadline_tick` | 500 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-001 |
| Recorded event · `contract.fault_schedule[0].event` | Backup failure before reservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Trigger occurrence · `contract.fault_schedule[0].occurrence` | 1 |
| Fault target · `contract.fault_schedule[0].target` | BACKUP |
| Trigger operation · `contract.fault_schedule[0].trigger` | reserve |
| Configured value · `contract.fault_schedule[0].value` | 0 |
| Recorded event · `contract.fault_schedule[1].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `contract.fault_schedule[1].occurrence` | 1 |
| Fault target · `contract.fault_schedule[1].target` | ANY |
| Trigger operation · `contract.fault_schedule[1].trigger` | inspect |
| Configured value · `contract.fault_schedule[1].value` | 0 |
| Recorded event · `contract.fault_schedule[2].event` | Candidate restart after acceptance (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `contract.fault_schedule[2].occurrence` | 1 |
| Fault target · `contract.fault_schedule[2].target` | ANY |
| Trigger operation · `contract.fault_schedule[2].trigger` | inspect |
| Configured value · `contract.fault_schedule[2].value` | 0 |
| Registered fixture identity · `contract.fixture_id` | constructed-continuity |
| `contract.lease_ticks` | 20 |
| `contract.lot_size` | 500 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Logical deadline · `contract.obligations[0].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[0].obligation_id` | DL-100 |
| Required quantity · `contract.obligations[0].quantity` | 1100 |
| Recipient · `contract.obligations[0].recipient` | RECIPIENT-A |
| Revision · `contract.obligations[0].revision` | 2 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[0].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[0].spec.lot` | BATCH-20261106 |
| `contract.obligations[0].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[0].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[0].spec.serial_prefix` | DL-100- |
| `contract.obligations[0].spec.sku` | KIT-DL-100 |
| Recorded status · `contract.obligations[0].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[1].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[1].obligation_id` | DL-200 |
| Required quantity · `contract.obligations[1].quantity` | 800 |
| Recipient · `contract.obligations[1].recipient` | RECIPIENT-B |
| Revision · `contract.obligations[1].revision` | 1 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[1].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[1].spec.lot` | BATCH-20261106 |
| `contract.obligations[1].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[1].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[1].spec.serial_prefix` | DL-200- |
| `contract.obligations[1].spec.sku` | KIT-DL-200 |
| Recorded status · `contract.obligations[1].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[2].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[2].obligation_id` | DL-300 |
| Required quantity · `contract.obligations[2].quantity` | 100 |
| Recipient · `contract.obligations[2].recipient` | RECIPIENT-C |
| Revision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[2].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[2].spec.lot` | BATCH-20261106 |
| `contract.obligations[2].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[2].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[2].spec.serial_prefix` | DL-300- |
| `contract.obligations[2].spec.sku` | KIT-DL-300 |
| Recorded status · `contract.obligations[2].status` | Cancelled (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 800 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | PRIMARY-HOST |
| `contract.providers[0].permissions.disclosure` | Yes |
| `contract.providers[0].permissions.production` | Yes |
| Provider identity · `contract.providers[0].provider_id` | PRIMARY |
| Role · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 2400 |
| `contract.providers[0].windows[0].end` | 800 |
| `contract.providers[0].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[0].windows[0].window_id` | W0 |
| `contract.providers[1].dependency` | BACKUP-HOST |
| `contract.providers[1].permissions.disclosure` | Yes |
| `contract.providers[1].permissions.production` | Yes |
| Provider identity · `contract.providers[1].provider_id` | BACKUP |
| Role · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 2400 |
| `contract.providers[1].windows[0].end` | 800 |
| `contract.providers[1].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[1].windows[0].window_id` | W0 |
| `contract.providers[2].dependency` | COMPAT-A-HOST |
| `contract.providers[2].permissions.disclosure` | Yes |
| `contract.providers[2].permissions.production` | Yes |
| Provider identity · `contract.providers[2].provider_id` | COMPAT-A |
| Role · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 1200 |
| `contract.providers[2].windows[0].end` | 800 |
| `contract.providers[2].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[2].windows[0].window_id` | W0 |
| `contract.providers[3].dependency` | COMPAT-B-HOST |
| `contract.providers[3].permissions.disclosure` | Yes |
| `contract.providers[3].permissions.production` | Yes |
| Provider identity · `contract.providers[3].provider_id` | COMPAT-B |
| Role · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 1100 |
| `contract.providers[3].windows[0].end` | 800 |
| `contract.providers[3].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[3].windows[0].window_id` | W0 |
| Revision · `contract.revision` | 1 |
| `contract.revocations` | No entries |
| Run identity · `contract.run_id` | constructed-continuity.conventional.f189246caf |
| Schema · `contract.schema` | continuity-economy/contract/v1 |
| Recorded seed · `contract.seed` | 703 |
| `contract.source_complete` | Yes |
| Logical deadline · `contract.source_events[0].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[0].obligation.obligation_id` | DL-100 |
| Required quantity · `contract.source_events[0].obligation.quantity` | 1000 |
| Recipient · `contract.source_events[0].obligation.recipient` | RECIPIENT-A |
| Revision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Obsolete instruction. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Instruction périmée. |
| `contract.source_events[0].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[0].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[0].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[0].obligation.spec.sku` | KIT-DL-100 |
| Recorded status · `contract.source_events[0].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[0].obligation_id` | DL-100 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Logical deadline · `contract.source_events[1].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[1].obligation.obligation_id` | DL-200 |
| Required quantity · `contract.source_events[1].obligation.quantity` | 800 |
| Recipient · `contract.source_events[1].obligation.recipient` | RECIPIENT-B |
| Revision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[1].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[1].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[1].obligation.spec.serial_prefix` | DL-200- |
| `contract.source_events[1].obligation.spec.sku` | KIT-DL-200 |
| Recorded status · `contract.source_events[1].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[1].obligation_id` | DL-200 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Logical deadline · `contract.source_events[2].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[2].obligation.obligation_id` | DL-300 |
| Required quantity · `contract.source_events[2].obligation.quantity` | 100 |
| Recipient · `contract.source_events[2].obligation.recipient` | RECIPIENT-C |
| Revision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[2].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[2].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[2].obligation.spec.serial_prefix` | DL-300- |
| `contract.source_events[2].obligation.spec.sku` | KIT-DL-300 |
| Recorded status · `contract.source_events[2].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[2].obligation_id` | DL-300 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Logical deadline · `contract.source_events[3].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[3].obligation.obligation_id` | DL-100 |
| Required quantity · `contract.source_events[3].obligation.quantity` | 1100 |
| Recipient · `contract.source_events[3].obligation.recipient` | RECIPIENT-A |
| Revision · `contract.source_events[3].obligation.revision` | 2 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[3].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[3].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[3].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[3].obligation.spec.sku` | KIT-DL-100 |
| Recorded status · `contract.source_events[3].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[3].obligation_id` | DL-100 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | AMEND |
| Obligation identity · `contract.source_events[4].obligation_id` | DL-300 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | CANCEL |
| `contract.source_id` | AUTHORED-DIGITAL-EVENTS |
| Source byte hashes · `contract.source_sha256` | 8d6a71fd1c26021120a5283bd7cf3eb7812b5c34ae6a4da3eec94dceaf8f7b81 |
| Start clock (ns) · `contract.start_ns` | 40081184923685 |
| Elapsed-time deadline (ms) · `contract.wall_deadline_ms` | 60000 |
| `controller.capacity_databases[0].path` | evidence/capacity/PRIMARY.W0.sqlite |
| Provider identity · `controller.capacity_databases[0].provider_id` | PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Capacity-window identity · `controller.capacity_databases[0].window_id` | W0 |
| `controller.capacity_databases[1].path` | evidence/capacity/BACKUP.W0.sqlite |
| Provider identity · `controller.capacity_databases[1].provider_id` | BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Capacity-window identity · `controller.capacity_databases[1].window_id` | W0 |
| `controller.capacity_databases[2].path` | evidence/capacity/COMPAT-A.W0.sqlite |
| Provider identity · `controller.capacity_databases[2].provider_id` | COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Capacity-window identity · `controller.capacity_databases[2].window_id` | W0 |
| `controller.capacity_databases[3].path` | evidence/capacity/COMPAT-B.W0.sqlite |
| Provider identity · `controller.capacity_databases[3].provider_id` | COMPAT-B |
| `controller.capacity_databases[3].route` | backup |
| Capacity-window identity · `controller.capacity_databases[3].window_id` | W0 |
| `controller.clock_tick` | 38 |
| Experiment cohort · `controller.cohort` | base |
| Retained contract SHA-256 · `controller.contract_sha256` | f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1 |
| `controller.db_snapshots.evidence/capacity/BACKUP.W0.sqlite` | 5920e3a7af1cbdda19c506d53227b4a9b4801ed0f2e58c1daea969cf83a5eb49 |
| `controller.db_snapshots.evidence/capacity/COMPAT-A.W0.sqlite` | a12ec277cbc3cb40e2c9d6d6175d5bcfe145cd0112c3dcadb36e40d38a03f56a |
| `controller.db_snapshots.evidence/capacity/COMPAT-B.W0.sqlite` | af5a5d3cf39dabbe9b4a8606376010b3d3fee73e2ae48a0e012ce9445d9c6699 |
| `controller.db_snapshots.evidence/capacity/PRIMARY.W0.sqlite` | 898556b4d98676cbe68aa8d9617c6d9da70d5307905d4780cf158edc89956a42 |
| `controller.db_snapshots.evidence/participants.sqlite` | d953c96c6a6c62b51de997f33ad0a5e210504523b2256ae04d8e799062876a51 |
| `controller.db_snapshots.evidence/producer.sqlite` | b964dc2b2c9865f0c4927b8ffb2c9831503f8fcfc80d476221d6414365045928 |
| `controller.db_snapshots.evidence/receiver.sqlite` | 2bd2414d3269f4f7a8c058b263ca782b07410f9c4374d8d2ec2136401ddf6c7e |
| Stable code · `controller.errors[0].code` | DATABASE_STATE_CHANGED |
| `controller.errors[0].detail` | DATABASE_STATE_CHANGED: /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1/base/runs/constructed-continuity.conventional/runtime/capacity/COMPAT-A.W0.sqlite |
| `controller.errors[0].message` | Durable database content changed after its retained snapshot. |
| `controller.events[0].detail.authority_kind` | Synthetic exercise authority (`SYNTHETIC_EXERCISE`) |
| External reference pin · `controller.events[0].detail.reference_sha256` | 3515001b3305413676901422f8c6395fa915673f7d62833397fab94b9680718a |
| Recorded seed · `controller.events[0].detail.seed` | 703 |
| Recorded event · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 40081205395819 |
| Logical tick · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 75 |
| `controller.events[1].detail.restart` | No |
| `controller.events[1].detail.service` | participants |
| Recorded event · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 40081255562787 |
| Logical tick · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 76 |
| `controller.events[2].detail.restart` | No |
| `controller.events[2].detail.service` | producer |
| Recorded event · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 40081298704627 |
| Logical tick · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 77 |
| `controller.events[3].detail.restart` | No |
| `controller.events[3].detail.service` | receiver |
| Recorded event · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 40081340276613 |
| Logical tick · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 78 |
| Provider identity · `controller.events[4].detail.provider_id` | PRIMARY |
| Capacity-window identity · `controller.events[4].detail.window_id` | W0 |
| Recorded event · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 40081388786556 |
| Logical tick · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 79 |
| Provider identity · `controller.events[5].detail.provider_id` | BACKUP |
| Capacity-window identity · `controller.events[5].detail.window_id` | W0 |
| Recorded event · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 40081440163063 |
| Logical tick · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 80 |
| Provider identity · `controller.events[6].detail.provider_id` | COMPAT-A |
| Capacity-window identity · `controller.events[6].detail.window_id` | W0 |
| Recorded event · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 40081482395808 |
| Logical tick · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 81 |
| Provider identity · `controller.events[7].detail.provider_id` | COMPAT-B |
| Capacity-window identity · `controller.events[7].detail.window_id` | W0 |
| Recorded event · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 40081519746875 |
| Logical tick · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.affected[0]` | PRIMARY.W0 |
| `controller.events[8].detail.dependency` | PRIMARY-HOST |
| Recorded event · `controller.events[8].event` | DEPENDENCY_DISABLED |
| `controller.events[8].monotonic_ns` | 40081520744503 |
| Logical tick · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.isolation.applied` | Yes |
| `controller.events[9].detail.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.events[9].detail.isolation.probe.authority_open_denied` | Yes |
| `controller.events[9].detail.isolation.probe.network_denied` | Yes |
| `controller.events[9].detail.isolation.probe.process_inspection_denied` | Yes |
| `controller.events[9].detail.isolation.probe.spawn_denied` | Yes |
| `controller.events[9].detail.isolation.probe.workspace_open_denied` | Yes |
| `controller.events[9].detail.pid` | 82 |
| `controller.events[9].detail.restart` | No |
| Recorded event · `controller.events[9].event` | CANDIDATE_STARTED |
| `controller.events[9].monotonic_ns` | 40081560149824 |
| Logical tick · `controller.events[9].tick` | 0 |
| `controller.events[10].detail.args` | No entries |
| `controller.events[10].detail.op` | status |
| Recorded event · `controller.events[10].event` | BROKER_REQUEST |
| `controller.events[10].monotonic_ns` | 40081561807069 |
| Logical tick · `controller.events[10].tick` | 1 |
| `controller.events[11].detail.measurement_kind` | Candidate-reported measurement (`CANDIDATE_REPORTED`) |
| `controller.events[11].detail.pid` | 82 |
| `controller.events[11].detail.report.assignment_domain` | 243 |
| `controller.events[11].detail.report.candidate_elapsed_ns` | 10082530 |
| `controller.events[11].detail.report.capacity_prunes` | 54 |
| `controller.events[11].detail.report.complete_assignments_observed` | 243 |
| `controller.events[11].detail.report.exhaustive_within_declared_domain` | Yes |
| `controller.events[11].detail.report.feasible_assignments` | 189 |
| `controller.events[11].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Candidate procedure · `controller.events[11].detail.report.method` | conventional |
| `controller.events[11].detail.report.partial_nodes_observed` | 0 |
| `controller.events[11].detail.report.participant_prunes` | 0 |
| `controller.events[11].detail.report.price_prunes` | 0 |
| Recorded event · `controller.events[11].event` | CANDIDATE_PLANNING |
| `controller.events[11].monotonic_ns` | 40081578344145 |
| Logical tick · `controller.events[11].tick` | 1 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[0].last_unit` | 500 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[0].pay_minor` | 4200 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[0].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[1].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[2].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[3].last_unit` | 500 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[3].pay_minor` | 0 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[3].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[4].last_unit` | 800 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[4].pay_minor` | 0 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[4].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.buyer_price_minor` | 4500 |
| Cancellation liability (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `controller.events[12].detail.args.proposal.contract_sha256` | f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1 |
| Coordinator fee (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.coordinator_fee_minor` | 300 |
| Exclusive expiry tick · `controller.events[12].detail.args.proposal.expires_tick` | 500 |
| Policy revision · `controller.events[12].detail.args.proposal.policy_revision` | 1 |
| Proposal identity · `controller.events[12].detail.args.proposal.proposal_id` | proposal-001 |
| Correction reserve (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.rework_budget_minor` | 2050 |
| Schema · `controller.events[12].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[12].detail.op` | propose |
| Recorded event · `controller.events[12].event` | BROKER_REQUEST |
| `controller.events[12].monotonic_ns` | 40081578505099 |
| Logical tick · `controller.events[12].tick` | 2 |
| Proposal identity · `controller.events[13].detail.args.proposal_id` | proposal-001 |
| `controller.events[13].detail.op` | decide |
| Recorded event · `controller.events[13].event` | BROKER_REQUEST |
| `controller.events[13].monotonic_ns` | 40081584136120 |
| Logical tick · `controller.events[13].tick` | 3 |
| `controller.events[14].detail.args` | No entries |
| `controller.events[14].detail.op` | status |
| Recorded event · `controller.events[14].event` | BROKER_REQUEST |
| `controller.events[14].monotonic_ns` | 40081589099502 |
| Logical tick · `controller.events[14].tick` | 4 |
| Agreement identity · `controller.events[15].detail.args.agreement_id` | proposal-001 |
| `controller.events[15].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[15].detail.args.lot_id` | DL-100.L001 |
| `controller.events[15].detail.op` | reserve |
| Recorded event · `controller.events[15].event` | BROKER_REQUEST |
| `controller.events[15].monotonic_ns` | 40081595733960 |
| Logical tick · `controller.events[15].tick` | 5 |
| `controller.events[16].detail.affected[0]` | BACKUP.W0 |
| `controller.events[16].detail.dependency` | BACKUP-HOST |
| Recorded event · `controller.events[16].event` | DEPENDENCY_DISABLED |
| `controller.events[16].monotonic_ns` | 40081599041089 |
| Logical tick · `controller.events[16].tick` | 5 |
| `controller.events[17].detail.dependency` | BACKUP-HOST |
| Recorded event · `controller.events[17].detail.schedule.event` | Backup failure before reservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Trigger occurrence · `controller.events[17].detail.schedule.occurrence` | 1 |
| Fault target · `controller.events[17].detail.schedule.target` | BACKUP |
| Trigger operation · `controller.events[17].detail.schedule.trigger` | reserve |
| Configured value · `controller.events[17].detail.schedule.value` | 0 |
| Recorded event · `controller.events[17].event` | Backup failure before reservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| `controller.events[17].monotonic_ns` | 40081599056653 |
| Logical tick · `controller.events[17].tick` | 5 |
| Stable code · `controller.events[18].detail.code` | DEPENDENCY_UNAVAILABLE |
| `controller.events[18].detail.detail` | BACKUP |
| `controller.events[18].detail.op` | reserve |
| Recorded event · `controller.events[18].event` | BROKER_REFUSED |
| `controller.events[18].monotonic_ns` | 40081601147533 |
| Logical tick · `controller.events[18].tick` | 5 |
| Agreement identity · `controller.events[19].detail.args.agreement_id` | proposal-001 |
| Recorded reason · `controller.events[19].detail.args.reason` | DEPENDENCY_UNAVAILABLE |
| `controller.events[19].detail.op` | cancel |
| Recorded event · `controller.events[19].event` | BROKER_REQUEST |
| `controller.events[19].monotonic_ns` | 40081601357080 |
| Logical tick · `controller.events[19].tick` | 6 |
| Agreement identity · `controller.events[20].detail.agreement_id` | proposal-001 |
| Recorded reason · `controller.events[20].detail.reason` | DEPENDENCY_UNAVAILABLE |
| Recorded event · `controller.events[20].event` | ARRANGEMENT_CANCELLED |
| `controller.events[20].monotonic_ns` | 40081606589658 |
| Logical tick · `controller.events[20].tick` | 6 |
| `controller.events[21].detail.args` | No entries |
| `controller.events[21].detail.op` | status |
| Recorded event · `controller.events[21].event` | BROKER_REQUEST |
| `controller.events[21].monotonic_ns` | 40081606954630 |
| Logical tick · `controller.events[21].tick` | 7 |
| `controller.events[22].detail.measurement_kind` | Candidate-reported measurement (`CANDIDATE_REPORTED`) |
| `controller.events[22].detail.pid` | 82 |
| `controller.events[22].detail.report.assignment_domain` | 32 |
| `controller.events[22].detail.report.candidate_elapsed_ns` | 2345365 |
| `controller.events[22].detail.report.capacity_prunes` | 20 |
| `controller.events[22].detail.report.complete_assignments_observed` | 32 |
| `controller.events[22].detail.report.exhaustive_within_declared_domain` | Yes |
| `controller.events[22].detail.report.feasible_assignments` | 12 |
| `controller.events[22].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Candidate procedure · `controller.events[22].detail.report.method` | conventional |
| `controller.events[22].detail.report.partial_nodes_observed` | 0 |
| `controller.events[22].detail.report.participant_prunes` | 0 |
| `controller.events[22].detail.report.price_prunes` | 0 |
| Recorded event · `controller.events[22].event` | CANDIDATE_PLANNING |
| `controller.events[22].monotonic_ns` | 40081615859780 |
| Logical tick · `controller.events[22].tick` | 7 |
| First ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[0].last_unit` | 500 |
| Fixed lot identity · `controller.events[23].detail.args.proposal.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `controller.events[23].detail.args.proposal.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.allocations[0].pay_minor` | 2700 |
| Provider identity · `controller.events[23].detail.args.proposal.allocations[0].provider_id` | COMPAT-A |
| Capacity-window identity · `controller.events[23].detail.args.proposal.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `controller.events[23].detail.args.proposal.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `controller.events[23].detail.args.proposal.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Provider identity · `controller.events[23].detail.args.proposal.allocations[1].provider_id` | COMPAT-A |
| Capacity-window identity · `controller.events[23].detail.args.proposal.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `controller.events[23].detail.args.proposal.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `controller.events[23].detail.args.proposal.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Provider identity · `controller.events[23].detail.args.proposal.allocations[2].provider_id` | COMPAT-A |
| Capacity-window identity · `controller.events[23].detail.args.proposal.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[3].last_unit` | 500 |
| Fixed lot identity · `controller.events[23].detail.args.proposal.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `controller.events[23].detail.args.proposal.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.allocations[3].pay_minor` | 2300 |
| Provider identity · `controller.events[23].detail.args.proposal.allocations[3].provider_id` | COMPAT-B |
| Capacity-window identity · `controller.events[23].detail.args.proposal.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `controller.events[23].detail.args.proposal.allocations[4].last_unit` | 800 |
| Fixed lot identity · `controller.events[23].detail.args.proposal.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `controller.events[23].detail.args.proposal.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.allocations[4].pay_minor` | 0 |
| Provider identity · `controller.events[23].detail.args.proposal.allocations[4].provider_id` | COMPAT-B |
| Capacity-window identity · `controller.events[23].detail.args.proposal.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.buyer_price_minor` | 5500 |
| Cancellation liability (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `controller.events[23].detail.args.proposal.contract_sha256` | f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1 |
| Coordinator fee (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.coordinator_fee_minor` | 500 |
| Exclusive expiry tick · `controller.events[23].detail.args.proposal.expires_tick` | 500 |
| Policy revision · `controller.events[23].detail.args.proposal.policy_revision` | 1 |
| Proposal identity · `controller.events[23].detail.args.proposal.proposal_id` | proposal-002 |
| Correction reserve (synthetic SMU minor units) · `controller.events[23].detail.args.proposal.rework_budget_minor` | 2400 |
| Schema · `controller.events[23].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[23].detail.op` | propose |
| Recorded event · `controller.events[23].event` | BROKER_REQUEST |
| `controller.events[23].monotonic_ns` | 40081616875826 |
| Logical tick · `controller.events[23].tick` | 8 |
| Proposal identity · `controller.events[24].detail.args.proposal_id` | proposal-002 |
| `controller.events[24].detail.op` | decide |
| Recorded event · `controller.events[24].event` | BROKER_REQUEST |
| `controller.events[24].monotonic_ns` | 40081622037598 |
| Logical tick · `controller.events[24].tick` | 9 |
| `controller.events[25].detail.args` | No entries |
| `controller.events[25].detail.op` | status |
| Recorded event · `controller.events[25].event` | BROKER_REQUEST |
| `controller.events[25].monotonic_ns` | 40081626412781 |
| Logical tick · `controller.events[25].tick` | 10 |
| Agreement identity · `controller.events[26].detail.args.agreement_id` | proposal-002 |
| `controller.events[26].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[26].detail.args.lot_id` | DL-100.L001 |
| `controller.events[26].detail.op` | reserve |
| Recorded event · `controller.events[26].event` | BROKER_REQUEST |
| `controller.events[26].monotonic_ns` | 40081634594789 |
| Logical tick · `controller.events[26].tick` | 11 |
| `controller.events[27].detail.key` | proposal-002.DL-100.L001.A1 |
| `controller.events[27].detail.slot` | COMPAT-A.W0 |
| Recorded status · `controller.events[27].detail.status` | RESERVED |
| Recorded event · `controller.events[27].event` | CAPACITY_RESERVED |
| `controller.events[27].monotonic_ns` | 40081643884400 |
| Logical tick · `controller.events[27].tick` | 11 |
| Agreement identity · `controller.events[28].detail.args.agreement_id` | proposal-002 |
| `controller.events[28].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[28].detail.args.lot_id` | DL-100.L001 |
| `controller.events[28].detail.args.supersedes` | Not recorded |
| `controller.events[28].detail.op` | produce |
| Recorded event · `controller.events[28].event` | BROKER_REQUEST |
| `controller.events[28].monotonic_ns` | 40081644268621 |
| Logical tick · `controller.events[28].tick` | 12 |
| `controller.events[29].detail.byte_count` | 195960 |
| `controller.events[29].detail.payload_sha256` | 8b2e981858a849886d72c5a804a477d34b69eb345cac6f875ca9a44a304327ae |
| `controller.events[29].detail.production_id` | proposal-002.DL-100.L001.A1 |
| Required quantity · `controller.events[29].detail.quantity` | 500 |
| Recorded event · `controller.events[29].event` | PRODUCT_MATERIALIZED |
| `controller.events[29].monotonic_ns` | 40081682099503 |
| Logical tick · `controller.events[29].tick` | 12 |
| `controller.events[30].detail.args.production_id` | proposal-002.DL-100.L001.A1 |
| `controller.events[30].detail.op` | transfer |
| Recorded event · `controller.events[30].event` | BROKER_REQUEST |
| `controller.events[30].monotonic_ns` | 40081682600059 |
| Logical tick · `controller.events[30].tick` | 13 |
| `controller.events[31].detail.byte_count` | 195960 |
| `controller.events[31].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[31].detail.produced_sha256` | 8b2e981858a849886d72c5a804a477d34b69eb345cac6f875ca9a44a304327ae |
| `controller.events[31].detail.production_id` | proposal-002.DL-100.L001.A1 |
| `controller.events[31].detail.received_sha256` | 8b2e981858a849886d72c5a804a477d34b69eb345cac6f875ca9a44a304327ae |
| Recorded event · `controller.events[31].event` | PRODUCT_TRANSFERRED |
| `controller.events[31].monotonic_ns` | 40081692145297 |
| Logical tick · `controller.events[31].tick` | 13 |
| `controller.events[32].detail.args.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[32].detail.op` | inspect |
| Recorded event · `controller.events[32].event` | BROKER_REQUEST |
| `controller.events[32].monotonic_ns` | 40081692465631 |
| Logical tick · `controller.events[32].tick` | 14 |
| `controller.events[33].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[33].detail.hook` | inspect.after_observation |
| Recorded event · `controller.events[33].detail.schedule.event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.events[33].detail.schedule.occurrence` | 1 |
| Fault target · `controller.events[33].detail.schedule.target` | ANY |
| Trigger operation · `controller.events[33].detail.schedule.trigger` | inspect |
| Configured value · `controller.events[33].detail.schedule.value` | 0 |
| Recorded event · `controller.events[33].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| `controller.events[33].monotonic_ns` | 40081730044932 |
| Logical tick · `controller.events[33].tick` | 14 |
| `controller.events[34].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[34].detail.hook` | inspect.after_observation |
| Recorded event · `controller.events[34].detail.schedule.event` | Candidate restart after acceptance (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.events[34].detail.schedule.occurrence` | 1 |
| Fault target · `controller.events[34].detail.schedule.target` | ANY |
| Trigger operation · `controller.events[34].detail.schedule.trigger` | inspect |
| Configured value · `controller.events[34].detail.schedule.value` | 0 |
| Recorded event · `controller.events[34].event` | Candidate restart after acceptance (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| `controller.events[34].monotonic_ns` | 40081730053005 |
| Logical tick · `controller.events[34].tick` | 14 |
| `controller.events[35].detail.pid` | 77 |
| `controller.events[35].detail.service` | receiver |
| Recorded event · `controller.events[35].event` | SERVICE_TERMINATED |
| `controller.events[35].monotonic_ns` | 40081731229583 |
| Logical tick · `controller.events[35].tick` | 14 |
| `controller.events[36].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[36].detail.pid` | 82 |
| Recorded event · `controller.events[36].event` | CANDIDATE_TERMINATED |
| `controller.events[36].monotonic_ns` | 40081732396547 |
| Logical tick · `controller.events[36].tick` | 14 |
| `controller.events[37].detail.pid` | 83 |
| `controller.events[37].detail.restart` | Yes |
| `controller.events[37].detail.service` | receiver |
| Recorded event · `controller.events[37].event` | SERVICE_STARTED |
| `controller.events[37].monotonic_ns` | 40081767236338 |
| Logical tick · `controller.events[37].tick` | 14 |
| `controller.events[38].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| Recorded event · `controller.events[38].event` | ACKNOWLEDGMENT_UNCERTAIN |
| `controller.events[38].monotonic_ns` | 40081767245682 |
| Logical tick · `controller.events[38].tick` | 14 |
| `controller.events[39].detail.isolation.applied` | Yes |
| `controller.events[39].detail.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.events[39].detail.isolation.probe.authority_open_denied` | Yes |
| `controller.events[39].detail.isolation.probe.network_denied` | Yes |
| `controller.events[39].detail.isolation.probe.process_inspection_denied` | Yes |
| `controller.events[39].detail.isolation.probe.spawn_denied` | Yes |
| `controller.events[39].detail.isolation.probe.workspace_open_denied` | Yes |
| `controller.events[39].detail.pid` | 84 |
| `controller.events[39].detail.restart` | Yes |
| Recorded event · `controller.events[39].event` | CANDIDATE_STARTED |
| `controller.events[39].monotonic_ns` | 40081805560796 |
| Logical tick · `controller.events[39].tick` | 15 |
| `controller.events[40].detail.args` | No entries |
| `controller.events[40].detail.op` | status |
| Recorded event · `controller.events[40].event` | BROKER_REQUEST |
| `controller.events[40].monotonic_ns` | 40081807136467 |
| Logical tick · `controller.events[40].tick` | 16 |
| `controller.events[41].detail.args` | No entries |
| `controller.events[41].detail.op` | status |
| Recorded event · `controller.events[41].event` | BROKER_REQUEST |
| `controller.events[41].monotonic_ns` | 40081814989708 |
| Logical tick · `controller.events[41].tick` | 17 |
| `controller.events[42].detail.args` | No entries |
| `controller.events[42].detail.op` | status |
| Recorded event · `controller.events[42].event` | BROKER_REQUEST |
| `controller.events[42].monotonic_ns` | 40081822668484 |
| Logical tick · `controller.events[42].tick` | 18 |
| Agreement identity · `controller.events[43].detail.args.agreement_id` | proposal-002 |
| `controller.events[43].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[43].detail.args.lot_id` | DL-100.L002 |
| `controller.events[43].detail.op` | reserve |
| Recorded event · `controller.events[43].event` | BROKER_REQUEST |
| `controller.events[43].monotonic_ns` | 40081829118073 |
| Logical tick · `controller.events[43].tick` | 19 |
| `controller.events[44].detail.key` | proposal-002.DL-100.L002.A1 |
| `controller.events[44].detail.slot` | COMPAT-A.W0 |
| Recorded status · `controller.events[44].detail.status` | RESERVED |
| Recorded event · `controller.events[44].event` | CAPACITY_RESERVED |
| `controller.events[44].monotonic_ns` | 40081841107245 |
| Logical tick · `controller.events[44].tick` | 19 |
| Agreement identity · `controller.events[45].detail.args.agreement_id` | proposal-002 |
| `controller.events[45].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[45].detail.args.lot_id` | DL-100.L002 |
| `controller.events[45].detail.args.supersedes` | Not recorded |
| `controller.events[45].detail.op` | produce |
| Recorded event · `controller.events[45].event` | BROKER_REQUEST |
| `controller.events[45].monotonic_ns` | 40081841588292 |
| Logical tick · `controller.events[45].tick` | 20 |
| `controller.events[46].detail.byte_count` | 196072 |
| `controller.events[46].detail.payload_sha256` | 2e63a949e801d0e6be8a30ba8f2b0865827f6bd6886001ffc580419e4b6b6709 |
| `controller.events[46].detail.production_id` | proposal-002.DL-100.L002.A1 |
| Required quantity · `controller.events[46].detail.quantity` | 500 |
| Recorded event · `controller.events[46].event` | PRODUCT_MATERIALIZED |
| `controller.events[46].monotonic_ns` | 40081879525044 |
| Logical tick · `controller.events[46].tick` | 20 |
| `controller.events[47].detail.args.production_id` | proposal-002.DL-100.L002.A1 |
| `controller.events[47].detail.op` | transfer |
| Recorded event · `controller.events[47].event` | BROKER_REQUEST |
| `controller.events[47].monotonic_ns` | 40081880087364 |
| Logical tick · `controller.events[47].tick` | 21 |
| `controller.events[48].detail.byte_count` | 196072 |
| `controller.events[48].detail.delivery_id` | proposal-002.DL-100.L002.A1.D |
| `controller.events[48].detail.produced_sha256` | 2e63a949e801d0e6be8a30ba8f2b0865827f6bd6886001ffc580419e4b6b6709 |
| `controller.events[48].detail.production_id` | proposal-002.DL-100.L002.A1 |
| `controller.events[48].detail.received_sha256` | 2e63a949e801d0e6be8a30ba8f2b0865827f6bd6886001ffc580419e4b6b6709 |
| Recorded event · `controller.events[48].event` | PRODUCT_TRANSFERRED |
| `controller.events[48].monotonic_ns` | 40081889233939 |
| Logical tick · `controller.events[48].tick` | 21 |
| `controller.events[49].detail.args.delivery_id` | proposal-002.DL-100.L002.A1.D |
| `controller.events[49].detail.op` | inspect |
| Recorded event · `controller.events[49].event` | BROKER_REQUEST |
| `controller.events[49].monotonic_ns` | 40081889542024 |
| Logical tick · `controller.events[49].tick` | 22 |
| `controller.events[50].detail.accepted_units` | 500 |
| `controller.events[50].detail.delivery_id` | proposal-002.DL-100.L002.A1.D |
| Recorded status · `controller.events[50].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[50].detail.timely` | Yes |
| Recorded event · `controller.events[50].event` | RECIPIENT_INSPECTED |
| `controller.events[50].monotonic_ns` | 40081925545264 |
| Logical tick · `controller.events[50].tick` | 22 |
| `controller.events[51].detail.args` | No entries |
| `controller.events[51].detail.op` | status |
| Recorded event · `controller.events[51].event` | BROKER_REQUEST |
| `controller.events[51].monotonic_ns` | 40081926041624 |
| Logical tick · `controller.events[51].tick` | 23 |
| Agreement identity · `controller.events[52].detail.args.agreement_id` | proposal-002 |
| `controller.events[52].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[52].detail.args.lot_id` | DL-100.L003 |
| `controller.events[52].detail.op` | reserve |
| Recorded event · `controller.events[52].event` | BROKER_REQUEST |
| `controller.events[52].monotonic_ns` | 40081935691380 |
| Logical tick · `controller.events[52].tick` | 24 |
| `controller.events[53].detail.key` | proposal-002.DL-100.L003.A1 |
| `controller.events[53].detail.slot` | COMPAT-A.W0 |
| Recorded status · `controller.events[53].detail.status` | RESERVED |
| Recorded event · `controller.events[53].event` | CAPACITY_RESERVED |
| `controller.events[53].monotonic_ns` | 40081947152754 |
| Logical tick · `controller.events[53].tick` | 24 |
| Agreement identity · `controller.events[54].detail.args.agreement_id` | proposal-002 |
| `controller.events[54].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[54].detail.args.lot_id` | DL-100.L003 |
| `controller.events[54].detail.args.supersedes` | Not recorded |
| `controller.events[54].detail.op` | produce |
| Recorded event · `controller.events[54].event` | BROKER_REQUEST |
| `controller.events[54].monotonic_ns` | 40081947562363 |
| Logical tick · `controller.events[54].tick` | 25 |
| `controller.events[55].detail.byte_count` | 39772 |
| `controller.events[55].detail.payload_sha256` | 0441a60722a81619d368744c6724e3c089fd7ae9c5fdcefdfcf868acafc2518a |
| `controller.events[55].detail.production_id` | proposal-002.DL-100.L003.A1 |
| Required quantity · `controller.events[55].detail.quantity` | 100 |
| Recorded event · `controller.events[55].event` | PRODUCT_MATERIALIZED |
| `controller.events[55].monotonic_ns` | 40081975843370 |
| Logical tick · `controller.events[55].tick` | 25 |
| `controller.events[56].detail.args.production_id` | proposal-002.DL-100.L003.A1 |
| `controller.events[56].detail.op` | transfer |
| Recorded event · `controller.events[56].event` | BROKER_REQUEST |
| `controller.events[56].monotonic_ns` | 40081976343356 |
| Logical tick · `controller.events[56].tick` | 26 |
| `controller.events[57].detail.byte_count` | 39772 |
| `controller.events[57].detail.delivery_id` | proposal-002.DL-100.L003.A1.D |
| `controller.events[57].detail.produced_sha256` | 0441a60722a81619d368744c6724e3c089fd7ae9c5fdcefdfcf868acafc2518a |
| `controller.events[57].detail.production_id` | proposal-002.DL-100.L003.A1 |
| `controller.events[57].detail.received_sha256` | 0441a60722a81619d368744c6724e3c089fd7ae9c5fdcefdfcf868acafc2518a |
| Recorded event · `controller.events[57].event` | PRODUCT_TRANSFERRED |
| `controller.events[57].monotonic_ns` | 40081989484844 |
| Logical tick · `controller.events[57].tick` | 26 |
| `controller.events[58].detail.args.delivery_id` | proposal-002.DL-100.L003.A1.D |
| `controller.events[58].detail.op` | inspect |
| Recorded event · `controller.events[58].event` | BROKER_REQUEST |
| `controller.events[58].monotonic_ns` | 40081989822355 |
| Logical tick · `controller.events[58].tick` | 27 |
| `controller.events[59].detail.accepted_units` | 100 |
| `controller.events[59].detail.delivery_id` | proposal-002.DL-100.L003.A1.D |
| Recorded status · `controller.events[59].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[59].detail.timely` | Yes |
| Recorded event · `controller.events[59].event` | RECIPIENT_INSPECTED |
| `controller.events[59].monotonic_ns` | 40082000515718 |
| Logical tick · `controller.events[59].tick` | 27 |
| `controller.events[60].detail.args` | No entries |
| `controller.events[60].detail.op` | status |
| Recorded event · `controller.events[60].event` | BROKER_REQUEST |
| `controller.events[60].monotonic_ns` | 40082001053551 |
| Logical tick · `controller.events[60].tick` | 28 |
| Agreement identity · `controller.events[61].detail.args.agreement_id` | proposal-002 |
| `controller.events[61].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[61].detail.args.lot_id` | DL-200.L001 |
| `controller.events[61].detail.op` | reserve |
| Recorded event · `controller.events[61].event` | BROKER_REQUEST |
| `controller.events[61].monotonic_ns` | 40082009711778 |
| Logical tick · `controller.events[61].tick` | 29 |
| `controller.events[62].detail.key` | proposal-002.DL-200.L001.A1 |
| `controller.events[62].detail.slot` | COMPAT-B.W0 |
| Recorded status · `controller.events[62].detail.status` | RESERVED |
| Recorded event · `controller.events[62].event` | CAPACITY_RESERVED |
| `controller.events[62].monotonic_ns` | 40082017792542 |
| Logical tick · `controller.events[62].tick` | 29 |
| Agreement identity · `controller.events[63].detail.args.agreement_id` | proposal-002 |
| `controller.events[63].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[63].detail.args.lot_id` | DL-200.L001 |
| `controller.events[63].detail.args.supersedes` | Not recorded |
| `controller.events[63].detail.op` | produce |
| Recorded event · `controller.events[63].event` | BROKER_REQUEST |
| `controller.events[63].monotonic_ns` | 40082018161510 |
| Logical tick · `controller.events[63].tick` | 30 |
| `controller.events[64].detail.byte_count` | 195960 |
| `controller.events[64].detail.payload_sha256` | 465cacbd8119033bdcc2f3b7011489bedbac51510cd46ce8bae8de45fe96ca83 |
| `controller.events[64].detail.production_id` | proposal-002.DL-200.L001.A1 |
| Required quantity · `controller.events[64].detail.quantity` | 500 |
| Recorded event · `controller.events[64].event` | PRODUCT_MATERIALIZED |
| `controller.events[64].monotonic_ns` | 40082047212430 |
| Logical tick · `controller.events[64].tick` | 30 |
| `controller.events[65].detail.args.production_id` | proposal-002.DL-200.L001.A1 |
| `controller.events[65].detail.op` | transfer |
| Recorded event · `controller.events[65].event` | BROKER_REQUEST |
| `controller.events[65].monotonic_ns` | 40082047653527 |
| Logical tick · `controller.events[65].tick` | 31 |
| `controller.events[66].detail.byte_count` | 195960 |
| `controller.events[66].detail.delivery_id` | proposal-002.DL-200.L001.A1.D |
| `controller.events[66].detail.produced_sha256` | 465cacbd8119033bdcc2f3b7011489bedbac51510cd46ce8bae8de45fe96ca83 |
| `controller.events[66].detail.production_id` | proposal-002.DL-200.L001.A1 |
| `controller.events[66].detail.received_sha256` | 465cacbd8119033bdcc2f3b7011489bedbac51510cd46ce8bae8de45fe96ca83 |
| Recorded event · `controller.events[66].event` | PRODUCT_TRANSFERRED |
| `controller.events[66].monotonic_ns` | 40082058001469 |
| Logical tick · `controller.events[66].tick` | 31 |
| `controller.events[67].detail.args.delivery_id` | proposal-002.DL-200.L001.A1.D |
| `controller.events[67].detail.op` | inspect |
| Recorded event · `controller.events[67].event` | BROKER_REQUEST |
| `controller.events[67].monotonic_ns` | 40082058311658 |
| Logical tick · `controller.events[67].tick` | 32 |
| `controller.events[68].detail.accepted_units` | 500 |
| `controller.events[68].detail.delivery_id` | proposal-002.DL-200.L001.A1.D |
| Recorded status · `controller.events[68].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[68].detail.timely` | Yes |
| Recorded event · `controller.events[68].event` | RECIPIENT_INSPECTED |
| `controller.events[68].monotonic_ns` | 40082093353213 |
| Logical tick · `controller.events[68].tick` | 32 |
| `controller.events[69].detail.args` | No entries |
| `controller.events[69].detail.op` | status |
| Recorded event · `controller.events[69].event` | BROKER_REQUEST |
| `controller.events[69].monotonic_ns` | 40082093771726 |
| Logical tick · `controller.events[69].tick` | 33 |
| Agreement identity · `controller.events[70].detail.args.agreement_id` | proposal-002 |
| `controller.events[70].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[70].detail.args.lot_id` | DL-200.L002 |
| `controller.events[70].detail.op` | reserve |
| Recorded event · `controller.events[70].event` | BROKER_REQUEST |
| `controller.events[70].monotonic_ns` | 40082104103943 |
| Logical tick · `controller.events[70].tick` | 34 |
| `controller.events[71].detail.key` | proposal-002.DL-200.L002.A1 |
| `controller.events[71].detail.slot` | COMPAT-B.W0 |
| Recorded status · `controller.events[71].detail.status` | RESERVED |
| Recorded event · `controller.events[71].event` | CAPACITY_RESERVED |
| `controller.events[71].monotonic_ns` | 40082112914891 |
| Logical tick · `controller.events[71].tick` | 34 |
| Agreement identity · `controller.events[72].detail.args.agreement_id` | proposal-002 |
| `controller.events[72].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[72].detail.args.lot_id` | DL-200.L002 |
| `controller.events[72].detail.args.supersedes` | Not recorded |
| `controller.events[72].detail.op` | produce |
| Recorded event · `controller.events[72].event` | BROKER_REQUEST |
| `controller.events[72].monotonic_ns` | 40082113241394 |
| Logical tick · `controller.events[72].tick` | 35 |
| `controller.events[73].detail.byte_count` | 117870 |
| `controller.events[73].detail.payload_sha256` | e630c235085dbdb18af91f8171e5f73e37acaa9a538f097fdf10778cde9840dc |
| `controller.events[73].detail.production_id` | proposal-002.DL-200.L002.A1 |
| Required quantity · `controller.events[73].detail.quantity` | 300 |
| Recorded event · `controller.events[73].event` | PRODUCT_MATERIALIZED |
| `controller.events[73].monotonic_ns` | 40082136714189 |
| Logical tick · `controller.events[73].tick` | 35 |
| `controller.events[74].detail.args.production_id` | proposal-002.DL-200.L002.A1 |
| `controller.events[74].detail.op` | transfer |
| Recorded event · `controller.events[74].event` | BROKER_REQUEST |
| `controller.events[74].monotonic_ns` | 40082137109776 |
| Logical tick · `controller.events[74].tick` | 36 |
| `controller.events[75].detail.byte_count` | 117870 |
| `controller.events[75].detail.delivery_id` | proposal-002.DL-200.L002.A1.D |
| `controller.events[75].detail.produced_sha256` | e630c235085dbdb18af91f8171e5f73e37acaa9a538f097fdf10778cde9840dc |
| `controller.events[75].detail.production_id` | proposal-002.DL-200.L002.A1 |
| `controller.events[75].detail.received_sha256` | e630c235085dbdb18af91f8171e5f73e37acaa9a538f097fdf10778cde9840dc |
| Recorded event · `controller.events[75].event` | PRODUCT_TRANSFERRED |
| `controller.events[75].monotonic_ns` | 40082144628861 |
| Logical tick · `controller.events[75].tick` | 36 |
| `controller.events[76].detail.args.delivery_id` | proposal-002.DL-200.L002.A1.D |
| `controller.events[76].detail.op` | inspect |
| Recorded event · `controller.events[76].event` | BROKER_REQUEST |
| `controller.events[76].monotonic_ns` | 40082144929946 |
| Logical tick · `controller.events[76].tick` | 37 |
| `controller.events[77].detail.accepted_units` | 300 |
| `controller.events[77].detail.delivery_id` | proposal-002.DL-200.L002.A1.D |
| Recorded status · `controller.events[77].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[77].detail.timely` | Yes |
| Recorded event · `controller.events[77].event` | RECIPIENT_INSPECTED |
| `controller.events[77].monotonic_ns` | 40082166712571 |
| Logical tick · `controller.events[77].tick` | 37 |
| Agreement identity · `controller.events[78].detail.args.agreement_id` | proposal-002 |
| `controller.events[78].detail.op` | settle |
| Recorded event · `controller.events[78].event` | BROKER_REQUEST |
| `controller.events[78].monotonic_ns` | 40082167181129 |
| Logical tick · `controller.events[78].tick` | 38 |
| Acceptance references · `controller.events[79].detail.acceptance_ids[0]` | proposal-002.DL-100.L001.A1.D |
| Acceptance references · `controller.events[79].detail.acceptance_ids[1]` | proposal-002.DL-100.L002.A1.D |
| Acceptance references · `controller.events[79].detail.acceptance_ids[2]` | proposal-002.DL-100.L003.A1.D |
| Acceptance references · `controller.events[79].detail.acceptance_ids[3]` | proposal-002.DL-200.L001.A1.D |
| Acceptance references · `controller.events[79].detail.acceptance_ids[4]` | proposal-002.DL-200.L002.A1.D |
| Agreement identity · `controller.events[79].detail.agreement_id` | proposal-002 |
| Recorded event · `controller.events[79].event` | ARRANGEMENT_SETTLED |
| `controller.events[79].monotonic_ns` | 40082173457606 |
| Logical tick · `controller.events[79].tick` | 38 |
| Recorded interventions · `controller.events[80].detail.interventions` | No entries |
| Recorded reason · `controller.events[80].detail.reason` | DIGITAL_PRODUCT_ACCEPTED |
| `controller.events[80].detail.searches` | No entries |
| Component verdict · `controller.events[80].detail.verdict` | Completed (`COMPLETED`) |
| Recorded event · `controller.events[80].event` | CANDIDATE_DONE |
| `controller.events[80].monotonic_ns` | 40082174266920 |
| Logical tick · `controller.events[80].tick` | 38 |
| `controller.events[81].detail.database` | participants |
| `controller.events[81].detail.sqlite[0]` | 0 |
| `controller.events[81].detail.sqlite[1]` | 0 |
| `controller.events[81].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[81].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[81].event` | DATABASE_CHECKPOINT |
| `controller.events[81].monotonic_ns` | 40082208428561 |
| Logical tick · `controller.events[81].tick` | 38 |
| `controller.events[82].detail.database` | producer |
| `controller.events[82].detail.sqlite[0]` | 0 |
| `controller.events[82].detail.sqlite[1]` | 0 |
| `controller.events[82].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[82].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[82].event` | DATABASE_CHECKPOINT |
| `controller.events[82].monotonic_ns` | 40082210472470 |
| Logical tick · `controller.events[82].tick` | 38 |
| `controller.events[83].detail.database` | receiver |
| `controller.events[83].detail.sqlite[0]` | 0 |
| `controller.events[83].detail.sqlite[1]` | 0 |
| `controller.events[83].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[83].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[83].event` | DATABASE_CHECKPOINT |
| `controller.events[83].monotonic_ns` | 40082213268657 |
| Logical tick · `controller.events[83].tick` | 38 |
| `controller.events[84].detail.database` | PRIMARY.W0 |
| `controller.events[84].detail.sqlite[0]` | 0 |
| `controller.events[84].detail.sqlite[1]` | 0 |
| `controller.events[84].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[84].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[84].event` | DATABASE_CHECKPOINT |
| `controller.events[84].monotonic_ns` | 40082214302650 |
| Logical tick · `controller.events[84].tick` | 38 |
| `controller.events[85].detail.database` | BACKUP.W0 |
| `controller.events[85].detail.sqlite[0]` | 0 |
| `controller.events[85].detail.sqlite[1]` | 0 |
| `controller.events[85].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[85].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[85].event` | DATABASE_CHECKPOINT |
| `controller.events[85].monotonic_ns` | 40082220600029 |
| Logical tick · `controller.events[85].tick` | 38 |
| `controller.events[86].detail.database` | COMPAT-A.W0 |
| `controller.events[86].detail.sqlite[0]` | 0 |
| `controller.events[86].detail.sqlite[1]` | 0 |
| `controller.events[86].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[86].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[86].event` | DATABASE_CHECKPOINT |
| `controller.events[86].monotonic_ns` | 40082225165569 |
| Logical tick · `controller.events[86].tick` | 38 |
| `controller.events[87].detail.database` | COMPAT-B.W0 |
| `controller.events[87].detail.sqlite[0]` | 0 |
| `controller.events[87].detail.sqlite[1]` | 0 |
| `controller.events[87].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[87].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[87].event` | DATABASE_CHECKPOINT |
| `controller.events[87].monotonic_ns` | 40082226180132 |
| Logical tick · `controller.events[87].tick` | 38 |
| Stable code · `controller.events[88].detail.code` | DATABASE_STATE_CHANGED |
| `controller.events[88].detail.detail` | DATABASE_STATE_CHANGED: /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1/base/runs/constructed-continuity.conventional/runtime/capacity/COMPAT-A.W0.sqlite |
| `controller.events[88].detail.message` | Durable database content changed after its retained snapshot. |
| Recorded event · `controller.events[88].event` | EXECUTION_ERROR |
| `controller.events[88].monotonic_ns` | 40082369122155 |
| Logical tick · `controller.events[88].tick` | 38 |
| Recorded event · `controller.fault_schedule[0].event` | Backup failure before reservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Trigger occurrence · `controller.fault_schedule[0].occurrence` | 1 |
| Fault target · `controller.fault_schedule[0].target` | BACKUP |
| Trigger operation · `controller.fault_schedule[0].trigger` | reserve |
| Configured value · `controller.fault_schedule[0].value` | 0 |
| Recorded event · `controller.fault_schedule[1].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.fault_schedule[1].occurrence` | 1 |
| Fault target · `controller.fault_schedule[1].target` | ANY |
| Trigger operation · `controller.fault_schedule[1].trigger` | inspect |
| Configured value · `controller.fault_schedule[1].value` | 0 |
| Recorded event · `controller.fault_schedule[2].event` | Candidate restart after acceptance (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.fault_schedule[2].occurrence` | 1 |
| Fault target · `controller.fault_schedule[2].target` | ANY |
| Trigger operation · `controller.fault_schedule[2].trigger` | inspect |
| Configured value · `controller.fault_schedule[2].value` | 0 |
| Recorded event · `controller.faults_observed[0].event` | Backup failure before reservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Trigger occurrence · `controller.faults_observed[0].occurrence` | 1 |
| Fault target · `controller.faults_observed[0].target` | BACKUP |
| Trigger operation · `controller.faults_observed[0].trigger` | reserve |
| Configured value · `controller.faults_observed[0].value` | 0 |
| Recorded event · `controller.faults_observed[1].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.faults_observed[1].occurrence` | 1 |
| Fault target · `controller.faults_observed[1].target` | ANY |
| Trigger operation · `controller.faults_observed[1].trigger` | inspect |
| Configured value · `controller.faults_observed[1].value` | 0 |
| Recorded event · `controller.faults_observed[2].event` | Candidate restart after acceptance (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.faults_observed[2].occurrence` | 1 |
| Fault target · `controller.faults_observed[2].target` | ANY |
| Trigger operation · `controller.faults_observed[2].trigger` | inspect |
| Configured value · `controller.faults_observed[2].value` | 0 |
| `controller.finished_monotonic_ns` | 40082369125981 |
| Registered fixture identity · `controller.fixture_id` | constructed-continuity |
| Uncommitted source changes present · `controller.implementation.dirty` | No |
| Exact process arguments · `controller.implementation.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Exact process arguments · `controller.implementation.environment.argv[1]` | -m |
| Exact process arguments · `controller.implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `controller.implementation.environment.argv[3]` | --language |
| Exact process arguments · `controller.implementation.environment.argv[4]` | en |
| Exact process arguments · `controller.implementation.environment.argv[5]` | experiment |
| Exact process arguments · `controller.implementation.environment.argv[6]` | --out |
| Exact process arguments · `controller.implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Operating platform · `controller.implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `controller.implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `controller.implementation.environment.sqlite_version` | 3.53.1 |
| Execution directory · `controller.implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Actual source commit · `controller.implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Preserved capacity implementation baseline · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Yes |
| `controller.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Yes |
| `controller.isolation.probe.network_denied` | Yes |
| `controller.isolation.probe.process_inspection_denied` | Yes |
| `controller.isolation.probe.spawn_denied` | Yes |
| `controller.isolation.probe.workspace_open_denied` | Yes |
| Candidate procedure · `controller.method` | conventional |
| `controller.policies_sha256` | fc701f004c83a9d4a45bc185a65c39b19b509d3ee059c10de93650513f48fae4 |
| Adaptation labor (seconds; unknown if absent) · `controller.resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `controller.resources.authority_storage_bytes_before_seal` | 30468 |
| Candidate restarts · `controller.resources.candidate_restarts` | 1 |
| Launched child processes · `controller.resources.child_processes` | 10 |
| Controller system CPU (ns) · `controller.resources.controller_cpu_system_ns` | 37726999 |
| Controller user CPU (ns) · `controller.resources.controller_cpu_user_ns` | 163732000 |
| System CPU (ns) · `controller.resources.cpu_system_ns` | 99530000 |
| User CPU (ns) · `controller.resources.cpu_user_ns` | 694082000 |
| Human interventions · `controller.resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `controller.resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `controller.resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `controller.resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `controller.resources.preparation_labor_seconds` | Not recorded |
| Requests · `controller.resources.requests` | 37 |
| Retries · `controller.resources.retries` | 0 |
| Internal service requests · `controller.resources.service_requests` | 180 |
| Recorded storage (bytes) · `controller.resources.storage_bytes` | 8476603 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `controller.resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `controller.resources.wall_ns` | 1184171770 |
| Worker restarts · `controller.resources.worker_restarts` | 1 |
| Run identity · `controller.run_id` | constructed-continuity.conventional.f189246caf |
| Schema · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 40081184954211 |
| `controller.started_utc` | 2026-11-07T00:44:43.300100+00:00 |
| `controller.state` | Execution error (`ERROR`) |
| Target verdict · `controller.target_verdict` | Execution error (`ERROR`) |
| Recorded event · `fault_schedule[0].event` | Backup failure before reservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Trigger occurrence · `fault_schedule[0].occurrence` | 1 |
| Fault target · `fault_schedule[0].target` | BACKUP |
| Trigger operation · `fault_schedule[0].trigger` | reserve |
| Configured value · `fault_schedule[0].value` | 0 |
| Recorded event · `fault_schedule[1].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `fault_schedule[1].occurrence` | 1 |
| Fault target · `fault_schedule[1].target` | ANY |
| Trigger operation · `fault_schedule[1].trigger` | inspect |
| Configured value · `fault_schedule[1].value` | 0 |
| Recorded event · `fault_schedule[2].event` | Candidate restart after acceptance (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `fault_schedule[2].occurrence` | 1 |
| Fault target · `fault_schedule[2].target` | ANY |
| Trigger operation · `fault_schedule[2].trigger` | inspect |
| Configured value · `fault_schedule[2].value` | 0 |
| Recorded event · `faults_observed[0].event` | Backup failure before reservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Trigger occurrence · `faults_observed[0].occurrence` | 1 |
| Fault target · `faults_observed[0].target` | BACKUP |
| Trigger operation · `faults_observed[0].trigger` | reserve |
| Configured value · `faults_observed[0].value` | 0 |
| Recorded event · `faults_observed[1].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `faults_observed[1].occurrence` | 1 |
| Fault target · `faults_observed[1].target` | ANY |
| Trigger operation · `faults_observed[1].trigger` | inspect |
| Configured value · `faults_observed[1].value` | 0 |
| Recorded event · `faults_observed[2].event` | Candidate restart after acceptance (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `faults_observed[2].occurrence` | 1 |
| Fault target · `faults_observed[2].target` | ANY |
| Trigger operation · `faults_observed[2].trigger` | inspect |
| Configured value · `faults_observed[2].value` | 0 |
| Registered fixture identity · `fixture_id` | constructed-continuity |
| Uncommitted source changes present · `implementation.dirty` | No |
| Exact process arguments · `implementation.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Exact process arguments · `implementation.environment.argv[1]` | -m |
| Exact process arguments · `implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `implementation.environment.argv[3]` | --language |
| Exact process arguments · `implementation.environment.argv[4]` | en |
| Exact process arguments · `implementation.environment.argv[5]` | experiment |
| Exact process arguments · `implementation.environment.argv[6]` | --out |
| Exact process arguments · `implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Operating platform · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `implementation.environment.sqlite_version` | 3.53.1 |
| Execution directory · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Actual source commit · `implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Preserved capacity implementation baseline · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `implementation.version` | 0.2.0 |
| Candidate procedure · `method` | conventional |
| Balance (synthetic SMU minor units) · `policies.buyer.balance_minor` | 30000 |
| `policies.buyer.consent_until_tick` | 800 |
| `policies.buyer.max_price_minor` | 25000 |
| Authored outside-option utility (synthetic SMU minor units) · `policies.buyer.outside_utility_minor` | 2000 |
| Participant identity · `policies.buyer.party_id` | BUYER |
| Authored value upper bound (synthetic SMU minor units) · `policies.buyer.value_max_minor` | 30000 |
| Authored value lower bound (synthetic SMU minor units) · `policies.buyer.value_min_minor` | 30000 |
| Balance (synthetic SMU minor units) · `policies.coordinator.balance_minor` | 10000 |
| `policies.coordinator.consent_until_tick` | 800 |
| `policies.coordinator.liability_limit_minor` | 10000 |
| `policies.coordinator.min_profit_minor` | 100 |
| `policies.coordinator.operating_cost_minor` | 200 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.coordinator.outside_profit_minor` | 100 |
| Participant identity · `policies.coordinator.party_id` | COORDINATOR |
| `policies.coordinator.technical_control_allowed` | Yes |
| Synthetic accounting unit · `policies.currency` | SMU |
| Balance (synthetic SMU minor units) · `policies.providers[0].balance_minor` | 40000 |
| `policies.providers[0].consent_until_tick` | 800 |
| `policies.providers[0].liability_limit_minor` | 40000 |
| `policies.providers[0].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[0].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[0].party_id` | PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 100 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 100 |
| `policies.providers[0].technical_control_allowed` | Yes |
| `policies.providers[0].unit_cost_minor` | 1 |
| Balance (synthetic SMU minor units) · `policies.providers[1].balance_minor` | 40000 |
| `policies.providers[1].consent_until_tick` | 800 |
| `policies.providers[1].liability_limit_minor` | 40000 |
| `policies.providers[1].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[1].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[1].party_id` | BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 150 |
| `policies.providers[1].rework_unit_cost_minor` | 1 |
| `policies.providers[1].setup_cost_minor` | 150 |
| `policies.providers[1].technical_control_allowed` | Yes |
| `policies.providers[1].unit_cost_minor` | 1 |
| Balance (synthetic SMU minor units) · `policies.providers[2].balance_minor` | 40000 |
| `policies.providers[2].consent_until_tick` | 800 |
| `policies.providers[2].liability_limit_minor` | 40000 |
| `policies.providers[2].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[2].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[2].party_id` | COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 200 |
| `policies.providers[2].rework_unit_cost_minor` | 1 |
| `policies.providers[2].setup_cost_minor` | 200 |
| `policies.providers[2].technical_control_allowed` | Yes |
| `policies.providers[2].unit_cost_minor` | 1 |
| Balance (synthetic SMU minor units) · `policies.providers[3].balance_minor` | 40000 |
| `policies.providers[3].consent_until_tick` | 800 |
| `policies.providers[3].liability_limit_minor` | 40000 |
| `policies.providers[3].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[3].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[3].party_id` | COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 300 |
| `policies.providers[3].rework_unit_cost_minor` | 1 |
| `policies.providers[3].setup_cost_minor` | 300 |
| `policies.providers[3].technical_control_allowed` | Yes |
| `policies.providers[3].unit_cost_minor` | 1 |
| Revision · `policies.revision` | 1 |
| Schema · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Yes |
| Balance (synthetic SMU minor units) · `policies.technical_sponsor.balance_minor` | 60000 |
| Participant identity · `policies.technical_sponsor.party_id` | TECHNICAL-SPONSOR |
| External reference pin · `reference_sha256` | 3515001b3305413676901422f8c6395fa915673f7d62833397fab94b9680718a |
| `registered_assertion.expected.accepted_units` | 1900 |
| Outcome · `registered_assertion.expected.outcome` | Demonstrated in scope (`DEMONSTRATED`) |
| `registered_assertion.expected.service_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| `registered_assertion.observed.accepted_units` | 0 |
| Outcome · `registered_assertion.observed.outcome` | Not established (`NOT_ESTABLISHED`) |
| `registered_assertion.observed.service_feasibility` | Not established (`NOT_ESTABLISHED`) |
| Assessment scope · `registered_assertion.scope` | Registered assessment assertion; it does not assert a favorable outcome or trade. |
| Recorded status · `registered_assertion.status` | Failed (`FAILED`) |
| Uncommitted source changes present · `source_version.dirty` | No |
| Exact process arguments · `source_version.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Exact process arguments · `source_version.environment.argv[1]` | -m |
| Exact process arguments · `source_version.environment.argv[2]` | continuity_economy |
| Exact process arguments · `source_version.environment.argv[3]` | --language |
| Exact process arguments · `source_version.environment.argv[4]` | en |
| Exact process arguments · `source_version.environment.argv[5]` | experiment |
| Exact process arguments · `source_version.environment.argv[6]` | --out |
| Exact process arguments · `source_version.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Operating platform · `source_version.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `source_version.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `source_version.environment.sqlite_version` | 3.53.1 |
| Execution directory · `source_version.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Actual source commit · `source_version.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Preserved capacity implementation baseline · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `source_version.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `source_version.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `source_version.version` | 0.2.0 |
| Explicit trust assumptions · `trust_assumptions[0]` | Trusted host, kernel, controller and clock (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Explicit trust assumptions · `trust_assumptions[1]` | Trusted retained synthetic authority (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Explicit trust assumptions · `trust_assumptions[2]` | Shared authorship; no third-party certification (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Explicit trust assumptions · `trust_assumptions[3]` | Semantic digital content only; physical delivery is untested (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Registered faults not triggered · `untriggered_faults` | No entries |

## Complete structured verification record

The same structured record generates both language versions. Machine keys, enum codes and literal evidence values remain unchanged; the localized sections above explain their meaning. No saved result is reused as fresh proof.

```json
{
  "accounting": {},
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "NOT_ESTABLISHED",
    "evidence_stage": "VERIFICATION_ATTEMPT",
    "target_verdict": "ERROR",
    "test_assertion": "FAILED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "NOT_ESTABLISHED",
    "service_feasibility": "NOT_ESTABLISHED"
  },
  "cohort": "base",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1",
  "evidence_sha256": {
    "evidence/capacity/BACKUP.W0.sqlite": "7a7ac2e80dde7705f93dc901ee9edb8397b9590215fcaf923ed09aadf5e6a451",
    "evidence/capacity/COMPAT-A.W0.closing": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "evidence/capacity/PRIMARY.W0.sqlite": "017cbc7ba188053893d674c36ec6eb4612ecf73f6878aed769cd286a6b751db8",
    "evidence/participants.sqlite": "c22d2cb5ec0be6b97a98254830f9449870ff0fcd1c6892986a7ed659727ee044",
    "evidence/producer.sqlite": "436abecf8e4d3a4f0beb7c022ebfaf4774ef30592b497474c849d5e73745442b",
    "evidence/receiver.sqlite": "a924e23206c1be61bc93278c5404c51d69242b912b74ac31f1c381299c5e13cf"
  },
  "failures": [],
  "fault_schedule": [
    {
      "event": "BACKUP_FAIL_BEFORE_RESERVE",
      "occurrence": 1,
      "target": "BACKUP",
      "trigger": "reserve",
      "value": 0
    },
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    },
    {
      "event": "CANDIDATE_RESTART_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "faults_observed": [
    {
      "event": "BACKUP_FAIL_BEFORE_RESERVE",
      "occurrence": 1,
      "target": "BACKUP",
      "trigger": "reserve",
      "value": 0
    },
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    },
    {
      "event": "CANDIDATE_RESTART_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "fixture_id": "constructed-continuity",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-post-review-source"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "method": "conventional",
  "per_arrangement": [],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "UNRESOLVED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNRESOLVED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "UNRESOLVED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "3515001b3305413676901422f8c6395fa915673f7d62833397fab94b9680718a",
  "registered_assertion": {
    "expected": {
      "accepted_units": 1900,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "observed": {
      "accepted_units": 0,
      "outcome": "NOT_ESTABLISHED",
      "service_feasibility": "NOT_ESTABLISHED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "FAILED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30468,
    "candidate_restarts": 1,
    "child_processes": 10,
    "controller_cpu_system_ns": 37726999,
    "controller_cpu_user_ns": 163732000,
    "cpu_system_ns": 99530000,
    "cpu_user_ns": 694082000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 37,
    "retries": 0,
    "service_requests": 180,
    "storage_bytes": 8476603,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 1184171770,
    "worker_restarts": 1
  },
  "run_id": "constructed-continuity.conventional.f189246caf",
  "safety_status": "NOT_ESTABLISHED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-post-review-source"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 0,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 0,
    "production_attempts": 0,
    "received_quantity": 0,
    "recipient_accepted_quantity": 0,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 0,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [
    {
      "code": "EXECUTION_INCOMPLETE",
      "detail": "",
      "scope": "outcome"
    },
    {
      "code": "VERIFICATION_EVIDENCE_MISSING",
      "detail": "MISSING_FILE:COMPAT-A.W0.sqlite",
      "scope": "integrity"
    }
  ],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 21265985,
    "evidence_files_read": 6,
    "wall_ns": 21298894
  },
  "verification_status": "INCOMPLETE",
  "verification_wall_ns": 21384843,
  "verifier_version": "0.2.0"
}
```
