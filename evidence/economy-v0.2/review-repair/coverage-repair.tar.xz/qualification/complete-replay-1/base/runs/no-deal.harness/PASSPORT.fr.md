# CONTINUITÉ Ω — Économie de la continuité

**Expérience de produit numérique · version 0.2.0**

Préserver un engagement grâce à une solution de continuité viable et volontairement acceptée.

**Portée : processus locaux jetables et produit numérique spécifié. Les politiques, consentements, valeurs, financements et flux SMU synthétiques sont des hypothèses et observations du modèle. Ils n’établissent ni contrats réels, ni demande, paiements, ventes, biens imprimés, apparence rendue ou qualité d’impression.**

Ce passeport présente l’évaluation consignée. Une vérification fraîche doit inspecter l’autorité conservée, le résultat durable réel et les preuves du destinataire ; ce document ne constitue jamais son oracle.

<!-- structured-result-sha256: f33be267ec38cbc3209b1b898a0b5a7d39c6e27bbeca7246640a5f479eb9a986 -->

## Trois affirmations distinctes

| Affirmation | État consigné |
| --- | --- |
| Travail numérique requis accepté dans les conditions figées | Échec (`FAILED`) |
| Faisabilité du service selon le modèle synthétique défini | Échec (`FAILED`) |
| Avantage de méthode face à des solutions compétentes | Non établi (`NOT_ESTABLISHED`) |
| Sûreté dans le modèle de défaillance éprouvé | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

## Champs d’évaluation distincts

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | Réussi (`PASSED`) |
| Verdict du composant | Aucun accord (`NO_DEAL`) |
| Stade de preuve | Exécution locale d’un produit numérique (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| État de l’affirmation évaluée | Échec (`FAILED`) |

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

## Identité, autorité et versions

| Champ | Valeur consignée |
| --- | --- |
| État des preuves d’autorité · `authority_status` | Établi uniquement pour l’exercice synthétique (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Valeur commerciale réelle · `commercial_value` | Non établi (`NOT_ESTABLISHED`) |
| Identité du contrat · `contract_id` | DIGITAL-006 |
| SHA-256 du contrat conservé · `contract_sha256` | bd92f2f86610d59ec7366f32fa71d198ddd7d847d904312ea4d1384c288827ce |
| Authenticité d’un client réel · `real_customer_authenticity` | Non établi (`NOT_ESTABLISHED`) |
| Empreinte externe de référence · `reference_sha256` | 3b73107b8a929414cff6ddb1caf727b12d1decc7fee8a756298c06b80349cbef |
| Identité de l’exécution · `run_id` | no-deal.harness.7ed2602c5e |
| Schéma · `schema` | continuity-economy/verification/v1 |
| État d’achèvement de la vérification · `verification_status` | Vérification complète (`COMPLETE`) |
| Version du vérificateur · `verifier_version` | 0.2.0 |

## Exécution et acceptation par obligation

Les quantités décrivent le stade consigné. Les tentatives refusées et corrigées restent distinctes. Une unité produite ou reçue n’est pas automatiquement acceptée. Les mesures absentes ne sont pas présentées comme nulles.

| Obligation | Destinataire | Révision | Requis | Produit | Reçu | Refusé | Accepté selon le contrat | Résultat |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 0 | 0 | 0 | 0 | Non réalisé (`UNFULFILLED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 0 | 0 | 0 | 0 | Non réalisé (`UNFULFILLED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Annulé (`CANCELLED`) |

### Obligation `DL-100`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 1100 |
| Identité de l’obligation · `obligation_id` | DL-100 |
| Résultat · `outcome` | Non réalisé (`UNFULFILLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 1100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-A |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 1100 |
| Révision · `revision` | 2 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

### Obligation `DL-200`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 800 |
| Identité de l’obligation · `obligation_id` | DL-200 |
| Résultat · `outcome` | Non réalisé (`UNFULFILLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 800 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-B |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 800 |
| Révision · `revision` | 1 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

### Obligation `DL-300`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-300 |
| Résultat · `outcome` | Annulé (`CANCELLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-C |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 0 |
| Révision · `revision` | 1 |
| État consigné · `status` | Annulé (`CANCELLED`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

## Propositions, décisions modélisées et solutions

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

Aucun enregistrement de solution n’est présent. Cette absence ne prouve ni accord accepté ni viabilité économique.

## Transferts, coûts, responsabilités et options externes modélisés

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

| Champ | Valeur consignée |
| --- | --- |
| Total des transferts acheteur (unités mineures SMU synthétiques) · `accounting.buyer_total_paid_minor` | 0 |
| Borne supérieure · `accounting.buyer_utility_interval_minor.maximum` | Non consigné |
| Borne inférieure · `accounting.buyer_utility_interval_minor.minimum` | Non consigné |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[0].final_balance_minor` | 30000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Seuil de participation modélisé couvert · `accounting.campaign[0].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[0].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[0].party_id` | BUYER |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[0].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[0].realized_profit_minor` | Non consigné |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[0].revenue_minor` | 0 |
| Rôle · `accounting.campaign[0].role` | buyer |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[1].final_balance_minor` | 10000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[1].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Seuil de participation modélisé couvert · `accounting.campaign[1].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[1].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[1].party_id` | COORDINATOR |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[1].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[1].revenue_minor` | 0 |
| Rôle · `accounting.campaign[1].role` | coordinator |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Seuil de participation modélisé couvert · `accounting.campaign[2].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[2].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[2].realized_profit_minor` | Non consigné |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[2].revenue_minor` | 0 |
| Rôle · `accounting.campaign[2].role` | technical_sponsor |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[3].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[3].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[3].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[3].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[3].party_id` | PRIMARY |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[3].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[3].revenue_minor` | 0 |
| Rôle · `accounting.campaign[3].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[4].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[4].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[4].party_id` | BACKUP |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[4].revenue_minor` | 0 |
| Rôle · `accounting.campaign[4].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[5].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[5].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[5].party_id` | COMPAT-A |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[5].revenue_minor` | 0 |
| Rôle · `accounting.campaign[5].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[6].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[6].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[6].party_id` | COMPAT-B |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[6].revenue_minor` | 0 |
| Rôle · `accounting.campaign[6].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Unité de compte synthétique · `accounting.currency` | SMU |
| Total final du registre (unités mineures SMU synthétiques) · `accounting.final_total_minor` | 260000 |
| Total initial du registre (unités mineures SMU synthétiques) · `accounting.initial_total_minor` | 260000 |
| Contrats, paiements ou demande réels · `accounting.real_contracts_payments_or_demand` | Non établi (`NOT_ESTABLISHED`) |
| Faisabilité modélisée réalisée pour l’acheteur · `accounting.realized_buyer` | Non établi (`NOT_ESTABLISHED`) |
| Portée de l’évaluation · `accounting.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Tous les coûts de correction (unités mineures SMU synthétiques) · `accounting.total_correction_cost_minor` | 0 |
| Tous les coûts engagés de campagne (unités mineures SMU synthétiques) · `accounting.total_incurred_cost_minor` | 0 |
| Tous les transferts de règlement modélisés (unités mineures SMU synthétiques) · `accounting.total_transfers_minor` | 0 |
| Transaction modélisée réglée · `accounting.trade_settled` | Non |
| Obligations acceptées · `totals.accepted_obligations` | 0 |
| Quantité acceptée selon le contrat · `totals.accepted_quantity` | 0 |
| Tentatives de livraison · `totals.delivery_attempts` | 0 |
| Unités acceptées en double · `totals.duplicate_acceptances` | 0 |
| Quantité tardive · `totals.late_quantity` | 0 |
| Quantité manquante · `totals.missing_quantity` | 1900 |
| Quantité produite · `totals.produced_quantity` | 0 |
| Tentatives de production durables · `totals.production_attempts` | 0 |
| Quantité reçue · `totals.received_quantity` | 0 |
| Unités acceptées par le composant destinataire · `totals.recipient_accepted_quantity` | 0 |
| Quantité refusée · `totals.rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `totals.rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `totals.rejection_count` | 0 |
| Obligations actives requises · `totals.required_obligations` | 2 |
| Quantité requise · `totals.required_quantity` | 1900 |
| Unités sémantiquement correctes observées à temps · `totals.timely_semantic_quantity` | 0 |
| Engagements non sûrs ou non autorisés · `totals.unsafe_or_unsupported_commitments` | 0 |

## Ressources mesurées et lacunes de comptabilisation

Les ressources de processus mesurées et les montants synthétiques configurés ont des significations différentes. Les efforts de préparation, d’intégration, d’adaptation, de vérification ou d’intervention non consignés restent inconnus. Les catégories absentes ne permettent aucune conclusion de coût complet ou de méthode moins coûteuse.

| Champ | Valeur consignée |
| --- | --- |
| Lacunes de comptabilisation · `accounting_gaps[0]` | Le travail de préparation n’a pas été mesuré (`PREPARATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[1]` | Le travail d’intégration n’a pas été mesuré (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[2]` | Le travail d’adaptation n’a pas été mesuré (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[3]` | Le travail humain de vérification n’a pas été mesuré (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[4]` | Les tarifs monétaires n’ont pas été mesurés (`MONETARY_RATES_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Travail d’adaptation (secondes ; inconnu si absent) · `resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `resources.authority_storage_bytes_before_seal` | 30037 |
| Redémarrages du candidat · `resources.candidate_restarts` | 0 |
| Processus enfants lancés · `resources.child_processes` | 8 |
| Processeur système du contrôleur (ns) · `resources.controller_cpu_system_ns` | 25653999 |
| Processeur utilisateur du contrôleur (ns) · `resources.controller_cpu_user_ns` | 25098000 |
| Processeur système (ns) · `resources.cpu_system_ns` | 84384999 |
| Processeur utilisateur (ns) · `resources.cpu_user_ns` | 258642000 |
| Interventions humaines · `resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `resources.requests` | 1 |
| Nouvelles tentatives · `resources.retries` | 0 |
| Requêtes internes aux services · `resources.service_requests` | 22 |
| Stockage consigné (octets) · `resources.storage_bytes` | 1216202 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `resources.wall_ns` | 488016666 |
| Redémarrages des services · `resources.worker_restarts` | 0 |
| Temps processeur (ns) · `verification_resources.cpu_ns` | 48340620 |
| Fichiers de preuve examinés · `verification_resources.evidence_files_read` | 7 |
| Durée écoulée (ns) · `verification_resources.wall_ns` | 48353870 |

## Échecs et contre-exemples observés

Aucune entrée d’échec n’a été consignée dans cette évaluation. Il s’agit de preuves bornées, non d’une démonstration générale.

## Preuves absentes et affirmations non établies

Aucune entrée non résolue supplémentaire n’a été consignée. Les limites de portée et de coûts inconnus restent applicables.

## Références des preuves et intégrité des octets

Les empreintes identifient les octets. Elles n’authentifient pas les instructions réelles d’un client, n’établissent pas l’exhaustivité des sources et ne remplacent pas une empreinte de référence conservée séparément.

| Champ | Valeur consignée |
| --- | --- |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 5ab5361e2d26b9ead5c7ca4e73b90b2073216e5c20250efc18f7f3da3ff7475a |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | 5eec5e5d052b3cefbbc66685876b09deda96c4cbded2ac1603de8019b002b9d5 |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | 81eae7c2280fb5bfa4e694f05358f97aef347a8b5c921ee270bd8a08f8d5d212 |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | f3905223cece0ce9a35f014af22fb3fea530f6b77e8e3570549ebe863b3c5694 |
| `evidence_sha256.evidence/participants.sqlite` | 19afc0c6d9c09e57e6e2907cc82447840b3ae14a1178ec0bf5dfff5390672331 |
| `evidence_sha256.evidence/producer.sqlite` | e9f483ffbd1c40b576fe0bbc838bf13eaa17c9fa245253fe3222c5e31923341a |
| `evidence_sha256.evidence/receiver.sqlite` | 291089ae3aa49fd36e82639ffc8a8e4cbeca95a7025b7ca4e685de162108bfde |
| SHA-256 du résultat structuré · `structured_result_sha256` | f33be267ec38cbc3209b1b898a0b5a7d39c6e27bbeca7246640a5f479eb9a986 |

## Exécution, pannes, commandes et provenance consignées

Les identifiants stables, commandes exactes, chemins et diagnostics machine originaux sont conservés littéralement. Ce sont des données, non des preuves d’acceptation supplémentaires. La confiance dans les sources et l’hôte est explicitée dans l’architecture et le modèle de menace.

| Champ | Valeur consignée |
| --- | --- |
| `authority_dir` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1/base/authorities/no-deal.harness |
| Cohorte d’expérience · `cohort` | base |
| `contract.allow_split` | Oui |
| `contract.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | PRIMARY-HOST |
| `contract.blocked_dependencies[1]` | BACKUP-HOST |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Cohorte d’expérience · `contract.cohort` | base |
| Identité du contrat · `contract.contract_id` | DIGITAL-006 |
| `contract.cutoff_sequence` | 5 |
| Échéance logique · `contract.deadline_tick` | 500 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-001 |
| Programme de pannes préenregistré · `contract.fault_schedule` | Aucune entrée |
| Identité du cas préenregistré · `contract.fixture_id` | no-deal |
| `contract.lease_ticks` | 20 |
| `contract.lot_size` | 500 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Échéance logique · `contract.obligations[0].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[0].obligation_id` | DL-100 |
| Quantité requise · `contract.obligations[0].quantity` | 1100 |
| Destinataire · `contract.obligations[0].recipient` | RECIPIENT-A |
| Révision · `contract.obligations[0].revision` | 2 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[0].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[0].spec.lot` | BATCH-20261106 |
| `contract.obligations[0].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[0].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[0].spec.serial_prefix` | DL-100- |
| `contract.obligations[0].spec.sku` | KIT-DL-100 |
| État consigné · `contract.obligations[0].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[1].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[1].obligation_id` | DL-200 |
| Quantité requise · `contract.obligations[1].quantity` | 800 |
| Destinataire · `contract.obligations[1].recipient` | RECIPIENT-B |
| Révision · `contract.obligations[1].revision` | 1 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[1].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[1].spec.lot` | BATCH-20261106 |
| `contract.obligations[1].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[1].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[1].spec.serial_prefix` | DL-200- |
| `contract.obligations[1].spec.sku` | KIT-DL-200 |
| État consigné · `contract.obligations[1].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[2].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[2].obligation_id` | DL-300 |
| Quantité requise · `contract.obligations[2].quantity` | 100 |
| Destinataire · `contract.obligations[2].recipient` | RECIPIENT-C |
| Révision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[2].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[2].spec.lot` | BATCH-20261106 |
| `contract.obligations[2].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[2].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[2].spec.serial_prefix` | DL-300- |
| `contract.obligations[2].spec.sku` | KIT-DL-300 |
| État consigné · `contract.obligations[2].status` | Annulé (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 800 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | PRIMARY-HOST |
| `contract.providers[0].permissions.disclosure` | Oui |
| `contract.providers[0].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[0].provider_id` | PRIMARY |
| Rôle · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 2400 |
| `contract.providers[0].windows[0].end` | 800 |
| `contract.providers[0].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[0].windows[0].window_id` | W0 |
| `contract.providers[1].dependency` | BACKUP-HOST |
| `contract.providers[1].permissions.disclosure` | Oui |
| `contract.providers[1].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[1].provider_id` | BACKUP |
| Rôle · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 2400 |
| `contract.providers[1].windows[0].end` | 800 |
| `contract.providers[1].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[1].windows[0].window_id` | W0 |
| `contract.providers[2].dependency` | COMPAT-A-HOST |
| `contract.providers[2].permissions.disclosure` | Oui |
| `contract.providers[2].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[2].provider_id` | COMPAT-A |
| Rôle · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 400 |
| `contract.providers[2].windows[0].end` | 800 |
| `contract.providers[2].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[2].windows[0].window_id` | W0 |
| `contract.providers[3].dependency` | COMPAT-B-HOST |
| `contract.providers[3].permissions.disclosure` | Oui |
| `contract.providers[3].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[3].provider_id` | COMPAT-B |
| Rôle · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 400 |
| `contract.providers[3].windows[0].end` | 800 |
| `contract.providers[3].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[3].windows[0].window_id` | W0 |
| Révision · `contract.revision` | 1 |
| `contract.revocations` | Aucune entrée |
| Identité de l’exécution · `contract.run_id` | no-deal.harness.7ed2602c5e |
| Schéma · `contract.schema` | continuity-economy/contract/v1 |
| Graine consignée · `contract.seed` | 706 |
| `contract.source_complete` | Oui |
| Échéance logique · `contract.source_events[0].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[0].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[0].obligation.quantity` | 1000 |
| Destinataire · `contract.source_events[0].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Obsolete instruction. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Instruction périmée. |
| `contract.source_events[0].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[0].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[0].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[0].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[0].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[0].obligation_id` | DL-100 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Échéance logique · `contract.source_events[1].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[1].obligation.obligation_id` | DL-200 |
| Quantité requise · `contract.source_events[1].obligation.quantity` | 800 |
| Destinataire · `contract.source_events[1].obligation.recipient` | RECIPIENT-B |
| Révision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[1].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[1].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[1].obligation.spec.serial_prefix` | DL-200- |
| `contract.source_events[1].obligation.spec.sku` | KIT-DL-200 |
| État consigné · `contract.source_events[1].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[1].obligation_id` | DL-200 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Échéance logique · `contract.source_events[2].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[2].obligation.obligation_id` | DL-300 |
| Quantité requise · `contract.source_events[2].obligation.quantity` | 100 |
| Destinataire · `contract.source_events[2].obligation.recipient` | RECIPIENT-C |
| Révision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[2].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[2].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[2].obligation.spec.serial_prefix` | DL-300- |
| `contract.source_events[2].obligation.spec.sku` | KIT-DL-300 |
| État consigné · `contract.source_events[2].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[2].obligation_id` | DL-300 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Échéance logique · `contract.source_events[3].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[3].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[3].obligation.quantity` | 1100 |
| Destinataire · `contract.source_events[3].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[3].obligation.revision` | 2 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[3].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[3].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[3].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[3].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[3].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[3].obligation_id` | DL-100 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | AMEND |
| Identité de l’obligation · `contract.source_events[4].obligation_id` | DL-300 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | CANCEL |
| `contract.source_id` | AUTHORED-DIGITAL-EVENTS |
| Empreintes des octets sources · `contract.source_sha256` | 8d6a71fd1c26021120a5283bd7cf3eb7812b5c34ae6a4da3eec94dceaf8f7b81 |
| Horloge de départ (ns) · `contract.start_ns` | 40091358903318 |
| Échéance en temps écoulé (ms) · `contract.wall_deadline_ms` | 60000 |
| `controller.capacity_databases[0].path` | evidence/capacity/PRIMARY.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[0].provider_id` | PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Identité de la fenêtre de capacité · `controller.capacity_databases[0].window_id` | W0 |
| `controller.capacity_databases[1].path` | evidence/capacity/BACKUP.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[1].provider_id` | BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[1].window_id` | W0 |
| `controller.capacity_databases[2].path` | evidence/capacity/COMPAT-A.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[2].provider_id` | COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[2].window_id` | W0 |
| `controller.capacity_databases[3].path` | evidence/capacity/COMPAT-B.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[3].provider_id` | COMPAT-B |
| `controller.capacity_databases[3].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[3].window_id` | W0 |
| `controller.clock_tick` | 1 |
| Cohorte d’expérience · `controller.cohort` | base |
| SHA-256 du contrat conservé · `controller.contract_sha256` | bd92f2f86610d59ec7366f32fa71d198ddd7d847d904312ea4d1384c288827ce |
| `controller.db_snapshots.evidence/capacity/BACKUP.W0.sqlite` | d9adc1379864a09ba598da15c479a3e750cfd45e7a75b679a54182ffe32613e1 |
| `controller.db_snapshots.evidence/capacity/COMPAT-A.W0.sqlite` | eaeaf7f1225bddd9feb81504421dc0daacd226f19126d76475a214d9688e97f8 |
| `controller.db_snapshots.evidence/capacity/COMPAT-B.W0.sqlite` | 2d1a6fb825e59ed694de26c935ca09155f20476919de39261e0d2cc8d718400c |
| `controller.db_snapshots.evidence/capacity/PRIMARY.W0.sqlite` | e222d3ab2961f70778a563236654583f624c3f70155376f0cf758900383ad20a |
| `controller.db_snapshots.evidence/participants.sqlite` | 2b91059a5b6df10416b3741b6d8c8de1c7a6e0f4982fb08e67fe09713fd04cbc |
| `controller.db_snapshots.evidence/producer.sqlite` | 934854c64061aad78942f266da683124fb85c305406cfa57be89d9b25e8997de |
| `controller.db_snapshots.evidence/receiver.sqlite` | 41d9ce3372cf568b2b2402bf6ada0be2e107965f08856a0790c9f4979c0428b9 |
| `controller.errors` | Aucune entrée |
| `controller.events[0].detail.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| Empreinte externe de référence · `controller.events[0].detail.reference_sha256` | 3b73107b8a929414cff6ddb1caf727b12d1decc7fee8a756298c06b80349cbef |
| Graine consignée · `controller.events[0].detail.seed` | 706 |
| Événement consigné · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 40091384061184 |
| Instant logique · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 187 |
| `controller.events[1].detail.restart` | Non |
| `controller.events[1].detail.service` | participants |
| Événement consigné · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 40091441330619 |
| Instant logique · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 188 |
| `controller.events[2].detail.restart` | Non |
| `controller.events[2].detail.service` | producer |
| Événement consigné · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 40091487009265 |
| Instant logique · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 189 |
| `controller.events[3].detail.restart` | Non |
| `controller.events[3].detail.service` | receiver |
| Événement consigné · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 40091538228296 |
| Instant logique · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 190 |
| Identité du fournisseur · `controller.events[4].detail.provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[4].detail.window_id` | W0 |
| Événement consigné · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 40091572585980 |
| Instant logique · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 191 |
| Identité du fournisseur · `controller.events[5].detail.provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[5].detail.window_id` | W0 |
| Événement consigné · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 40091608326149 |
| Instant logique · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 192 |
| Identité du fournisseur · `controller.events[6].detail.provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[6].detail.window_id` | W0 |
| Événement consigné · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 40091641987184 |
| Instant logique · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 193 |
| Identité du fournisseur · `controller.events[7].detail.provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[7].detail.window_id` | W0 |
| Événement consigné · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 40091678195901 |
| Instant logique · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.affected[0]` | BACKUP.W0 |
| `controller.events[8].detail.dependency` | BACKUP-HOST |
| Événement consigné · `controller.events[8].event` | DEPENDENCY_DISABLED |
| `controller.events[8].monotonic_ns` | 40091679446652 |
| Instant logique · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.affected[0]` | PRIMARY.W0 |
| `controller.events[9].detail.dependency` | PRIMARY-HOST |
| Événement consigné · `controller.events[9].event` | DEPENDENCY_DISABLED |
| `controller.events[9].monotonic_ns` | 40091680389808 |
| Instant logique · `controller.events[9].tick` | 0 |
| `controller.events[10].detail.isolation.applied` | Oui |
| `controller.events[10].detail.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.events[10].detail.isolation.probe.authority_open_denied` | Oui |
| `controller.events[10].detail.isolation.probe.network_denied` | Oui |
| `controller.events[10].detail.isolation.probe.process_inspection_denied` | Oui |
| `controller.events[10].detail.isolation.probe.spawn_denied` | Oui |
| `controller.events[10].detail.isolation.probe.workspace_open_denied` | Oui |
| `controller.events[10].detail.pid` | 194 |
| `controller.events[10].detail.restart` | Non |
| Événement consigné · `controller.events[10].event` | CANDIDATE_STARTED |
| `controller.events[10].monotonic_ns` | 40091725185950 |
| Instant logique · `controller.events[10].tick` | 0 |
| `controller.events[11].detail.args` | Aucune entrée |
| `controller.events[11].detail.op` | status |
| Événement consigné · `controller.events[11].event` | BROKER_REQUEST |
| `controller.events[11].monotonic_ns` | 40091726648571 |
| Instant logique · `controller.events[11].tick` | 1 |
| `controller.events[12].detail.measurement_kind` | Mesure déclarée par le candidat (`CANDIDATE_REPORTED`) |
| `controller.events[12].detail.pid` | 194 |
| `controller.events[12].detail.report.assignment_domain` | 32 |
| `controller.events[12].detail.report.candidate_elapsed_ns` | 1015255 |
| `controller.events[12].detail.report.capacity_prunes` | 2 |
| `controller.events[12].detail.report.complete_assignments_observed` | 0 |
| `controller.events[12].detail.report.exhaustive_within_declared_domain` | Oui |
| `controller.events[12].detail.report.feasible_assignments` | 0 |
| `controller.events[12].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Procédure candidate · `controller.events[12].detail.report.method` | harness |
| `controller.events[12].detail.report.partial_nodes_observed` | 1 |
| `controller.events[12].detail.report.participant_prunes` | 0 |
| `controller.events[12].detail.report.price_prunes` | 0 |
| Événement consigné · `controller.events[12].event` | CANDIDATE_PLANNING |
| `controller.events[12].monotonic_ns` | 40091731600155 |
| Instant logique · `controller.events[12].tick` | 1 |
| Interventions consignées · `controller.events[13].detail.interventions` | Aucune entrée |
| Motif consigné · `controller.events[13].detail.reason` | NO_CAPACITY_ARRANGEMENT |
| `controller.events[13].detail.searches[0].assignment_domain` | 32 |
| `controller.events[13].detail.searches[0].candidate_elapsed_ns` | 1015255 |
| `controller.events[13].detail.searches[0].capacity_prunes` | 2 |
| `controller.events[13].detail.searches[0].complete_assignments_observed` | 0 |
| `controller.events[13].detail.searches[0].exhaustive_within_declared_domain` | Oui |
| `controller.events[13].detail.searches[0].feasible_assignments` | 0 |
| `controller.events[13].detail.searches[0].funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Procédure candidate · `controller.events[13].detail.searches[0].method` | harness |
| `controller.events[13].detail.searches[0].partial_nodes_observed` | 1 |
| `controller.events[13].detail.searches[0].participant_prunes` | 0 |
| `controller.events[13].detail.searches[0].price_prunes` | 0 |
| Verdict du composant · `controller.events[13].detail.verdict` | Aucun accord (`NO_DEAL`) |
| Événement consigné · `controller.events[13].event` | CANDIDATE_DONE |
| `controller.events[13].monotonic_ns` | 40091731657893 |
| Instant logique · `controller.events[13].tick` | 1 |
| `controller.events[14].detail.database` | participants |
| `controller.events[14].detail.sqlite[0]` | 0 |
| `controller.events[14].detail.sqlite[1]` | 0 |
| `controller.events[14].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[14].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[14].event` | DATABASE_CHECKPOINT |
| `controller.events[14].monotonic_ns` | 40091741638649 |
| Instant logique · `controller.events[14].tick` | 1 |
| `controller.events[15].detail.database` | producer |
| `controller.events[15].detail.sqlite[0]` | 0 |
| `controller.events[15].detail.sqlite[1]` | 0 |
| `controller.events[15].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[15].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[15].event` | DATABASE_CHECKPOINT |
| `controller.events[15].monotonic_ns` | 40091743071265 |
| Instant logique · `controller.events[15].tick` | 1 |
| `controller.events[16].detail.database` | receiver |
| `controller.events[16].detail.sqlite[0]` | 0 |
| `controller.events[16].detail.sqlite[1]` | 0 |
| `controller.events[16].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[16].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[16].event` | DATABASE_CHECKPOINT |
| `controller.events[16].monotonic_ns` | 40091744350789 |
| Instant logique · `controller.events[16].tick` | 1 |
| `controller.events[17].detail.database` | PRIMARY.W0 |
| `controller.events[17].detail.sqlite[0]` | 0 |
| `controller.events[17].detail.sqlite[1]` | 0 |
| `controller.events[17].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[17].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[17].event` | DATABASE_CHECKPOINT |
| `controller.events[17].monotonic_ns` | 40091745324350 |
| Instant logique · `controller.events[17].tick` | 1 |
| `controller.events[18].detail.database` | BACKUP.W0 |
| `controller.events[18].detail.sqlite[0]` | 0 |
| `controller.events[18].detail.sqlite[1]` | 0 |
| `controller.events[18].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[18].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[18].event` | DATABASE_CHECKPOINT |
| `controller.events[18].monotonic_ns` | 40091746562161 |
| Instant logique · `controller.events[18].tick` | 1 |
| `controller.events[19].detail.database` | COMPAT-A.W0 |
| `controller.events[19].detail.sqlite[0]` | 0 |
| `controller.events[19].detail.sqlite[1]` | 0 |
| `controller.events[19].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[19].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[19].event` | DATABASE_CHECKPOINT |
| `controller.events[19].monotonic_ns` | 40091747710316 |
| Instant logique · `controller.events[19].tick` | 1 |
| `controller.events[20].detail.database` | COMPAT-B.W0 |
| `controller.events[20].detail.sqlite[0]` | 0 |
| `controller.events[20].detail.sqlite[1]` | 0 |
| `controller.events[20].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[20].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[20].event` | DATABASE_CHECKPOINT |
| `controller.events[20].monotonic_ns` | 40091748991213 |
| Instant logique · `controller.events[20].tick` | 1 |
| `controller.events[21].detail.databases` | 7 |
| `controller.events[21].detail.snapshot_method` | SQLITE_BACKUP_DELETE_FULL_LOGICAL_DIGEST |
| Événement consigné · `controller.events[21].event` | EVIDENCE_FINALIZED |
| `controller.events[21].monotonic_ns` | 40091846951411 |
| Instant logique · `controller.events[21].tick` | 1 |
| Programme de pannes préenregistré · `controller.fault_schedule` | Aucune entrée |
| Pannes effectivement observées · `controller.faults_observed` | Aucune entrée |
| `controller.finished_monotonic_ns` | 40091846954406 |
| Identité du cas préenregistré · `controller.fixture_id` | no-deal |
| Modifications sources non consignées présentes · `controller.implementation.dirty` | Non |
| Arguments exacts du processus · `controller.implementation.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Arguments exacts du processus · `controller.implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `controller.implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `controller.implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `controller.implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `controller.implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `controller.implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `controller.implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Plateforme d’exécution · `controller.implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `controller.implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `controller.implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `controller.implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `controller.implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Oui |
| `controller.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Oui |
| `controller.isolation.probe.network_denied` | Oui |
| `controller.isolation.probe.process_inspection_denied` | Oui |
| `controller.isolation.probe.spawn_denied` | Oui |
| `controller.isolation.probe.workspace_open_denied` | Oui |
| Procédure candidate · `controller.method` | harness |
| `controller.policies_sha256` | aec5d1e78061188f95f835bb9ccb752d4522ca5592f62a9e436543c7f6af107f |
| Travail d’adaptation (secondes ; inconnu si absent) · `controller.resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `controller.resources.authority_storage_bytes_before_seal` | 30037 |
| Redémarrages du candidat · `controller.resources.candidate_restarts` | 0 |
| Processus enfants lancés · `controller.resources.child_processes` | 8 |
| Processeur système du contrôleur (ns) · `controller.resources.controller_cpu_system_ns` | 25653999 |
| Processeur utilisateur du contrôleur (ns) · `controller.resources.controller_cpu_user_ns` | 25098000 |
| Processeur système (ns) · `controller.resources.cpu_system_ns` | 84384999 |
| Processeur utilisateur (ns) · `controller.resources.cpu_user_ns` | 258642000 |
| Interventions humaines · `controller.resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `controller.resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `controller.resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `controller.resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `controller.resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `controller.resources.requests` | 1 |
| Nouvelles tentatives · `controller.resources.retries` | 0 |
| Requêtes internes aux services · `controller.resources.service_requests` | 22 |
| Stockage consigné (octets) · `controller.resources.storage_bytes` | 1216202 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `controller.resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `controller.resources.wall_ns` | 488016666 |
| Redémarrages des services · `controller.resources.worker_restarts` | 0 |
| Identité de l’exécution · `controller.run_id` | no-deal.harness.7ed2602c5e |
| Schéma · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 40091358937740 |
| `controller.started_utc` | 2026-11-07T00:44:53.477529+00:00 |
| `controller.state` | Vérification complète (`COMPLETE`) |
| Verdict du composant · `controller.target_verdict` | Aucun accord (`NO_DEAL`) |
| Programme de pannes préenregistré · `fault_schedule` | Aucune entrée |
| Pannes effectivement observées · `faults_observed` | Aucune entrée |
| Identité du cas préenregistré · `fixture_id` | no-deal |
| Modifications sources non consignées présentes · `implementation.dirty` | Non |
| Arguments exacts du processus · `implementation.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Arguments exacts du processus · `implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Plateforme d’exécution · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `implementation.version` | 0.2.0 |
| Procédure candidate · `method` | harness |
| Solde (unités mineures SMU synthétiques) · `policies.buyer.balance_minor` | 30000 |
| `policies.buyer.consent_until_tick` | 800 |
| `policies.buyer.max_price_minor` | 25000 |
| Utilité d’option externe définie (unités mineures SMU synthétiques) · `policies.buyer.outside_utility_minor` | 2000 |
| Identité du participant · `policies.buyer.party_id` | BUYER |
| Borne supérieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_max_minor` | 30000 |
| Borne inférieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_min_minor` | 30000 |
| Solde (unités mineures SMU synthétiques) · `policies.coordinator.balance_minor` | 10000 |
| `policies.coordinator.consent_until_tick` | 800 |
| `policies.coordinator.liability_limit_minor` | 10000 |
| `policies.coordinator.min_profit_minor` | 100 |
| `policies.coordinator.operating_cost_minor` | 200 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.coordinator.outside_profit_minor` | 100 |
| Identité du participant · `policies.coordinator.party_id` | COORDINATOR |
| `policies.coordinator.technical_control_allowed` | Oui |
| Unité de compte synthétique · `policies.currency` | SMU |
| Solde (unités mineures SMU synthétiques) · `policies.providers[0].balance_minor` | 40000 |
| `policies.providers[0].consent_until_tick` | 800 |
| `policies.providers[0].liability_limit_minor` | 40000 |
| `policies.providers[0].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[0].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[0].party_id` | PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 100 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 100 |
| `policies.providers[0].technical_control_allowed` | Oui |
| `policies.providers[0].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[1].balance_minor` | 40000 |
| `policies.providers[1].consent_until_tick` | 800 |
| `policies.providers[1].liability_limit_minor` | 40000 |
| `policies.providers[1].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[1].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[1].party_id` | BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 150 |
| `policies.providers[1].rework_unit_cost_minor` | 2 |
| `policies.providers[1].setup_cost_minor` | 150 |
| `policies.providers[1].technical_control_allowed` | Oui |
| `policies.providers[1].unit_cost_minor` | 2 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[2].balance_minor` | 40000 |
| `policies.providers[2].consent_until_tick` | 800 |
| `policies.providers[2].liability_limit_minor` | 40000 |
| `policies.providers[2].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[2].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[2].party_id` | COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 200 |
| `policies.providers[2].rework_unit_cost_minor` | 3 |
| `policies.providers[2].setup_cost_minor` | 200 |
| `policies.providers[2].technical_control_allowed` | Oui |
| `policies.providers[2].unit_cost_minor` | 3 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[3].balance_minor` | 40000 |
| `policies.providers[3].consent_until_tick` | 800 |
| `policies.providers[3].liability_limit_minor` | 40000 |
| `policies.providers[3].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[3].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[3].party_id` | COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 300 |
| `policies.providers[3].rework_unit_cost_minor` | 3 |
| `policies.providers[3].setup_cost_minor` | 300 |
| `policies.providers[3].technical_control_allowed` | Oui |
| `policies.providers[3].unit_cost_minor` | 3 |
| Révision · `policies.revision` | 1 |
| Schéma · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Oui |
| Solde (unités mineures SMU synthétiques) · `policies.technical_sponsor.balance_minor` | 60000 |
| Identité du participant · `policies.technical_sponsor.party_id` | TECHNICAL-SPONSOR |
| Empreinte externe de référence · `reference_sha256` | 3b73107b8a929414cff6ddb1caf727b12d1decc7fee8a756298c06b80349cbef |
| `registered_assertion.expected.accepted_units` | 0 |
| Résultat · `registered_assertion.expected.outcome` | Échec (`FAILED`) |
| `registered_assertion.expected.service_feasibility` | Échec (`FAILED`) |
| `registered_assertion.observed.accepted_units` | 0 |
| Résultat · `registered_assertion.observed.outcome` | Échec (`FAILED`) |
| `registered_assertion.observed.service_feasibility` | Échec (`FAILED`) |
| Portée de l’évaluation · `registered_assertion.scope` | Assertion d’évaluation préenregistrée ; elle n’affirme ni résultat favorable ni transaction acceptable. |
| État consigné · `registered_assertion.status` | Réussi (`PASSED`) |
| Modifications sources non consignées présentes · `source_version.dirty` | Non |
| Arguments exacts du processus · `source_version.environment.argv[0]` | /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 |
| Arguments exacts du processus · `source_version.environment.argv[1]` | -m |
| Arguments exacts du processus · `source_version.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `source_version.environment.argv[3]` | --language |
| Arguments exacts du processus · `source_version.environment.argv[4]` | en |
| Arguments exacts du processus · `source_version.environment.argv[5]` | experiment |
| Arguments exacts du processus · `source_version.environment.argv[6]` | --out |
| Arguments exacts du processus · `source_version.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1 |
| Plateforme d’exécution · `source_version.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `source_version.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `source_version.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `source_version.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `source_version.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `source_version.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `source_version.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `source_version.version` | 0.2.0 |
| Hypothèses de confiance explicites · `trust_assumptions[0]` | Hôte, noyau, contrôleur et horloge de confiance (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Hypothèses de confiance explicites · `trust_assumptions[1]` | Autorité synthétique conservée de confiance (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Hypothèses de confiance explicites · `trust_assumptions[2]` | Auteur commun ; aucune certification par un tiers (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Hypothèses de confiance explicites · `trust_assumptions[3]` | Contenu numérique sémantique uniquement ; livraison physique non éprouvée (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Pannes préenregistrées non déclenchées · `untriggered_faults` | Aucune entrée |

## Enregistrement structuré complet de vérification

Le même enregistrement structuré génère les deux versions linguistiques. Les clés machine, codes d’état et valeurs littérales des preuves restent inchangés ; les sections localisées ci-dessus expliquent leur sens. Aucun résultat sauvegardé n’est réutilisé comme preuve fraîche.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 0,
    "buyer_utility_interval_minor": {
      "maximum": null,
      "minimum": null
    },
    "campaign": [
      {
        "final_balance_minor": 30000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 10000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "NOT_ESTABLISHED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 0,
    "total_transfers_minor": 0,
    "trade_settled": false
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "FAILED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "NO_DEAL",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "FAILED",
    "service_feasibility": "FAILED"
  },
  "cohort": "base",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "bd92f2f86610d59ec7366f32fa71d198ddd7d847d904312ea4d1384c288827ce",
  "evidence_sha256": {
    "evidence/capacity/BACKUP.W0.sqlite": "5ab5361e2d26b9ead5c7ca4e73b90b2073216e5c20250efc18f7f3da3ff7475a",
    "evidence/capacity/COMPAT-A.W0.sqlite": "5eec5e5d052b3cefbbc66685876b09deda96c4cbded2ac1603de8019b002b9d5",
    "evidence/capacity/COMPAT-B.W0.sqlite": "81eae7c2280fb5bfa4e694f05358f97aef347a8b5c921ee270bd8a08f8d5d212",
    "evidence/capacity/PRIMARY.W0.sqlite": "f3905223cece0ce9a35f014af22fb3fea530f6b77e8e3570549ebe863b3c5694",
    "evidence/participants.sqlite": "19afc0c6d9c09e57e6e2907cc82447840b3ae14a1178ec0bf5dfff5390672331",
    "evidence/producer.sqlite": "e9f483ffbd1c40b576fe0bbc838bf13eaa17c9fa245253fe3222c5e31923341a",
    "evidence/receiver.sqlite": "291089ae3aa49fd36e82639ffc8a8e4cbeca95a7025b7ca4e685de162108bfde"
  },
  "failures": [],
  "fault_schedule": [],
  "faults_observed": [],
  "fixture_id": "no-deal",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-post-review-source"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "method": "harness",
  "per_arrangement": [],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "UNFULFILLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNFULFILLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "3b73107b8a929414cff6ddb1caf727b12d1decc7fee8a756298c06b80349cbef",
  "registered_assertion": {
    "expected": {
      "accepted_units": 0,
      "outcome": "FAILED",
      "service_feasibility": "FAILED"
    },
    "observed": {
      "accepted_units": 0,
      "outcome": "FAILED",
      "service_feasibility": "FAILED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "PASSED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30037,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 25653999,
    "controller_cpu_user_ns": 25098000,
    "cpu_system_ns": 84384999,
    "cpu_user_ns": 258642000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 1,
    "retries": 0,
    "service_requests": 22,
    "storage_bytes": 1216202,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 488016666,
    "worker_restarts": 0
  },
  "run_id": "no-deal.harness.7ed2602c5e",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-post-review-source"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 0,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 0,
    "production_attempts": 0,
    "received_quantity": 0,
    "recipient_accepted_quantity": 0,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 0,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 48340620,
    "evidence_files_read": 7,
    "wall_ns": 48353870
  },
  "verification_status": "COMPLETE",
  "verification_wall_ns": 48445849,
  "verifier_version": "0.2.0"
}
```
