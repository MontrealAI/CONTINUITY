#!/usr/bin/env python3
"""Preserve and reproduce experiment-role false acceptance without editing source."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
DECLARATION = ROOT / "PREDECLARATION.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")


def inventory(root):
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise RuntimeError(f"Unexpected symlink: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = {
                "sha256": sha(path), "bytes": path.stat().st_size
            }
    return result


def target_head(checkout):
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=checkout, text=True
    ).strip()


def prepare(declaration):
    original = Path(declaration["historical_source"]["directory"])
    checkout = Path(declaration["target"]["checkout"])
    if target_head(checkout) != declaration["target"]["head"]:
        raise RuntimeError("Published target revision changed")
    if sha(original / "INDEX.json") != declaration["historical_source"]["index_sha256"]:
        raise RuntimeError("Original historical index changed")
    original_files = inventory(original)
    write_new(ROOT / "original-base-inventory.json", original_files)
    provenance = ROOT / "provenance"
    provenance.mkdir(exist_ok=False)
    shutil.copy2(original / "INDEX.json", provenance / "original-base-INDEX.json")
    shutil.copy2(checkout / "continuity_economy/suite.py", provenance / "published-suite.py")
    shutil.copy2(checkout / "continuity_economy/__main__.py", provenance / "published-cli.py")
    source_index = json.loads((original / "INDEX.json").read_text())
    preparation = {
        "predeclaration_sha256": sha(DECLARATION),
        "prepared_utc": datetime.now(timezone.utc).isoformat(),
        "original_index_sha256": sha(original / "INDEX.json"),
        "original_inventory_sha256": sha(ROOT / "original-base-inventory.json"),
        "cases": [],
    }
    for case in declaration["cases"]:
        package = ROOT / case["input_directory"]
        package.mkdir(parents=True, exist_ok=False)
        child = package / case["child_directory"]
        entries = [entry for entry in source_index["entries"]
                   if entry["method"] in case["selected_methods"]]
        if len(entries) != case["expected_unique_cells"]:
            raise RuntimeError("Unexpected selected source cell count")
        if case["child_kind"] == "comparison":
            shutil.copytree(original, child)
        else:
            child.mkdir()
            for entry in entries:
                for name in ("run", "authority"):
                    source = original / entry[name]
                    destination = child / entry[name]
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copytree(source, destination)
            index = dict(source_index)
            index.update(kind="demo", methods=["harness"], entries=entries,
                         created_utc=datetime.now(timezone.utc).isoformat())
            write_new(child / "INDEX.json", index)
        copied_files = inventory(child)
        raw_identity = []
        for entry in entries:
            for name in ("run", "authority"):
                for source in sorted((original / entry[name]).rglob("*")):
                    if not source.is_file():
                        continue
                    relative = source.relative_to(original).as_posix()
                    destination = child / relative
                    if sha(source) != sha(destination):
                        raise RuntimeError(f"Copied evidence changed: {relative}")
                    before, after = source.stat(), destination.stat()
                    if (before.st_dev, before.st_ino) == (after.st_dev, after.st_ino):
                        raise RuntimeError(f"Evidence is not physically copied: {relative}")
                    raw_identity.append(relative)
        experiment = {
            "schema": "continuity-economy/experiment-index/v1",
            "version": "0.2.0",
            "members": {role: case["child_directory"]
                        for role in ("base", "successor", "challenges")},
        }
        write_new(package / "INDEX.json", experiment)
        preparation["cases"].append({
            "id": case["id"], "input_directory": str(package),
            "experiment_index_sha256": sha(package / "INDEX.json"),
            "child_index_sha256": sha(child / "INDEX.json"),
            "unique_historical_cells": len(entries),
            "raw_files_copied_and_byte_identical": len(raw_identity),
            "all_copied_child_files": len(copied_files),
            "all_copied_child_bytes": sum(x["bytes"] for x in copied_files.values()),
            "physical_copy_no_shared_inodes": True,
        })
    write_new(ROOT / "input-inventory-before.json", inventory(ROOT / "inputs"))
    if inventory(original) != original_files:
        raise RuntimeError("Original historical evidence changed during copying")
    preparation["input_inventory_sha256"] = sha(ROOT / "input-inventory-before.json")
    preparation["original_evidence_unchanged"] = True
    preparation["target_not_executed"] = True
    write_new(ROOT / "PREPARED.json", preparation)
    print(json.dumps(preparation, ensure_ascii=False, indent=2))


def execute(declaration):
    checkout = Path(declaration["target"]["checkout"])
    if target_head(checkout) != declaration["target"]["head"]:
        raise RuntimeError("Published target revision changed")
    if sha(checkout / "continuity_economy/suite.py") != declaration["target"]["suite_py_sha256"]:
        raise RuntimeError("Published target suite changed")
    expected_files = json.loads((ROOT / "input-inventory-before.json").read_text())
    if inventory(ROOT / "inputs") != expected_files:
        raise RuntimeError("Registered reproduction inputs changed before execution")
    outputs = ROOT / "outputs"
    outputs.mkdir(exist_ok=False)
    environment = dict(os.environ)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment.pop("PYTHONPATH", None)
    results = []
    for case in declaration["cases"]:
        directory = outputs / case["id"]
        directory.mkdir()
        argv = [sys.executable, "-m", "continuity_economy", "--language", "en",
                "verify-suite", "--in-dir", str(ROOT / case["input_directory"])]
        started_utc = datetime.now(timezone.utc).isoformat()
        started = time.monotonic_ns()
        print(f"Running published checker for {case['id']}", flush=True)
        with (directory / "stdout.json").open("xb") as out, (directory / "stderr.txt").open("xb") as err:
            completed = subprocess.run(argv, cwd=checkout, env=environment,
                                       stdout=out, stderr=err, check=False)
        elapsed = time.monotonic_ns() - started
        raw = (directory / "stdout.json").read_bytes()
        try:
            response = json.loads(raw)
        except (ValueError, UnicodeDecodeError):
            response = {}
        observed = response.get("test_assertion", "NO_STRUCTURED_VERDICT")
        exposed = completed.returncode == case["expected_target_exit"] and observed == case["expected_target_verdict"]
        member_summary = {
            role: {key: record.get(key) for key in
                   ("schema", "kind", "cohort", "test_assertion",
                    "executed_method_records", "ai_not_run_records",
                    "critical_safety_failures")}
            for role, record in response.get("members", {}).items()
        }
        execution = {
            "schema": "continuity-economy/review-counterexample-observation/v1",
            "case_id": case["id"], "target_head": target_head(checkout),
            "target_suite_sha256": sha(checkout / "continuity_economy/suite.py"),
            "predeclaration_sha256": sha(DECLARATION),
            "input_inventory_sha256": sha(ROOT / "input-inventory-before.json"),
            "command": {"argv": argv, "cwd": str(checkout),
                        "environment_additions": {"PYTHONDONTWRITEBYTECODE": "1"},
                        "environment_removals": ["PYTHONPATH"]},
            "started_utc": started_utc, "elapsed_ns": elapsed,
            "python": sys.version, "platform": platform.platform(),
            "target_exit_code": completed.returncode,
            "stdout_sha256": sha(directory / "stdout.json"),
            "stderr_sha256": sha(directory / "stderr.txt"),
            "assessment": {
                "test_assertion": "PASSED" if exposed else "FAILED",
                "target_verdict": observed,
                "evidence_stage": "COPIED_HISTORICAL_EVIDENCE_ROLE_BINDING_CHALLENGE",
                "claim_status": "FAILED" if exposed else "NOT_ESTABLISHED",
            },
            "checker_qualification": "FAILED" if exposed else "NOT_ESTABLISHED",
            "false_acceptance_observed": exposed,
            "actual_unique_historical_cells": case["expected_unique_cells"],
            "member_results": member_summary,
            "missing_required_evidence": case["omitted_required_evidence"],
            "historical_base_outcomes_reinterpreted": False,
            "interpretation": "Outer test success demonstrates deficient experiment-role verification; it does not qualify the checker or invalidate the copied historical base executions.",
        }
        write_new(directory / "execution.json", execution)
        results.append(execution)
        print(json.dumps({"case": case["id"], "exit_code": completed.returncode,
                          "target_verdict": observed, "outer_test": execution["assessment"]["test_assertion"],
                          "checker_qualification": execution["checker_qualification"]}), flush=True)
    after_files = inventory(ROOT / "inputs")
    original_after = inventory(Path(declaration["historical_source"]["directory"]))
    original_before = json.loads((ROOT / "original-base-inventory.json").read_text())
    write_new(ROOT / "input-inventory-after.json", after_files)
    unchanged = after_files == expected_files and original_after == original_before
    summary = {
        "schema": "continuity-economy/review-counterexample-summary/v1",
        "source_head": target_head(checkout),
        "predeclaration_sha256": sha(DECLARATION),
        "input_inventory_sha256": sha(ROOT / "input-inventory-before.json"),
        "reproduction_script_sha256": sha(Path(__file__)),
        "input_files_unchanged": after_files == expected_files,
        "original_historical_files_unchanged": original_after == original_before,
        "published_worktree_status": subprocess.check_output(
            ["git", "status", "--porcelain=v1"], cwd=checkout, text=True),
        "test_assertion": "PASSED" if unchanged and all(x["false_acceptance_observed"] for x in results) else "FAILED",
        "checker_qualification": "FAILED" if any(x["false_acceptance_observed"] for x in results) else "NOT_ESTABLISHED",
        "case_results": [{"id": x["case_id"], "target_exit_code": x["target_exit_code"],
                          "assessment": x["assessment"], "checker_qualification": x["checker_qualification"]}
                         for x in results],
        "source_or_runtime_changes": False, "committed": False, "published": False,
    }
    write_new(ROOT / "SUMMARY.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0 if summary["test_assertion"] == "PASSED" else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("prepare", "execute"))
    args = parser.parse_args()
    declaration = json.loads(DECLARATION.read_text())
    if args.stage == "prepare":
        prepare(declaration)
    else:
        raise SystemExit(execute(declaration))
