# CONTINUITÉ Ω — Économie de la continuité

**Expérience de produit numérique · version 0.2.0**

Préserver un engagement grâce à une solution de continuité viable et volontairement acceptée.

**Portée : processus locaux jetables et produit numérique spécifié. Les politiques, consentements, valeurs, financements et flux SMU synthétiques sont des hypothèses et observations du modèle. Ils n’établissent ni contrats réels, ni demande, paiements, ventes, biens imprimés, apparence rendue ou qualité d’impression.**

Ce passeport présente l’évaluation consignée. Une vérification fraîche doit inspecter l’autorité conservée, le résultat durable réel et les preuves du destinataire ; ce document ne constitue jamais son oracle.

<!-- structured-result-sha256: b3bd9c349f21799ac5e702252cf008d2c0d64a01407f82e65fd42df2dfab5726 -->

## Trois affirmations distinctes

| Affirmation | État consigné |
| --- | --- |
| Travail numérique requis accepté dans les conditions figées | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Faisabilité du service selon le modèle synthétique défini | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Avantage de méthode face à des solutions compétentes | Non établi (`NOT_ESTABLISHED`) |
| Sûreté dans le modèle de défaillance éprouvé | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

## Champs d’évaluation distincts

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | Réussi (`PASSED`) |
| Verdict du composant | Réalisé (`COMPLETED`) |
| Stade de preuve | Exécution locale d’un produit numérique (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| État de l’affirmation évaluée | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

## Identité, autorité et versions

| Champ | Valeur consignée |
| --- | --- |
| État des preuves d’autorité · `authority_status` | Établi uniquement pour l’exercice synthétique (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Valeur commerciale réelle · `commercial_value` | Non établi (`NOT_ESTABLISHED`) |
| Identité du contrat · `contract_id` | DIGITAL-ARCHIVE-001 |
| SHA-256 du contrat conservé · `contract_sha256` | 4b0175bd4cf77f0d87cb495b29ee9ebb1fc805429148a8de5d6b8f514056b02a |
| Authenticité d’un client réel · `real_customer_authenticity` | Non établi (`NOT_ESTABLISHED`) |
| Empreinte externe de référence · `reference_sha256` | 09fc8f5d832610f3c4ca6cdf99fc385ea4606fcdcd63685742b0dc0f5ec77fa9 |
| Identité de l’exécution · `run_id` | archive-window-transfer.harness.b1a9b63aa7 |
| Schéma · `schema` | continuity-economy/verification/v1 |
| État d’achèvement de la vérification · `verification_status` | Vérification complète (`COMPLETE`) |
| Version du vérificateur · `verifier_version` | 0.2.0 |

## Exécution et acceptation par obligation

Les quantités décrivent le stade consigné. Les tentatives refusées et corrigées restent distinctes. Une unité produite ou reçue n’est pas automatiquement acceptée. Les mesures absentes ne sont pas présentées comme nulles.

| Obligation | Destinataire | Révision | Requis | Produit | Reçu | Refusé | Accepté selon le contrat | Résultat |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ARC-410 | RECIPIENT-NORD | 3 | 420 | 420 | 420 | 0 | 420 | Réalisé (`COMPLETED`) |
| ARC-520 | RECIPIENT-EST | 2 | 330 | 330 | 330 | 0 | 330 | Réalisé (`COMPLETED`) |
| ARC-630 | RECIPIENT-SUD | 1 | 270 | 270 | 270 | 0 | 270 | Réalisé (`COMPLETED`) |
| ARC-740 | RECIPIENT-OUEST | 1 | 0 | 0 | 0 | 0 | 0 | Annulé (`CANCELLED`) |

### Obligation `ARC-410`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 420 |
| Échéance logique · `deadline_tick` | 130 |
| Tentatives de livraison · `delivery_attempts` | 3 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | ARC-410 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 420 |
| Tentatives de production durables · `production_attempts` | 3 |
| Quantité requise · `quantity` | 420 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 420 |
| Destinataire · `recipient` | RECIPIENT-NORD |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 420 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 420 |
| Révision · `revision` | 3 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 420 |

### Obligation `ARC-520`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 330 |
| Échéance logique · `deadline_tick` | 440 |
| Tentatives de livraison · `delivery_attempts` | 3 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | ARC-520 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 330 |
| Tentatives de production durables · `production_attempts` | 3 |
| Quantité requise · `quantity` | 330 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 330 |
| Destinataire · `recipient` | RECIPIENT-EST |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 330 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 330 |
| Révision · `revision` | 2 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 330 |

### Obligation `ARC-630`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 270 |
| Échéance logique · `deadline_tick` | 520 |
| Tentatives de livraison · `delivery_attempts` | 2 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | ARC-630 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 270 |
| Tentatives de production durables · `production_attempts` | 2 |
| Quantité requise · `quantity` | 270 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 270 |
| Destinataire · `recipient` | RECIPIENT-SUD |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 270 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 270 |
| Révision · `revision` | 1 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 270 |

### Obligation `ARC-740`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 360 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | ARC-740 |
| Résultat · `outcome` | Annulé (`CANCELLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 90 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-OUEST |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 0 |
| Révision · `revision` | 1 |
| État consigné · `status` | Annulé (`CANCELLED`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

## Propositions, décisions modélisées et solutions

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

### Solution `proposal-001`

| Champ | Valeur consignée |
| --- | --- |
| Références d’acceptation · `acceptance_ids[0]` | proposal-001.ARC-410.L001.A1.D |
| Références d’acceptation · `acceptance_ids[1]` | proposal-001.ARC-410.L002.A1.D |
| Références d’acceptation · `acceptance_ids[2]` | proposal-001.ARC-410.L003.A1.D |
| Références d’acceptation · `acceptance_ids[3]` | proposal-001.ARC-520.L001.A1.D |
| Références d’acceptation · `acceptance_ids[4]` | proposal-001.ARC-520.L002.A1.D |
| Références d’acceptation · `acceptance_ids[5]` | proposal-001.ARC-520.L003.A1.D |
| Références d’acceptation · `acceptance_ids[6]` | proposal-001.ARC-630.L001.A1.D |
| Références d’acceptation · `acceptance_ids[7]` | proposal-001.ARC-630.L002.A1.D |
| Instant d’acceptation de l’accord · `accepted_tick` | 3 |
| Identité de l’accord · `agreement_id` | proposal-001 |
| Instant d’annulation · `cancelled_tick` | Non consigné |
| Coût de correction engagé (unités mineures SMU synthétiques) · `correction_cost_minor` | 0 |
| Faisabilité modélisée au moment de l’accord · `ex_ante_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Coût engagé (unités mineures SMU synthétiques) · `incurred_cost_minor` | 2790 |
| Valeur d’équilibre de l’acheteur (unités mineures SMU synthétiques) · `independent_terms.break_even_value_minor` | 7500 |
| Plafond acheteur à la borne de valeur inférieure (unités mineures SMU synthétiques) · `independent_terms.buyer_definite_max_price_minor` | 6400 |
| Plafond acheteur à la borne de valeur supérieure (unités mineures SMU synthétiques) · `independent_terms.buyer_possible_max_price_minor` | 7000 |
| Unité de compte synthétique · `independent_terms.currency` | SMU |
| Prix acheteur minimal réalisable (unités mineures SMU synthétiques) · `independent_terms.minimum_buyer_price_minor` | 5700 |
| Rémunération minimale du coordonnateur (unités mineures SMU synthétiques) · `independent_terms.minimum_coordinator_fee_minor` | 290 |
| Coût de production initiale (unités mineures SMU synthétiques) · `independent_terms.providers[0].base_cost_minor` | 2040 |
| Profit modélisé après correction maximale spécifiée (unités mineures SMU synthétiques) · `independent_terms.providers[0].guaranteed_profit_minor` | 260 |
| Exposition maximale aux coûts impayés (unités mineures SMU synthétiques) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 3960 |
| Paiement minimal au fournisseur (unités mineures SMU synthétiques) · `independent_terms.providers[0].minimum_payment_minor` | 4220 |
| Profit requis de participation (unités mineures SMU synthétiques) · `independent_terms.providers[0].participation_profit_minor` | 260 |
| Identité du participant · `independent_terms.providers[0].party_id` | ARCHIVE-COMPAT-A |
| Paiement promis au fournisseur (unités mineures SMU synthétiques) · `independent_terms.providers[0].promised_payment_minor` | 4220 |
| Coût maximal de correction (unités mineures SMU synthétiques) · `independent_terms.providers[0].rework_cost_minor` | 1920 |
| Unités · `independent_terms.providers[0].units` | 900 |
| Coût de production initiale (unités mineures SMU synthétiques) · `independent_terms.providers[1].base_cost_minor` | 570 |
| Profit modélisé après correction maximale spécifiée (unités mineures SMU synthétiques) · `independent_terms.providers[1].guaranteed_profit_minor` | 200 |
| Exposition maximale aux coûts impayés (unités mineures SMU synthétiques) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 990 |
| Paiement minimal au fournisseur (unités mineures SMU synthétiques) · `independent_terms.providers[1].minimum_payment_minor` | 1190 |
| Profit requis de participation (unités mineures SMU synthétiques) · `independent_terms.providers[1].participation_profit_minor` | 200 |
| Identité du participant · `independent_terms.providers[1].party_id` | ARCHIVE-COMPAT-B |
| Paiement promis au fournisseur (unités mineures SMU synthétiques) · `independent_terms.providers[1].promised_payment_minor` | 1190 |
| Coût maximal de correction (unités mineures SMU synthétiques) · `independent_terms.providers[1].rework_cost_minor` | 420 |
| Unités · `independent_terms.providers[1].units` | 120 |
| Réserve de correction (unités mineures SMU synthétiques) · `independent_terms.rework_budget_minor` | 2340 |
| Portée de l’évaluation · `independent_terms.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Nature de la solution · `kind` | Accord d’échange modélisé (`TRADE`) |
| Code stable · `participant_decisions[0].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[0].party_id` | BUYER-ARCHIVE |
| Rôle · `participant_decisions[0].role` | buyer |
| Verdict du composant · `participant_decisions[0].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[1].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[1].party_id` | ARCHIVE-COMPAT-A |
| Rôle · `participant_decisions[1].role` | provider |
| Verdict du composant · `participant_decisions[1].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[2].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[2].party_id` | ARCHIVE-COMPAT-B |
| Rôle · `participant_decisions[2].role` | provider |
| Verdict du composant · `participant_decisions[2].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[3].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[3].party_id` | COORDINATOR-ARCHIVE |
| Rôle · `participant_decisions[3].role` | coordinator |
| Verdict du composant · `participant_decisions[3].verdict` | Accepté (`ACCEPTED`) |
| Paiements modélisés (unités mineures SMU synthétiques) · `payments_minor` | 5700 |
| Identité de la proposition · `proposal_id` | proposal-001 |
| Premier ordinal inclus · `proposed_terms.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[0].last_unit` | 150 |
| Identité du lot fixe · `proposed_terms.allocations[0].lot_id` | ARC-410.L001 |
| Identité de l’obligation · `proposed_terms.allocations[0].obligation_id` | ARC-410 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[0].pay_minor` | 4220 |
| Identité du fournisseur · `proposed_terms.allocations[0].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[0].window_id` | EARLY |
| Premier ordinal inclus · `proposed_terms.allocations[1].first_unit` | 151 |
| Dernier ordinal inclus · `proposed_terms.allocations[1].last_unit` | 300 |
| Identité du lot fixe · `proposed_terms.allocations[1].lot_id` | ARC-410.L002 |
| Identité de l’obligation · `proposed_terms.allocations[1].obligation_id` | ARC-410 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[1].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[1].window_id` | EARLY |
| Premier ordinal inclus · `proposed_terms.allocations[2].first_unit` | 301 |
| Dernier ordinal inclus · `proposed_terms.allocations[2].last_unit` | 420 |
| Identité du lot fixe · `proposed_terms.allocations[2].lot_id` | ARC-410.L003 |
| Identité de l’obligation · `proposed_terms.allocations[2].obligation_id` | ARC-410 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[2].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[2].window_id` | EARLY |
| Premier ordinal inclus · `proposed_terms.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[3].last_unit` | 150 |
| Identité du lot fixe · `proposed_terms.allocations[3].lot_id` | ARC-520.L001 |
| Identité de l’obligation · `proposed_terms.allocations[3].obligation_id` | ARC-520 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[3].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[3].window_id` | EARLY |
| Premier ordinal inclus · `proposed_terms.allocations[4].first_unit` | 151 |
| Dernier ordinal inclus · `proposed_terms.allocations[4].last_unit` | 300 |
| Identité du lot fixe · `proposed_terms.allocations[4].lot_id` | ARC-520.L002 |
| Identité de l’obligation · `proposed_terms.allocations[4].obligation_id` | ARC-520 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[4].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[4].window_id` | Tardif (`LATE`) |
| Premier ordinal inclus · `proposed_terms.allocations[5].first_unit` | 301 |
| Dernier ordinal inclus · `proposed_terms.allocations[5].last_unit` | 330 |
| Identité du lot fixe · `proposed_terms.allocations[5].lot_id` | ARC-520.L003 |
| Identité de l’obligation · `proposed_terms.allocations[5].obligation_id` | ARC-520 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[5].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[5].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[5].window_id` | Tardif (`LATE`) |
| Premier ordinal inclus · `proposed_terms.allocations[6].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[6].last_unit` | 150 |
| Identité du lot fixe · `proposed_terms.allocations[6].lot_id` | ARC-630.L001 |
| Identité de l’obligation · `proposed_terms.allocations[6].obligation_id` | ARC-630 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[6].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[6].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[6].window_id` | Tardif (`LATE`) |
| Premier ordinal inclus · `proposed_terms.allocations[7].first_unit` | 151 |
| Dernier ordinal inclus · `proposed_terms.allocations[7].last_unit` | 270 |
| Identité du lot fixe · `proposed_terms.allocations[7].lot_id` | ARC-630.L002 |
| Identité de l’obligation · `proposed_terms.allocations[7].obligation_id` | ARC-630 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[7].pay_minor` | 1190 |
| Identité du fournisseur · `proposed_terms.allocations[7].provider_id` | ARCHIVE-COMPAT-B |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[7].window_id` | Tardif (`LATE`) |
| Prix acheteur (unités mineures SMU synthétiques) · `proposed_terms.buyer_price_minor` | 5700 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `proposed_terms.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `proposed_terms.contract_sha256` | 4b0175bd4cf77f0d87cb495b29ee9ebb1fc805429148a8de5d6b8f514056b02a |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `proposed_terms.coordinator_fee_minor` | 290 |
| Instant exclusif d’expiration · `proposed_terms.expires_tick` | 560 |
| Révision des politiques · `proposed_terms.policy_revision` | 1 |
| Identité de la proposition · `proposed_terms.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `proposed_terms.rework_budget_minor` | 2340 |
| Schéma · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Faisabilité modélisée après exécution · `realized_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Instant de règlement modélisé · `settled_tick` | 279 |
| État consigné · `status` | Réglé dans le registre synthétique (`SETTLED`) |

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.


## Transferts, coûts, responsabilités et options externes modélisés

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

| Champ | Valeur consignée |
| --- | --- |
| Total des transferts acheteur (unités mineures SMU synthétiques) · `accounting.buyer_total_paid_minor` | 5700 |
| Borne supérieure · `accounting.buyer_utility_interval_minor.maximum` | 3900 |
| Borne inférieure · `accounting.buyer_utility_interval_minor.minimum` | 2500 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[0].final_balance_minor` | 1900 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[0].initial_balance_minor` | 7600 |
| Seuil de participation modélisé couvert · `accounting.campaign[0].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[0].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[0].party_id` | BUYER-ARCHIVE |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[0].purchase_payments_minor` | 5700 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[0].realized_profit_minor` | Non consigné |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[0].revenue_minor` | 0 |
| Rôle · `accounting.campaign[0].role` | buyer |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[1].final_balance_minor` | 1110 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[1].incurred_cost_minor` | 180 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[1].initial_balance_minor` | 1000 |
| Seuil de participation modélisé couvert · `accounting.campaign[1].participation_covered` | Oui |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[1].participation_threshold_minor` | 110 |
| Identité du participant · `accounting.campaign[1].party_id` | COORDINATOR-ARCHIVE |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[1].realized_profit_minor` | 110 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[1].revenue_minor` | 290 |
| Rôle · `accounting.campaign[1].role` | coordinator |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[2].final_balance_minor` | 0 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[2].initial_balance_minor` | 0 |
| Seuil de participation modélisé couvert · `accounting.campaign[2].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[2].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[2].party_id` | UNUSED-SPONSOR |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[2].realized_profit_minor` | Non consigné |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[2].revenue_minor` | 0 |
| Rôle · `accounting.campaign[2].role` | technical_sponsor |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[3].final_balance_minor` | 4500 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[3].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[3].initial_balance_minor` | 4500 |
| Seuil de participation modélisé couvert · `accounting.campaign[3].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[3].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[3].party_id` | ARCHIVE-PRIMARY |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[3].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[3].revenue_minor` | 0 |
| Rôle · `accounting.campaign[3].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[4].final_balance_minor` | 4500 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[4].initial_balance_minor` | 4500 |
| Seuil de participation modélisé couvert · `accounting.campaign[4].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[4].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[4].party_id` | ARCHIVE-BACKUP |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[4].revenue_minor` | 0 |
| Rôle · `accounting.campaign[4].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[5].final_balance_minor` | 8180 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[5].incurred_cost_minor` | 2040 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[5].initial_balance_minor` | 6000 |
| Seuil de participation modélisé couvert · `accounting.campaign[5].participation_covered` | Oui |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[5].participation_threshold_minor` | 260 |
| Identité du participant · `accounting.campaign[5].party_id` | ARCHIVE-COMPAT-A |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[5].realized_profit_minor` | 2180 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[5].revenue_minor` | 4220 |
| Rôle · `accounting.campaign[5].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[6].final_balance_minor` | 3120 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[6].incurred_cost_minor` | 570 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[6].initial_balance_minor` | 2500 |
| Seuil de participation modélisé couvert · `accounting.campaign[6].participation_covered` | Oui |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[6].participation_threshold_minor` | 200 |
| Identité du participant · `accounting.campaign[6].party_id` | ARCHIVE-COMPAT-B |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[6].realized_profit_minor` | 620 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[6].revenue_minor` | 1190 |
| Rôle · `accounting.campaign[6].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Unité de compte synthétique · `accounting.currency` | SMU |
| Total final du registre (unités mineures SMU synthétiques) · `accounting.final_total_minor` | 26100 |
| Total initial du registre (unités mineures SMU synthétiques) · `accounting.initial_total_minor` | 26100 |
| Contrats, paiements ou demande réels · `accounting.real_contracts_payments_or_demand` | Non établi (`NOT_ESTABLISHED`) |
| Faisabilité modélisée réalisée pour l’acheteur · `accounting.realized_buyer` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Portée de l’évaluation · `accounting.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Tous les coûts de correction (unités mineures SMU synthétiques) · `accounting.total_correction_cost_minor` | 0 |
| Tous les coûts engagés de campagne (unités mineures SMU synthétiques) · `accounting.total_incurred_cost_minor` | 2790 |
| Tous les transferts de règlement modélisés (unités mineures SMU synthétiques) · `accounting.total_transfers_minor` | 5700 |
| Transaction modélisée réglée · `accounting.trade_settled` | Oui |
| Obligations acceptées · `totals.accepted_obligations` | 3 |
| Quantité acceptée selon le contrat · `totals.accepted_quantity` | 1020 |
| Tentatives de livraison · `totals.delivery_attempts` | 8 |
| Unités acceptées en double · `totals.duplicate_acceptances` | 0 |
| Quantité tardive · `totals.late_quantity` | 0 |
| Quantité manquante · `totals.missing_quantity` | 0 |
| Quantité produite · `totals.produced_quantity` | 1020 |
| Tentatives de production durables · `totals.production_attempts` | 8 |
| Quantité reçue · `totals.received_quantity` | 1020 |
| Unités acceptées par le composant destinataire · `totals.recipient_accepted_quantity` | 1020 |
| Quantité refusée · `totals.rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `totals.rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `totals.rejection_count` | 0 |
| Obligations actives requises · `totals.required_obligations` | 3 |
| Quantité requise · `totals.required_quantity` | 1020 |
| Unités sémantiquement correctes observées à temps · `totals.timely_semantic_quantity` | 1020 |
| Engagements non sûrs ou non autorisés · `totals.unsafe_or_unsupported_commitments` | 0 |

## Ressources mesurées et lacunes de comptabilisation

Les ressources de processus mesurées et les montants synthétiques configurés ont des significations différentes. Les efforts de préparation, d’intégration, d’adaptation, de vérification ou d’intervention non consignés restent inconnus. Les catégories absentes ne permettent aucune conclusion de coût complet ou de méthode moins coûteuse.

| Champ | Valeur consignée |
| --- | --- |
| Lacunes de comptabilisation · `accounting_gaps[0]` | Le travail de préparation n’a pas été mesuré (`PREPARATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[1]` | Le travail d’intégration n’a pas été mesuré (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[2]` | Le travail d’adaptation n’a pas été mesuré (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[3]` | Le travail humain de vérification n’a pas été mesuré (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[4]` | Les tarifs monétaires n’ont pas été mesurés (`MONETARY_RATES_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Travail d’adaptation (secondes ; inconnu si absent) · `resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `resources.authority_storage_bytes_before_seal` | 52830 |
| Redémarrages du candidat · `resources.candidate_restarts` | 0 |
| Processus enfants lancés · `resources.child_processes` | 10 |
| Processeur système du contrôleur (ns) · `resources.controller_cpu_system_ns` | 25675000 |
| Processeur utilisateur du contrôleur (ns) · `resources.controller_cpu_user_ns` | 153705999 |
| Processeur système (ns) · `resources.cpu_system_ns` | 117783999 |
| Processeur utilisateur (ns) · `resources.cpu_user_ns` | 594324000 |
| Interventions humaines · `resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `resources.requests` | 45 |
| Nouvelles tentatives · `resources.retries` | 1 |
| Requêtes internes aux services · `resources.service_requests` | 239 |
| Stockage consigné (octets) · `resources.storage_bytes` | 6498224 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `resources.wall_ns` | 2640827349 |
| Redémarrages des services · `resources.worker_restarts` | 1 |
| Temps processeur (ns) · `verification_resources.cpu_ns` | 200665958 |
| Fichiers de preuve examinés · `verification_resources.evidence_files_read` | 32 |
| Durée écoulée (ns) · `verification_resources.wall_ns` | 200805423 |

## Échecs et contre-exemples observés

Aucune entrée d’échec n’a été consignée dans cette évaluation. Il s’agit de preuves bornées, non d’une démonstration générale.

## Preuves absentes et affirmations non établies

Aucune entrée non résolue supplémentaire n’a été consignée. Les limites de portée et de coûts inconnus restent applicables.

## Références des preuves et intégrité des octets

Les empreintes identifient les octets. Elles n’authentifient pas les instructions réelles d’un client, n’établissent pas l’exhaustivité des sources et ne remplacent pas une empreinte de référence conservée séparément.

| Champ | Valeur consignée |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L001.A1.json` | 7c774b2fec8501ed966408290568047e31b09c50aa0273580f50c79419231209 |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L002.A1.json` | 380752c754901a1272d90acdc832725109fb4d1624fa1a69a964b65565e84159 |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L003.A1.json` | 42437cd5607b43e3a1a22a7f306d8eb5c24a337487e8f07e7f2f395926a1a737 |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-520.L001.A1.json` | 279c139e446af029cdcd43e09195238b975c88527e518784599fc51d05a08d00 |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-520.L002.A1.json` | 725de1b3012490554d253c6818e4358782c192afbdc6c278933cbcc8e140c0aa |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-520.L003.A1.json` | 93d4c5095069324ea30ef8d3ade6c42bce4457d68d4358e4acc41668ab6008a8 |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-630.L001.A1.json` | b089555b65e5a5f3c85077aa1c0e3804d22f66f62d355c2794db7f8658acb681 |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-B.LATE/ARC-630.L002.A1.json` | 1af3b391fe62b4ad2de56c5403ed62b32e191e6f91acbe04f59f226ff638b7d5 |
| `evidence_sha256.evidence/capacity/ARCHIVE-BACKUP.ALL.sqlite` | 22cbeabeaec5f61ed5f9653c206d131119ed03eb121c2ed4af6d0bf7b251b7b4 |
| `evidence_sha256.evidence/capacity/ARCHIVE-COMPAT-A.EARLY.sqlite` | 640e15948c46801753d3f125363d87f8f6099d45c818c207710c8a150ad908d7 |
| `evidence_sha256.evidence/capacity/ARCHIVE-COMPAT-A.LATE.sqlite` | 0cb2f5cb16d0d4bf7324c5dc0fb63b74f6811d64399630727eb3d4adb7217eea |
| `evidence_sha256.evidence/capacity/ARCHIVE-COMPAT-B.LATE.sqlite` | d50d7244f2a1dc8d19b9d690b9328a3689410c77075b0fc656c567779effb938 |
| `evidence_sha256.evidence/capacity/ARCHIVE-PRIMARY.ALL.sqlite` | a7ac99247c605e39ba8f74dfbf7a7183c3f62b5f6bc6f29259ae7af02252d592 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-410.L001.A1.D.json` | 75b46223ccc1f562903e39278010c0e6d446371acc6643e338804cc8c4c398c4 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-410.L002.A1.D.json` | b1b14777863894e3af3b958603da9aa7f97cd90d0baef46ba54cb6c77de933eb |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-410.L003.A1.D.json` | 621fa2e4d1f41f152eb7b6438f935d747861f4278c3f79626202e84b0f4bda7e |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-520.L001.A1.D.json` | 54ba6e39748c07c3f3b85e81d694c245b90bcff6e44ac7a49f82c60e116e1b2e |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-520.L002.A1.D.json` | 99fbc03732a92a78d94f1d88aafc7ace74ba17c26d28fae98afd78dcccdf58ec |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-520.L003.A1.D.json` | 4fdd1d369ac548c3163dfe58ebb0f2430d99a9b45dbf59889fc8b6cffe86ace5 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-630.L001.A1.D.json` | 1857a3dde816ba270748be6eaee1f41bb89e6b5fd605080e0bbdda22430b06c1 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-630.L002.A1.D.json` | 295866988087712384e460fd84e1b17d9fdbb9984de4857c18bff5ed34ac906a |
| `evidence_sha256.evidence/participants.sqlite` | 4b0b5fe8425a9b1ed5581d9945a68d6aaac24c57df150132c617cc3e9d003467 |
| `evidence_sha256.evidence/producer.sqlite` | b88130fee9115236f57e9ac918986f7b0dfbe73d253c9bd4e464e5baf1d84789 |
| `evidence_sha256.evidence/products/proposal-001.ARC-410.L001.A1.json` | 75b46223ccc1f562903e39278010c0e6d446371acc6643e338804cc8c4c398c4 |
| `evidence_sha256.evidence/products/proposal-001.ARC-410.L002.A1.json` | b1b14777863894e3af3b958603da9aa7f97cd90d0baef46ba54cb6c77de933eb |
| `evidence_sha256.evidence/products/proposal-001.ARC-410.L003.A1.json` | 621fa2e4d1f41f152eb7b6438f935d747861f4278c3f79626202e84b0f4bda7e |
| `evidence_sha256.evidence/products/proposal-001.ARC-520.L001.A1.json` | 54ba6e39748c07c3f3b85e81d694c245b90bcff6e44ac7a49f82c60e116e1b2e |
| `evidence_sha256.evidence/products/proposal-001.ARC-520.L002.A1.json` | 99fbc03732a92a78d94f1d88aafc7ace74ba17c26d28fae98afd78dcccdf58ec |
| `evidence_sha256.evidence/products/proposal-001.ARC-520.L003.A1.json` | 4fdd1d369ac548c3163dfe58ebb0f2430d99a9b45dbf59889fc8b6cffe86ace5 |
| `evidence_sha256.evidence/products/proposal-001.ARC-630.L001.A1.json` | 1857a3dde816ba270748be6eaee1f41bb89e6b5fd605080e0bbdda22430b06c1 |
| `evidence_sha256.evidence/products/proposal-001.ARC-630.L002.A1.json` | 295866988087712384e460fd84e1b17d9fdbb9984de4857c18bff5ed34ac906a |
| `evidence_sha256.evidence/receiver.sqlite` | 26d2f556e7eca08a478db5399e3256c895edfda35c29f2641562e02903332fb2 |
| SHA-256 du résultat structuré · `structured_result_sha256` | b3bd9c349f21799ac5e702252cf008d2c0d64a01407f82e65fd42df2dfab5726 |

## Exécution, pannes, commandes et provenance consignées

Les identifiants stables, commandes exactes, chemins et diagnostics machine originaux sont conservés littéralement. Ce sont des données, non des preuves d’acceptation supplémentaires. La confiance dans les sources et l’hôte est explicitée dans l’architecture et le modèle de menace.

| Champ | Valeur consignée |
| --- | --- |
| `authority_dir` | /home/runner/work/_temp/continuity-economy/complete/successor/authorities/archive-window-transfer.harness |
| Cohorte d’expérience · `cohort` | successor |
| `contract.allow_split` | Oui |
| `contract.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | SHARED-INDEX-NETWORK |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Cohorte d’expérience · `contract.cohort` | successor |
| Identité du contrat · `contract.contract_id` | DIGITAL-ARCHIVE-001 |
| `contract.cutoff_sequence` | 8 |
| Échéance logique · `contract.deadline_tick` | 560 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-SUCCESSOR-001 |
| Événement consigné · `contract.fault_schedule[0].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `contract.fault_schedule[0].occurrence` | 2 |
| Cible de la panne · `contract.fault_schedule[0].target` | ANY |
| Opération déclenchante · `contract.fault_schedule[0].trigger` | inspect |
| Valeur configurée · `contract.fault_schedule[0].value` | 0 |
| Identité du cas préenregistré · `contract.fixture_id` | archive-window-transfer |
| `contract.lease_ticks` | 15 |
| `contract.lot_size` | 150 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Échéance logique · `contract.obligations[0].deadline_tick` | 130 |
| Identité de l’obligation · `contract.obligations[0].obligation_id` | ARC-410 |
| Quantité requise · `contract.obligations[0].quantity` | 420 |
| Destinataire · `contract.obligations[0].recipient` | RECIPIENT-NORD |
| Révision · `contract.obligations[0].revision` | 3 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Import this serial under accession N26 with shelf code B-14; retain the revision shown in the job. |
| `contract.obligations[0].spec.instructions_fr` | Importer ce numéro sous l’entrée N26 avec le code d’étagère B-14 ; conserver la révision indiquée dans le dossier. |
| `contract.obligations[0].spec.lot` | ARC-N26-20261106 |
| `contract.obligations[0].spec.name_en` | Digital archive box index |
| `contract.obligations[0].spec.name_fr` | Index numérique de boîte d’archives |
| `contract.obligations[0].spec.serial_prefix` | ARC410-N26- |
| `contract.obligations[0].spec.sku` | ARCHIVE-BOX-A7 |
| État consigné · `contract.obligations[0].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[1].deadline_tick` | 440 |
| Identité de l’obligation · `contract.obligations[1].obligation_id` | ARC-520 |
| Quantité requise · `contract.obligations[1].quantity` | 330 |
| Destinataire · `contract.obligations[1].recipient` | RECIPIENT-EST |
| Révision · `contract.obligations[1].revision` | 2 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Import this serial for return bin R-08 and recipient reference EAST-27; preserve both identifiers. |
| `contract.obligations[1].spec.instructions_fr` | Importer ce numéro pour le bac de retour R-08 et la référence destinataire EAST-27 ; conserver les deux identifiants. |
| `contract.obligations[1].spec.lot` | ARC-E27-20261106 |
| `contract.obligations[1].spec.name_en` | Digital loan return record |
| `contract.obligations[1].spec.name_fr` | Fiche numérique de retour de prêt |
| `contract.obligations[1].spec.serial_prefix` | ARC520-E27- |
| `contract.obligations[1].spec.sku` | ARCHIVE-RETURN-B4 |
| État consigné · `contract.obligations[1].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[2].deadline_tick` | 520 |
| Identité de l’obligation · `contract.obligations[2].obligation_id` | ARC-630 |
| Quantité requise · `contract.obligations[2].quantity` | 270 |
| Destinataire · `contract.obligations[2].recipient` | RECIPIENT-SUD |
| Révision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep accession S19 and category PAPER in the imported unit; do not substitute another accession. |
| `contract.obligations[2].spec.instructions_fr` | Conserver l’entrée S19 et la catégorie PAPER dans l’unité importée ; ne pas substituer une autre entrée. |
| `contract.obligations[2].spec.lot` | ARC-S19-20261106 |
| `contract.obligations[2].spec.name_en` | Digital conservation index record |
| `contract.obligations[2].spec.name_fr` | Fiche numérique d’index de conservation |
| `contract.obligations[2].spec.serial_prefix` | ARC630-S19- |
| `contract.obligations[2].spec.sku` | ARCHIVE-INDEX-C2 |
| État consigné · `contract.obligations[2].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[3].deadline_tick` | 360 |
| Identité de l’obligation · `contract.obligations[3].obligation_id` | ARC-740 |
| Quantité requise · `contract.obligations[3].quantity` | 90 |
| Destinataire · `contract.obligations[3].recipient` | RECIPIENT-OUEST |
| Révision · `contract.obligations[3].revision` | 1 |
| `contract.obligations[3].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[3].spec.instructions_en` | Import return route WEST-09 with this exact serial. |
| `contract.obligations[3].spec.instructions_fr` | Importer la voie de retour WEST-09 avec ce numéro exact. |
| `contract.obligations[3].spec.lot` | ARC-W09-20261106 |
| `contract.obligations[3].spec.name_en` | Digital west return-route record |
| `contract.obligations[3].spec.name_fr` | Fiche numérique de retour ouest |
| `contract.obligations[3].spec.serial_prefix` | ARC740-W09- |
| `contract.obligations[3].spec.sku` | ARCHIVE-RETURN-D9 |
| État consigné · `contract.obligations[3].status` | Annulé (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 650 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | SHARED-INDEX-NETWORK |
| `contract.providers[0].permissions.disclosure` | Non |
| `contract.providers[0].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[0].provider_id` | ARCHIVE-PRIMARY |
| Rôle · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 1600 |
| `contract.providers[0].windows[0].end` | 600 |
| `contract.providers[0].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[0].windows[0].window_id` | ALL |
| `contract.providers[1].dependency` | SHARED-INDEX-NETWORK |
| `contract.providers[1].permissions.disclosure` | Oui |
| `contract.providers[1].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[1].provider_id` | ARCHIVE-BACKUP |
| Rôle · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 1600 |
| `contract.providers[1].windows[0].end` | 600 |
| `contract.providers[1].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[1].windows[0].window_id` | ALL |
| `contract.providers[2].dependency` | ARCHIVE-OFFLINE-A |
| `contract.providers[2].permissions.disclosure` | Oui |
| `contract.providers[2].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[2].provider_id` | ARCHIVE-COMPAT-A |
| Rôle · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 570 |
| `contract.providers[2].windows[0].end` | 140 |
| `contract.providers[2].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[2].windows[0].window_id` | EARLY |
| `contract.providers[2].windows[1].capacity` | 330 |
| `contract.providers[2].windows[1].end` | 560 |
| `contract.providers[2].windows[1].start` | 260 |
| Identité de la fenêtre de capacité · `contract.providers[2].windows[1].window_id` | Tardif (`LATE`) |
| `contract.providers[3].dependency` | ARCHIVE-OFFLINE-B |
| `contract.providers[3].permissions.disclosure` | Oui |
| `contract.providers[3].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[3].provider_id` | ARCHIVE-COMPAT-B |
| Rôle · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 330 |
| `contract.providers[3].windows[0].end` | 560 |
| `contract.providers[3].windows[0].start` | 260 |
| Identité de la fenêtre de capacité · `contract.providers[3].windows[0].window_id` | Tardif (`LATE`) |
| Révision · `contract.revision` | 1 |
| `contract.revocations` | Aucune entrée |
| Identité de l’exécution · `contract.run_id` | archive-window-transfer.harness.b1a9b63aa7 |
| Schéma · `contract.schema` | continuity-economy/contract/v1 |
| Graine consignée · `contract.seed` | 7919 |
| `contract.source_complete` | Oui |
| Échéance logique · `contract.source_events[0].obligation.deadline_tick` | 130 |
| Identité de l’obligation · `contract.source_events[0].obligation.obligation_id` | ARC-410 |
| Quantité requise · `contract.source_events[0].obligation.quantity` | 390 |
| Destinataire · `contract.source_events[0].obligation.recipient` | RECIPIENT-NORD |
| Révision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Import this serial under accession N26 with shelf code B-09; retain the revision shown in the job. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Importer ce numéro sous l’entrée N26 avec le code d’étagère B-09 ; conserver la révision indiquée dans le dossier. |
| `contract.source_events[0].obligation.spec.lot` | ARC-N26-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Digital archive box index |
| `contract.source_events[0].obligation.spec.name_fr` | Index numérique de boîte d’archives |
| `contract.source_events[0].obligation.spec.serial_prefix` | ARC410-N26- |
| `contract.source_events[0].obligation.spec.sku` | ARCHIVE-BOX-A7 |
| État consigné · `contract.source_events[0].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[0].obligation_id` | ARC-410 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Échéance logique · `contract.source_events[1].obligation.deadline_tick` | 440 |
| Identité de l’obligation · `contract.source_events[1].obligation.obligation_id` | ARC-520 |
| Quantité requise · `contract.source_events[1].obligation.quantity` | 300 |
| Destinataire · `contract.source_events[1].obligation.recipient` | RECIPIENT-CENTRE |
| Révision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Import this serial for return bin R-03 and recipient reference CENTRE-11; preserve both identifiers. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Importer ce numéro pour le bac de retour R-03 et la référence destinataire CENTRE-11 ; conserver les deux identifiants. |
| `contract.source_events[1].obligation.spec.lot` | ARC-E27-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Digital loan return record |
| `contract.source_events[1].obligation.spec.name_fr` | Fiche numérique de retour de prêt |
| `contract.source_events[1].obligation.spec.serial_prefix` | ARC520-E27- |
| `contract.source_events[1].obligation.spec.sku` | ARCHIVE-RETURN-B4 |
| État consigné · `contract.source_events[1].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[1].obligation_id` | ARC-520 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Échéance logique · `contract.source_events[2].obligation.deadline_tick` | 520 |
| Identité de l’obligation · `contract.source_events[2].obligation.obligation_id` | ARC-630 |
| Quantité requise · `contract.source_events[2].obligation.quantity` | 270 |
| Destinataire · `contract.source_events[2].obligation.recipient` | RECIPIENT-SUD |
| Révision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep accession S19 and category PAPER in the imported unit; do not substitute another accession. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Conserver l’entrée S19 et la catégorie PAPER dans l’unité importée ; ne pas substituer une autre entrée. |
| `contract.source_events[2].obligation.spec.lot` | ARC-S19-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Digital conservation index record |
| `contract.source_events[2].obligation.spec.name_fr` | Fiche numérique d’index de conservation |
| `contract.source_events[2].obligation.spec.serial_prefix` | ARC630-S19- |
| `contract.source_events[2].obligation.spec.sku` | ARCHIVE-INDEX-C2 |
| État consigné · `contract.source_events[2].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[2].obligation_id` | ARC-630 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Échéance logique · `contract.source_events[3].obligation.deadline_tick` | 360 |
| Identité de l’obligation · `contract.source_events[3].obligation.obligation_id` | ARC-740 |
| Quantité requise · `contract.source_events[3].obligation.quantity` | 90 |
| Destinataire · `contract.source_events[3].obligation.recipient` | RECIPIENT-OUEST |
| Révision · `contract.source_events[3].obligation.revision` | 1 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Import return route WEST-09 with this exact serial. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Importer la voie de retour WEST-09 avec ce numéro exact. |
| `contract.source_events[3].obligation.spec.lot` | ARC-W09-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Digital west return-route record |
| `contract.source_events[3].obligation.spec.name_fr` | Fiche numérique de retour ouest |
| `contract.source_events[3].obligation.spec.serial_prefix` | ARC740-W09- |
| `contract.source_events[3].obligation.spec.sku` | ARCHIVE-RETURN-D9 |
| État consigné · `contract.source_events[3].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[3].obligation_id` | ARC-740 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | ACCEPT |
| Échéance logique · `contract.source_events[4].obligation.deadline_tick` | 130 |
| Identité de l’obligation · `contract.source_events[4].obligation.obligation_id` | ARC-410 |
| Quantité requise · `contract.source_events[4].obligation.quantity` | 420 |
| Destinataire · `contract.source_events[4].obligation.recipient` | RECIPIENT-NORD |
| Révision · `contract.source_events[4].obligation.revision` | 2 |
| `contract.source_events[4].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[4].obligation.spec.instructions_en` | Import this serial under accession N26 with shelf code B-12; retain the revision shown in the job. |
| `contract.source_events[4].obligation.spec.instructions_fr` | Importer ce numéro sous l’entrée N26 avec le code d’étagère B-12 ; conserver la révision indiquée dans le dossier. |
| `contract.source_events[4].obligation.spec.lot` | ARC-N26-20261106 |
| `contract.source_events[4].obligation.spec.name_en` | Digital archive box index |
| `contract.source_events[4].obligation.spec.name_fr` | Index numérique de boîte d’archives |
| `contract.source_events[4].obligation.spec.serial_prefix` | ARC410-N26- |
| `contract.source_events[4].obligation.spec.sku` | ARCHIVE-BOX-A7 |
| État consigné · `contract.source_events[4].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[4].obligation_id` | ARC-410 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | AMEND |
| Échéance logique · `contract.source_events[5].obligation.deadline_tick` | 440 |
| Identité de l’obligation · `contract.source_events[5].obligation.obligation_id` | ARC-520 |
| Quantité requise · `contract.source_events[5].obligation.quantity` | 330 |
| Destinataire · `contract.source_events[5].obligation.recipient` | RECIPIENT-EST |
| Révision · `contract.source_events[5].obligation.revision` | 2 |
| `contract.source_events[5].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[5].obligation.spec.instructions_en` | Import this serial for return bin R-08 and recipient reference EAST-27; preserve both identifiers. |
| `contract.source_events[5].obligation.spec.instructions_fr` | Importer ce numéro pour le bac de retour R-08 et la référence destinataire EAST-27 ; conserver les deux identifiants. |
| `contract.source_events[5].obligation.spec.lot` | ARC-E27-20261106 |
| `contract.source_events[5].obligation.spec.name_en` | Digital loan return record |
| `contract.source_events[5].obligation.spec.name_fr` | Fiche numérique de retour de prêt |
| `contract.source_events[5].obligation.spec.serial_prefix` | ARC520-E27- |
| `contract.source_events[5].obligation.spec.sku` | ARCHIVE-RETURN-B4 |
| État consigné · `contract.source_events[5].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[5].obligation_id` | ARC-520 |
| `contract.source_events[5].sequence` | 6 |
| `contract.source_events[5].type` | AMEND |
| Échéance logique · `contract.source_events[6].obligation.deadline_tick` | 130 |
| Identité de l’obligation · `contract.source_events[6].obligation.obligation_id` | ARC-410 |
| Quantité requise · `contract.source_events[6].obligation.quantity` | 420 |
| Destinataire · `contract.source_events[6].obligation.recipient` | RECIPIENT-NORD |
| Révision · `contract.source_events[6].obligation.revision` | 3 |
| `contract.source_events[6].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[6].obligation.spec.instructions_en` | Import this serial under accession N26 with shelf code B-14; retain the revision shown in the job. |
| `contract.source_events[6].obligation.spec.instructions_fr` | Importer ce numéro sous l’entrée N26 avec le code d’étagère B-14 ; conserver la révision indiquée dans le dossier. |
| `contract.source_events[6].obligation.spec.lot` | ARC-N26-20261106 |
| `contract.source_events[6].obligation.spec.name_en` | Digital archive box index |
| `contract.source_events[6].obligation.spec.name_fr` | Index numérique de boîte d’archives |
| `contract.source_events[6].obligation.spec.serial_prefix` | ARC410-N26- |
| `contract.source_events[6].obligation.spec.sku` | ARCHIVE-BOX-A7 |
| État consigné · `contract.source_events[6].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[6].obligation_id` | ARC-410 |
| `contract.source_events[6].sequence` | 7 |
| `contract.source_events[6].type` | AMEND |
| Identité de l’obligation · `contract.source_events[7].obligation_id` | ARC-740 |
| `contract.source_events[7].sequence` | 8 |
| `contract.source_events[7].type` | CANCEL |
| `contract.source_id` | AUTHORED-ARCHIVE-TRANSFER-EVENTS |
| Empreintes des octets sources · `contract.source_sha256` | bba4d4ad000f97e302cd199c68dd2ff2f6117dd8197b7ae89c1f3872d00d8d4a |
| Horloge de départ (ns) · `contract.start_ns` | 262587856586 |
| Échéance en temps écoulé (ms) · `contract.wall_deadline_ms` | 90000 |
| `controller.capacity_databases[0].path` | evidence/capacity/ARCHIVE-PRIMARY.ALL.sqlite |
| Identité du fournisseur · `controller.capacity_databases[0].provider_id` | ARCHIVE-PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Identité de la fenêtre de capacité · `controller.capacity_databases[0].window_id` | ALL |
| `controller.capacity_databases[1].path` | evidence/capacity/ARCHIVE-BACKUP.ALL.sqlite |
| Identité du fournisseur · `controller.capacity_databases[1].provider_id` | ARCHIVE-BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[1].window_id` | ALL |
| `controller.capacity_databases[2].path` | evidence/capacity/ARCHIVE-COMPAT-A.EARLY.sqlite |
| Identité du fournisseur · `controller.capacity_databases[2].provider_id` | ARCHIVE-COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[2].window_id` | EARLY |
| `controller.capacity_databases[3].path` | evidence/capacity/ARCHIVE-COMPAT-A.LATE.sqlite |
| Identité du fournisseur · `controller.capacity_databases[3].provider_id` | ARCHIVE-COMPAT-A |
| `controller.capacity_databases[3].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[3].window_id` | Tardif (`LATE`) |
| `controller.capacity_databases[4].path` | evidence/capacity/ARCHIVE-COMPAT-B.LATE.sqlite |
| Identité du fournisseur · `controller.capacity_databases[4].provider_id` | ARCHIVE-COMPAT-B |
| `controller.capacity_databases[4].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[4].window_id` | Tardif (`LATE`) |
| `controller.clock_tick` | 279 |
| Cohorte d’expérience · `controller.cohort` | successor |
| SHA-256 du contrat conservé · `controller.contract_sha256` | 4b0175bd4cf77f0d87cb495b29ee9ebb1fc805429148a8de5d6b8f514056b02a |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-BACKUP.ALL.sqlite` | c5e44fd50f95429735a7247de823e976e01c00cad02111adf28debb1a6c387ff |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-COMPAT-A.EARLY.sqlite` | 8bf340579c3dc5c1b0b2391db4985e67b09a0a9e5f7655f76c22681b199039df |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-COMPAT-A.LATE.sqlite` | e6489c9e7a2aa8847f397ebb4a2e320a842e5aa9ec753fc231ae090ad997553c |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-COMPAT-B.LATE.sqlite` | 6675cdaca1b44a76e5709190b5a4f8ff94dcd505e2f4b36add12caac4d8317d2 |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-PRIMARY.ALL.sqlite` | 6694a8bb9385144faab58562d7ff198dc84c6248f35b16163cb560fdc6ee3a63 |
| `controller.db_snapshots.evidence/participants.sqlite` | 9dfe18eb473006c1fef7f495a3bbc94088975dc666684b49dc843728b4720d7c |
| `controller.db_snapshots.evidence/producer.sqlite` | 2a6cdf29461e8ee54e3f9261de34b8a855ad2f6a4059b0b538416ff9786a94b4 |
| `controller.db_snapshots.evidence/receiver.sqlite` | 5681d1454d566858d1b6715b297442ebcd33dd1a46899beb84d22f50b88f9826 |
| `controller.errors` | Aucune entrée |
| `controller.events[0].detail.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| Empreinte externe de référence · `controller.events[0].detail.reference_sha256` | 09fc8f5d832610f3c4ca6cdf99fc385ea4606fcdcd63685742b0dc0f5ec77fa9 |
| Graine consignée · `controller.events[0].detail.seed` | 7919 |
| Événement consigné · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 262778390878 |
| Instant logique · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 2856 |
| `controller.events[1].detail.restart` | Non |
| `controller.events[1].detail.service` | participants |
| Événement consigné · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 262991548595 |
| Instant logique · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 2857 |
| `controller.events[2].detail.restart` | Non |
| `controller.events[2].detail.service` | producer |
| Événement consigné · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 263142875234 |
| Instant logique · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 2858 |
| `controller.events[3].detail.restart` | Non |
| `controller.events[3].detail.service` | receiver |
| Événement consigné · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 263181109713 |
| Instant logique · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 2859 |
| Identité du fournisseur · `controller.events[4].detail.provider_id` | ARCHIVE-PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[4].detail.window_id` | ALL |
| Événement consigné · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 263228624106 |
| Instant logique · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 2860 |
| Identité du fournisseur · `controller.events[5].detail.provider_id` | ARCHIVE-BACKUP |
| Identité de la fenêtre de capacité · `controller.events[5].detail.window_id` | ALL |
| Événement consigné · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 263269402047 |
| Instant logique · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 2861 |
| Identité du fournisseur · `controller.events[6].detail.provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[6].detail.window_id` | EARLY |
| Événement consigné · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 263311040844 |
| Instant logique · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 2862 |
| Identité du fournisseur · `controller.events[7].detail.provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[7].detail.window_id` | Tardif (`LATE`) |
| Événement consigné · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 263351067269 |
| Instant logique · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.pid` | 2863 |
| Identité du fournisseur · `controller.events[8].detail.provider_id` | ARCHIVE-COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[8].detail.window_id` | Tardif (`LATE`) |
| Événement consigné · `controller.events[8].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[8].monotonic_ns` | 263425585744 |
| Instant logique · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.affected[0]` | ARCHIVE-PRIMARY.ALL |
| `controller.events[9].detail.affected[1]` | ARCHIVE-BACKUP.ALL |
| `controller.events[9].detail.dependency` | SHARED-INDEX-NETWORK |
| Événement consigné · `controller.events[9].event` | DEPENDENCY_DISABLED |
| `controller.events[9].monotonic_ns` | 263427074134 |
| Instant logique · `controller.events[9].tick` | 0 |
| `controller.events[10].detail.isolation.applied` | Oui |
| `controller.events[10].detail.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.events[10].detail.isolation.probe.authority_open_denied` | Oui |
| `controller.events[10].detail.isolation.probe.network_denied` | Oui |
| `controller.events[10].detail.isolation.probe.process_inspection_denied` | Oui |
| `controller.events[10].detail.isolation.probe.spawn_denied` | Oui |
| `controller.events[10].detail.isolation.probe.workspace_open_denied` | Oui |
| `controller.events[10].detail.pid` | 2864 |
| `controller.events[10].detail.restart` | Non |
| Événement consigné · `controller.events[10].event` | CANDIDATE_STARTED |
| `controller.events[10].monotonic_ns` | 263463572597 |
| Instant logique · `controller.events[10].tick` | 0 |
| `controller.events[11].detail.args` | Aucune entrée |
| `controller.events[11].detail.op` | status |
| Événement consigné · `controller.events[11].event` | BROKER_REQUEST |
| `controller.events[11].monotonic_ns` | 263465468187 |
| Instant logique · `controller.events[11].tick` | 1 |
| `controller.events[12].detail.measurement_kind` | Mesure déclarée par le candidat (`CANDIDATE_REPORTED`) |
| `controller.events[12].detail.pid` | 2864 |
| `controller.events[12].detail.report.assignment_domain` | 6561 |
| `controller.events[12].detail.report.candidate_elapsed_ns` | 4497808 |
| `controller.events[12].detail.report.capacity_prunes` | 62 |
| `controller.events[12].detail.report.complete_assignments_observed` | 48 |
| `controller.events[12].detail.report.exhaustive_within_declared_domain` | Oui |
| `controller.events[12].detail.report.feasible_assignments` | 27 |
| `controller.events[12].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Procédure candidate · `controller.events[12].detail.report.method` | harness |
| `controller.events[12].detail.report.partial_nodes_observed` | 125 |
| `controller.events[12].detail.report.participant_prunes` | 21 |
| `controller.events[12].detail.report.price_prunes` | 15 |
| Événement consigné · `controller.events[12].event` | CANDIDATE_PLANNING |
| `controller.events[12].monotonic_ns` | 263474204732 |
| Instant logique · `controller.events[12].tick` | 1 |
| Premier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[0].last_unit` | 150 |
| Identité du lot fixe · `controller.events[13].detail.args.proposal.allocations[0].lot_id` | ARC-410.L001 |
| Identité de l’obligation · `controller.events[13].detail.args.proposal.allocations[0].obligation_id` | ARC-410 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.allocations[0].pay_minor` | 4220 |
| Identité du fournisseur · `controller.events[13].detail.args.proposal.allocations[0].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[13].detail.args.proposal.allocations[0].window_id` | EARLY |
| Premier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[1].first_unit` | 151 |
| Dernier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[1].last_unit` | 300 |
| Identité du lot fixe · `controller.events[13].detail.args.proposal.allocations[1].lot_id` | ARC-410.L002 |
| Identité de l’obligation · `controller.events[13].detail.args.proposal.allocations[1].obligation_id` | ARC-410 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[13].detail.args.proposal.allocations[1].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[13].detail.args.proposal.allocations[1].window_id` | EARLY |
| Premier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[2].first_unit` | 301 |
| Dernier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[2].last_unit` | 420 |
| Identité du lot fixe · `controller.events[13].detail.args.proposal.allocations[2].lot_id` | ARC-410.L003 |
| Identité de l’obligation · `controller.events[13].detail.args.proposal.allocations[2].obligation_id` | ARC-410 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[13].detail.args.proposal.allocations[2].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[13].detail.args.proposal.allocations[2].window_id` | EARLY |
| Premier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[3].last_unit` | 150 |
| Identité du lot fixe · `controller.events[13].detail.args.proposal.allocations[3].lot_id` | ARC-520.L001 |
| Identité de l’obligation · `controller.events[13].detail.args.proposal.allocations[3].obligation_id` | ARC-520 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[13].detail.args.proposal.allocations[3].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[13].detail.args.proposal.allocations[3].window_id` | EARLY |
| Premier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[4].first_unit` | 151 |
| Dernier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[4].last_unit` | 300 |
| Identité du lot fixe · `controller.events[13].detail.args.proposal.allocations[4].lot_id` | ARC-520.L002 |
| Identité de l’obligation · `controller.events[13].detail.args.proposal.allocations[4].obligation_id` | ARC-520 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[13].detail.args.proposal.allocations[4].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[13].detail.args.proposal.allocations[4].window_id` | Tardif (`LATE`) |
| Premier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[5].first_unit` | 301 |
| Dernier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[5].last_unit` | 330 |
| Identité du lot fixe · `controller.events[13].detail.args.proposal.allocations[5].lot_id` | ARC-520.L003 |
| Identité de l’obligation · `controller.events[13].detail.args.proposal.allocations[5].obligation_id` | ARC-520 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.allocations[5].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[13].detail.args.proposal.allocations[5].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[13].detail.args.proposal.allocations[5].window_id` | Tardif (`LATE`) |
| Premier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[6].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[6].last_unit` | 150 |
| Identité du lot fixe · `controller.events[13].detail.args.proposal.allocations[6].lot_id` | ARC-630.L001 |
| Identité de l’obligation · `controller.events[13].detail.args.proposal.allocations[6].obligation_id` | ARC-630 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.allocations[6].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[13].detail.args.proposal.allocations[6].provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[13].detail.args.proposal.allocations[6].window_id` | Tardif (`LATE`) |
| Premier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[7].first_unit` | 151 |
| Dernier ordinal inclus · `controller.events[13].detail.args.proposal.allocations[7].last_unit` | 270 |
| Identité du lot fixe · `controller.events[13].detail.args.proposal.allocations[7].lot_id` | ARC-630.L002 |
| Identité de l’obligation · `controller.events[13].detail.args.proposal.allocations[7].obligation_id` | ARC-630 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.allocations[7].pay_minor` | 1190 |
| Identité du fournisseur · `controller.events[13].detail.args.proposal.allocations[7].provider_id` | ARCHIVE-COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[13].detail.args.proposal.allocations[7].window_id` | Tardif (`LATE`) |
| Prix acheteur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.buyer_price_minor` | 5700 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `controller.events[13].detail.args.proposal.contract_sha256` | 4b0175bd4cf77f0d87cb495b29ee9ebb1fc805429148a8de5d6b8f514056b02a |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.coordinator_fee_minor` | 290 |
| Instant exclusif d’expiration · `controller.events[13].detail.args.proposal.expires_tick` | 560 |
| Révision des politiques · `controller.events[13].detail.args.proposal.policy_revision` | 1 |
| Identité de la proposition · `controller.events[13].detail.args.proposal.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `controller.events[13].detail.args.proposal.rework_budget_minor` | 2340 |
| Schéma · `controller.events[13].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[13].detail.op` | propose |
| Événement consigné · `controller.events[13].event` | BROKER_REQUEST |
| `controller.events[13].monotonic_ns` | 263475068853 |
| Instant logique · `controller.events[13].tick` | 2 |
| Identité de la proposition · `controller.events[14].detail.args.proposal_id` | proposal-001 |
| `controller.events[14].detail.op` | decide |
| Événement consigné · `controller.events[14].event` | BROKER_REQUEST |
| `controller.events[14].monotonic_ns` | 263479854204 |
| Instant logique · `controller.events[14].tick` | 3 |
| `controller.events[15].detail.args` | Aucune entrée |
| `controller.events[15].detail.op` | status |
| Événement consigné · `controller.events[15].event` | BROKER_REQUEST |
| `controller.events[15].monotonic_ns` | 263484364020 |
| Instant logique · `controller.events[15].tick` | 4 |
| Identité de l’accord · `controller.events[16].detail.args.agreement_id` | proposal-001 |
| `controller.events[16].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[16].detail.args.lot_id` | ARC-410.L001 |
| `controller.events[16].detail.op` | reserve |
| Événement consigné · `controller.events[16].event` | BROKER_REQUEST |
| `controller.events[16].monotonic_ns` | 263489570912 |
| Instant logique · `controller.events[16].tick` | 5 |
| `controller.events[17].detail.key` | proposal-001.ARC-410.L001.A1 |
| `controller.events[17].detail.slot` | ARCHIVE-COMPAT-A.EARLY |
| État consigné · `controller.events[17].detail.status` | RESERVED |
| Événement consigné · `controller.events[17].event` | CAPACITY_RESERVED |
| `controller.events[17].monotonic_ns` | 263511371378 |
| Instant logique · `controller.events[17].tick` | 5 |
| Identité de l’accord · `controller.events[18].detail.args.agreement_id` | proposal-001 |
| `controller.events[18].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[18].detail.args.lot_id` | ARC-410.L001 |
| `controller.events[18].detail.args.supersedes` | Non consigné |
| `controller.events[18].detail.op` | produce |
| Événement consigné · `controller.events[18].event` | BROKER_REQUEST |
| `controller.events[18].monotonic_ns` | 263511643028 |
| Instant logique · `controller.events[18].tick` | 6 |
| `controller.events[19].detail.byte_count` | 73680 |
| `controller.events[19].detail.payload_sha256` | 75b46223ccc1f562903e39278010c0e6d446371acc6643e338804cc8c4c398c4 |
| `controller.events[19].detail.production_id` | proposal-001.ARC-410.L001.A1 |
| Quantité requise · `controller.events[19].detail.quantity` | 150 |
| Événement consigné · `controller.events[19].event` | PRODUCT_MATERIALIZED |
| `controller.events[19].monotonic_ns` | 263544071403 |
| Instant logique · `controller.events[19].tick` | 6 |
| `controller.events[20].detail.args.production_id` | proposal-001.ARC-410.L001.A1 |
| `controller.events[20].detail.op` | transfer |
| Événement consigné · `controller.events[20].event` | BROKER_REQUEST |
| `controller.events[20].monotonic_ns` | 263544379256 |
| Instant logique · `controller.events[20].tick` | 7 |
| `controller.events[21].detail.byte_count` | 73680 |
| `controller.events[21].detail.delivery_id` | proposal-001.ARC-410.L001.A1.D |
| `controller.events[21].detail.produced_sha256` | 75b46223ccc1f562903e39278010c0e6d446371acc6643e338804cc8c4c398c4 |
| `controller.events[21].detail.production_id` | proposal-001.ARC-410.L001.A1 |
| `controller.events[21].detail.received_sha256` | 75b46223ccc1f562903e39278010c0e6d446371acc6643e338804cc8c4c398c4 |
| Événement consigné · `controller.events[21].event` | PRODUCT_TRANSFERRED |
| `controller.events[21].monotonic_ns` | 263549347466 |
| Instant logique · `controller.events[21].tick` | 7 |
| `controller.events[22].detail.args.delivery_id` | proposal-001.ARC-410.L001.A1.D |
| `controller.events[22].detail.op` | inspect |
| Événement consigné · `controller.events[22].event` | BROKER_REQUEST |
| `controller.events[22].monotonic_ns` | 263549538627 |
| Instant logique · `controller.events[22].tick` | 8 |
| `controller.events[23].detail.accepted_units` | 150 |
| `controller.events[23].detail.delivery_id` | proposal-001.ARC-410.L001.A1.D |
| État consigné · `controller.events[23].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[23].detail.timely` | Oui |
| Événement consigné · `controller.events[23].event` | RECIPIENT_INSPECTED |
| `controller.events[23].monotonic_ns` | 263562792058 |
| Instant logique · `controller.events[23].tick` | 8 |
| `controller.events[24].detail.args` | Aucune entrée |
| `controller.events[24].detail.op` | status |
| Événement consigné · `controller.events[24].event` | BROKER_REQUEST |
| `controller.events[24].monotonic_ns` | 263563079722 |
| Instant logique · `controller.events[24].tick` | 9 |
| Identité de l’accord · `controller.events[25].detail.args.agreement_id` | proposal-001 |
| `controller.events[25].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[25].detail.args.lot_id` | ARC-410.L002 |
| `controller.events[25].detail.op` | reserve |
| Événement consigné · `controller.events[25].event` | BROKER_REQUEST |
| `controller.events[25].monotonic_ns` | 263568841469 |
| Instant logique · `controller.events[25].tick` | 10 |
| `controller.events[26].detail.key` | proposal-001.ARC-410.L002.A1 |
| `controller.events[26].detail.slot` | ARCHIVE-COMPAT-A.EARLY |
| État consigné · `controller.events[26].detail.status` | RESERVED |
| Événement consigné · `controller.events[26].event` | CAPACITY_RESERVED |
| `controller.events[26].monotonic_ns` | 263573612029 |
| Instant logique · `controller.events[26].tick` | 10 |
| Identité de l’accord · `controller.events[27].detail.args.agreement_id` | proposal-001 |
| `controller.events[27].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[27].detail.args.lot_id` | ARC-410.L002 |
| `controller.events[27].detail.args.supersedes` | Non consigné |
| `controller.events[27].detail.op` | produce |
| Événement consigné · `controller.events[27].event` | BROKER_REQUEST |
| `controller.events[27].monotonic_ns` | 263573846974 |
| Instant logique · `controller.events[27].tick` | 11 |
| `controller.events[28].detail.byte_count` | 73790 |
| `controller.events[28].detail.payload_sha256` | b1b14777863894e3af3b958603da9aa7f97cd90d0baef46ba54cb6c77de933eb |
| `controller.events[28].detail.production_id` | proposal-001.ARC-410.L002.A1 |
| Quantité requise · `controller.events[28].detail.quantity` | 150 |
| Événement consigné · `controller.events[28].event` | PRODUCT_MATERIALIZED |
| `controller.events[28].monotonic_ns` | 264058146568 |
| Instant logique · `controller.events[28].tick` | 11 |
| `controller.events[29].detail.args.production_id` | proposal-001.ARC-410.L002.A1 |
| `controller.events[29].detail.op` | transfer |
| Événement consigné · `controller.events[29].event` | BROKER_REQUEST |
| `controller.events[29].monotonic_ns` | 264058516893 |
| Instant logique · `controller.events[29].tick` | 12 |
| `controller.events[30].detail.byte_count` | 73790 |
| `controller.events[30].detail.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[30].detail.produced_sha256` | b1b14777863894e3af3b958603da9aa7f97cd90d0baef46ba54cb6c77de933eb |
| `controller.events[30].detail.production_id` | proposal-001.ARC-410.L002.A1 |
| `controller.events[30].detail.received_sha256` | b1b14777863894e3af3b958603da9aa7f97cd90d0baef46ba54cb6c77de933eb |
| Événement consigné · `controller.events[30].event` | PRODUCT_TRANSFERRED |
| `controller.events[30].monotonic_ns` | 264063719839 |
| Instant logique · `controller.events[30].tick` | 12 |
| `controller.events[31].detail.args.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[31].detail.op` | inspect |
| Événement consigné · `controller.events[31].event` | BROKER_REQUEST |
| `controller.events[31].monotonic_ns` | 264063932511 |
| Instant logique · `controller.events[31].tick` | 13 |
| `controller.events[32].detail.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[32].detail.hook` | inspect.after_observation |
| Événement consigné · `controller.events[32].detail.schedule.event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.events[32].detail.schedule.occurrence` | 2 |
| Cible de la panne · `controller.events[32].detail.schedule.target` | ANY |
| Opération déclenchante · `controller.events[32].detail.schedule.trigger` | inspect |
| Valeur configurée · `controller.events[32].detail.schedule.value` | 0 |
| Événement consigné · `controller.events[32].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| `controller.events[32].monotonic_ns` | 264077030994 |
| Instant logique · `controller.events[32].tick` | 13 |
| `controller.events[33].detail.pid` | 2858 |
| `controller.events[33].detail.service` | receiver |
| Événement consigné · `controller.events[33].event` | SERVICE_TERMINATED |
| `controller.events[33].monotonic_ns` | 264080195901 |
| Instant logique · `controller.events[33].tick` | 13 |
| `controller.events[34].detail.pid` | 2865 |
| `controller.events[34].detail.restart` | Oui |
| `controller.events[34].detail.service` | receiver |
| Événement consigné · `controller.events[34].event` | SERVICE_STARTED |
| `controller.events[34].monotonic_ns` | 264114278500 |
| Instant logique · `controller.events[34].tick` | 13 |
| `controller.events[35].detail.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| Événement consigné · `controller.events[35].event` | ACKNOWLEDGMENT_UNCERTAIN |
| `controller.events[35].monotonic_ns` | 264114283157 |
| Instant logique · `controller.events[35].tick` | 13 |
| Code stable · `controller.events[36].detail.code` | ACK_UNKNOWN |
| `controller.events[36].detail.detail` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[36].detail.op` | inspect |
| Événement consigné · `controller.events[36].event` | BROKER_REFUSED |
| `controller.events[36].monotonic_ns` | 264114294474 |
| Instant logique · `controller.events[36].tick` | 13 |
| `controller.events[37].detail.args.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[37].detail.op` | inspect |
| Événement consigné · `controller.events[37].event` | BROKER_REQUEST |
| `controller.events[37].monotonic_ns` | 264114537521 |
| Instant logique · `controller.events[37].tick` | 14 |
| `controller.events[38].detail.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| État consigné · `controller.events[38].detail.status` | Accepté (`ACCEPTED`) |
| Événement consigné · `controller.events[38].event` | ACCEPTANCE_RECONCILED |
| `controller.events[38].monotonic_ns` | 264114895258 |
| Instant logique · `controller.events[38].tick` | 14 |
| `controller.events[39].detail.args` | Aucune entrée |
| `controller.events[39].detail.op` | status |
| Événement consigné · `controller.events[39].event` | BROKER_REQUEST |
| `controller.events[39].monotonic_ns` | 264115153227 |
| Instant logique · `controller.events[39].tick` | 15 |
| Identité de l’accord · `controller.events[40].detail.args.agreement_id` | proposal-001 |
| `controller.events[40].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[40].detail.args.lot_id` | ARC-410.L003 |
| `controller.events[40].detail.op` | reserve |
| Événement consigné · `controller.events[40].event` | BROKER_REQUEST |
| `controller.events[40].monotonic_ns` | 264121861548 |
| Instant logique · `controller.events[40].tick` | 16 |
| `controller.events[41].detail.key` | proposal-001.ARC-410.L003.A1 |
| `controller.events[41].detail.slot` | ARCHIVE-COMPAT-A.EARLY |
| État consigné · `controller.events[41].detail.status` | RESERVED |
| Événement consigné · `controller.events[41].event` | CAPACITY_RESERVED |
| `controller.events[41].monotonic_ns` | 264194796051 |
| Instant logique · `controller.events[41].tick` | 16 |
| Identité de l’accord · `controller.events[42].detail.args.agreement_id` | proposal-001 |
| `controller.events[42].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[42].detail.args.lot_id` | ARC-410.L003 |
| `controller.events[42].detail.args.supersedes` | Non consigné |
| `controller.events[42].detail.op` | produce |
| Événement consigné · `controller.events[42].event` | BROKER_REQUEST |
| `controller.events[42].monotonic_ns` | 264195134479 |
| Instant logique · `controller.events[42].tick` | 17 |
| `controller.events[43].detail.byte_count` | 59150 |
| `controller.events[43].detail.payload_sha256` | 621fa2e4d1f41f152eb7b6438f935d747861f4278c3f79626202e84b0f4bda7e |
| `controller.events[43].detail.production_id` | proposal-001.ARC-410.L003.A1 |
| Quantité requise · `controller.events[43].detail.quantity` | 120 |
| Événement consigné · `controller.events[43].event` | PRODUCT_MATERIALIZED |
| `controller.events[43].monotonic_ns` | 264315294433 |
| Instant logique · `controller.events[43].tick` | 17 |
| `controller.events[44].detail.args.production_id` | proposal-001.ARC-410.L003.A1 |
| `controller.events[44].detail.op` | transfer |
| Événement consigné · `controller.events[44].event` | BROKER_REQUEST |
| `controller.events[44].monotonic_ns` | 264315628604 |
| Instant logique · `controller.events[44].tick` | 18 |
| `controller.events[45].detail.byte_count` | 59150 |
| `controller.events[45].detail.delivery_id` | proposal-001.ARC-410.L003.A1.D |
| `controller.events[45].detail.produced_sha256` | 621fa2e4d1f41f152eb7b6438f935d747861f4278c3f79626202e84b0f4bda7e |
| `controller.events[45].detail.production_id` | proposal-001.ARC-410.L003.A1 |
| `controller.events[45].detail.received_sha256` | 621fa2e4d1f41f152eb7b6438f935d747861f4278c3f79626202e84b0f4bda7e |
| Événement consigné · `controller.events[45].event` | PRODUCT_TRANSFERRED |
| `controller.events[45].monotonic_ns` | 264321200613 |
| Instant logique · `controller.events[45].tick` | 18 |
| `controller.events[46].detail.args.delivery_id` | proposal-001.ARC-410.L003.A1.D |
| `controller.events[46].detail.op` | inspect |
| Événement consigné · `controller.events[46].event` | BROKER_REQUEST |
| `controller.events[46].monotonic_ns` | 264321434097 |
| Instant logique · `controller.events[46].tick` | 19 |
| `controller.events[47].detail.accepted_units` | 120 |
| `controller.events[47].detail.delivery_id` | proposal-001.ARC-410.L003.A1.D |
| État consigné · `controller.events[47].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[47].detail.timely` | Oui |
| Événement consigné · `controller.events[47].event` | RECIPIENT_INSPECTED |
| `controller.events[47].monotonic_ns` | 264332513559 |
| Instant logique · `controller.events[47].tick` | 19 |
| `controller.events[48].detail.args` | Aucune entrée |
| `controller.events[48].detail.op` | status |
| Événement consigné · `controller.events[48].event` | BROKER_REQUEST |
| `controller.events[48].monotonic_ns` | 264332826700 |
| Instant logique · `controller.events[48].tick` | 20 |
| Identité de l’accord · `controller.events[49].detail.args.agreement_id` | proposal-001 |
| `controller.events[49].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[49].detail.args.lot_id` | ARC-520.L001 |
| `controller.events[49].detail.op` | reserve |
| Événement consigné · `controller.events[49].event` | BROKER_REQUEST |
| `controller.events[49].monotonic_ns` | 264340236753 |
| Instant logique · `controller.events[49].tick` | 21 |
| `controller.events[50].detail.key` | proposal-001.ARC-520.L001.A1 |
| `controller.events[50].detail.slot` | ARCHIVE-COMPAT-A.EARLY |
| État consigné · `controller.events[50].detail.status` | RESERVED |
| Événement consigné · `controller.events[50].event` | CAPACITY_RESERVED |
| `controller.events[50].monotonic_ns` | 264521518819 |
| Instant logique · `controller.events[50].tick` | 21 |
| Identité de l’accord · `controller.events[51].detail.args.agreement_id` | proposal-001 |
| `controller.events[51].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[51].detail.args.lot_id` | ARC-520.L001 |
| `controller.events[51].detail.args.supersedes` | Non consigné |
| `controller.events[51].detail.op` | produce |
| Événement consigné · `controller.events[51].event` | BROKER_REQUEST |
| `controller.events[51].monotonic_ns` | 264521941411 |
| Instant logique · `controller.events[51].tick` | 22 |
| `controller.events[52].detail.byte_count` | 69929 |
| `controller.events[52].detail.payload_sha256` | 54ba6e39748c07c3f3b85e81d694c245b90bcff6e44ac7a49f82c60e116e1b2e |
| `controller.events[52].detail.production_id` | proposal-001.ARC-520.L001.A1 |
| Quantité requise · `controller.events[52].detail.quantity` | 150 |
| Événement consigné · `controller.events[52].event` | PRODUCT_MATERIALIZED |
| `controller.events[52].monotonic_ns` | 264598524876 |
| Instant logique · `controller.events[52].tick` | 22 |
| `controller.events[53].detail.args.production_id` | proposal-001.ARC-520.L001.A1 |
| `controller.events[53].detail.op` | transfer |
| Événement consigné · `controller.events[53].event` | BROKER_REQUEST |
| `controller.events[53].monotonic_ns` | 264598863694 |
| Instant logique · `controller.events[53].tick` | 23 |
| `controller.events[54].detail.byte_count` | 69929 |
| `controller.events[54].detail.delivery_id` | proposal-001.ARC-520.L001.A1.D |
| `controller.events[54].detail.produced_sha256` | 54ba6e39748c07c3f3b85e81d694c245b90bcff6e44ac7a49f82c60e116e1b2e |
| `controller.events[54].detail.production_id` | proposal-001.ARC-520.L001.A1 |
| `controller.events[54].detail.received_sha256` | 54ba6e39748c07c3f3b85e81d694c245b90bcff6e44ac7a49f82c60e116e1b2e |
| Événement consigné · `controller.events[54].event` | PRODUCT_TRANSFERRED |
| `controller.events[54].monotonic_ns` | 264619802513 |
| Instant logique · `controller.events[54].tick` | 23 |
| `controller.events[55].detail.args.delivery_id` | proposal-001.ARC-520.L001.A1.D |
| `controller.events[55].detail.op` | inspect |
| Événement consigné · `controller.events[55].event` | BROKER_REQUEST |
| `controller.events[55].monotonic_ns` | 264620066111 |
| Instant logique · `controller.events[55].tick` | 24 |
| `controller.events[56].detail.accepted_units` | 150 |
| `controller.events[56].detail.delivery_id` | proposal-001.ARC-520.L001.A1.D |
| État consigné · `controller.events[56].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[56].detail.timely` | Oui |
| Événement consigné · `controller.events[56].event` | RECIPIENT_INSPECTED |
| `controller.events[56].monotonic_ns` | 264633213386 |
| Instant logique · `controller.events[56].tick` | 24 |
| `controller.events[57].detail.args` | Aucune entrée |
| `controller.events[57].detail.op` | status |
| Événement consigné · `controller.events[57].event` | BROKER_REQUEST |
| `controller.events[57].monotonic_ns` | 264633540457 |
| Instant logique · `controller.events[57].tick` | 25 |
| Identité de l’accord · `controller.events[58].detail.args.agreement_id` | proposal-001 |
| `controller.events[58].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[58].detail.args.lot_id` | ARC-520.L002 |
| `controller.events[58].detail.op` | reserve |
| Événement consigné · `controller.events[58].event` | BROKER_REQUEST |
| `controller.events[58].monotonic_ns` | 264641847540 |
| Instant logique · `controller.events[58].tick` | 26 |
| Identité du fournisseur · `controller.events[59].detail.provider_id` | ARCHIVE-COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[59].detail.window_id` | Tardif (`LATE`) |
| Événement consigné · `controller.events[59].event` | WINDOW_ADVANCED |
| `controller.events[59].monotonic_ns` | 264645705256 |
| Instant logique · `controller.events[59].tick` | 260 |
| `controller.events[60].detail.key` | proposal-001.ARC-520.L002.A1 |
| `controller.events[60].detail.slot` | ARCHIVE-COMPAT-A.LATE |
| État consigné · `controller.events[60].detail.status` | RESERVED |
| Événement consigné · `controller.events[60].event` | CAPACITY_RESERVED |
| `controller.events[60].monotonic_ns` | 264647727592 |
| Instant logique · `controller.events[60].tick` | 260 |
| Identité de l’accord · `controller.events[61].detail.args.agreement_id` | proposal-001 |
| `controller.events[61].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[61].detail.args.lot_id` | ARC-520.L002 |
| `controller.events[61].detail.args.supersedes` | Non consigné |
| `controller.events[61].detail.op` | produce |
| Événement consigné · `controller.events[61].event` | BROKER_REQUEST |
| `controller.events[61].monotonic_ns` | 264647996017 |
| Instant logique · `controller.events[61].tick` | 261 |
| `controller.events[62].detail.byte_count` | 70039 |
| `controller.events[62].detail.payload_sha256` | 99fbc03732a92a78d94f1d88aafc7ace74ba17c26d28fae98afd78dcccdf58ec |
| `controller.events[62].detail.production_id` | proposal-001.ARC-520.L002.A1 |
| Quantité requise · `controller.events[62].detail.quantity` | 150 |
| Événement consigné · `controller.events[62].event` | PRODUCT_MATERIALIZED |
| `controller.events[62].monotonic_ns` | 264745593419 |
| Instant logique · `controller.events[62].tick` | 261 |
| `controller.events[63].detail.args.production_id` | proposal-001.ARC-520.L002.A1 |
| `controller.events[63].detail.op` | transfer |
| Événement consigné · `controller.events[63].event` | BROKER_REQUEST |
| `controller.events[63].monotonic_ns` | 264745938567 |
| Instant logique · `controller.events[63].tick` | 262 |
| `controller.events[64].detail.byte_count` | 70039 |
| `controller.events[64].detail.delivery_id` | proposal-001.ARC-520.L002.A1.D |
| `controller.events[64].detail.produced_sha256` | 99fbc03732a92a78d94f1d88aafc7ace74ba17c26d28fae98afd78dcccdf58ec |
| `controller.events[64].detail.production_id` | proposal-001.ARC-520.L002.A1 |
| `controller.events[64].detail.received_sha256` | 99fbc03732a92a78d94f1d88aafc7ace74ba17c26d28fae98afd78dcccdf58ec |
| Événement consigné · `controller.events[64].event` | PRODUCT_TRANSFERRED |
| `controller.events[64].monotonic_ns` | 264751881902 |
| Instant logique · `controller.events[64].tick` | 262 |
| `controller.events[65].detail.args.delivery_id` | proposal-001.ARC-520.L002.A1.D |
| `controller.events[65].detail.op` | inspect |
| Événement consigné · `controller.events[65].event` | BROKER_REQUEST |
| `controller.events[65].monotonic_ns` | 264752120974 |
| Instant logique · `controller.events[65].tick` | 263 |
| `controller.events[66].detail.accepted_units` | 150 |
| `controller.events[66].detail.delivery_id` | proposal-001.ARC-520.L002.A1.D |
| État consigné · `controller.events[66].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[66].detail.timely` | Oui |
| Événement consigné · `controller.events[66].event` | RECIPIENT_INSPECTED |
| `controller.events[66].monotonic_ns` | 264765157105 |
| Instant logique · `controller.events[66].tick` | 263 |
| `controller.events[67].detail.args` | Aucune entrée |
| `controller.events[67].detail.op` | status |
| Événement consigné · `controller.events[67].event` | BROKER_REQUEST |
| `controller.events[67].monotonic_ns` | 264765437278 |
| Instant logique · `controller.events[67].tick` | 264 |
| Identité de l’accord · `controller.events[68].detail.args.agreement_id` | proposal-001 |
| `controller.events[68].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[68].detail.args.lot_id` | ARC-520.L003 |
| `controller.events[68].detail.op` | reserve |
| Événement consigné · `controller.events[68].event` | BROKER_REQUEST |
| `controller.events[68].monotonic_ns` | 264774328300 |
| Instant logique · `controller.events[68].tick` | 265 |
| `controller.events[69].detail.key` | proposal-001.ARC-520.L003.A1 |
| `controller.events[69].detail.slot` | ARCHIVE-COMPAT-A.LATE |
| État consigné · `controller.events[69].detail.status` | RESERVED |
| Événement consigné · `controller.events[69].event` | CAPACITY_RESERVED |
| `controller.events[69].monotonic_ns` | 264841646081 |
| Instant logique · `controller.events[69].tick` | 265 |
| Identité de l’accord · `controller.events[70].detail.args.agreement_id` | proposal-001 |
| `controller.events[70].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[70].detail.args.lot_id` | ARC-520.L003 |
| `controller.events[70].detail.args.supersedes` | Non consigné |
| `controller.events[70].detail.op` | produce |
| Événement consigné · `controller.events[70].event` | BROKER_REQUEST |
| `controller.events[70].monotonic_ns` | 264842017939 |
| Instant logique · `controller.events[70].tick` | 266 |
| `controller.events[71].detail.byte_count` | 14479 |
| `controller.events[71].detail.payload_sha256` | 4fdd1d369ac548c3163dfe58ebb0f2430d99a9b45dbf59889fc8b6cffe86ace5 |
| `controller.events[71].detail.production_id` | proposal-001.ARC-520.L003.A1 |
| Quantité requise · `controller.events[71].detail.quantity` | 30 |
| Événement consigné · `controller.events[71].event` | PRODUCT_MATERIALIZED |
| `controller.events[71].monotonic_ns` | 264854738766 |
| Instant logique · `controller.events[71].tick` | 266 |
| `controller.events[72].detail.args.production_id` | proposal-001.ARC-520.L003.A1 |
| `controller.events[72].detail.op` | transfer |
| Événement consigné · `controller.events[72].event` | BROKER_REQUEST |
| `controller.events[72].monotonic_ns` | 264855051757 |
| Instant logique · `controller.events[72].tick` | 267 |
| `controller.events[73].detail.byte_count` | 14479 |
| `controller.events[73].detail.delivery_id` | proposal-001.ARC-520.L003.A1.D |
| `controller.events[73].detail.produced_sha256` | 4fdd1d369ac548c3163dfe58ebb0f2430d99a9b45dbf59889fc8b6cffe86ace5 |
| `controller.events[73].detail.production_id` | proposal-001.ARC-520.L003.A1 |
| `controller.events[73].detail.received_sha256` | 4fdd1d369ac548c3163dfe58ebb0f2430d99a9b45dbf59889fc8b6cffe86ace5 |
| Événement consigné · `controller.events[73].event` | PRODUCT_TRANSFERRED |
| `controller.events[73].monotonic_ns` | 264863662336 |
| Instant logique · `controller.events[73].tick` | 267 |
| `controller.events[74].detail.args.delivery_id` | proposal-001.ARC-520.L003.A1.D |
| `controller.events[74].detail.op` | inspect |
| Événement consigné · `controller.events[74].event` | BROKER_REQUEST |
| `controller.events[74].monotonic_ns` | 264863857473 |
| Instant logique · `controller.events[74].tick` | 268 |
| `controller.events[75].detail.accepted_units` | 30 |
| `controller.events[75].detail.delivery_id` | proposal-001.ARC-520.L003.A1.D |
| État consigné · `controller.events[75].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[75].detail.timely` | Oui |
| Événement consigné · `controller.events[75].event` | RECIPIENT_INSPECTED |
| `controller.events[75].monotonic_ns` | 264868448859 |
| Instant logique · `controller.events[75].tick` | 268 |
| `controller.events[76].detail.args` | Aucune entrée |
| `controller.events[76].detail.op` | status |
| Événement consigné · `controller.events[76].event` | BROKER_REQUEST |
| `controller.events[76].monotonic_ns` | 264868707429 |
| Instant logique · `controller.events[76].tick` | 269 |
| Identité de l’accord · `controller.events[77].detail.args.agreement_id` | proposal-001 |
| `controller.events[77].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[77].detail.args.lot_id` | ARC-630.L001 |
| `controller.events[77].detail.op` | reserve |
| Événement consigné · `controller.events[77].event` | BROKER_REQUEST |
| `controller.events[77].monotonic_ns` | 264877983117 |
| Instant logique · `controller.events[77].tick` | 270 |
| `controller.events[78].detail.key` | proposal-001.ARC-630.L001.A1 |
| `controller.events[78].detail.slot` | ARCHIVE-COMPAT-A.LATE |
| État consigné · `controller.events[78].detail.status` | RESERVED |
| Événement consigné · `controller.events[78].event` | CAPACITY_RESERVED |
| `controller.events[78].monotonic_ns` | 264883435490 |
| Instant logique · `controller.events[78].tick` | 270 |
| Identité de l’accord · `controller.events[79].detail.args.agreement_id` | proposal-001 |
| `controller.events[79].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[79].detail.args.lot_id` | ARC-630.L001 |
| `controller.events[79].detail.args.supersedes` | Non consigné |
| `controller.events[79].detail.op` | produce |
| Événement consigné · `controller.events[79].event` | BROKER_REQUEST |
| `controller.events[79].monotonic_ns` | 264883683265 |
| Instant logique · `controller.events[79].tick` | 271 |
| `controller.events[80].detail.byte_count` | 72479 |
| `controller.events[80].detail.payload_sha256` | 1857a3dde816ba270748be6eaee1f41bb89e6b5fd605080e0bbdda22430b06c1 |
| `controller.events[80].detail.production_id` | proposal-001.ARC-630.L001.A1 |
| Quantité requise · `controller.events[80].detail.quantity` | 150 |
| Événement consigné · `controller.events[80].event` | PRODUCT_MATERIALIZED |
| `controller.events[80].monotonic_ns` | 264900124326 |
| Instant logique · `controller.events[80].tick` | 271 |
| `controller.events[81].detail.args.production_id` | proposal-001.ARC-630.L001.A1 |
| `controller.events[81].detail.op` | transfer |
| Événement consigné · `controller.events[81].event` | BROKER_REQUEST |
| `controller.events[81].monotonic_ns` | 264900395996 |
| Instant logique · `controller.events[81].tick` | 272 |
| `controller.events[82].detail.byte_count` | 72479 |
| `controller.events[82].detail.delivery_id` | proposal-001.ARC-630.L001.A1.D |
| `controller.events[82].detail.produced_sha256` | 1857a3dde816ba270748be6eaee1f41bb89e6b5fd605080e0bbdda22430b06c1 |
| `controller.events[82].detail.production_id` | proposal-001.ARC-630.L001.A1 |
| `controller.events[82].detail.received_sha256` | 1857a3dde816ba270748be6eaee1f41bb89e6b5fd605080e0bbdda22430b06c1 |
| Événement consigné · `controller.events[82].event` | PRODUCT_TRANSFERRED |
| `controller.events[82].monotonic_ns` | 264921421362 |
| Instant logique · `controller.events[82].tick` | 272 |
| `controller.events[83].detail.args.delivery_id` | proposal-001.ARC-630.L001.A1.D |
| `controller.events[83].detail.op` | inspect |
| Événement consigné · `controller.events[83].event` | BROKER_REQUEST |
| `controller.events[83].monotonic_ns` | 264921630770 |
| Instant logique · `controller.events[83].tick` | 273 |
| `controller.events[84].detail.accepted_units` | 150 |
| `controller.events[84].detail.delivery_id` | proposal-001.ARC-630.L001.A1.D |
| État consigné · `controller.events[84].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[84].detail.timely` | Oui |
| Événement consigné · `controller.events[84].event` | RECIPIENT_INSPECTED |
| `controller.events[84].monotonic_ns` | 264934766698 |
| Instant logique · `controller.events[84].tick` | 273 |
| `controller.events[85].detail.args` | Aucune entrée |
| `controller.events[85].detail.op` | status |
| Événement consigné · `controller.events[85].event` | BROKER_REQUEST |
| `controller.events[85].monotonic_ns` | 264935085658 |
| Instant logique · `controller.events[85].tick` | 274 |
| Identité de l’accord · `controller.events[86].detail.args.agreement_id` | proposal-001 |
| `controller.events[86].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[86].detail.args.lot_id` | ARC-630.L002 |
| `controller.events[86].detail.op` | reserve |
| Événement consigné · `controller.events[86].event` | BROKER_REQUEST |
| `controller.events[86].monotonic_ns` | 264945236113 |
| Instant logique · `controller.events[86].tick` | 275 |
| `controller.events[87].detail.key` | proposal-001.ARC-630.L002.A1 |
| `controller.events[87].detail.slot` | ARCHIVE-COMPAT-B.LATE |
| État consigné · `controller.events[87].detail.status` | RESERVED |
| Événement consigné · `controller.events[87].event` | CAPACITY_RESERVED |
| `controller.events[87].monotonic_ns` | 264951215752 |
| Instant logique · `controller.events[87].tick` | 275 |
| Identité de l’accord · `controller.events[88].detail.args.agreement_id` | proposal-001 |
| `controller.events[88].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[88].detail.args.lot_id` | ARC-630.L002 |
| `controller.events[88].detail.args.supersedes` | Non consigné |
| `controller.events[88].detail.op` | produce |
| Événement consigné · `controller.events[88].event` | BROKER_REQUEST |
| `controller.events[88].monotonic_ns` | 264951459580 |
| Instant logique · `controller.events[88].tick` | 276 |
| `controller.events[89].detail.byte_count` | 58189 |
| `controller.events[89].detail.payload_sha256` | 295866988087712384e460fd84e1b17d9fdbb9984de4857c18bff5ed34ac906a |
| `controller.events[89].detail.production_id` | proposal-001.ARC-630.L002.A1 |
| Quantité requise · `controller.events[89].detail.quantity` | 120 |
| Événement consigné · `controller.events[89].event` | PRODUCT_MATERIALIZED |
| `controller.events[89].monotonic_ns` | 264979553748 |
| Instant logique · `controller.events[89].tick` | 276 |
| `controller.events[90].detail.args.production_id` | proposal-001.ARC-630.L002.A1 |
| `controller.events[90].detail.op` | transfer |
| Événement consigné · `controller.events[90].event` | BROKER_REQUEST |
| `controller.events[90].monotonic_ns` | 264979856343 |
| Instant logique · `controller.events[90].tick` | 277 |
| `controller.events[91].detail.byte_count` | 58189 |
| `controller.events[91].detail.delivery_id` | proposal-001.ARC-630.L002.A1.D |
| `controller.events[91].detail.produced_sha256` | 295866988087712384e460fd84e1b17d9fdbb9984de4857c18bff5ed34ac906a |
| `controller.events[91].detail.production_id` | proposal-001.ARC-630.L002.A1 |
| `controller.events[91].detail.received_sha256` | 295866988087712384e460fd84e1b17d9fdbb9984de4857c18bff5ed34ac906a |
| Événement consigné · `controller.events[91].event` | PRODUCT_TRANSFERRED |
| `controller.events[91].monotonic_ns` | 264986077667 |
| Instant logique · `controller.events[91].tick` | 277 |
| `controller.events[92].detail.args.delivery_id` | proposal-001.ARC-630.L002.A1.D |
| `controller.events[92].detail.op` | inspect |
| Événement consigné · `controller.events[92].event` | BROKER_REQUEST |
| `controller.events[92].monotonic_ns` | 264986271723 |
| Instant logique · `controller.events[92].tick` | 278 |
| `controller.events[93].detail.accepted_units` | 120 |
| `controller.events[93].detail.delivery_id` | proposal-001.ARC-630.L002.A1.D |
| État consigné · `controller.events[93].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[93].detail.timely` | Oui |
| Événement consigné · `controller.events[93].event` | RECIPIENT_INSPECTED |
| `controller.events[93].monotonic_ns` | 264997109509 |
| Instant logique · `controller.events[93].tick` | 278 |
| Identité de l’accord · `controller.events[94].detail.args.agreement_id` | proposal-001 |
| `controller.events[94].detail.op` | settle |
| Événement consigné · `controller.events[94].event` | BROKER_REQUEST |
| `controller.events[94].monotonic_ns` | 264997374038 |
| Instant logique · `controller.events[94].tick` | 279 |
| Références d’acceptation · `controller.events[95].detail.acceptance_ids[0]` | proposal-001.ARC-410.L001.A1.D |
| Références d’acceptation · `controller.events[95].detail.acceptance_ids[1]` | proposal-001.ARC-410.L002.A1.D |
| Références d’acceptation · `controller.events[95].detail.acceptance_ids[2]` | proposal-001.ARC-410.L003.A1.D |
| Références d’acceptation · `controller.events[95].detail.acceptance_ids[3]` | proposal-001.ARC-520.L001.A1.D |
| Références d’acceptation · `controller.events[95].detail.acceptance_ids[4]` | proposal-001.ARC-520.L002.A1.D |
| Références d’acceptation · `controller.events[95].detail.acceptance_ids[5]` | proposal-001.ARC-520.L003.A1.D |
| Références d’acceptation · `controller.events[95].detail.acceptance_ids[6]` | proposal-001.ARC-630.L001.A1.D |
| Références d’acceptation · `controller.events[95].detail.acceptance_ids[7]` | proposal-001.ARC-630.L002.A1.D |
| Identité de l’accord · `controller.events[95].detail.agreement_id` | proposal-001 |
| Événement consigné · `controller.events[95].event` | ARRANGEMENT_SETTLED |
| `controller.events[95].monotonic_ns` | 265002600419 |
| Instant logique · `controller.events[95].tick` | 279 |
| `controller.events[96].detail.interventions[0].delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[96].detail.interventions[0].type` | AUTOMATIC_IDEMPOTENT_RETRY |
| Motif consigné · `controller.events[96].detail.reason` | DIGITAL_PRODUCT_ACCEPTED |
| `controller.events[96].detail.searches[0].assignment_domain` | 6561 |
| `controller.events[96].detail.searches[0].candidate_elapsed_ns` | 4497808 |
| `controller.events[96].detail.searches[0].capacity_prunes` | 62 |
| `controller.events[96].detail.searches[0].complete_assignments_observed` | 48 |
| `controller.events[96].detail.searches[0].exhaustive_within_declared_domain` | Oui |
| `controller.events[96].detail.searches[0].feasible_assignments` | 27 |
| `controller.events[96].detail.searches[0].funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Procédure candidate · `controller.events[96].detail.searches[0].method` | harness |
| `controller.events[96].detail.searches[0].partial_nodes_observed` | 125 |
| `controller.events[96].detail.searches[0].participant_prunes` | 21 |
| `controller.events[96].detail.searches[0].price_prunes` | 15 |
| Verdict du composant · `controller.events[96].detail.verdict` | Réalisé (`COMPLETED`) |
| Événement consigné · `controller.events[96].event` | CANDIDATE_DONE |
| `controller.events[96].monotonic_ns` | 265003076499 |
| Instant logique · `controller.events[96].tick` | 279 |
| `controller.events[97].detail.database` | participants |
| `controller.events[97].detail.sqlite[0]` | 0 |
| `controller.events[97].detail.sqlite[1]` | 0 |
| `controller.events[97].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[97].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[97].event` | DATABASE_CHECKPOINT |
| `controller.events[97].monotonic_ns` | 265029445578 |
| Instant logique · `controller.events[97].tick` | 279 |
| `controller.events[98].detail.database` | producer |
| `controller.events[98].detail.sqlite[0]` | 0 |
| `controller.events[98].detail.sqlite[1]` | 0 |
| `controller.events[98].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[98].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[98].event` | DATABASE_CHECKPOINT |
| `controller.events[98].monotonic_ns` | 265033825453 |
| Instant logique · `controller.events[98].tick` | 279 |
| `controller.events[99].detail.database` | receiver |
| `controller.events[99].detail.sqlite[0]` | 0 |
| `controller.events[99].detail.sqlite[1]` | 0 |
| `controller.events[99].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[99].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[99].event` | DATABASE_CHECKPOINT |
| `controller.events[99].monotonic_ns` | 265037476916 |
| Instant logique · `controller.events[99].tick` | 279 |
| `controller.events[100].detail.database` | ARCHIVE-PRIMARY.ALL |
| `controller.events[100].detail.sqlite[0]` | 0 |
| `controller.events[100].detail.sqlite[1]` | 0 |
| `controller.events[100].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[100].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[100].event` | DATABASE_CHECKPOINT |
| `controller.events[100].monotonic_ns` | 265038564065 |
| Instant logique · `controller.events[100].tick` | 279 |
| `controller.events[101].detail.database` | ARCHIVE-BACKUP.ALL |
| `controller.events[101].detail.sqlite[0]` | 0 |
| `controller.events[101].detail.sqlite[1]` | 0 |
| `controller.events[101].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[101].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[101].event` | DATABASE_CHECKPOINT |
| `controller.events[101].monotonic_ns` | 265039593780 |
| Instant logique · `controller.events[101].tick` | 279 |
| `controller.events[102].detail.database` | ARCHIVE-COMPAT-A.EARLY |
| `controller.events[102].detail.sqlite[0]` | 0 |
| `controller.events[102].detail.sqlite[1]` | 0 |
| `controller.events[102].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[102].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[102].event` | DATABASE_CHECKPOINT |
| `controller.events[102].monotonic_ns` | 265040927372 |
| Instant logique · `controller.events[102].tick` | 279 |
| `controller.events[103].detail.database` | ARCHIVE-COMPAT-A.LATE |
| `controller.events[103].detail.sqlite[0]` | 0 |
| `controller.events[103].detail.sqlite[1]` | 0 |
| `controller.events[103].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[103].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[103].event` | DATABASE_CHECKPOINT |
| `controller.events[103].monotonic_ns` | 265042125065 |
| Instant logique · `controller.events[103].tick` | 279 |
| `controller.events[104].detail.database` | ARCHIVE-COMPAT-B.LATE |
| `controller.events[104].detail.sqlite[0]` | 0 |
| `controller.events[104].detail.sqlite[1]` | 0 |
| `controller.events[104].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[104].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[104].event` | DATABASE_CHECKPOINT |
| `controller.events[104].monotonic_ns` | 265043051728 |
| Instant logique · `controller.events[104].tick` | 279 |
| `controller.events[105].detail.databases` | 8 |
| `controller.events[105].detail.snapshot_method` | SQLITE_BACKUP_DELETE_FULL_LOGICAL_DIGEST |
| Événement consigné · `controller.events[105].event` | EVIDENCE_FINALIZED |
| `controller.events[105].monotonic_ns` | 265228717845 |
| Instant logique · `controller.events[105].tick` | 279 |
| Événement consigné · `controller.fault_schedule[0].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.fault_schedule[0].occurrence` | 2 |
| Cible de la panne · `controller.fault_schedule[0].target` | ANY |
| Opération déclenchante · `controller.fault_schedule[0].trigger` | inspect |
| Valeur configurée · `controller.fault_schedule[0].value` | 0 |
| Événement consigné · `controller.faults_observed[0].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.faults_observed[0].occurrence` | 2 |
| Cible de la panne · `controller.faults_observed[0].target` | ANY |
| Opération déclenchante · `controller.faults_observed[0].trigger` | inspect |
| Valeur configurée · `controller.faults_observed[0].value` | 0 |
| `controller.finished_monotonic_ns` | 265228721000 |
| Identité du cas préenregistré · `controller.fixture_id` | archive-window-transfer |
| Modifications sources non consignées présentes · `controller.implementation.dirty` | Non |
| Arguments exacts du processus · `controller.implementation.environment.argv[0]` | python3 |
| Arguments exacts du processus · `controller.implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `controller.implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `controller.implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `controller.implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `controller.implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `controller.implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `controller.implementation.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Plateforme d’exécution · `controller.implementation.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Interpréteur Python · `controller.implementation.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| Version de SQLite · `controller.implementation.environment.sqlite_version` | 3.45.1 |
| Répertoire d’exécution · `controller.implementation.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Commit source effectif · `controller.implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Oui |
| `controller.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Oui |
| `controller.isolation.probe.network_denied` | Oui |
| `controller.isolation.probe.process_inspection_denied` | Oui |
| `controller.isolation.probe.spawn_denied` | Oui |
| `controller.isolation.probe.workspace_open_denied` | Oui |
| Procédure candidate · `controller.method` | harness |
| `controller.policies_sha256` | 70dd87bf5d2d57357abeb0a5d537324b3aba1560a3fe3d9a23e442fd05b710b9 |
| Travail d’adaptation (secondes ; inconnu si absent) · `controller.resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `controller.resources.authority_storage_bytes_before_seal` | 52830 |
| Redémarrages du candidat · `controller.resources.candidate_restarts` | 0 |
| Processus enfants lancés · `controller.resources.child_processes` | 10 |
| Processeur système du contrôleur (ns) · `controller.resources.controller_cpu_system_ns` | 25675000 |
| Processeur utilisateur du contrôleur (ns) · `controller.resources.controller_cpu_user_ns` | 153705999 |
| Processeur système (ns) · `controller.resources.cpu_system_ns` | 117783999 |
| Processeur utilisateur (ns) · `controller.resources.cpu_user_ns` | 594324000 |
| Interventions humaines · `controller.resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `controller.resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `controller.resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `controller.resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `controller.resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `controller.resources.requests` | 45 |
| Nouvelles tentatives · `controller.resources.retries` | 1 |
| Requêtes internes aux services · `controller.resources.service_requests` | 239 |
| Stockage consigné (octets) · `controller.resources.storage_bytes` | 6498224 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `controller.resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `controller.resources.wall_ns` | 2640827349 |
| Redémarrages des services · `controller.resources.worker_restarts` | 1 |
| Identité de l’exécution · `controller.run_id` | archive-window-transfer.harness.b1a9b63aa7 |
| Schéma · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 262587893651 |
| `controller.started_utc` | 2026-11-07T00:45:18.732955+00:00 |
| `controller.state` | Vérification complète (`COMPLETE`) |
| Verdict du composant · `controller.target_verdict` | Réalisé (`COMPLETED`) |
| Événement consigné · `fault_schedule[0].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `fault_schedule[0].occurrence` | 2 |
| Cible de la panne · `fault_schedule[0].target` | ANY |
| Opération déclenchante · `fault_schedule[0].trigger` | inspect |
| Valeur configurée · `fault_schedule[0].value` | 0 |
| Événement consigné · `faults_observed[0].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `faults_observed[0].occurrence` | 2 |
| Cible de la panne · `faults_observed[0].target` | ANY |
| Opération déclenchante · `faults_observed[0].trigger` | inspect |
| Valeur configurée · `faults_observed[0].value` | 0 |
| Identité du cas préenregistré · `fixture_id` | archive-window-transfer |
| Modifications sources non consignées présentes · `implementation.dirty` | Non |
| Arguments exacts du processus · `implementation.environment.argv[0]` | python3 |
| Arguments exacts du processus · `implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `implementation.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Plateforme d’exécution · `implementation.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Interpréteur Python · `implementation.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| Version de SQLite · `implementation.environment.sqlite_version` | 3.45.1 |
| Répertoire d’exécution · `implementation.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Commit source effectif · `implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `implementation.version` | 0.2.0 |
| Procédure candidate · `method` | harness |
| Solde (unités mineures SMU synthétiques) · `policies.buyer.balance_minor` | 7600 |
| `policies.buyer.consent_until_tick` | 650 |
| `policies.buyer.max_price_minor` | 7000 |
| Utilité d’option externe définie (unités mineures SMU synthétiques) · `policies.buyer.outside_utility_minor` | 1800 |
| Identité du participant · `policies.buyer.party_id` | BUYER-ARCHIVE |
| Borne supérieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_max_minor` | 9600 |
| Borne inférieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_min_minor` | 8200 |
| Solde (unités mineures SMU synthétiques) · `policies.coordinator.balance_minor` | 1000 |
| `policies.coordinator.consent_until_tick` | 650 |
| `policies.coordinator.liability_limit_minor` | 600 |
| `policies.coordinator.min_profit_minor` | 70 |
| `policies.coordinator.operating_cost_minor` | 180 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.coordinator.outside_profit_minor` | 110 |
| Identité du participant · `policies.coordinator.party_id` | COORDINATOR-ARCHIVE |
| `policies.coordinator.technical_control_allowed` | Non |
| Unité de compte synthétique · `policies.currency` | SMU |
| Solde (unités mineures SMU synthétiques) · `policies.providers[0].balance_minor` | 4500 |
| `policies.providers[0].consent_until_tick` | 600 |
| `policies.providers[0].liability_limit_minor` | 4500 |
| `policies.providers[0].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[0].outside_profit_minor` | 150 |
| Identité du participant · `policies.providers[0].party_id` | ARCHIVE-PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 80 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 80 |
| `policies.providers[0].technical_control_allowed` | Non |
| `policies.providers[0].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[1].balance_minor` | 4500 |
| `policies.providers[1].consent_until_tick` | 600 |
| `policies.providers[1].liability_limit_minor` | 4500 |
| `policies.providers[1].min_profit_minor` | 120 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[1].outside_profit_minor` | 160 |
| Identité du participant · `policies.providers[1].party_id` | ARCHIVE-BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 100 |
| `policies.providers[1].rework_unit_cost_minor` | 1 |
| `policies.providers[1].setup_cost_minor` | 60 |
| `policies.providers[1].technical_control_allowed` | Non |
| `policies.providers[1].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[2].balance_minor` | 6000 |
| `policies.providers[2].consent_until_tick` | 600 |
| `policies.providers[2].liability_limit_minor` | 4200 |
| `policies.providers[2].min_profit_minor` | 180 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[2].outside_profit_minor` | 260 |
| Identité du participant · `policies.providers[2].party_id` | ARCHIVE-COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 120 |
| `policies.providers[2].rework_unit_cost_minor` | 2 |
| `policies.providers[2].setup_cost_minor` | 240 |
| `policies.providers[2].technical_control_allowed` | Non |
| `policies.providers[2].unit_cost_minor` | 2 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[3].balance_minor` | 2500 |
| `policies.providers[3].consent_until_tick` | 600 |
| `policies.providers[3].liability_limit_minor` | 1600 |
| `policies.providers[3].min_profit_minor` | 150 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[3].outside_profit_minor` | 200 |
| Identité du participant · `policies.providers[3].party_id` | ARCHIVE-COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 60 |
| `policies.providers[3].rework_unit_cost_minor` | 3 |
| `policies.providers[3].setup_cost_minor` | 90 |
| `policies.providers[3].technical_control_allowed` | Non |
| `policies.providers[3].unit_cost_minor` | 4 |
| Révision · `policies.revision` | 1 |
| Schéma · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Non |
| Solde (unités mineures SMU synthétiques) · `policies.technical_sponsor.balance_minor` | 0 |
| Identité du participant · `policies.technical_sponsor.party_id` | UNUSED-SPONSOR |
| Empreinte externe de référence · `reference_sha256` | 09fc8f5d832610f3c4ca6cdf99fc385ea4606fcdcd63685742b0dc0f5ec77fa9 |
| `registered_assertion.expected.accepted_units` | 1020 |
| Résultat · `registered_assertion.expected.outcome` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `registered_assertion.expected.service_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `registered_assertion.observed.accepted_units` | 1020 |
| Résultat · `registered_assertion.observed.outcome` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `registered_assertion.observed.service_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Portée de l’évaluation · `registered_assertion.scope` | Assertion d’évaluation préenregistrée ; elle n’affirme ni résultat favorable ni transaction acceptable. |
| État consigné · `registered_assertion.status` | Réussi (`PASSED`) |
| Modifications sources non consignées présentes · `source_version.dirty` | Non |
| Arguments exacts du processus · `source_version.environment.argv[0]` | python3 |
| Arguments exacts du processus · `source_version.environment.argv[1]` | -m |
| Arguments exacts du processus · `source_version.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `source_version.environment.argv[3]` | --language |
| Arguments exacts du processus · `source_version.environment.argv[4]` | en |
| Arguments exacts du processus · `source_version.environment.argv[5]` | experiment |
| Arguments exacts du processus · `source_version.environment.argv[6]` | --out |
| Arguments exacts du processus · `source_version.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Plateforme d’exécution · `source_version.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Interpréteur Python · `source_version.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| Version de SQLite · `source_version.environment.sqlite_version` | 3.45.1 |
| Répertoire d’exécution · `source_version.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Commit source effectif · `source_version.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `source_version.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `source_version.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `source_version.version` | 0.2.0 |
| Hypothèses de confiance explicites · `trust_assumptions[0]` | Hôte, noyau, contrôleur et horloge de confiance (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Hypothèses de confiance explicites · `trust_assumptions[1]` | Autorité synthétique conservée de confiance (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Hypothèses de confiance explicites · `trust_assumptions[2]` | Auteur commun ; aucune certification par un tiers (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Hypothèses de confiance explicites · `trust_assumptions[3]` | Contenu numérique sémantique uniquement ; livraison physique non éprouvée (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Pannes préenregistrées non déclenchées · `untriggered_faults` | Aucune entrée |

## Enregistrement structuré complet de vérification

Le même enregistrement structuré génère les deux versions linguistiques. Les clés machine, codes d’état et valeurs littérales des preuves restent inchangés ; les sections localisées ci-dessus expliquent leur sens. Aucun résultat sauvegardé n’est réutilisé comme preuve fraîche.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 5700,
    "buyer_utility_interval_minor": {
      "maximum": 3900,
      "minimum": 2500
    },
    "campaign": [
      {
        "final_balance_minor": 1900,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 7600,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER-ARCHIVE",
        "purchase_payments_minor": 5700,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 1110,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 180,
        "initial_balance_minor": 1000,
        "participation_covered": true,
        "participation_threshold_minor": 110,
        "party_id": "COORDINATOR-ARCHIVE",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 110,
        "revenue_minor": 290,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 0,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 0,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "UNUSED-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 4500,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 4500,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "ARCHIVE-PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 4500,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 4500,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "ARCHIVE-BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 8180,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 2040,
        "initial_balance_minor": 6000,
        "participation_covered": true,
        "participation_threshold_minor": 260,
        "party_id": "ARCHIVE-COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 2180,
        "revenue_minor": 4220,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 3120,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 570,
        "initial_balance_minor": 2500,
        "participation_covered": true,
        "participation_threshold_minor": 200,
        "party_id": "ARCHIVE-COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 620,
        "revenue_minor": 1190,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 26100,
    "initial_total_minor": 26100,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 2790,
    "total_transfers_minor": 5700,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "DEMONSTRATED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "COMPLETED",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "DEMONSTRATED",
    "service_feasibility": "DEMONSTRATED"
  },
  "cohort": "successor",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "4b0175bd4cf77f0d87cb495b29ee9ebb1fc805429148a8de5d6b8f514056b02a",
  "evidence_sha256": {
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L001.A1.json": "7c774b2fec8501ed966408290568047e31b09c50aa0273580f50c79419231209",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L002.A1.json": "380752c754901a1272d90acdc832725109fb4d1624fa1a69a964b65565e84159",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L003.A1.json": "42437cd5607b43e3a1a22a7f306d8eb5c24a337487e8f07e7f2f395926a1a737",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-520.L001.A1.json": "279c139e446af029cdcd43e09195238b975c88527e518784599fc51d05a08d00",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-520.L002.A1.json": "725de1b3012490554d253c6818e4358782c192afbdc6c278933cbcc8e140c0aa",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-520.L003.A1.json": "93d4c5095069324ea30ef8d3ade6c42bce4457d68d4358e4acc41668ab6008a8",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-630.L001.A1.json": "b089555b65e5a5f3c85077aa1c0e3804d22f66f62d355c2794db7f8658acb681",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-B.LATE/ARC-630.L002.A1.json": "1af3b391fe62b4ad2de56c5403ed62b32e191e6f91acbe04f59f226ff638b7d5",
    "evidence/capacity/ARCHIVE-BACKUP.ALL.sqlite": "22cbeabeaec5f61ed5f9653c206d131119ed03eb121c2ed4af6d0bf7b251b7b4",
    "evidence/capacity/ARCHIVE-COMPAT-A.EARLY.sqlite": "640e15948c46801753d3f125363d87f8f6099d45c818c207710c8a150ad908d7",
    "evidence/capacity/ARCHIVE-COMPAT-A.LATE.sqlite": "0cb2f5cb16d0d4bf7324c5dc0fb63b74f6811d64399630727eb3d4adb7217eea",
    "evidence/capacity/ARCHIVE-COMPAT-B.LATE.sqlite": "d50d7244f2a1dc8d19b9d690b9328a3689410c77075b0fc656c567779effb938",
    "evidence/capacity/ARCHIVE-PRIMARY.ALL.sqlite": "a7ac99247c605e39ba8f74dfbf7a7183c3f62b5f6bc6f29259ae7af02252d592",
    "evidence/inbox/proposal-001.ARC-410.L001.A1.D.json": "75b46223ccc1f562903e39278010c0e6d446371acc6643e338804cc8c4c398c4",
    "evidence/inbox/proposal-001.ARC-410.L002.A1.D.json": "b1b14777863894e3af3b958603da9aa7f97cd90d0baef46ba54cb6c77de933eb",
    "evidence/inbox/proposal-001.ARC-410.L003.A1.D.json": "621fa2e4d1f41f152eb7b6438f935d747861f4278c3f79626202e84b0f4bda7e",
    "evidence/inbox/proposal-001.ARC-520.L001.A1.D.json": "54ba6e39748c07c3f3b85e81d694c245b90bcff6e44ac7a49f82c60e116e1b2e",
    "evidence/inbox/proposal-001.ARC-520.L002.A1.D.json": "99fbc03732a92a78d94f1d88aafc7ace74ba17c26d28fae98afd78dcccdf58ec",
    "evidence/inbox/proposal-001.ARC-520.L003.A1.D.json": "4fdd1d369ac548c3163dfe58ebb0f2430d99a9b45dbf59889fc8b6cffe86ace5",
    "evidence/inbox/proposal-001.ARC-630.L001.A1.D.json": "1857a3dde816ba270748be6eaee1f41bb89e6b5fd605080e0bbdda22430b06c1",
    "evidence/inbox/proposal-001.ARC-630.L002.A1.D.json": "295866988087712384e460fd84e1b17d9fdbb9984de4857c18bff5ed34ac906a",
    "evidence/participants.sqlite": "4b0b5fe8425a9b1ed5581d9945a68d6aaac24c57df150132c617cc3e9d003467",
    "evidence/producer.sqlite": "b88130fee9115236f57e9ac918986f7b0dfbe73d253c9bd4e464e5baf1d84789",
    "evidence/products/proposal-001.ARC-410.L001.A1.json": "75b46223ccc1f562903e39278010c0e6d446371acc6643e338804cc8c4c398c4",
    "evidence/products/proposal-001.ARC-410.L002.A1.json": "b1b14777863894e3af3b958603da9aa7f97cd90d0baef46ba54cb6c77de933eb",
    "evidence/products/proposal-001.ARC-410.L003.A1.json": "621fa2e4d1f41f152eb7b6438f935d747861f4278c3f79626202e84b0f4bda7e",
    "evidence/products/proposal-001.ARC-520.L001.A1.json": "54ba6e39748c07c3f3b85e81d694c245b90bcff6e44ac7a49f82c60e116e1b2e",
    "evidence/products/proposal-001.ARC-520.L002.A1.json": "99fbc03732a92a78d94f1d88aafc7ace74ba17c26d28fae98afd78dcccdf58ec",
    "evidence/products/proposal-001.ARC-520.L003.A1.json": "4fdd1d369ac548c3163dfe58ebb0f2430d99a9b45dbf59889fc8b6cffe86ace5",
    "evidence/products/proposal-001.ARC-630.L001.A1.json": "1857a3dde816ba270748be6eaee1f41bb89e6b5fd605080e0bbdda22430b06c1",
    "evidence/products/proposal-001.ARC-630.L002.A1.json": "295866988087712384e460fd84e1b17d9fdbb9984de4857c18bff5ed34ac906a",
    "evidence/receiver.sqlite": "26d2f556e7eca08a478db5399e3256c895edfda35c29f2641562e02903332fb2"
  },
  "failures": [],
  "fault_schedule": [
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 2,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "faults_observed": [
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 2,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "fixture_id": "archive-window-transfer",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/home/runner/work/_temp/continuity-economy/complete"
      ],
      "platform": "Linux-7.0.0-1017-azure-x86_64-with-glibc2.39",
      "python": "3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]",
      "sqlite_version": "3.45.1",
      "working_directory": "/home/runner/work/CONTINUITY/CONTINUITY"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "method": "harness",
  "per_arrangement": [
    {
      "acceptance_ids": [
        "proposal-001.ARC-410.L001.A1.D",
        "proposal-001.ARC-410.L002.A1.D",
        "proposal-001.ARC-410.L003.A1.D",
        "proposal-001.ARC-520.L001.A1.D",
        "proposal-001.ARC-520.L002.A1.D",
        "proposal-001.ARC-520.L003.A1.D",
        "proposal-001.ARC-630.L001.A1.D",
        "proposal-001.ARC-630.L002.A1.D"
      ],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 2790,
      "independent_terms": {
        "break_even_value_minor": 7500,
        "buyer_definite_max_price_minor": 6400,
        "buyer_possible_max_price_minor": 7000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5700,
        "minimum_coordinator_fee_minor": 290,
        "providers": [
          {
            "base_cost_minor": 2040,
            "guaranteed_profit_minor": 260,
            "maximum_unpaid_cost_exposure_minor": 3960,
            "minimum_payment_minor": 4220,
            "participation_profit_minor": 260,
            "party_id": "ARCHIVE-COMPAT-A",
            "promised_payment_minor": 4220,
            "rework_cost_minor": 1920,
            "units": 900
          },
          {
            "base_cost_minor": 570,
            "guaranteed_profit_minor": 200,
            "maximum_unpaid_cost_exposure_minor": 990,
            "minimum_payment_minor": 1190,
            "participation_profit_minor": 200,
            "party_id": "ARCHIVE-COMPAT-B",
            "promised_payment_minor": 1190,
            "rework_cost_minor": 420,
            "units": 120
          }
        ],
        "rework_budget_minor": 2340,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER-ARCHIVE",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "ARCHIVE-COMPAT-A",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "ARCHIVE-COMPAT-B",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR-ARCHIVE",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 5700,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 150,
            "lot_id": "ARC-410.L001",
            "obligation_id": "ARC-410",
            "pay_minor": 4220,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "EARLY"
          },
          {
            "first_unit": 151,
            "last_unit": 300,
            "lot_id": "ARC-410.L002",
            "obligation_id": "ARC-410",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "EARLY"
          },
          {
            "first_unit": 301,
            "last_unit": 420,
            "lot_id": "ARC-410.L003",
            "obligation_id": "ARC-410",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "EARLY"
          },
          {
            "first_unit": 1,
            "last_unit": 150,
            "lot_id": "ARC-520.L001",
            "obligation_id": "ARC-520",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "EARLY"
          },
          {
            "first_unit": 151,
            "last_unit": 300,
            "lot_id": "ARC-520.L002",
            "obligation_id": "ARC-520",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "LATE"
          },
          {
            "first_unit": 301,
            "last_unit": 330,
            "lot_id": "ARC-520.L003",
            "obligation_id": "ARC-520",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "LATE"
          },
          {
            "first_unit": 1,
            "last_unit": 150,
            "lot_id": "ARC-630.L001",
            "obligation_id": "ARC-630",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "LATE"
          },
          {
            "first_unit": 151,
            "last_unit": 270,
            "lot_id": "ARC-630.L002",
            "obligation_id": "ARC-630",
            "pay_minor": 1190,
            "provider_id": "ARCHIVE-COMPAT-B",
            "window_id": "LATE"
          }
        ],
        "buyer_price_minor": 5700,
        "cancellation_fee_minor": 0,
        "contract_sha256": "4b0175bd4cf77f0d87cb495b29ee9ebb1fc805429148a8de5d6b8f514056b02a",
        "coordinator_fee_minor": 290,
        "expires_tick": 560,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2340,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "DEMONSTRATED",
      "settled_tick": 279,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 420,
      "deadline_tick": 130,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "ARC-410",
      "outcome": "COMPLETED",
      "produced_quantity": 420,
      "production_attempts": 3,
      "quantity": 420,
      "reason_codes": [],
      "received_quantity": 420,
      "recipient": "RECIPIENT-NORD",
      "recipient_accepted_quantity": 420,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 420,
      "revision": 3,
      "status": "ACTIVE",
      "timely_semantic_quantity": 420
    },
    {
      "accepted_quantity": 330,
      "deadline_tick": 440,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "ARC-520",
      "outcome": "COMPLETED",
      "produced_quantity": 330,
      "production_attempts": 3,
      "quantity": 330,
      "reason_codes": [],
      "received_quantity": 330,
      "recipient": "RECIPIENT-EST",
      "recipient_accepted_quantity": 330,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 330,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 330
    },
    {
      "accepted_quantity": 270,
      "deadline_tick": 520,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "ARC-630",
      "outcome": "COMPLETED",
      "produced_quantity": 270,
      "production_attempts": 2,
      "quantity": 270,
      "reason_codes": [],
      "received_quantity": 270,
      "recipient": "RECIPIENT-SUD",
      "recipient_accepted_quantity": 270,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 270,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 270
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 360,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "ARC-740",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 90,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-OUEST",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "09fc8f5d832610f3c4ca6cdf99fc385ea4606fcdcd63685742b0dc0f5ec77fa9",
  "registered_assertion": {
    "expected": {
      "accepted_units": 1020,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "observed": {
      "accepted_units": 1020,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "PASSED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 52830,
    "candidate_restarts": 0,
    "child_processes": 10,
    "controller_cpu_system_ns": 25675000,
    "controller_cpu_user_ns": 153705999,
    "cpu_system_ns": 117783999,
    "cpu_user_ns": 594324000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 45,
    "retries": 1,
    "service_requests": 239,
    "storage_bytes": 6498224,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 2640827349,
    "worker_restarts": 1
  },
  "run_id": "archive-window-transfer.harness.b1a9b63aa7",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/home/runner/work/_temp/continuity-economy/complete"
      ],
      "platform": "Linux-7.0.0-1017-azure-x86_64-with-glibc2.39",
      "python": "3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]",
      "sqlite_version": "3.45.1",
      "working_directory": "/home/runner/work/CONTINUITY/CONTINUITY"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 3,
    "accepted_quantity": 1020,
    "delivery_attempts": 8,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 0,
    "produced_quantity": 1020,
    "production_attempts": 8,
    "received_quantity": 1020,
    "recipient_accepted_quantity": 1020,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 3,
    "required_quantity": 1020,
    "timely_semantic_quantity": 1020,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 200665958,
    "evidence_files_read": 32,
    "wall_ns": 200805423
  },
  "verification_status": "COMPLETE",
  "verification_wall_ns": 202284369,
  "verifier_version": "0.2.0"
}
```
