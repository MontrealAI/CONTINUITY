# CONTINUITY Ω Harness — Economy of continuity

**Digital-product experiment · version 0.2.0**

Preserve a promise through a viable, voluntarily accepted continuity arrangement.

**Scope: disposable local processes and a specified digital product. Authored synthetic policies, consent, values, funding and SMU cash flows are model inputs and observations. They do not establish real contracts, demand, payments, sales, printed goods, rendered appearance or print quality.**
**Checker qualification FAILED. A favorable target verdict in this adversarial observation is a challenged component claim, not qualified acceptance.**


This Passport presents the recorded assessment. Fresh verification must inspect retained authority, actual durable output and recipient evidence; this document is never its oracle.

<!-- structured-result-sha256: 1a3a4cd9fbebc4fcde753867cd13df2f5e3712ffdbe14651544c4337842454e7 -->

## Three distinct claims

| Claim | Recorded status |
| --- | --- |
| Required digital work accepted within the frozen conditions | Failed (`FAILED`) |
| Service feasibility under the authored synthetic model | Failed (`FAILED`) |
| Method advantage over competent alternatives | Not established (`NOT_ESTABLISHED`) |
| Qualification of the challenged checker | Failed (`FAILED`) |
| Safety within the exercised failure model | Failed (`FAILED`) |

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

## Assessment fields kept separate

| Field | Recorded value |
| --- | --- |
| Test assertion | Passed (`PASSED`) |
| Component verdict | Demonstrated in scope (`DEMONSTRATED`) |
| Evidence stage | Targeted verifier mutation (`TARGETED_VERIFIER_MUTATION`) |
| Assessed claim status | Failed (`FAILED`) |

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

## Identity, authority and versions

| Field | Recorded value |
| --- | --- |
| Authority evidence status · `authority_status` | Established for the synthetic exercise only (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Real commercial value · `commercial_value` | Not established (`NOT_ESTABLISHED`) |
| Contract identity · `contract_id` | Not recorded |
| Retained contract SHA-256 · `contract_sha256` | 95334b666e52aab36c26711fbfeb876f59e6b3069de859c8dd988969e2defae7 |
| Real customer authenticity · `real_customer_authenticity` | Not established (`NOT_ESTABLISHED`) |
| External reference pin · `reference_sha256` | 87eb6b08f3080a49cf00ff1eb786dbb44d8463ea02625e38d1f3f19ef340bf43 |
| Run identity · `run_id` | valid-digital-control.05617f90d5 |
| Schema · `schema` | continuity-economy/verification/v1 |
| Verification completion status · `verification_status` | Complete verification (`COMPLETE`) |
| Verifier version · `verifier_version` | 0.2.0 |

## Per-obligation execution and acceptance

Counts describe the recorded stage. Rejected and corrected attempts remain distinct. A produced or received unit is not automatically accepted. Missing measurements are not displayed as zero.

| Obligation | Recipient | Revision | Required | Produced | Received | Rejected | Accepted within contract | Outcome |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 1100 | 1100 | 0 | 0 | Incorrect (`INCORRECT`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 800 | 800 | 0 | 0 | Unfulfilled (`UNFULFILLED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Cancelled (`CANCELLED`) |

### Obligation `DL-100`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 3 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 1100 |
| Obligation identity · `obligation_id` | DL-100 |
| Outcome · `outcome` | Incorrect (`INCORRECT`) |
| Produced quantity · `produced_quantity` | 1100 |
| Durable production attempts · `production_attempts` | 3 |
| Required quantity · `quantity` | 1100 |
| Reason codes · `reason_codes[0]` | FALSE_RECIPIENT_ACCEPTANCE |
| Reason codes · `reason_codes[1]` | IMPORTED_CONTENT_INCOMPLETE |
| Reason codes · `reason_codes[2]` | IMPORTED_CONTENT_MISMATCH |
| Received quantity · `received_quantity` | 1100 |
| Recipient · `recipient` | RECIPIENT-A |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 600 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 1100 |
| Revision · `revision` | 2 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 600 |

### Obligation `DL-200`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 2 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 800 |
| Obligation identity · `obligation_id` | DL-200 |
| Outcome · `outcome` | Unfulfilled (`UNFULFILLED`) |
| Produced quantity · `produced_quantity` | 800 |
| Durable production attempts · `production_attempts` | 2 |
| Required quantity · `quantity` | 800 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 800 |
| Recipient · `recipient` | RECIPIENT-B |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 800 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 800 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 800 |

### Obligation `DL-300`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | DL-300 |
| Outcome · `outcome` | Cancelled (`CANCELLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-C |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 0 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Cancelled (`CANCELLED`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

## Proposals, modeled decisions and arrangements

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-001`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids[0]` | proposal-001.DL-100.L001.A1.D |
| Acceptance references · `acceptance_ids[1]` | proposal-001.DL-100.L002.A1.D |
| Acceptance references · `acceptance_ids[2]` | proposal-001.DL-100.L003.A1.D |
| Acceptance references · `acceptance_ids[3]` | proposal-001.DL-200.L001.A1.D |
| Acceptance references · `acceptance_ids[4]` | proposal-001.DL-200.L002.A1.D |
| Agreement acceptance tick · `accepted_tick` | 3 |
| Agreement identity · `agreement_id` | proposal-001 |
| Cancellation tick · `cancelled_tick` | Not recorded |
| Incurred correction cost (synthetic SMU minor units) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Incurred cost (synthetic SMU minor units) · `incurred_cost_minor` | 2200 |
| Break-even buyer value (synthetic SMU minor units) · `independent_terms.break_even_value_minor` | 6400 |
| Buyer price ceiling at the lower value bound (synthetic SMU minor units) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU minor units) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU minor units) · `independent_terms.minimum_buyer_price_minor` | 4400 |
| Minimum coordinator fee (synthetic SMU minor units) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU minor units) · `independent_terms.providers[0].base_cost_minor` | 2000 |
| Modeled profit after maximum specified rework (synthetic SMU minor units) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU minor units) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 4000 |
| Minimum provider payment (synthetic SMU minor units) · `independent_terms.providers[0].minimum_payment_minor` | 4100 |
| Required participation profit (synthetic SMU minor units) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU minor units) · `independent_terms.providers[0].promised_payment_minor` | 4100 |
| Maximum correction cost (synthetic SMU minor units) · `independent_terms.providers[0].rework_cost_minor` | 2000 |
| Units · `independent_terms.providers[0].units` | 1900 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2000 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | Modeled trade agreement (`TRADE`) |
| Stable code · `participant_decisions[0].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[1].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[2].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[2].party_id` | COORDINATOR |
| Role · `participant_decisions[2].role` | coordinator |
| Component verdict · `participant_decisions[2].verdict` | Accepted (`ACCEPTED`) |
| Modeled payments (synthetic SMU minor units) · `payments_minor` | 4400 |
| Proposal identity · `proposal_id` | proposal-001 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 4100 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 4400 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 95334b666e52aab36c26711fbfeb876f59e6b3069de859c8dd988969e2defae7 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 300 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-001 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2000 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Not established (`NOT_ESTABLISHED`) |
| Modeled settlement tick · `settled_tick` | 30 |
| Recorded status · `status` | Settled in the synthetic ledger (`SETTLED`) |

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.


## Modeled transfers, costs, liabilities and outside options

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

| Field | Recorded value |
| --- | --- |
| Total buyer transfers (synthetic SMU minor units) · `accounting.buyer_total_paid_minor` | 4400 |
| Upper bound · `accounting.buyer_utility_interval_minor.maximum` | 25600 |
| Lower bound · `accounting.buyer_utility_interval_minor.minimum` | 25600 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[0].final_balance_minor` | 25600 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Modeled participation threshold covered · `accounting.campaign[0].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[0].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[0].party_id` | BUYER |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[0].purchase_payments_minor` | 4400 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[0].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[0].revenue_minor` | 0 |
| Role · `accounting.campaign[0].role` | buyer |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[1].final_balance_minor` | 10100 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[1].incurred_cost_minor` | 200 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Modeled participation threshold covered · `accounting.campaign[1].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[1].participation_threshold_minor` | 100 |
| Participant identity · `accounting.campaign[1].party_id` | COORDINATOR |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[1].realized_profit_minor` | 100 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[1].revenue_minor` | 300 |
| Role · `accounting.campaign[1].role` | coordinator |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Modeled participation threshold covered · `accounting.campaign[2].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[2].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[2].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[2].revenue_minor` | 0 |
| Role · `accounting.campaign[2].role` | technical_sponsor |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[3].final_balance_minor` | 42100 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[3].incurred_cost_minor` | 2000 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[3].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[3].participation_threshold_minor` | 100 |
| Participant identity · `accounting.campaign[3].party_id` | PRIMARY |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[3].realized_profit_minor` | 2100 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[3].revenue_minor` | 4100 |
| Role · `accounting.campaign[3].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[4].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[4].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[4].party_id` | BACKUP |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[4].revenue_minor` | 0 |
| Role · `accounting.campaign[4].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[5].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[5].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[5].party_id` | COMPAT-A |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[5].revenue_minor` | 0 |
| Role · `accounting.campaign[5].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[6].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[6].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[6].party_id` | COMPAT-B |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[6].revenue_minor` | 0 |
| Role · `accounting.campaign[6].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Synthetic accounting unit · `accounting.currency` | SMU |
| Final ledger total (synthetic SMU minor units) · `accounting.final_total_minor` | 260000 |
| Initial ledger total (synthetic SMU minor units) · `accounting.initial_total_minor` | 260000 |
| Real contracts, payments or demand · `accounting.real_contracts_payments_or_demand` | Not established (`NOT_ESTABLISHED`) |
| Realized modeled buyer feasibility · `accounting.realized_buyer` | Demonstrated in scope (`DEMONSTRATED`) |
| Assessment scope · `accounting.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| All correction costs (synthetic SMU minor units) · `accounting.total_correction_cost_minor` | 0 |
| All incurred campaign costs (synthetic SMU minor units) · `accounting.total_incurred_cost_minor` | 2200 |
| All modeled settlement transfers (synthetic SMU minor units) · `accounting.total_transfers_minor` | 4400 |
| Modeled trade settled · `accounting.trade_settled` | Yes |
| Accepted obligations · `totals.accepted_obligations` | 0 |
| Accepted quantity within contract · `totals.accepted_quantity` | 0 |
| Delivery attempts · `totals.delivery_attempts` | 5 |
| Duplicate accepted units · `totals.duplicate_acceptances` | 0 |
| Late quantity · `totals.late_quantity` | 0 |
| Missing quantity · `totals.missing_quantity` | 1900 |
| Produced quantity · `totals.produced_quantity` | 1900 |
| Durable production attempts · `totals.production_attempts` | 5 |
| Received quantity · `totals.received_quantity` | 1900 |
| Units accepted by the recipient component · `totals.recipient_accepted_quantity` | 1400 |
| Rejected quantity · `totals.rejected_quantity` | 0 |
| Requested units in rejected deliveries · `totals.rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `totals.rejection_count` | 0 |
| Required active obligations · `totals.required_obligations` | 2 |
| Required quantity · `totals.required_quantity` | 1900 |
| Semantically correct units observed in time · `totals.timely_semantic_quantity` | 1400 |
| Unsafe or unsupported commitments · `totals.unsafe_or_unsupported_commitments` | 3 |

## Measured resources and accounting gaps

Measured process resources and configured synthetic amounts have different meanings. Unrecorded preparation, integration, adaptation, verification or intervention effort remains unknown. Missing categories cannot support a complete-cost or cheaper-method conclusion.

| Field | Recorded value |
| --- | --- |
| Accounting gaps · `accounting_gaps[0]` | Preparation labor was not measured (`PREPARATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[1]` | Integration labor was not measured (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[2]` | Adaptation labor was not measured (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[3]` | Human verification labor was not measured (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[4]` | Monetary rates were not measured (`MONETARY_RATES_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Adaptation labor (seconds; unknown if absent) · `resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `resources.authority_storage_bytes_before_seal` | 30066 |
| Candidate restarts · `resources.candidate_restarts` | 0 |
| Launched child processes · `resources.child_processes` | 8 |
| Controller system CPU (ns) · `resources.controller_cpu_system_ns` | 31471999 |
| Controller user CPU (ns) · `resources.controller_cpu_user_ns` | 118089000 |
| System CPU (ns) · `resources.cpu_system_ns` | 116610000 |
| User CPU (ns) · `resources.cpu_user_ns` | 506190999 |
| Human interventions · `resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `resources.preparation_labor_seconds` | Not recorded |
| Requests · `resources.requests` | 30 |
| Retries · `resources.retries` | 0 |
| Internal service requests · `resources.service_requests` | 158 |
| Recorded storage (bytes) · `resources.storage_bytes` | 8776528 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `resources.wall_ns` | 1307213348 |
| Worker restarts · `resources.worker_restarts` | 0 |
| Process CPU (ns) · `verification_resources.cpu_ns` | 197600303 |
| Evidence files inspected · `verification_resources.evidence_files_read` | 22 |
| Wall duration (ns) · `verification_resources.wall_ns` | 197607763 |

## Observed failures and counterexamples

| Stable code | Scope | Obligation | Arrangement | Interpretation | Original technical locator |
| --- | --- | --- | --- | --- | --- |
| `FALSE_RECIPIENT_ACCEPTANCE` | safety | DL-100 | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `proposal-001.DL-100.L001.A1.D` |
| `IMPORTED_CONTENT_MISMATCH` | safety | DL-100 | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `proposal-001.DL-100.L001.A1.D` |
| `IMPORTED_CONTENT_INCOMPLETE` | outcome | DL-100 | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `` |
| `SETTLEMENT_WITHOUT_ACCEPTED_CONTENT` | safety | Not recorded | proposal-001 | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `proposal-001` |

## Missing evidence and unresolved claims

No additional unresolved entry was recorded. Scope and unknown-cost limits still apply.

## Evidence references and byte integrity

Hashes identify bytes. They do not authenticate real customer instructions, establish source completeness, or replace an externally retained reference pin.

| Field | Recorded value |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json` | 9474250e3544ec8057ba6fc9320fd2ee536cae43b6b0d3738141f94bef871344 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L002.A1.json` | df991a1c130e486f8288fc7d84aa1a41181a7051c0218b929bcf3c966ab7474b |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L003.A1.json` | 9ead331fa1c3171a9a3dd52f6812e48f0f966bcfaa9be3c608ed2e755a873488 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-200.L001.A1.json` | 13cd2eacbd121dc2aa89e6ce9cdc18a2c754815131f700fe0041ac9c3b197bd8 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-200.L002.A1.json` | 44557d25e5d2fbcda0b5ad2736efbffc3d94614f75ac9524463ea46abfc1ffa5 |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 7c7ce855cfeb0194f49e6dd3df50f15f05a7fcd7983bef8b25914b000c9d613e |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | c4fb81f4d86072805484c4361009c522de0815aee0cc1287cbebc777a16c32c3 |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | cf1dfe561a079fa8bdb5cccae7cd3000ca2076a3caada2342ac81f05f50f0c8d |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | f5e4143567e23d78e100de40ce60f446070e766fc89d524016b6706d57e40547 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L001.A1.D.json` | 39214ae0b5943ad07bfcf96483b56612b7c479a410d1ceb41880817470903cbc |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L002.A1.D.json` | 1491b2762d3fb28e91b068b8ccb3acbc782307bad48700142ebb0ec8c18fc424 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L003.A1.D.json` | 95523620d7e90b73d70e6022a6cbb506aba8a3d80f98779a762b2715eee5ff0a |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L001.A1.D.json` | e6e3c68a78538342aa3f931045deb00528b38de1a2437772d8b51cc6d3a7f0c6 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L002.A1.D.json` | 0d896fc069d1915058ac0f5d7d73fafa98d7719b2f89ed043d76192488e3119a |
| `evidence_sha256.evidence/participants.sqlite` | 65501339359f0270de240926643ce47c9d7822db9dd6576318f6fd58e2ee4f5d |
| `evidence_sha256.evidence/producer.sqlite` | 6fbd6336aa734e7b6b4a9174af5780dd5cac9319eb7dd143363cc4d5efc5ebb2 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L001.A1.json` | 39214ae0b5943ad07bfcf96483b56612b7c479a410d1ceb41880817470903cbc |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L002.A1.json` | 1491b2762d3fb28e91b068b8ccb3acbc782307bad48700142ebb0ec8c18fc424 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L003.A1.json` | 95523620d7e90b73d70e6022a6cbb506aba8a3d80f98779a762b2715eee5ff0a |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L001.A1.json` | e6e3c68a78538342aa3f931045deb00528b38de1a2437772d8b51cc6d3a7f0c6 |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L002.A1.json` | 0d896fc069d1915058ac0f5d7d73fafa98d7719b2f89ed043d76192488e3119a |
| `evidence_sha256.evidence/receiver.sqlite` | 1bd7dfa58b1996450ba233bb8d0b65a1482bc8ff2f99d06f6d56b2b2edf84bcb |
| Structured result SHA-256 · `structured_result_sha256` | 1a3a4cd9fbebc4fcde753867cd13df2f5e3712ffdbe14651544c4337842454e7 |

## Recorded execution, faults, commands and provenance

Stable identifiers, exact commands, paths and original machine diagnostics are retained literally. They are data, not additional acceptance evidence. Source and host trust remain explicit in the architecture and threat model.

| Field | Recorded value |
| --- | --- |
| `command[0]` | python |
| `command[1]` | -m |
| `command[2]` | continuity_economy |
| `command[3]` | challenge |
| `command[4]` | --out |
| `command[5]` | /home/runner/work/_temp/continuity-economy/complete/challenges |
| Registered fault schedule · `fault_schedule` | No entries |
| Actually observed faults · `faults_observed` | No entries |
| Uncommitted source changes present · `implementation.dirty` | No |
| Exact process arguments · `implementation.environment.argv[0]` | python3 |
| Exact process arguments · `implementation.environment.argv[1]` | -m |
| Exact process arguments · `implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `implementation.environment.argv[3]` | --language |
| Exact process arguments · `implementation.environment.argv[4]` | en |
| Exact process arguments · `implementation.environment.argv[5]` | experiment |
| Exact process arguments · `implementation.environment.argv[6]` | --out |
| Exact process arguments · `implementation.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Operating platform · `implementation.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Python interpreter · `implementation.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| SQLite version · `implementation.environment.sqlite_version` | 3.45.1 |
| Execution directory · `implementation.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Actual source commit · `implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Preserved capacity implementation baseline · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `implementation.version` | 0.2.0 |
| External reference pin · `reference_sha256` | 87eb6b08f3080a49cf00ff1eb786dbb44d8463ea02625e38d1f3f19ef340bf43 |
| Registered test criterion · `registered_case.criterion` | FALSE_POSITIVE_MUTANT_EXPOSED |
| `registered_case.id` | mutant-ignores-semantic-content |
| Arrangement kind · `registered_case.kind` | verifier_mutation |
| `registered_case.mutation` | ignore_wrong_content |
| `registered_case.source` | wrong-content-resealed |
| Challenge registration SHA-256 · `registration_sha256` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| Explicit trust assumptions · `trust_assumptions[0]` | Trusted host, kernel, controller and clock (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Explicit trust assumptions · `trust_assumptions[1]` | Trusted retained synthetic authority (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Explicit trust assumptions · `trust_assumptions[2]` | Shared authorship; no third-party certification (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Explicit trust assumptions · `trust_assumptions[3]` | Semantic digital content only; physical delivery is untested (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Registered faults not triggered · `untriggered_faults` | No entries |

## Adversarial observation and checker qualification

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `assertion.accepted_quantity` | 0 |
| Checker qualification · `assertion.checker_qualification` | Failed (`FAILED`) |
| Registered test criterion · `assertion.criterion` | FALSE_POSITIVE_MUTANT_EXPOSED |
| Observed finding codes · `assertion.finding_codes[0]` | FALSE_RECIPIENT_ACCEPTANCE |
| Observed finding codes · `assertion.finding_codes[1]` | IMPORTED_CONTENT_INCOMPLETE |
| Observed finding codes · `assertion.finding_codes[2]` | IMPORTED_CONTENT_MISMATCH |
| Observed finding codes · `assertion.finding_codes[3]` | SETTLEMENT_WITHOUT_ACCEPTED_CONTENT |
| Independently observed outcome · `assertion.observed_outcome` | Failed (`FAILED`) |
| Independently observed safety status · `assertion.observed_safety_status` | Failed (`FAILED`) |
| Independently observed modeled feasibility · `assertion.observed_service_feasibility` | Failed (`FAILED`) |
| Recorded status · `assertion.status` | Passed (`PASSED`) |
| Claim under assessment · `assessed_claim` | Qualification of the challenged checker (`CHECKER_QUALIFICATION`) |
| Checker qualification · `checker_qualification` | Failed (`FAILED`) |
| Registered test criterion · `criterion` | FALSE_POSITIVE_MUTANT_EXPOSED |
| Retained execution used for this challenge · `execution_reused_from` | wrong-content-resealed |
| `id` | mutant-ignores-semantic-content |
| Arrangement kind · `kind` | verifier_mutation |
| Challenge observation elapsed time (ns) · `observation_wall_ns` | 400200211 |
| Reference verdict · `reference_verdict` | Failed (`FAILED`) |
| Assessment scope · `scope` | Registered synthetic challenge (`REGISTERED_SYNTHETIC_CHALLENGE`) |
| Target verdict · `target_verdict` | Demonstrated in scope (`DEMONSTRATED`) |

## Complete structured verification record

The same structured record generates both language versions. Machine keys, enum codes and literal evidence values remain unchanged; the localized sections above explain their meaning. No saved result is reused as fresh proof.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 4400,
    "buyer_utility_interval_minor": {
      "maximum": 25600,
      "minimum": 25600
    },
    "campaign": [
      {
        "final_balance_minor": 25600,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 4400,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 200,
        "initial_balance_minor": 10000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 100,
        "revenue_minor": 300,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 42100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 2000,
        "initial_balance_minor": 40000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 2100,
        "revenue_minor": 4100,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 2200,
    "total_transfers_minor": 4400,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "FAILED",
    "evidence_stage": "TARGETED_VERIFIER_MUTATION",
    "target_verdict": "DEMONSTRATED",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "challenge": {
    "assertion": {
      "accepted_quantity": 0,
      "checker_qualification": "FAILED",
      "criterion": "FALSE_POSITIVE_MUTANT_EXPOSED",
      "finding_codes": [
        "FALSE_RECIPIENT_ACCEPTANCE",
        "IMPORTED_CONTENT_INCOMPLETE",
        "IMPORTED_CONTENT_MISMATCH",
        "SETTLEMENT_WITHOUT_ACCEPTED_CONTENT"
      ],
      "observed_outcome": "FAILED",
      "observed_safety_status": "FAILED",
      "observed_service_feasibility": "FAILED",
      "status": "PASSED"
    },
    "assessed_claim": "CHECKER_QUALIFICATION",
    "checker_qualification": "FAILED",
    "criterion": "FALSE_POSITIVE_MUTANT_EXPOSED",
    "execution_reused_from": "wrong-content-resealed",
    "id": "mutant-ignores-semantic-content",
    "kind": "verifier_mutation",
    "observation_wall_ns": 400200211,
    "reference_verdict": "FAILED",
    "scope": "REGISTERED_SYNTHETIC_CHALLENGE",
    "target_verdict": "DEMONSTRATED"
  },
  "claims": {
    "checker_qualification": "FAILED",
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "FAILED",
    "service_feasibility": "FAILED"
  },
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "95334b666e52aab36c26711fbfeb876f59e6b3069de859c8dd988969e2defae7",
  "evidence_sha256": {
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json": "9474250e3544ec8057ba6fc9320fd2ee536cae43b6b0d3738141f94bef871344",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L002.A1.json": "df991a1c130e486f8288fc7d84aa1a41181a7051c0218b929bcf3c966ab7474b",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L003.A1.json": "9ead331fa1c3171a9a3dd52f6812e48f0f966bcfaa9be3c608ed2e755a873488",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-200.L001.A1.json": "13cd2eacbd121dc2aa89e6ce9cdc18a2c754815131f700fe0041ac9c3b197bd8",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-200.L002.A1.json": "44557d25e5d2fbcda0b5ad2736efbffc3d94614f75ac9524463ea46abfc1ffa5",
    "evidence/capacity/BACKUP.W0.sqlite": "7c7ce855cfeb0194f49e6dd3df50f15f05a7fcd7983bef8b25914b000c9d613e",
    "evidence/capacity/COMPAT-A.W0.sqlite": "c4fb81f4d86072805484c4361009c522de0815aee0cc1287cbebc777a16c32c3",
    "evidence/capacity/COMPAT-B.W0.sqlite": "cf1dfe561a079fa8bdb5cccae7cd3000ca2076a3caada2342ac81f05f50f0c8d",
    "evidence/capacity/PRIMARY.W0.sqlite": "f5e4143567e23d78e100de40ce60f446070e766fc89d524016b6706d57e40547",
    "evidence/inbox/proposal-001.DL-100.L001.A1.D.json": "39214ae0b5943ad07bfcf96483b56612b7c479a410d1ceb41880817470903cbc",
    "evidence/inbox/proposal-001.DL-100.L002.A1.D.json": "1491b2762d3fb28e91b068b8ccb3acbc782307bad48700142ebb0ec8c18fc424",
    "evidence/inbox/proposal-001.DL-100.L003.A1.D.json": "95523620d7e90b73d70e6022a6cbb506aba8a3d80f98779a762b2715eee5ff0a",
    "evidence/inbox/proposal-001.DL-200.L001.A1.D.json": "e6e3c68a78538342aa3f931045deb00528b38de1a2437772d8b51cc6d3a7f0c6",
    "evidence/inbox/proposal-001.DL-200.L002.A1.D.json": "0d896fc069d1915058ac0f5d7d73fafa98d7719b2f89ed043d76192488e3119a",
    "evidence/participants.sqlite": "65501339359f0270de240926643ce47c9d7822db9dd6576318f6fd58e2ee4f5d",
    "evidence/producer.sqlite": "6fbd6336aa734e7b6b4a9174af5780dd5cac9319eb7dd143363cc4d5efc5ebb2",
    "evidence/products/proposal-001.DL-100.L001.A1.json": "39214ae0b5943ad07bfcf96483b56612b7c479a410d1ceb41880817470903cbc",
    "evidence/products/proposal-001.DL-100.L002.A1.json": "1491b2762d3fb28e91b068b8ccb3acbc782307bad48700142ebb0ec8c18fc424",
    "evidence/products/proposal-001.DL-100.L003.A1.json": "95523620d7e90b73d70e6022a6cbb506aba8a3d80f98779a762b2715eee5ff0a",
    "evidence/products/proposal-001.DL-200.L001.A1.json": "e6e3c68a78538342aa3f931045deb00528b38de1a2437772d8b51cc6d3a7f0c6",
    "evidence/products/proposal-001.DL-200.L002.A1.json": "0d896fc069d1915058ac0f5d7d73fafa98d7719b2f89ed043d76192488e3119a",
    "evidence/receiver.sqlite": "1bd7dfa58b1996450ba233bb8d0b65a1482bc8ff2f99d06f6d56b2b2edf84bcb"
  },
  "failures": [
    {
      "code": "FALSE_RECIPIENT_ACCEPTANCE",
      "detail": "proposal-001.DL-100.L001.A1.D",
      "obligation_id": "DL-100",
      "scope": "safety"
    },
    {
      "code": "IMPORTED_CONTENT_MISMATCH",
      "detail": "proposal-001.DL-100.L001.A1.D",
      "obligation_id": "DL-100",
      "scope": "safety"
    },
    {
      "code": "IMPORTED_CONTENT_INCOMPLETE",
      "detail": "",
      "obligation_id": "DL-100",
      "scope": "outcome"
    },
    {
      "arrangement_id": "proposal-001",
      "code": "SETTLEMENT_WITHOUT_ACCEPTED_CONTENT",
      "detail": "proposal-001",
      "scope": "safety"
    }
  ],
  "fault_schedule": [],
  "faults_observed": [],
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/home/runner/work/_temp/continuity-economy/complete"
      ],
      "platform": "Linux-7.0.0-1017-azure-x86_64-with-glibc2.39",
      "python": "3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]",
      "sqlite_version": "3.45.1",
      "working_directory": "/home/runner/work/CONTINUITY/CONTINUITY"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "per_arrangement": [
    {
      "acceptance_ids": [
        "proposal-001.DL-100.L001.A1.D",
        "proposal-001.DL-100.L002.A1.D",
        "proposal-001.DL-100.L003.A1.D",
        "proposal-001.DL-200.L001.A1.D",
        "proposal-001.DL-200.L002.A1.D"
      ],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 2200,
      "independent_terms": {
        "break_even_value_minor": 6400,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 4400,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 2000,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 4000,
            "minimum_payment_minor": 4100,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 4100,
            "rework_cost_minor": 2000,
            "units": 1900
          }
        ],
        "rework_budget_minor": 2000,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 4400,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 4100,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 4400,
        "cancellation_fee_minor": 0,
        "contract_sha256": "95334b666e52aab36c26711fbfeb876f59e6b3069de859c8dd988969e2defae7",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2000,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "NOT_ESTABLISHED",
      "settled_tick": 30,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "INCORRECT",
      "produced_quantity": 1100,
      "production_attempts": 3,
      "quantity": 1100,
      "reason_codes": [
        "FALSE_RECIPIENT_ACCEPTANCE",
        "IMPORTED_CONTENT_INCOMPLETE",
        "IMPORTED_CONTENT_MISMATCH"
      ],
      "received_quantity": 1100,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 600,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 600
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNFULFILLED",
      "produced_quantity": 800,
      "production_attempts": 2,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 800,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 800,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 800
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "87eb6b08f3080a49cf00ff1eb786dbb44d8463ea02625e38d1f3f19ef340bf43",
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30066,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 31471999,
    "controller_cpu_user_ns": 118089000,
    "cpu_system_ns": 116610000,
    "cpu_user_ns": 506190999,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 30,
    "retries": 0,
    "service_requests": 158,
    "storage_bytes": 8776528,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 1307213348,
    "worker_restarts": 0
  },
  "run_id": "valid-digital-control.05617f90d5",
  "safety_status": "FAILED",
  "schema": "continuity-economy/verification/v1",
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 5,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 1900,
    "production_attempts": 5,
    "received_quantity": 1900,
    "recipient_accepted_quantity": 1400,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 1400,
    "unsafe_or_unsupported_commitments": 3
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 197600303,
    "evidence_files_read": 22,
    "wall_ns": 197607763
  },
  "verification_status": "COMPLETE",
  "verifier_version": "0.2.0"
}
```
