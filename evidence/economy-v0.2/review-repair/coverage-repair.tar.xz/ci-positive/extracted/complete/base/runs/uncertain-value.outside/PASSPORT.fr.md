# CONTINUITÉ Ω — Économie de la continuité

**Expérience de produit numérique · version 0.2.0**

Préserver un engagement grâce à une solution de continuité viable et volontairement acceptée.

**Portée : processus locaux jetables et produit numérique spécifié. Les politiques, consentements, valeurs, financements et flux SMU synthétiques sont des hypothèses et observations du modèle. Ils n’établissent ni contrats réels, ni demande, paiements, ventes, biens imprimés, apparence rendue ou qualité d’impression.**

Ce passeport présente l’évaluation consignée. Une vérification fraîche doit inspecter l’autorité conservée, le résultat durable réel et les preuves du destinataire ; ce document ne constitue jamais son oracle.

<!-- structured-result-sha256: b4a1d0727591472b7145c2422563f12aef69abf710726f274226a03537b42a40 -->

## Trois affirmations distinctes

| Affirmation | État consigné |
| --- | --- |
| Travail numérique requis accepté dans les conditions figées | Échec (`FAILED`) |
| Faisabilité du service selon le modèle synthétique défini | Non établi (`NOT_ESTABLISHED`) |
| Avantage de méthode face à des solutions compétentes | Non établi (`NOT_ESTABLISHED`) |
| Sûreté dans le modèle de défaillance éprouvé | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

## Champs d’évaluation distincts

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | Réussi (`PASSED`) |
| Verdict du composant | OUTSIDE_OPTION |
| Stade de preuve | Exécution locale d’un produit numérique (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| État de l’affirmation évaluée | Échec (`FAILED`) |

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

## Identité, autorité et versions

| Champ | Valeur consignée |
| --- | --- |
| État des preuves d’autorité · `authority_status` | Établi uniquement pour l’exercice synthétique (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Valeur commerciale réelle · `commercial_value` | Non établi (`NOT_ESTABLISHED`) |
| Identité du contrat · `contract_id` | DIGITAL-007 |
| SHA-256 du contrat conservé · `contract_sha256` | d95f4c63d992c1d74e3b68724c775459c7eab00c6a697b073f9f841bfb43e361 |
| Authenticité d’un client réel · `real_customer_authenticity` | Non établi (`NOT_ESTABLISHED`) |
| Empreinte externe de référence · `reference_sha256` | 804a42652d727cc56175483416620d25e2c9b731b0fe6431a46657cc6439e7bc |
| Identité de l’exécution · `run_id` | uncertain-value.outside.3dcb2c3a62 |
| Schéma · `schema` | continuity-economy/verification/v1 |
| État d’achèvement de la vérification · `verification_status` | Vérification complète (`COMPLETE`) |
| Version du vérificateur · `verifier_version` | 0.2.0 |

## Exécution et acceptation par obligation

Les quantités décrivent le stade consigné. Les tentatives refusées et corrigées restent distinctes. Une unité produite ou reçue n’est pas automatiquement acceptée. Les mesures absentes ne sont pas présentées comme nulles.

| Obligation | Destinataire | Révision | Requis | Produit | Reçu | Refusé | Accepté selon le contrat | Résultat |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 0 | 0 | 0 | 0 | Non réalisé (`UNFULFILLED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 0 | 0 | 0 | 0 | Non réalisé (`UNFULFILLED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Annulé (`CANCELLED`) |

### Obligation `DL-100`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 1100 |
| Identité de l’obligation · `obligation_id` | DL-100 |
| Résultat · `outcome` | Non réalisé (`UNFULFILLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 1100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-A |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 1100 |
| Révision · `revision` | 2 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

### Obligation `DL-200`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 800 |
| Identité de l’obligation · `obligation_id` | DL-200 |
| Résultat · `outcome` | Non réalisé (`UNFULFILLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 800 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-B |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 800 |
| Révision · `revision` | 1 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

### Obligation `DL-300`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-300 |
| Résultat · `outcome` | Annulé (`CANCELLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-C |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 0 |
| Révision · `revision` | 1 |
| État consigné · `status` | Annulé (`CANCELLED`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

## Propositions, décisions modélisées et solutions

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

Aucun enregistrement de solution n’est présent. Cette absence ne prouve ni accord accepté ni viabilité économique.

## Transferts, coûts, responsabilités et options externes modélisés

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

| Champ | Valeur consignée |
| --- | --- |
| Total des transferts acheteur (unités mineures SMU synthétiques) · `accounting.buyer_total_paid_minor` | 0 |
| Borne supérieure · `accounting.buyer_utility_interval_minor.maximum` | Non consigné |
| Borne inférieure · `accounting.buyer_utility_interval_minor.minimum` | Non consigné |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[0].final_balance_minor` | 30000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Seuil de participation modélisé couvert · `accounting.campaign[0].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[0].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[0].party_id` | BUYER |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[0].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[0].realized_profit_minor` | Non consigné |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[0].revenue_minor` | 0 |
| Rôle · `accounting.campaign[0].role` | buyer |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[1].final_balance_minor` | 10000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[1].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Seuil de participation modélisé couvert · `accounting.campaign[1].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[1].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[1].party_id` | COORDINATOR |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[1].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[1].revenue_minor` | 0 |
| Rôle · `accounting.campaign[1].role` | coordinator |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Seuil de participation modélisé couvert · `accounting.campaign[2].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[2].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[2].realized_profit_minor` | Non consigné |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[2].revenue_minor` | 0 |
| Rôle · `accounting.campaign[2].role` | technical_sponsor |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[3].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[3].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[3].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[3].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[3].party_id` | PRIMARY |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[3].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[3].revenue_minor` | 0 |
| Rôle · `accounting.campaign[3].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[4].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[4].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[4].party_id` | BACKUP |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[4].revenue_minor` | 0 |
| Rôle · `accounting.campaign[4].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[5].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[5].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[5].party_id` | COMPAT-A |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[5].revenue_minor` | 0 |
| Rôle · `accounting.campaign[5].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[6].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[6].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[6].party_id` | COMPAT-B |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[6].revenue_minor` | 0 |
| Rôle · `accounting.campaign[6].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Unité de compte synthétique · `accounting.currency` | SMU |
| Total final du registre (unités mineures SMU synthétiques) · `accounting.final_total_minor` | 260000 |
| Total initial du registre (unités mineures SMU synthétiques) · `accounting.initial_total_minor` | 260000 |
| Contrats, paiements ou demande réels · `accounting.real_contracts_payments_or_demand` | Non établi (`NOT_ESTABLISHED`) |
| Faisabilité modélisée réalisée pour l’acheteur · `accounting.realized_buyer` | Non établi (`NOT_ESTABLISHED`) |
| Portée de l’évaluation · `accounting.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Tous les coûts de correction (unités mineures SMU synthétiques) · `accounting.total_correction_cost_minor` | 0 |
| Tous les coûts engagés de campagne (unités mineures SMU synthétiques) · `accounting.total_incurred_cost_minor` | 0 |
| Tous les transferts de règlement modélisés (unités mineures SMU synthétiques) · `accounting.total_transfers_minor` | 0 |
| Transaction modélisée réglée · `accounting.trade_settled` | Non |
| Obligations acceptées · `totals.accepted_obligations` | 0 |
| Quantité acceptée selon le contrat · `totals.accepted_quantity` | 0 |
| Tentatives de livraison · `totals.delivery_attempts` | 0 |
| Unités acceptées en double · `totals.duplicate_acceptances` | 0 |
| Quantité tardive · `totals.late_quantity` | 0 |
| Quantité manquante · `totals.missing_quantity` | 1900 |
| Quantité produite · `totals.produced_quantity` | 0 |
| Tentatives de production durables · `totals.production_attempts` | 0 |
| Quantité reçue · `totals.received_quantity` | 0 |
| Unités acceptées par le composant destinataire · `totals.recipient_accepted_quantity` | 0 |
| Quantité refusée · `totals.rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `totals.rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `totals.rejection_count` | 0 |
| Obligations actives requises · `totals.required_obligations` | 2 |
| Quantité requise · `totals.required_quantity` | 1900 |
| Unités sémantiquement correctes observées à temps · `totals.timely_semantic_quantity` | 0 |
| Engagements non sûrs ou non autorisés · `totals.unsafe_or_unsupported_commitments` | 0 |

## Ressources mesurées et lacunes de comptabilisation

Les ressources de processus mesurées et les montants synthétiques configurés ont des significations différentes. Les efforts de préparation, d’intégration, d’adaptation, de vérification ou d’intervention non consignés restent inconnus. Les catégories absentes ne permettent aucune conclusion de coût complet ou de méthode moins coûteuse.

| Champ | Valeur consignée |
| --- | --- |
| Lacunes de comptabilisation · `accounting_gaps[0]` | Le travail de préparation n’a pas été mesuré (`PREPARATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[1]` | Le travail d’intégration n’a pas été mesuré (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[2]` | Le travail d’adaptation n’a pas été mesuré (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[3]` | Le travail humain de vérification n’a pas été mesuré (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[4]` | Les tarifs monétaires n’ont pas été mesurés (`MONETARY_RATES_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Travail d’adaptation (secondes ; inconnu si absent) · `resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `resources.authority_storage_bytes_before_seal` | 30080 |
| Redémarrages du candidat · `resources.candidate_restarts` | 0 |
| Processus enfants lancés · `resources.child_processes` | 8 |
| Processeur système du contrôleur (ns) · `resources.controller_cpu_system_ns` | 13565000 |
| Processeur utilisateur du contrôleur (ns) · `resources.controller_cpu_user_ns` | 28446999 |
| Processeur système (ns) · `resources.cpu_system_ns` | 82479000 |
| Processeur utilisateur (ns) · `resources.cpu_user_ns` | 264644999 |
| Interventions humaines · `resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `resources.requests` | 0 |
| Nouvelles tentatives · `resources.retries` | 0 |
| Requêtes internes aux services · `resources.service_requests` | 18 |
| Stockage consigné (octets) · `resources.storage_bytes` | 1216210 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `resources.wall_ns` | 2409972754 |
| Redémarrages des services · `resources.worker_restarts` | 0 |
| Temps processeur (ns) · `verification_resources.cpu_ns` | 33318109 |
| Fichiers de preuve examinés · `verification_resources.evidence_files_read` | 7 |
| Durée écoulée (ns) · `verification_resources.wall_ns` | 33324653 |

## Échecs et contre-exemples observés

Aucune entrée d’échec n’a été consignée dans cette évaluation. Il s’agit de preuves bornées, non d’une démonstration générale.

## Preuves absentes et affirmations non établies

Aucune entrée non résolue supplémentaire n’a été consignée. Les limites de portée et de coûts inconnus restent applicables.

## Références des preuves et intégrité des octets

Les empreintes identifient les octets. Elles n’authentifient pas les instructions réelles d’un client, n’établissent pas l’exhaustivité des sources et ne remplacent pas une empreinte de référence conservée séparément.

| Champ | Valeur consignée |
| --- | --- |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 9844ea2a949246f7ca6b58a3bb5013498825c2f131826cf3f61ecdb54c410d35 |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | 1a79c7682827b0a9446cff55cf3ce8f17b43daa7e59daf6667569c836373b0ed |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | 9b59edd2d984f035b4b818157005c7e4e74875be2861c0277e902736ae249183 |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | e0f86e4a15707a9c9f460b7a88e3230fa689ff0f60b877a06032d2dd72e5b4d8 |
| `evidence_sha256.evidence/participants.sqlite` | 52770819be8b228ac42ada23bd2faf61caacf8d9c690bc99fe0f04aa561ca20d |
| `evidence_sha256.evidence/producer.sqlite` | f74c6f0452bb0fec019a385ecd98330fe727657da275627dfb6cb87a67c1eda4 |
| `evidence_sha256.evidence/receiver.sqlite` | e1f4007761d480266c499898bff598f62c3a81e607c80d034e8f6dd2f9ad6065 |
| SHA-256 du résultat structuré · `structured_result_sha256` | b4a1d0727591472b7145c2422563f12aef69abf710726f274226a03537b42a40 |

## Exécution, pannes, commandes et provenance consignées

Les identifiants stables, commandes exactes, chemins et diagnostics machine originaux sont conservés littéralement. Ce sont des données, non des preuves d’acceptation supplémentaires. La confiance dans les sources et l’hôte est explicitée dans l’architecture et le modèle de menace.

| Champ | Valeur consignée |
| --- | --- |
| `authority_dir` | /home/runner/work/_temp/continuity-economy/complete/base/authorities/uncertain-value.outside |
| Cohorte d’expérience · `cohort` | base |
| `contract.allow_split` | Oui |
| `contract.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | PRIMARY-HOST |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Cohorte d’expérience · `contract.cohort` | base |
| Identité du contrat · `contract.contract_id` | DIGITAL-007 |
| `contract.cutoff_sequence` | 5 |
| Échéance logique · `contract.deadline_tick` | 500 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-001 |
| Programme de pannes préenregistré · `contract.fault_schedule` | Aucune entrée |
| Identité du cas préenregistré · `contract.fixture_id` | uncertain-value |
| `contract.lease_ticks` | 20 |
| `contract.lot_size` | 500 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Échéance logique · `contract.obligations[0].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[0].obligation_id` | DL-100 |
| Quantité requise · `contract.obligations[0].quantity` | 1100 |
| Destinataire · `contract.obligations[0].recipient` | RECIPIENT-A |
| Révision · `contract.obligations[0].revision` | 2 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[0].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[0].spec.lot` | BATCH-20261106 |
| `contract.obligations[0].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[0].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[0].spec.serial_prefix` | DL-100- |
| `contract.obligations[0].spec.sku` | KIT-DL-100 |
| État consigné · `contract.obligations[0].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[1].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[1].obligation_id` | DL-200 |
| Quantité requise · `contract.obligations[1].quantity` | 800 |
| Destinataire · `contract.obligations[1].recipient` | RECIPIENT-B |
| Révision · `contract.obligations[1].revision` | 1 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[1].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[1].spec.lot` | BATCH-20261106 |
| `contract.obligations[1].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[1].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[1].spec.serial_prefix` | DL-200- |
| `contract.obligations[1].spec.sku` | KIT-DL-200 |
| État consigné · `contract.obligations[1].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[2].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[2].obligation_id` | DL-300 |
| Quantité requise · `contract.obligations[2].quantity` | 100 |
| Destinataire · `contract.obligations[2].recipient` | RECIPIENT-C |
| Révision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[2].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[2].spec.lot` | BATCH-20261106 |
| `contract.obligations[2].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[2].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[2].spec.serial_prefix` | DL-300- |
| `contract.obligations[2].spec.sku` | KIT-DL-300 |
| État consigné · `contract.obligations[2].status` | Annulé (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 800 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | PRIMARY-HOST |
| `contract.providers[0].permissions.disclosure` | Oui |
| `contract.providers[0].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[0].provider_id` | PRIMARY |
| Rôle · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 2400 |
| `contract.providers[0].windows[0].end` | 800 |
| `contract.providers[0].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[0].windows[0].window_id` | W0 |
| `contract.providers[1].dependency` | BACKUP-HOST |
| `contract.providers[1].permissions.disclosure` | Oui |
| `contract.providers[1].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[1].provider_id` | BACKUP |
| Rôle · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 2400 |
| `contract.providers[1].windows[0].end` | 800 |
| `contract.providers[1].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[1].windows[0].window_id` | W0 |
| `contract.providers[2].dependency` | COMPAT-A-HOST |
| `contract.providers[2].permissions.disclosure` | Oui |
| `contract.providers[2].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[2].provider_id` | COMPAT-A |
| Rôle · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 1200 |
| `contract.providers[2].windows[0].end` | 800 |
| `contract.providers[2].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[2].windows[0].window_id` | W0 |
| `contract.providers[3].dependency` | COMPAT-B-HOST |
| `contract.providers[3].permissions.disclosure` | Oui |
| `contract.providers[3].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[3].provider_id` | COMPAT-B |
| Rôle · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 1100 |
| `contract.providers[3].windows[0].end` | 800 |
| `contract.providers[3].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[3].windows[0].window_id` | W0 |
| Révision · `contract.revision` | 1 |
| `contract.revocations` | Aucune entrée |
| Identité de l’exécution · `contract.run_id` | uncertain-value.outside.3dcb2c3a62 |
| Schéma · `contract.schema` | continuity-economy/contract/v1 |
| Graine consignée · `contract.seed` | 707 |
| `contract.source_complete` | Oui |
| Échéance logique · `contract.source_events[0].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[0].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[0].obligation.quantity` | 1000 |
| Destinataire · `contract.source_events[0].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Obsolete instruction. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Instruction périmée. |
| `contract.source_events[0].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[0].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[0].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[0].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[0].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[0].obligation_id` | DL-100 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Échéance logique · `contract.source_events[1].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[1].obligation.obligation_id` | DL-200 |
| Quantité requise · `contract.source_events[1].obligation.quantity` | 800 |
| Destinataire · `contract.source_events[1].obligation.recipient` | RECIPIENT-B |
| Révision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[1].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[1].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[1].obligation.spec.serial_prefix` | DL-200- |
| `contract.source_events[1].obligation.spec.sku` | KIT-DL-200 |
| État consigné · `contract.source_events[1].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[1].obligation_id` | DL-200 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Échéance logique · `contract.source_events[2].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[2].obligation.obligation_id` | DL-300 |
| Quantité requise · `contract.source_events[2].obligation.quantity` | 100 |
| Destinataire · `contract.source_events[2].obligation.recipient` | RECIPIENT-C |
| Révision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[2].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[2].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[2].obligation.spec.serial_prefix` | DL-300- |
| `contract.source_events[2].obligation.spec.sku` | KIT-DL-300 |
| État consigné · `contract.source_events[2].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[2].obligation_id` | DL-300 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Échéance logique · `contract.source_events[3].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[3].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[3].obligation.quantity` | 1100 |
| Destinataire · `contract.source_events[3].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[3].obligation.revision` | 2 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[3].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[3].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[3].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[3].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[3].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[3].obligation_id` | DL-100 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | AMEND |
| Identité de l’obligation · `contract.source_events[4].obligation_id` | DL-300 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | CANCEL |
| `contract.source_id` | AUTHORED-DIGITAL-EVENTS |
| Empreintes des octets sources · `contract.source_sha256` | 8d6a71fd1c26021120a5283bd7cf3eb7812b5c34ae6a4da3eec94dceaf8f7b81 |
| Horloge de départ (ns) · `contract.start_ns` | 256936608089 |
| Échéance en temps écoulé (ms) · `contract.wall_deadline_ms` | 60000 |
| `controller.capacity_databases[0].path` | evidence/capacity/PRIMARY.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[0].provider_id` | PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Identité de la fenêtre de capacité · `controller.capacity_databases[0].window_id` | W0 |
| `controller.capacity_databases[1].path` | evidence/capacity/BACKUP.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[1].provider_id` | BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[1].window_id` | W0 |
| `controller.capacity_databases[2].path` | evidence/capacity/COMPAT-A.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[2].provider_id` | COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[2].window_id` | W0 |
| `controller.capacity_databases[3].path` | evidence/capacity/COMPAT-B.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[3].provider_id` | COMPAT-B |
| `controller.capacity_databases[3].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[3].window_id` | W0 |
| `controller.clock_tick` | 0 |
| Cohorte d’expérience · `controller.cohort` | base |
| SHA-256 du contrat conservé · `controller.contract_sha256` | d95f4c63d992c1d74e3b68724c775459c7eab00c6a697b073f9f841bfb43e361 |
| `controller.db_snapshots.evidence/capacity/BACKUP.W0.sqlite` | 7aaaef5a30f74d979ba90b2c41a50c30dc88fcf893bbeae71ab5a8e8f2332ba3 |
| `controller.db_snapshots.evidence/capacity/COMPAT-A.W0.sqlite` | 4a6cb0298f149a4ddd1be3bf1d59b8c1bee12ceaffc33b19d388464b6ecec04d |
| `controller.db_snapshots.evidence/capacity/COMPAT-B.W0.sqlite` | ce075ffd6e2e64e455840b74549f201d95c502a395dba018b5b61985cbdb961b |
| `controller.db_snapshots.evidence/capacity/PRIMARY.W0.sqlite` | 3ce6f6659ef28c6b2b283e2e5824d8f3d7739dd33c80089530c88ef277244f6e |
| `controller.db_snapshots.evidence/participants.sqlite` | 9e35fbff05d211ec139e4afe711c408ddce3cc1622e50f086c1e4381d841b33f |
| `controller.db_snapshots.evidence/producer.sqlite` | e7ae41e3752f9a02c8e85b18887ae9cdb1f4dc45ade19dbbf0e405415a5815bc |
| `controller.db_snapshots.evidence/receiver.sqlite` | f528041ec5feacba7cf86b5c801f7951ab0f17c1624a36fe3e88f0ac2ad1e8c2 |
| `controller.errors` | Aucune entrée |
| `controller.events[0].detail.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| Empreinte externe de référence · `controller.events[0].detail.reference_sha256` | 804a42652d727cc56175483416620d25e2c9b731b0fe6431a46657cc6439e7bc |
| Graine consignée · `controller.events[0].detail.seed` | 707 |
| Événement consigné · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 256953043527 |
| Instant logique · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 2831 |
| `controller.events[1].detail.restart` | Non |
| `controller.events[1].detail.service` | participants |
| Événement consigné · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 256993087950 |
| Instant logique · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 2832 |
| `controller.events[2].detail.restart` | Non |
| `controller.events[2].detail.service` | producer |
| Événement consigné · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 257169788566 |
| Instant logique · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 2833 |
| `controller.events[3].detail.restart` | Non |
| `controller.events[3].detail.service` | receiver |
| Événement consigné · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 257233146869 |
| Instant logique · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 2834 |
| Identité du fournisseur · `controller.events[4].detail.provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[4].detail.window_id` | W0 |
| Événement consigné · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 257721620485 |
| Instant logique · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 2835 |
| Identité du fournisseur · `controller.events[5].detail.provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[5].detail.window_id` | W0 |
| Événement consigné · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 258117373777 |
| Instant logique · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 2836 |
| Identité du fournisseur · `controller.events[6].detail.provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[6].detail.window_id` | W0 |
| Événement consigné · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 258345738045 |
| Instant logique · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 2837 |
| Identité du fournisseur · `controller.events[7].detail.provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[7].detail.window_id` | W0 |
| Événement consigné · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 258610993626 |
| Instant logique · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.affected[0]` | PRIMARY.W0 |
| `controller.events[8].detail.dependency` | PRIMARY-HOST |
| Événement consigné · `controller.events[8].event` | DEPENDENCY_DISABLED |
| `controller.events[8].monotonic_ns` | 258611728438 |
| Instant logique · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.isolation.applied` | Oui |
| `controller.events[9].detail.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.events[9].detail.isolation.probe.authority_open_denied` | Oui |
| `controller.events[9].detail.isolation.probe.network_denied` | Oui |
| `controller.events[9].detail.isolation.probe.process_inspection_denied` | Oui |
| `controller.events[9].detail.isolation.probe.spawn_denied` | Oui |
| `controller.events[9].detail.isolation.probe.workspace_open_denied` | Oui |
| `controller.events[9].detail.pid` | 2839 |
| `controller.events[9].detail.restart` | Non |
| Événement consigné · `controller.events[9].event` | CANDIDATE_STARTED |
| `controller.events[9].monotonic_ns` | 258647915934 |
| Instant logique · `controller.events[9].tick` | 0 |
| Interventions consignées · `controller.events[10].detail.interventions` | Aucune entrée |
| Motif consigné · `controller.events[10].detail.reason` | VOLUNTARY_NO_PURCHASE |
| `controller.events[10].detail.searches` | Aucune entrée |
| Verdict du composant · `controller.events[10].detail.verdict` | OUTSIDE_OPTION |
| Événement consigné · `controller.events[10].event` | CANDIDATE_DONE |
| `controller.events[10].monotonic_ns` | 258649323726 |
| Instant logique · `controller.events[10].tick` | 0 |
| `controller.events[11].detail.database` | participants |
| `controller.events[11].detail.sqlite[0]` | 0 |
| `controller.events[11].detail.sqlite[1]` | 0 |
| `controller.events[11].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[11].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[11].event` | DATABASE_CHECKPOINT |
| `controller.events[11].monotonic_ns` | 258657657079 |
| Instant logique · `controller.events[11].tick` | 0 |
| `controller.events[12].detail.database` | producer |
| `controller.events[12].detail.sqlite[0]` | 0 |
| `controller.events[12].detail.sqlite[1]` | 0 |
| `controller.events[12].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[12].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[12].event` | DATABASE_CHECKPOINT |
| `controller.events[12].monotonic_ns` | 258658501132 |
| Instant logique · `controller.events[12].tick` | 0 |
| `controller.events[13].detail.database` | receiver |
| `controller.events[13].detail.sqlite[0]` | 0 |
| `controller.events[13].detail.sqlite[1]` | 0 |
| `controller.events[13].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[13].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[13].event` | DATABASE_CHECKPOINT |
| `controller.events[13].monotonic_ns` | 258659258466 |
| Instant logique · `controller.events[13].tick` | 0 |
| `controller.events[14].detail.database` | PRIMARY.W0 |
| `controller.events[14].detail.sqlite[0]` | 0 |
| `controller.events[14].detail.sqlite[1]` | 0 |
| `controller.events[14].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[14].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[14].event` | DATABASE_CHECKPOINT |
| `controller.events[14].monotonic_ns` | 258660276995 |
| Instant logique · `controller.events[14].tick` | 0 |
| `controller.events[15].detail.database` | BACKUP.W0 |
| `controller.events[15].detail.sqlite[0]` | 0 |
| `controller.events[15].detail.sqlite[1]` | 0 |
| `controller.events[15].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[15].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[15].event` | DATABASE_CHECKPOINT |
| `controller.events[15].monotonic_ns` | 258661310606 |
| Instant logique · `controller.events[15].tick` | 0 |
| `controller.events[16].detail.database` | COMPAT-A.W0 |
| `controller.events[16].detail.sqlite[0]` | 0 |
| `controller.events[16].detail.sqlite[1]` | 0 |
| `controller.events[16].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[16].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[16].event` | DATABASE_CHECKPOINT |
| `controller.events[16].monotonic_ns` | 258662255977 |
| Instant logique · `controller.events[16].tick` | 0 |
| `controller.events[17].detail.database` | COMPAT-B.W0 |
| `controller.events[17].detail.sqlite[0]` | 0 |
| `controller.events[17].detail.sqlite[1]` | 0 |
| `controller.events[17].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[17].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[17].event` | DATABASE_CHECKPOINT |
| `controller.events[17].monotonic_ns` | 258663172496 |
| Instant logique · `controller.events[17].tick` | 0 |
| `controller.events[18].detail.databases` | 7 |
| `controller.events[18].detail.snapshot_method` | SQLITE_BACKUP_DELETE_FULL_LOGICAL_DIGEST |
| Événement consigné · `controller.events[18].event` | EVIDENCE_FINALIZED |
| `controller.events[18].monotonic_ns` | 259346615844 |
| Instant logique · `controller.events[18].tick` | 0 |
| Programme de pannes préenregistré · `controller.fault_schedule` | Aucune entrée |
| Pannes effectivement observées · `controller.faults_observed` | Aucune entrée |
| `controller.finished_monotonic_ns` | 259346618348 |
| Identité du cas préenregistré · `controller.fixture_id` | uncertain-value |
| Modifications sources non consignées présentes · `controller.implementation.dirty` | Non |
| Arguments exacts du processus · `controller.implementation.environment.argv[0]` | python3 |
| Arguments exacts du processus · `controller.implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `controller.implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `controller.implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `controller.implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `controller.implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `controller.implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `controller.implementation.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Plateforme d’exécution · `controller.implementation.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Interpréteur Python · `controller.implementation.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| Version de SQLite · `controller.implementation.environment.sqlite_version` | 3.45.1 |
| Répertoire d’exécution · `controller.implementation.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Commit source effectif · `controller.implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Oui |
| `controller.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Oui |
| `controller.isolation.probe.network_denied` | Oui |
| `controller.isolation.probe.process_inspection_denied` | Oui |
| `controller.isolation.probe.spawn_denied` | Oui |
| `controller.isolation.probe.workspace_open_denied` | Oui |
| Procédure candidate · `controller.method` | outside |
| `controller.policies_sha256` | bb4df4d166119dfb851e70872433cac566333051c319785d95f518af2e2ffeca |
| Travail d’adaptation (secondes ; inconnu si absent) · `controller.resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `controller.resources.authority_storage_bytes_before_seal` | 30080 |
| Redémarrages du candidat · `controller.resources.candidate_restarts` | 0 |
| Processus enfants lancés · `controller.resources.child_processes` | 8 |
| Processeur système du contrôleur (ns) · `controller.resources.controller_cpu_system_ns` | 13565000 |
| Processeur utilisateur du contrôleur (ns) · `controller.resources.controller_cpu_user_ns` | 28446999 |
| Processeur système (ns) · `controller.resources.cpu_system_ns` | 82479000 |
| Processeur utilisateur (ns) · `controller.resources.cpu_user_ns` | 264644999 |
| Interventions humaines · `controller.resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `controller.resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `controller.resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `controller.resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `controller.resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `controller.resources.requests` | 0 |
| Nouvelles tentatives · `controller.resources.retries` | 0 |
| Requêtes internes aux services · `controller.resources.service_requests` | 18 |
| Stockage consigné (octets) · `controller.resources.storage_bytes` | 1216210 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `controller.resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `controller.resources.wall_ns` | 2409972754 |
| Redémarrages des services · `controller.resources.worker_restarts` | 0 |
| Identité de l’exécution · `controller.run_id` | uncertain-value.outside.3dcb2c3a62 |
| Schéma · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 256936645594 |
| `controller.started_utc` | 2026-11-07T00:45:12.907802+00:00 |
| `controller.state` | Vérification complète (`COMPLETE`) |
| Verdict du composant · `controller.target_verdict` | OUTSIDE_OPTION |
| Programme de pannes préenregistré · `fault_schedule` | Aucune entrée |
| Pannes effectivement observées · `faults_observed` | Aucune entrée |
| Identité du cas préenregistré · `fixture_id` | uncertain-value |
| Modifications sources non consignées présentes · `implementation.dirty` | Non |
| Arguments exacts du processus · `implementation.environment.argv[0]` | python3 |
| Arguments exacts du processus · `implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `implementation.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Plateforme d’exécution · `implementation.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Interpréteur Python · `implementation.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| Version de SQLite · `implementation.environment.sqlite_version` | 3.45.1 |
| Répertoire d’exécution · `implementation.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Commit source effectif · `implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `implementation.version` | 0.2.0 |
| Procédure candidate · `method` | outside |
| Solde (unités mineures SMU synthétiques) · `policies.buyer.balance_minor` | 30000 |
| `policies.buyer.consent_until_tick` | 800 |
| `policies.buyer.max_price_minor` | 25000 |
| Utilité d’option externe définie (unités mineures SMU synthétiques) · `policies.buyer.outside_utility_minor` | 2000 |
| Identité du participant · `policies.buyer.party_id` | BUYER |
| Borne supérieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_max_minor` | 30000 |
| Borne inférieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_min_minor` | 2000 |
| Solde (unités mineures SMU synthétiques) · `policies.coordinator.balance_minor` | 10000 |
| `policies.coordinator.consent_until_tick` | 800 |
| `policies.coordinator.liability_limit_minor` | 10000 |
| `policies.coordinator.min_profit_minor` | 100 |
| `policies.coordinator.operating_cost_minor` | 200 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.coordinator.outside_profit_minor` | 100 |
| Identité du participant · `policies.coordinator.party_id` | COORDINATOR |
| `policies.coordinator.technical_control_allowed` | Oui |
| Unité de compte synthétique · `policies.currency` | SMU |
| Solde (unités mineures SMU synthétiques) · `policies.providers[0].balance_minor` | 40000 |
| `policies.providers[0].consent_until_tick` | 800 |
| `policies.providers[0].liability_limit_minor` | 40000 |
| `policies.providers[0].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[0].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[0].party_id` | PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 100 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 100 |
| `policies.providers[0].technical_control_allowed` | Oui |
| `policies.providers[0].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[1].balance_minor` | 40000 |
| `policies.providers[1].consent_until_tick` | 800 |
| `policies.providers[1].liability_limit_minor` | 40000 |
| `policies.providers[1].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[1].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[1].party_id` | BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 150 |
| `policies.providers[1].rework_unit_cost_minor` | 2 |
| `policies.providers[1].setup_cost_minor` | 150 |
| `policies.providers[1].technical_control_allowed` | Oui |
| `policies.providers[1].unit_cost_minor` | 2 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[2].balance_minor` | 40000 |
| `policies.providers[2].consent_until_tick` | 800 |
| `policies.providers[2].liability_limit_minor` | 40000 |
| `policies.providers[2].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[2].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[2].party_id` | COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 200 |
| `policies.providers[2].rework_unit_cost_minor` | 3 |
| `policies.providers[2].setup_cost_minor` | 200 |
| `policies.providers[2].technical_control_allowed` | Oui |
| `policies.providers[2].unit_cost_minor` | 3 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[3].balance_minor` | 40000 |
| `policies.providers[3].consent_until_tick` | 800 |
| `policies.providers[3].liability_limit_minor` | 40000 |
| `policies.providers[3].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[3].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[3].party_id` | COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 300 |
| `policies.providers[3].rework_unit_cost_minor` | 3 |
| `policies.providers[3].setup_cost_minor` | 300 |
| `policies.providers[3].technical_control_allowed` | Oui |
| `policies.providers[3].unit_cost_minor` | 3 |
| Révision · `policies.revision` | 1 |
| Schéma · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Oui |
| Solde (unités mineures SMU synthétiques) · `policies.technical_sponsor.balance_minor` | 60000 |
| Identité du participant · `policies.technical_sponsor.party_id` | TECHNICAL-SPONSOR |
| Empreinte externe de référence · `reference_sha256` | 804a42652d727cc56175483416620d25e2c9b731b0fe6431a46657cc6439e7bc |
| `registered_assertion.expected.accepted_units` | 0 |
| Résultat · `registered_assertion.expected.outcome` | Échec (`FAILED`) |
| `registered_assertion.expected.service_feasibility` | Non établi (`NOT_ESTABLISHED`) |
| `registered_assertion.observed.accepted_units` | 0 |
| Résultat · `registered_assertion.observed.outcome` | Échec (`FAILED`) |
| `registered_assertion.observed.service_feasibility` | Non établi (`NOT_ESTABLISHED`) |
| Portée de l’évaluation · `registered_assertion.scope` | Assertion d’évaluation préenregistrée ; elle n’affirme ni résultat favorable ni transaction acceptable. |
| État consigné · `registered_assertion.status` | Réussi (`PASSED`) |
| Modifications sources non consignées présentes · `source_version.dirty` | Non |
| Arguments exacts du processus · `source_version.environment.argv[0]` | python3 |
| Arguments exacts du processus · `source_version.environment.argv[1]` | -m |
| Arguments exacts du processus · `source_version.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `source_version.environment.argv[3]` | --language |
| Arguments exacts du processus · `source_version.environment.argv[4]` | en |
| Arguments exacts du processus · `source_version.environment.argv[5]` | experiment |
| Arguments exacts du processus · `source_version.environment.argv[6]` | --out |
| Arguments exacts du processus · `source_version.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Plateforme d’exécution · `source_version.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Interpréteur Python · `source_version.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| Version de SQLite · `source_version.environment.sqlite_version` | 3.45.1 |
| Répertoire d’exécution · `source_version.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Commit source effectif · `source_version.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `source_version.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `source_version.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `source_version.version` | 0.2.0 |
| Hypothèses de confiance explicites · `trust_assumptions[0]` | Hôte, noyau, contrôleur et horloge de confiance (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Hypothèses de confiance explicites · `trust_assumptions[1]` | Autorité synthétique conservée de confiance (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Hypothèses de confiance explicites · `trust_assumptions[2]` | Auteur commun ; aucune certification par un tiers (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Hypothèses de confiance explicites · `trust_assumptions[3]` | Contenu numérique sémantique uniquement ; livraison physique non éprouvée (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Pannes préenregistrées non déclenchées · `untriggered_faults` | Aucune entrée |

## Enregistrement structuré complet de vérification

Le même enregistrement structuré génère les deux versions linguistiques. Les clés machine, codes d’état et valeurs littérales des preuves restent inchangés ; les sections localisées ci-dessus expliquent leur sens. Aucun résultat sauvegardé n’est réutilisé comme preuve fraîche.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 0,
    "buyer_utility_interval_minor": {
      "maximum": null,
      "minimum": null
    },
    "campaign": [
      {
        "final_balance_minor": 30000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 10000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "NOT_ESTABLISHED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 0,
    "total_transfers_minor": 0,
    "trade_settled": false
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "FAILED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "OUTSIDE_OPTION",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "FAILED",
    "service_feasibility": "NOT_ESTABLISHED"
  },
  "cohort": "base",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "d95f4c63d992c1d74e3b68724c775459c7eab00c6a697b073f9f841bfb43e361",
  "evidence_sha256": {
    "evidence/capacity/BACKUP.W0.sqlite": "9844ea2a949246f7ca6b58a3bb5013498825c2f131826cf3f61ecdb54c410d35",
    "evidence/capacity/COMPAT-A.W0.sqlite": "1a79c7682827b0a9446cff55cf3ce8f17b43daa7e59daf6667569c836373b0ed",
    "evidence/capacity/COMPAT-B.W0.sqlite": "9b59edd2d984f035b4b818157005c7e4e74875be2861c0277e902736ae249183",
    "evidence/capacity/PRIMARY.W0.sqlite": "e0f86e4a15707a9c9f460b7a88e3230fa689ff0f60b877a06032d2dd72e5b4d8",
    "evidence/participants.sqlite": "52770819be8b228ac42ada23bd2faf61caacf8d9c690bc99fe0f04aa561ca20d",
    "evidence/producer.sqlite": "f74c6f0452bb0fec019a385ecd98330fe727657da275627dfb6cb87a67c1eda4",
    "evidence/receiver.sqlite": "e1f4007761d480266c499898bff598f62c3a81e607c80d034e8f6dd2f9ad6065"
  },
  "failures": [],
  "fault_schedule": [],
  "faults_observed": [],
  "fixture_id": "uncertain-value",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/home/runner/work/_temp/continuity-economy/complete"
      ],
      "platform": "Linux-7.0.0-1017-azure-x86_64-with-glibc2.39",
      "python": "3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]",
      "sqlite_version": "3.45.1",
      "working_directory": "/home/runner/work/CONTINUITY/CONTINUITY"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "method": "outside",
  "per_arrangement": [],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "UNFULFILLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNFULFILLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "804a42652d727cc56175483416620d25e2c9b731b0fe6431a46657cc6439e7bc",
  "registered_assertion": {
    "expected": {
      "accepted_units": 0,
      "outcome": "FAILED",
      "service_feasibility": "NOT_ESTABLISHED"
    },
    "observed": {
      "accepted_units": 0,
      "outcome": "FAILED",
      "service_feasibility": "NOT_ESTABLISHED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "PASSED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30080,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 13565000,
    "controller_cpu_user_ns": 28446999,
    "cpu_system_ns": 82479000,
    "cpu_user_ns": 264644999,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 0,
    "retries": 0,
    "service_requests": 18,
    "storage_bytes": 1216210,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 2409972754,
    "worker_restarts": 0
  },
  "run_id": "uncertain-value.outside.3dcb2c3a62",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/home/runner/work/_temp/continuity-economy/complete"
      ],
      "platform": "Linux-7.0.0-1017-azure-x86_64-with-glibc2.39",
      "python": "3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]",
      "sqlite_version": "3.45.1",
      "working_directory": "/home/runner/work/CONTINUITY/CONTINUITY"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 0,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 0,
    "production_attempts": 0,
    "received_quantity": 0,
    "recipient_accepted_quantity": 0,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 0,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 33318109,
    "evidence_files_read": 7,
    "wall_ns": 33324653
  },
  "verification_status": "COMPLETE",
  "verification_wall_ns": 33381247,
  "verifier_version": "0.2.0"
}
```
