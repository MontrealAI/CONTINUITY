# CONTINUITY Ω Harness — Economy of continuity

**Digital-product experiment · version 0.2.0**

Preserve a promise through a viable, voluntarily accepted continuity arrangement.

**Scope: disposable local processes and a specified digital product. Authored synthetic policies, consent, values, funding and SMU cash flows are model inputs and observations. They do not establish real contracts, demand, payments, sales, printed goods, rendered appearance or print quality.**

This Passport presents the recorded assessment. Fresh verification must inspect retained authority, actual durable output and recipient evidence; this document is never its oracle.

<!-- structured-result-sha256: f864ff6bb3cfd5270ba659b2153a530fea86873ff3473fd7b6369d3fcd3610bb -->

## Three distinct claims

| Claim | Recorded status |
| --- | --- |
| Required digital work accepted within the frozen conditions | Demonstrated in scope (`DEMONSTRATED`) |
| Service feasibility under the authored synthetic model | Demonstrated in scope (`DEMONSTRATED`) |
| Method advantage over competent alternatives | Not established (`NOT_ESTABLISHED`) |
| Safety within the exercised failure model | Demonstrated in scope (`DEMONSTRATED`) |

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

## Assessment fields kept separate

| Field | Recorded value |
| --- | --- |
| Test assertion | Passed (`PASSED`) |
| Component verdict | Completed (`COMPLETED`) |
| Evidence stage | Local digital-product execution (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| Assessed claim status | Demonstrated in scope (`DEMONSTRATED`) |

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

## Identity, authority and versions

| Field | Recorded value |
| --- | --- |
| Authority evidence status · `authority_status` | Established for the synthetic exercise only (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Real commercial value · `commercial_value` | Not established (`NOT_ESTABLISHED`) |
| Contract identity · `contract_id` | DIGITAL-002 |
| Retained contract SHA-256 · `contract_sha256` | 17d59774966d9805cb46bc3109cb11cec1fea2e78679b777b11ff2197d05f803 |
| Real customer authenticity · `real_customer_authenticity` | Not established (`NOT_ESTABLISHED`) |
| External reference pin · `reference_sha256` | 672e48cb25bd39788b0ccdb9ac23ea3e131e29fb8295e60a3d68abdd91bde1d1 |
| Run identity · `run_id` | conventional-better.conventional.faf91ef689 |
| Schema · `schema` | continuity-economy/verification/v1 |
| Verification completion status · `verification_status` | Complete verification (`COMPLETE`) |
| Verifier version · `verifier_version` | 0.2.0 |

## Per-obligation execution and acceptance

Counts describe the recorded stage. Rejected and corrected attempts remain distinct. A produced or received unit is not automatically accepted. Missing measurements are not displayed as zero.

| Obligation | Recipient | Revision | Required | Produced | Received | Rejected | Accepted within contract | Outcome |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 1100 | 1100 | 0 | 1100 | Completed (`COMPLETED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 800 | 800 | 0 | 800 | Completed (`COMPLETED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Cancelled (`CANCELLED`) |

### Obligation `DL-100`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 1100 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 3 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | DL-100 |
| Outcome · `outcome` | Completed (`COMPLETED`) |
| Produced quantity · `produced_quantity` | 1100 |
| Durable production attempts · `production_attempts` | 3 |
| Required quantity · `quantity` | 1100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 1100 |
| Recipient · `recipient` | RECIPIENT-A |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 1100 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 1100 |
| Revision · `revision` | 2 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 1100 |

### Obligation `DL-200`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 800 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 2 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | DL-200 |
| Outcome · `outcome` | Completed (`COMPLETED`) |
| Produced quantity · `produced_quantity` | 800 |
| Durable production attempts · `production_attempts` | 2 |
| Required quantity · `quantity` | 800 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 800 |
| Recipient · `recipient` | RECIPIENT-B |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 800 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 800 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 800 |

### Obligation `DL-300`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | DL-300 |
| Outcome · `outcome` | Cancelled (`CANCELLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-C |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 0 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Cancelled (`CANCELLED`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

## Proposals, modeled decisions and arrangements

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-001`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids[0]` | proposal-001.DL-100.L001.A1.D |
| Acceptance references · `acceptance_ids[1]` | proposal-001.DL-100.L002.A1.D |
| Acceptance references · `acceptance_ids[2]` | proposal-001.DL-100.L003.A1.D |
| Acceptance references · `acceptance_ids[3]` | proposal-001.DL-200.L001.A1.D |
| Acceptance references · `acceptance_ids[4]` | proposal-001.DL-200.L002.A1.D |
| Agreement acceptance tick · `accepted_tick` | 3 |
| Agreement identity · `agreement_id` | proposal-001 |
| Cancellation tick · `cancelled_tick` | Not recorded |
| Incurred correction cost (synthetic SMU minor units) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Incurred cost (synthetic SMU minor units) · `incurred_cost_minor` | 2250 |
| Break-even buyer value (synthetic SMU minor units) · `independent_terms.break_even_value_minor` | 6500 |
| Buyer price ceiling at the lower value bound (synthetic SMU minor units) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU minor units) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU minor units) · `independent_terms.minimum_buyer_price_minor` | 4500 |
| Minimum coordinator fee (synthetic SMU minor units) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU minor units) · `independent_terms.providers[0].base_cost_minor` | 2050 |
| Modeled profit after maximum specified rework (synthetic SMU minor units) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU minor units) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 4100 |
| Minimum provider payment (synthetic SMU minor units) · `independent_terms.providers[0].minimum_payment_minor` | 4200 |
| Required participation profit (synthetic SMU minor units) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | BACKUP |
| Promised provider payment (synthetic SMU minor units) · `independent_terms.providers[0].promised_payment_minor` | 4200 |
| Maximum correction cost (synthetic SMU minor units) · `independent_terms.providers[0].rework_cost_minor` | 2050 |
| Units · `independent_terms.providers[0].units` | 1900 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2050 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | Modeled trade agreement (`TRADE`) |
| Stable code · `participant_decisions[0].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[1].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[1].party_id` | BACKUP |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[2].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[2].party_id` | COORDINATOR |
| Role · `participant_decisions[2].role` | coordinator |
| Component verdict · `participant_decisions[2].verdict` | Accepted (`ACCEPTED`) |
| Modeled payments (synthetic SMU minor units) · `payments_minor` | 4500 |
| Proposal identity · `proposal_id` | proposal-001 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 4200 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 4500 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 17d59774966d9805cb46bc3109cb11cec1fea2e78679b777b11ff2197d05f803 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 300 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-001 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2050 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Modeled settlement tick · `settled_tick` | 29 |
| Recorded status · `status` | Settled in the synthetic ledger (`SETTLED`) |

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.


## Modeled transfers, costs, liabilities and outside options

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

| Field | Recorded value |
| --- | --- |
| Total buyer transfers (synthetic SMU minor units) · `accounting.buyer_total_paid_minor` | 4500 |
| Upper bound · `accounting.buyer_utility_interval_minor.maximum` | 25500 |
| Lower bound · `accounting.buyer_utility_interval_minor.minimum` | 25500 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[0].final_balance_minor` | 25500 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Modeled participation threshold covered · `accounting.campaign[0].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[0].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[0].party_id` | BUYER |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[0].purchase_payments_minor` | 4500 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[0].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[0].revenue_minor` | 0 |
| Role · `accounting.campaign[0].role` | buyer |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[1].final_balance_minor` | 10100 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[1].incurred_cost_minor` | 200 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Modeled participation threshold covered · `accounting.campaign[1].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[1].participation_threshold_minor` | 100 |
| Participant identity · `accounting.campaign[1].party_id` | COORDINATOR |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[1].realized_profit_minor` | 100 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[1].revenue_minor` | 300 |
| Role · `accounting.campaign[1].role` | coordinator |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Modeled participation threshold covered · `accounting.campaign[2].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[2].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[2].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[2].revenue_minor` | 0 |
| Role · `accounting.campaign[2].role` | technical_sponsor |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[3].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[3].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[3].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[3].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[3].party_id` | PRIMARY |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[3].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[3].revenue_minor` | 0 |
| Role · `accounting.campaign[3].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[4].final_balance_minor` | 42150 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[4].incurred_cost_minor` | 2050 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[4].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[4].participation_threshold_minor` | 100 |
| Participant identity · `accounting.campaign[4].party_id` | BACKUP |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[4].realized_profit_minor` | 2150 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[4].revenue_minor` | 4200 |
| Role · `accounting.campaign[4].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[5].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[5].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[5].party_id` | COMPAT-A |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[5].revenue_minor` | 0 |
| Role · `accounting.campaign[5].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[6].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[6].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[6].party_id` | COMPAT-B |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[6].revenue_minor` | 0 |
| Role · `accounting.campaign[6].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Synthetic accounting unit · `accounting.currency` | SMU |
| Final ledger total (synthetic SMU minor units) · `accounting.final_total_minor` | 260000 |
| Initial ledger total (synthetic SMU minor units) · `accounting.initial_total_minor` | 260000 |
| Real contracts, payments or demand · `accounting.real_contracts_payments_or_demand` | Not established (`NOT_ESTABLISHED`) |
| Realized modeled buyer feasibility · `accounting.realized_buyer` | Demonstrated in scope (`DEMONSTRATED`) |
| Assessment scope · `accounting.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| All correction costs (synthetic SMU minor units) · `accounting.total_correction_cost_minor` | 0 |
| All incurred campaign costs (synthetic SMU minor units) · `accounting.total_incurred_cost_minor` | 2250 |
| All modeled settlement transfers (synthetic SMU minor units) · `accounting.total_transfers_minor` | 4500 |
| Modeled trade settled · `accounting.trade_settled` | Yes |
| Accepted obligations · `totals.accepted_obligations` | 2 |
| Accepted quantity within contract · `totals.accepted_quantity` | 1900 |
| Delivery attempts · `totals.delivery_attempts` | 5 |
| Duplicate accepted units · `totals.duplicate_acceptances` | 0 |
| Late quantity · `totals.late_quantity` | 0 |
| Missing quantity · `totals.missing_quantity` | 0 |
| Produced quantity · `totals.produced_quantity` | 1900 |
| Durable production attempts · `totals.production_attempts` | 5 |
| Received quantity · `totals.received_quantity` | 1900 |
| Units accepted by the recipient component · `totals.recipient_accepted_quantity` | 1900 |
| Rejected quantity · `totals.rejected_quantity` | 0 |
| Requested units in rejected deliveries · `totals.rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `totals.rejection_count` | 0 |
| Required active obligations · `totals.required_obligations` | 2 |
| Required quantity · `totals.required_quantity` | 1900 |
| Semantically correct units observed in time · `totals.timely_semantic_quantity` | 1900 |
| Unsafe or unsupported commitments · `totals.unsafe_or_unsupported_commitments` | 0 |

## Measured resources and accounting gaps

Measured process resources and configured synthetic amounts have different meanings. Unrecorded preparation, integration, adaptation, verification or intervention effort remains unknown. Missing categories cannot support a complete-cost or cheaper-method conclusion.

| Field | Recorded value |
| --- | --- |
| Accounting gaps · `accounting_gaps[0]` | Preparation labor was not measured (`PREPARATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[1]` | Integration labor was not measured (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[2]` | Adaptation labor was not measured (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[3]` | Human verification labor was not measured (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[4]` | Monetary rates were not measured (`MONETARY_RATES_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Adaptation labor (seconds; unknown if absent) · `resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `resources.authority_storage_bytes_before_seal` | 30139 |
| Candidate restarts · `resources.candidate_restarts` | 0 |
| Launched child processes · `resources.child_processes` | 8 |
| Controller system CPU (ns) · `resources.controller_cpu_system_ns` | 22142000 |
| Controller user CPU (ns) · `resources.controller_cpu_user_ns` | 122058000 |
| System CPU (ns) · `resources.cpu_system_ns` | 116676000 |
| User CPU (ns) · `resources.cpu_user_ns` | 541890999 |
| Human interventions · `resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `resources.preparation_labor_seconds` | Not recorded |
| Requests · `resources.requests` | 29 |
| Retries · `resources.retries` | 0 |
| Internal service requests · `resources.service_requests` | 156 |
| Recorded storage (bytes) · `resources.storage_bytes` | 8776801 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `resources.wall_ns` | 1486967564 |
| Worker restarts · `resources.worker_restarts` | 0 |
| Process CPU (ns) · `verification_resources.cpu_ns` | 188758023 |
| Evidence files inspected · `verification_resources.evidence_files_read` | 22 |
| Wall duration (ns) · `verification_resources.wall_ns` | 188784158 |

## Observed failures and counterexamples

No failure entry was recorded in this assessment. This is bounded evidence, not a general proof.

## Missing evidence and unresolved claims

No additional unresolved entry was recorded. Scope and unknown-cost limits still apply.

## Evidence references and byte integrity

Hashes identify bytes. They do not authenticate real customer instructions, establish source completeness, or replace an externally retained reference pin.

| Field | Recorded value |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-100.L001.A1.json` | bd55fa3e07b271fe45ee6ff7bd3a37ec58c44b0087612a605bceb39c6b1ebd91 |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-100.L002.A1.json` | 89b4a3ef9c2d60fda5b7741f79fc0812d782bf36facc5d54d016351b7607af39 |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-100.L003.A1.json` | 50f4a06406223f10bcc8fb7a9eb44e7e061c7eb69d8362e8c10bb3d9622fc6fd |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-200.L001.A1.json` | 603b1b44e6a71d6da8e9441bce03991d69826b30f1c3be31db2cc7a3c4e66317 |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-200.L002.A1.json` | 44287db462e61fc37ec8c0a8044807bb0389b1d9d47d0e55a8cfbacc394734db |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 5fa1a32af13a71496a0fc22d000976d503f58c2800ce37905d067def9fbbb0a0 |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | 35d39399f26246f1be5184c4b384abd9278da1d802618ed05dd9803f3e82d00e |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | 9adf60dbeb3689168582b68d17955441ee8f02b33f23e6da96374f6e9309933f |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | 733b9b7b07c185db3b2ffadcc5d1f3022aa2a78e99c40a6b6e11b5da5a8f339e |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L001.A1.D.json` | 676cec40f871a790d01d6b3c15a9e7ab5e103c0c5a27c561e760377040ce2000 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L002.A1.D.json` | cc712b522686aa6300b242f52668e341ec96ccb19d6a855930b65af0096ef290 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L003.A1.D.json` | aab0645b717d1dc5682ef5a83931b495548a4e14d3490d89f30fbefb2bf0fa9b |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L001.A1.D.json` | 36826849d8655193d339556f20cb6109ccee2ae20bf552683eca7ed81fb29afb |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L002.A1.D.json` | 06af74f86a833d46487c4be341ce60a05acd728b12a3dca83b64bb91aa5499bd |
| `evidence_sha256.evidence/participants.sqlite` | 14ed77dffc1f1c0f95a6ee61c11109a3fbe0877da599aea05e67962102cfb577 |
| `evidence_sha256.evidence/producer.sqlite` | 6f5e35c6c60096bc6811e0876fa1de352b91040f6ffebe2731b36d477b8c6bb9 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L001.A1.json` | 676cec40f871a790d01d6b3c15a9e7ab5e103c0c5a27c561e760377040ce2000 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L002.A1.json` | cc712b522686aa6300b242f52668e341ec96ccb19d6a855930b65af0096ef290 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L003.A1.json` | aab0645b717d1dc5682ef5a83931b495548a4e14d3490d89f30fbefb2bf0fa9b |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L001.A1.json` | 36826849d8655193d339556f20cb6109ccee2ae20bf552683eca7ed81fb29afb |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L002.A1.json` | 06af74f86a833d46487c4be341ce60a05acd728b12a3dca83b64bb91aa5499bd |
| `evidence_sha256.evidence/receiver.sqlite` | 0668d9710ba3046f595396a8fb02b7bee35878297e2732f93fdc881356ed0550 |
| Structured result SHA-256 · `structured_result_sha256` | f864ff6bb3cfd5270ba659b2153a530fea86873ff3473fd7b6369d3fcd3610bb |

## Recorded execution, faults, commands and provenance

Stable identifiers, exact commands, paths and original machine diagnostics are retained literally. They are data, not additional acceptance evidence. Source and host trust remain explicit in the architecture and threat model.

| Field | Recorded value |
| --- | --- |
| `authority_dir` | /home/runner/work/_temp/continuity-economy/complete/base/authorities/conventional-better.conventional |
| Experiment cohort · `cohort` | base |
| `contract.allow_split` | Yes |
| `contract.authority_kind` | Synthetic exercise authority (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | PRIMARY-HOST |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Experiment cohort · `contract.cohort` | base |
| Contract identity · `contract.contract_id` | DIGITAL-002 |
| `contract.cutoff_sequence` | 5 |
| Logical deadline · `contract.deadline_tick` | 500 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-001 |
| Registered fault schedule · `contract.fault_schedule` | No entries |
| Registered fixture identity · `contract.fixture_id` | conventional-better |
| `contract.lease_ticks` | 20 |
| `contract.lot_size` | 500 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Logical deadline · `contract.obligations[0].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[0].obligation_id` | DL-100 |
| Required quantity · `contract.obligations[0].quantity` | 1100 |
| Recipient · `contract.obligations[0].recipient` | RECIPIENT-A |
| Revision · `contract.obligations[0].revision` | 2 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[0].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[0].spec.lot` | BATCH-20261106 |
| `contract.obligations[0].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[0].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[0].spec.serial_prefix` | DL-100- |
| `contract.obligations[0].spec.sku` | KIT-DL-100 |
| Recorded status · `contract.obligations[0].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[1].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[1].obligation_id` | DL-200 |
| Required quantity · `contract.obligations[1].quantity` | 800 |
| Recipient · `contract.obligations[1].recipient` | RECIPIENT-B |
| Revision · `contract.obligations[1].revision` | 1 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[1].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[1].spec.lot` | BATCH-20261106 |
| `contract.obligations[1].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[1].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[1].spec.serial_prefix` | DL-200- |
| `contract.obligations[1].spec.sku` | KIT-DL-200 |
| Recorded status · `contract.obligations[1].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[2].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[2].obligation_id` | DL-300 |
| Required quantity · `contract.obligations[2].quantity` | 100 |
| Recipient · `contract.obligations[2].recipient` | RECIPIENT-C |
| Revision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[2].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[2].spec.lot` | BATCH-20261106 |
| `contract.obligations[2].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[2].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[2].spec.serial_prefix` | DL-300- |
| `contract.obligations[2].spec.sku` | KIT-DL-300 |
| Recorded status · `contract.obligations[2].status` | Cancelled (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 800 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | PRIMARY-HOST |
| `contract.providers[0].permissions.disclosure` | Yes |
| `contract.providers[0].permissions.production` | Yes |
| Provider identity · `contract.providers[0].provider_id` | PRIMARY |
| Role · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 2400 |
| `contract.providers[0].windows[0].end` | 800 |
| `contract.providers[0].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[0].windows[0].window_id` | W0 |
| `contract.providers[1].dependency` | BACKUP-HOST |
| `contract.providers[1].permissions.disclosure` | Yes |
| `contract.providers[1].permissions.production` | Yes |
| Provider identity · `contract.providers[1].provider_id` | BACKUP |
| Role · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 2400 |
| `contract.providers[1].windows[0].end` | 800 |
| `contract.providers[1].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[1].windows[0].window_id` | W0 |
| `contract.providers[2].dependency` | COMPAT-A-HOST |
| `contract.providers[2].permissions.disclosure` | Yes |
| `contract.providers[2].permissions.production` | Yes |
| Provider identity · `contract.providers[2].provider_id` | COMPAT-A |
| Role · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 1200 |
| `contract.providers[2].windows[0].end` | 800 |
| `contract.providers[2].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[2].windows[0].window_id` | W0 |
| `contract.providers[3].dependency` | COMPAT-B-HOST |
| `contract.providers[3].permissions.disclosure` | Yes |
| `contract.providers[3].permissions.production` | Yes |
| Provider identity · `contract.providers[3].provider_id` | COMPAT-B |
| Role · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 1100 |
| `contract.providers[3].windows[0].end` | 800 |
| `contract.providers[3].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[3].windows[0].window_id` | W0 |
| Revision · `contract.revision` | 1 |
| `contract.revocations` | No entries |
| Run identity · `contract.run_id` | conventional-better.conventional.faf91ef689 |
| Schema · `contract.schema` | continuity-economy/contract/v1 |
| Recorded seed · `contract.seed` | 702 |
| `contract.source_complete` | Yes |
| Logical deadline · `contract.source_events[0].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[0].obligation.obligation_id` | DL-100 |
| Required quantity · `contract.source_events[0].obligation.quantity` | 1000 |
| Recipient · `contract.source_events[0].obligation.recipient` | RECIPIENT-A |
| Revision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Obsolete instruction. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Instruction périmée. |
| `contract.source_events[0].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[0].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[0].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[0].obligation.spec.sku` | KIT-DL-100 |
| Recorded status · `contract.source_events[0].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[0].obligation_id` | DL-100 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Logical deadline · `contract.source_events[1].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[1].obligation.obligation_id` | DL-200 |
| Required quantity · `contract.source_events[1].obligation.quantity` | 800 |
| Recipient · `contract.source_events[1].obligation.recipient` | RECIPIENT-B |
| Revision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[1].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[1].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[1].obligation.spec.serial_prefix` | DL-200- |
| `contract.source_events[1].obligation.spec.sku` | KIT-DL-200 |
| Recorded status · `contract.source_events[1].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[1].obligation_id` | DL-200 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Logical deadline · `contract.source_events[2].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[2].obligation.obligation_id` | DL-300 |
| Required quantity · `contract.source_events[2].obligation.quantity` | 100 |
| Recipient · `contract.source_events[2].obligation.recipient` | RECIPIENT-C |
| Revision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[2].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[2].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[2].obligation.spec.serial_prefix` | DL-300- |
| `contract.source_events[2].obligation.spec.sku` | KIT-DL-300 |
| Recorded status · `contract.source_events[2].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[2].obligation_id` | DL-300 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Logical deadline · `contract.source_events[3].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[3].obligation.obligation_id` | DL-100 |
| Required quantity · `contract.source_events[3].obligation.quantity` | 1100 |
| Recipient · `contract.source_events[3].obligation.recipient` | RECIPIENT-A |
| Revision · `contract.source_events[3].obligation.revision` | 2 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[3].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[3].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[3].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[3].obligation.spec.sku` | KIT-DL-100 |
| Recorded status · `contract.source_events[3].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[3].obligation_id` | DL-100 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | AMEND |
| Obligation identity · `contract.source_events[4].obligation_id` | DL-300 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | CANCEL |
| `contract.source_id` | AUTHORED-DIGITAL-EVENTS |
| Source byte hashes · `contract.source_sha256` | 8d6a71fd1c26021120a5283bd7cf3eb7812b5c34ae6a4da3eec94dceaf8f7b81 |
| Start clock (ns) · `contract.start_ns` | 227905755391 |
| Elapsed-time deadline (ms) · `contract.wall_deadline_ms` | 60000 |
| `controller.capacity_databases[0].path` | evidence/capacity/PRIMARY.W0.sqlite |
| Provider identity · `controller.capacity_databases[0].provider_id` | PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Capacity-window identity · `controller.capacity_databases[0].window_id` | W0 |
| `controller.capacity_databases[1].path` | evidence/capacity/BACKUP.W0.sqlite |
| Provider identity · `controller.capacity_databases[1].provider_id` | BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Capacity-window identity · `controller.capacity_databases[1].window_id` | W0 |
| `controller.capacity_databases[2].path` | evidence/capacity/COMPAT-A.W0.sqlite |
| Provider identity · `controller.capacity_databases[2].provider_id` | COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Capacity-window identity · `controller.capacity_databases[2].window_id` | W0 |
| `controller.capacity_databases[3].path` | evidence/capacity/COMPAT-B.W0.sqlite |
| Provider identity · `controller.capacity_databases[3].provider_id` | COMPAT-B |
| `controller.capacity_databases[3].route` | backup |
| Capacity-window identity · `controller.capacity_databases[3].window_id` | W0 |
| `controller.clock_tick` | 29 |
| Experiment cohort · `controller.cohort` | base |
| Retained contract SHA-256 · `controller.contract_sha256` | 17d59774966d9805cb46bc3109cb11cec1fea2e78679b777b11ff2197d05f803 |
| `controller.db_snapshots.evidence/capacity/BACKUP.W0.sqlite` | d9d32ccc6c15351c57f2a0d6f73526f1394bbd14d70c2efd1ae1ae62b3cf6669 |
| `controller.db_snapshots.evidence/capacity/COMPAT-A.W0.sqlite` | d20c88327adb1c3bc97cf1b1607f95ffde31c0180ec4a24e1af02eefb1ed425b |
| `controller.db_snapshots.evidence/capacity/COMPAT-B.W0.sqlite` | 58d1d46ff247bd47a1a0e79fc019e9393ce006a85d74358bf470601761042e26 |
| `controller.db_snapshots.evidence/capacity/PRIMARY.W0.sqlite` | 5eb76dbb26900c92ea290925e125714511af6da7840c3e2f61e8e5d8c0304935 |
| `controller.db_snapshots.evidence/participants.sqlite` | d6869f9ae10fb0edcab628f94d8b17b02ff8ec86fa13a46e3dd1e012a5a2ed41 |
| `controller.db_snapshots.evidence/producer.sqlite` | 2846ac61e4a487fbf45fbf3a3c81933c55880e82959d783089c7af0d8667e309 |
| `controller.db_snapshots.evidence/receiver.sqlite` | fd4c5aefa2bfb418e90f82a3d0fa6c723386859f5ab8a23b92ed428b78c5edfb |
| `controller.errors` | No entries |
| `controller.events[0].detail.authority_kind` | Synthetic exercise authority (`SYNTHETIC_EXERCISE`) |
| External reference pin · `controller.events[0].detail.reference_sha256` | 672e48cb25bd39788b0ccdb9ac23ea3e131e29fb8295e60a3d68abdd91bde1d1 |
| Recorded seed · `controller.events[0].detail.seed` | 702 |
| Recorded event · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 227922197190 |
| Logical tick · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 2618 |
| `controller.events[1].detail.restart` | No |
| `controller.events[1].detail.service` | participants |
| Recorded event · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 228093632595 |
| Logical tick · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 2619 |
| `controller.events[2].detail.restart` | No |
| `controller.events[2].detail.service` | producer |
| Recorded event · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 228140069262 |
| Logical tick · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 2620 |
| `controller.events[3].detail.restart` | No |
| `controller.events[3].detail.service` | receiver |
| Recorded event · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 228178900410 |
| Logical tick · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 2621 |
| Provider identity · `controller.events[4].detail.provider_id` | PRIMARY |
| Capacity-window identity · `controller.events[4].detail.window_id` | W0 |
| Recorded event · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 228308521567 |
| Logical tick · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 2622 |
| Provider identity · `controller.events[5].detail.provider_id` | BACKUP |
| Capacity-window identity · `controller.events[5].detail.window_id` | W0 |
| Recorded event · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 228351679831 |
| Logical tick · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 2623 |
| Provider identity · `controller.events[6].detail.provider_id` | COMPAT-A |
| Capacity-window identity · `controller.events[6].detail.window_id` | W0 |
| Recorded event · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 228396461364 |
| Logical tick · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 2624 |
| Provider identity · `controller.events[7].detail.provider_id` | COMPAT-B |
| Capacity-window identity · `controller.events[7].detail.window_id` | W0 |
| Recorded event · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 228544677127 |
| Logical tick · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.affected[0]` | PRIMARY.W0 |
| `controller.events[8].detail.dependency` | PRIMARY-HOST |
| Recorded event · `controller.events[8].event` | DEPENDENCY_DISABLED |
| `controller.events[8].monotonic_ns` | 228545395524 |
| Logical tick · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.isolation.applied` | Yes |
| `controller.events[9].detail.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.events[9].detail.isolation.probe.authority_open_denied` | Yes |
| `controller.events[9].detail.isolation.probe.network_denied` | Yes |
| `controller.events[9].detail.isolation.probe.process_inspection_denied` | Yes |
| `controller.events[9].detail.isolation.probe.spawn_denied` | Yes |
| `controller.events[9].detail.isolation.probe.workspace_open_denied` | Yes |
| `controller.events[9].detail.pid` | 2625 |
| `controller.events[9].detail.restart` | No |
| Recorded event · `controller.events[9].event` | CANDIDATE_STARTED |
| `controller.events[9].monotonic_ns` | 228599052343 |
| Logical tick · `controller.events[9].tick` | 0 |
| `controller.events[10].detail.args` | No entries |
| `controller.events[10].detail.op` | status |
| Recorded event · `controller.events[10].event` | BROKER_REQUEST |
| `controller.events[10].monotonic_ns` | 228600444411 |
| Logical tick · `controller.events[10].tick` | 1 |
| `controller.events[11].detail.measurement_kind` | Candidate-reported measurement (`CANDIDATE_REPORTED`) |
| `controller.events[11].detail.pid` | 2625 |
| `controller.events[11].detail.report.assignment_domain` | 243 |
| `controller.events[11].detail.report.candidate_elapsed_ns` | 6880222 |
| `controller.events[11].detail.report.capacity_prunes` | 54 |
| `controller.events[11].detail.report.complete_assignments_observed` | 243 |
| `controller.events[11].detail.report.exhaustive_within_declared_domain` | Yes |
| `controller.events[11].detail.report.feasible_assignments` | 189 |
| `controller.events[11].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Candidate procedure · `controller.events[11].detail.report.method` | conventional |
| `controller.events[11].detail.report.partial_nodes_observed` | 0 |
| `controller.events[11].detail.report.participant_prunes` | 0 |
| `controller.events[11].detail.report.price_prunes` | 0 |
| Recorded event · `controller.events[11].event` | CANDIDATE_PLANNING |
| `controller.events[11].monotonic_ns` | 228611230700 |
| Logical tick · `controller.events[11].tick` | 1 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[0].last_unit` | 500 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[0].pay_minor` | 4200 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[0].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[1].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[2].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[3].last_unit` | 500 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[3].pay_minor` | 0 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[3].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `controller.events[12].detail.args.proposal.allocations[4].last_unit` | 800 |
| Fixed lot identity · `controller.events[12].detail.args.proposal.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `controller.events[12].detail.args.proposal.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.allocations[4].pay_minor` | 0 |
| Provider identity · `controller.events[12].detail.args.proposal.allocations[4].provider_id` | BACKUP |
| Capacity-window identity · `controller.events[12].detail.args.proposal.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.buyer_price_minor` | 4500 |
| Cancellation liability (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `controller.events[12].detail.args.proposal.contract_sha256` | 17d59774966d9805cb46bc3109cb11cec1fea2e78679b777b11ff2197d05f803 |
| Coordinator fee (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.coordinator_fee_minor` | 300 |
| Exclusive expiry tick · `controller.events[12].detail.args.proposal.expires_tick` | 500 |
| Policy revision · `controller.events[12].detail.args.proposal.policy_revision` | 1 |
| Proposal identity · `controller.events[12].detail.args.proposal.proposal_id` | proposal-001 |
| Correction reserve (synthetic SMU minor units) · `controller.events[12].detail.args.proposal.rework_budget_minor` | 2050 |
| Schema · `controller.events[12].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[12].detail.op` | propose |
| Recorded event · `controller.events[12].event` | BROKER_REQUEST |
| `controller.events[12].monotonic_ns` | 228611797254 |
| Logical tick · `controller.events[12].tick` | 2 |
| Proposal identity · `controller.events[13].detail.args.proposal_id` | proposal-001 |
| `controller.events[13].detail.op` | decide |
| Recorded event · `controller.events[13].event` | BROKER_REQUEST |
| `controller.events[13].monotonic_ns` | 228615656712 |
| Logical tick · `controller.events[13].tick` | 3 |
| `controller.events[14].detail.args` | No entries |
| `controller.events[14].detail.op` | status |
| Recorded event · `controller.events[14].event` | BROKER_REQUEST |
| `controller.events[14].monotonic_ns` | 228619190140 |
| Logical tick · `controller.events[14].tick` | 4 |
| Agreement identity · `controller.events[15].detail.args.agreement_id` | proposal-001 |
| `controller.events[15].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[15].detail.args.lot_id` | DL-100.L001 |
| `controller.events[15].detail.op` | reserve |
| Recorded event · `controller.events[15].event` | BROKER_REQUEST |
| `controller.events[15].monotonic_ns` | 228623587980 |
| Logical tick · `controller.events[15].tick` | 5 |
| `controller.events[16].detail.key` | proposal-001.DL-100.L001.A1 |
| `controller.events[16].detail.slot` | BACKUP.W0 |
| Recorded status · `controller.events[16].detail.status` | RESERVED |
| Recorded event · `controller.events[16].event` | CAPACITY_RESERVED |
| `controller.events[16].monotonic_ns` | 228628658620 |
| Logical tick · `controller.events[16].tick` | 5 |
| Agreement identity · `controller.events[17].detail.args.agreement_id` | proposal-001 |
| `controller.events[17].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[17].detail.args.lot_id` | DL-100.L001 |
| `controller.events[17].detail.args.supersedes` | Not recorded |
| `controller.events[17].detail.op` | produce |
| Recorded event · `controller.events[17].event` | BROKER_REQUEST |
| `controller.events[17].monotonic_ns` | 228628954665 |
| Logical tick · `controller.events[17].tick` | 6 |
| `controller.events[18].detail.byte_count` | 195955 |
| `controller.events[18].detail.payload_sha256` | 676cec40f871a790d01d6b3c15a9e7ab5e103c0c5a27c561e760377040ce2000 |
| `controller.events[18].detail.production_id` | proposal-001.DL-100.L001.A1 |
| Required quantity · `controller.events[18].detail.quantity` | 500 |
| Recorded event · `controller.events[18].event` | PRODUCT_MATERIALIZED |
| `controller.events[18].monotonic_ns` | 228654060381 |
| Logical tick · `controller.events[18].tick` | 6 |
| `controller.events[19].detail.args.production_id` | proposal-001.DL-100.L001.A1 |
| `controller.events[19].detail.op` | transfer |
| Recorded event · `controller.events[19].event` | BROKER_REQUEST |
| `controller.events[19].monotonic_ns` | 228654405849 |
| Logical tick · `controller.events[19].tick` | 7 |
| `controller.events[20].detail.byte_count` | 195955 |
| `controller.events[20].detail.delivery_id` | proposal-001.DL-100.L001.A1.D |
| `controller.events[20].detail.produced_sha256` | 676cec40f871a790d01d6b3c15a9e7ab5e103c0c5a27c561e760377040ce2000 |
| `controller.events[20].detail.production_id` | proposal-001.DL-100.L001.A1 |
| `controller.events[20].detail.received_sha256` | 676cec40f871a790d01d6b3c15a9e7ab5e103c0c5a27c561e760377040ce2000 |
| Recorded event · `controller.events[20].event` | PRODUCT_TRANSFERRED |
| `controller.events[20].monotonic_ns` | 228660363704 |
| Logical tick · `controller.events[20].tick` | 7 |
| `controller.events[21].detail.args.delivery_id` | proposal-001.DL-100.L001.A1.D |
| `controller.events[21].detail.op` | inspect |
| Recorded event · `controller.events[21].event` | BROKER_REQUEST |
| `controller.events[21].monotonic_ns` | 228660626561 |
| Logical tick · `controller.events[21].tick` | 8 |
| `controller.events[22].detail.accepted_units` | 500 |
| `controller.events[22].detail.delivery_id` | proposal-001.DL-100.L001.A1.D |
| Recorded status · `controller.events[22].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[22].detail.timely` | Yes |
| Recorded event · `controller.events[22].event` | RECIPIENT_INSPECTED |
| `controller.events[22].monotonic_ns` | 228693837430 |
| Logical tick · `controller.events[22].tick` | 8 |
| `controller.events[23].detail.args` | No entries |
| `controller.events[23].detail.op` | status |
| Recorded event · `controller.events[23].event` | BROKER_REQUEST |
| `controller.events[23].monotonic_ns` | 228694225902 |
| Logical tick · `controller.events[23].tick` | 9 |
| Agreement identity · `controller.events[24].detail.args.agreement_id` | proposal-001 |
| `controller.events[24].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[24].detail.args.lot_id` | DL-100.L002 |
| `controller.events[24].detail.op` | reserve |
| Recorded event · `controller.events[24].event` | BROKER_REQUEST |
| `controller.events[24].monotonic_ns` | 228699702539 |
| Logical tick · `controller.events[24].tick` | 10 |
| `controller.events[25].detail.key` | proposal-001.DL-100.L002.A1 |
| `controller.events[25].detail.slot` | BACKUP.W0 |
| Recorded status · `controller.events[25].detail.status` | RESERVED |
| Recorded event · `controller.events[25].event` | CAPACITY_RESERVED |
| `controller.events[25].monotonic_ns` | 228704568057 |
| Logical tick · `controller.events[25].tick` | 10 |
| Agreement identity · `controller.events[26].detail.args.agreement_id` | proposal-001 |
| `controller.events[26].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[26].detail.args.lot_id` | DL-100.L002 |
| `controller.events[26].detail.args.supersedes` | Not recorded |
| `controller.events[26].detail.op` | produce |
| Recorded event · `controller.events[26].event` | BROKER_REQUEST |
| `controller.events[26].monotonic_ns` | 228704844284 |
| Logical tick · `controller.events[26].tick` | 11 |
| `controller.events[27].detail.byte_count` | 196067 |
| `controller.events[27].detail.payload_sha256` | cc712b522686aa6300b242f52668e341ec96ccb19d6a855930b65af0096ef290 |
| `controller.events[27].detail.production_id` | proposal-001.DL-100.L002.A1 |
| Required quantity · `controller.events[27].detail.quantity` | 500 |
| Recorded event · `controller.events[27].event` | PRODUCT_MATERIALIZED |
| `controller.events[27].monotonic_ns` | 228778121468 |
| Logical tick · `controller.events[27].tick` | 11 |
| `controller.events[28].detail.args.production_id` | proposal-001.DL-100.L002.A1 |
| `controller.events[28].detail.op` | transfer |
| Recorded event · `controller.events[28].event` | BROKER_REQUEST |
| `controller.events[28].monotonic_ns` | 228778454128 |
| Logical tick · `controller.events[28].tick` | 12 |
| `controller.events[29].detail.byte_count` | 196067 |
| `controller.events[29].detail.delivery_id` | proposal-001.DL-100.L002.A1.D |
| `controller.events[29].detail.produced_sha256` | cc712b522686aa6300b242f52668e341ec96ccb19d6a855930b65af0096ef290 |
| `controller.events[29].detail.production_id` | proposal-001.DL-100.L002.A1 |
| `controller.events[29].detail.received_sha256` | cc712b522686aa6300b242f52668e341ec96ccb19d6a855930b65af0096ef290 |
| Recorded event · `controller.events[29].event` | PRODUCT_TRANSFERRED |
| `controller.events[29].monotonic_ns` | 228784946590 |
| Logical tick · `controller.events[29].tick` | 12 |
| `controller.events[30].detail.args.delivery_id` | proposal-001.DL-100.L002.A1.D |
| `controller.events[30].detail.op` | inspect |
| Recorded event · `controller.events[30].event` | BROKER_REQUEST |
| `controller.events[30].monotonic_ns` | 228785213602 |
| Logical tick · `controller.events[30].tick` | 13 |
| `controller.events[31].detail.accepted_units` | 500 |
| `controller.events[31].detail.delivery_id` | proposal-001.DL-100.L002.A1.D |
| Recorded status · `controller.events[31].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[31].detail.timely` | Yes |
| Recorded event · `controller.events[31].event` | RECIPIENT_INSPECTED |
| `controller.events[31].monotonic_ns` | 228817582994 |
| Logical tick · `controller.events[31].tick` | 13 |
| `controller.events[32].detail.args` | No entries |
| `controller.events[32].detail.op` | status |
| Recorded event · `controller.events[32].event` | BROKER_REQUEST |
| `controller.events[32].monotonic_ns` | 228817914582 |
| Logical tick · `controller.events[32].tick` | 14 |
| Agreement identity · `controller.events[33].detail.args.agreement_id` | proposal-001 |
| `controller.events[33].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[33].detail.args.lot_id` | DL-100.L003 |
| `controller.events[33].detail.op` | reserve |
| Recorded event · `controller.events[33].event` | BROKER_REQUEST |
| `controller.events[33].monotonic_ns` | 228824128053 |
| Logical tick · `controller.events[33].tick` | 15 |
| `controller.events[34].detail.key` | proposal-001.DL-100.L003.A1 |
| `controller.events[34].detail.slot` | BACKUP.W0 |
| Recorded status · `controller.events[34].detail.status` | RESERVED |
| Recorded event · `controller.events[34].event` | CAPACITY_RESERVED |
| `controller.events[34].monotonic_ns` | 228828890499 |
| Logical tick · `controller.events[34].tick` | 15 |
| Agreement identity · `controller.events[35].detail.args.agreement_id` | proposal-001 |
| `controller.events[35].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[35].detail.args.lot_id` | DL-100.L003 |
| `controller.events[35].detail.args.supersedes` | Not recorded |
| `controller.events[35].detail.op` | produce |
| Recorded event · `controller.events[35].event` | BROKER_REQUEST |
| `controller.events[35].monotonic_ns` | 228829163110 |
| Logical tick · `controller.events[35].tick` | 16 |
| `controller.events[36].detail.byte_count` | 39767 |
| `controller.events[36].detail.payload_sha256` | aab0645b717d1dc5682ef5a83931b495548a4e14d3490d89f30fbefb2bf0fa9b |
| `controller.events[36].detail.production_id` | proposal-001.DL-100.L003.A1 |
| Required quantity · `controller.events[36].detail.quantity` | 100 |
| Recorded event · `controller.events[36].event` | PRODUCT_MATERIALIZED |
| `controller.events[36].monotonic_ns` | 228841759117 |
| Logical tick · `controller.events[36].tick` | 16 |
| `controller.events[37].detail.args.production_id` | proposal-001.DL-100.L003.A1 |
| `controller.events[37].detail.op` | transfer |
| Recorded event · `controller.events[37].event` | BROKER_REQUEST |
| `controller.events[37].monotonic_ns` | 228842101140 |
| Logical tick · `controller.events[37].tick` | 17 |
| `controller.events[38].detail.byte_count` | 39767 |
| `controller.events[38].detail.delivery_id` | proposal-001.DL-100.L003.A1.D |
| `controller.events[38].detail.produced_sha256` | aab0645b717d1dc5682ef5a83931b495548a4e14d3490d89f30fbefb2bf0fa9b |
| `controller.events[38].detail.production_id` | proposal-001.DL-100.L003.A1 |
| `controller.events[38].detail.received_sha256` | aab0645b717d1dc5682ef5a83931b495548a4e14d3490d89f30fbefb2bf0fa9b |
| Recorded event · `controller.events[38].event` | PRODUCT_TRANSFERRED |
| `controller.events[38].monotonic_ns` | 228848458723 |
| Logical tick · `controller.events[38].tick` | 17 |
| `controller.events[39].detail.args.delivery_id` | proposal-001.DL-100.L003.A1.D |
| `controller.events[39].detail.op` | inspect |
| Recorded event · `controller.events[39].event` | BROKER_REQUEST |
| `controller.events[39].monotonic_ns` | 228848699287 |
| Logical tick · `controller.events[39].tick` | 18 |
| `controller.events[40].detail.accepted_units` | 100 |
| `controller.events[40].detail.delivery_id` | proposal-001.DL-100.L003.A1.D |
| Recorded status · `controller.events[40].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[40].detail.timely` | Yes |
| Recorded event · `controller.events[40].event` | RECIPIENT_INSPECTED |
| `controller.events[40].monotonic_ns` | 228857267352 |
| Logical tick · `controller.events[40].tick` | 18 |
| `controller.events[41].detail.args` | No entries |
| `controller.events[41].detail.op` | status |
| Recorded event · `controller.events[41].event` | BROKER_REQUEST |
| `controller.events[41].monotonic_ns` | 228857590708 |
| Logical tick · `controller.events[41].tick` | 19 |
| Agreement identity · `controller.events[42].detail.args.agreement_id` | proposal-001 |
| `controller.events[42].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[42].detail.args.lot_id` | DL-200.L001 |
| `controller.events[42].detail.op` | reserve |
| Recorded event · `controller.events[42].event` | BROKER_REQUEST |
| `controller.events[42].monotonic_ns` | 228864709491 |
| Logical tick · `controller.events[42].tick` | 20 |
| `controller.events[43].detail.key` | proposal-001.DL-200.L001.A1 |
| `controller.events[43].detail.slot` | BACKUP.W0 |
| Recorded status · `controller.events[43].detail.status` | RESERVED |
| Recorded event · `controller.events[43].event` | CAPACITY_RESERVED |
| `controller.events[43].monotonic_ns` | 229075845872 |
| Logical tick · `controller.events[43].tick` | 20 |
| Agreement identity · `controller.events[44].detail.args.agreement_id` | proposal-001 |
| `controller.events[44].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[44].detail.args.lot_id` | DL-200.L001 |
| `controller.events[44].detail.args.supersedes` | Not recorded |
| `controller.events[44].detail.op` | produce |
| Recorded event · `controller.events[44].event` | BROKER_REQUEST |
| `controller.events[44].monotonic_ns` | 229076214825 |
| Logical tick · `controller.events[44].tick` | 21 |
| `controller.events[45].detail.byte_count` | 195955 |
| `controller.events[45].detail.payload_sha256` | 36826849d8655193d339556f20cb6109ccee2ae20bf552683eca7ed81fb29afb |
| `controller.events[45].detail.production_id` | proposal-001.DL-200.L001.A1 |
| Required quantity · `controller.events[45].detail.quantity` | 500 |
| Recorded event · `controller.events[45].event` | PRODUCT_MATERIALIZED |
| `controller.events[45].monotonic_ns` | 229101927444 |
| Logical tick · `controller.events[45].tick` | 21 |
| `controller.events[46].detail.args.production_id` | proposal-001.DL-200.L001.A1 |
| `controller.events[46].detail.op` | transfer |
| Recorded event · `controller.events[46].event` | BROKER_REQUEST |
| `controller.events[46].monotonic_ns` | 229102284029 |
| Logical tick · `controller.events[46].tick` | 22 |
| `controller.events[47].detail.byte_count` | 195955 |
| `controller.events[47].detail.delivery_id` | proposal-001.DL-200.L001.A1.D |
| `controller.events[47].detail.produced_sha256` | 36826849d8655193d339556f20cb6109ccee2ae20bf552683eca7ed81fb29afb |
| `controller.events[47].detail.production_id` | proposal-001.DL-200.L001.A1 |
| `controller.events[47].detail.received_sha256` | 36826849d8655193d339556f20cb6109ccee2ae20bf552683eca7ed81fb29afb |
| Recorded event · `controller.events[47].event` | PRODUCT_TRANSFERRED |
| `controller.events[47].monotonic_ns` | 229109702232 |
| Logical tick · `controller.events[47].tick` | 22 |
| `controller.events[48].detail.args.delivery_id` | proposal-001.DL-200.L001.A1.D |
| `controller.events[48].detail.op` | inspect |
| Recorded event · `controller.events[48].event` | BROKER_REQUEST |
| `controller.events[48].monotonic_ns` | 229109955705 |
| Logical tick · `controller.events[48].tick` | 23 |
| `controller.events[49].detail.accepted_units` | 500 |
| `controller.events[49].detail.delivery_id` | proposal-001.DL-200.L001.A1.D |
| Recorded status · `controller.events[49].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[49].detail.timely` | Yes |
| Recorded event · `controller.events[49].event` | RECIPIENT_INSPECTED |
| `controller.events[49].monotonic_ns` | 229148078761 |
| Logical tick · `controller.events[49].tick` | 23 |
| `controller.events[50].detail.args` | No entries |
| `controller.events[50].detail.op` | status |
| Recorded event · `controller.events[50].event` | BROKER_REQUEST |
| `controller.events[50].monotonic_ns` | 229148457929 |
| Logical tick · `controller.events[50].tick` | 24 |
| Agreement identity · `controller.events[51].detail.args.agreement_id` | proposal-001 |
| `controller.events[51].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[51].detail.args.lot_id` | DL-200.L002 |
| `controller.events[51].detail.op` | reserve |
| Recorded event · `controller.events[51].event` | BROKER_REQUEST |
| `controller.events[51].monotonic_ns` | 229156280888 |
| Logical tick · `controller.events[51].tick` | 25 |
| `controller.events[52].detail.key` | proposal-001.DL-200.L002.A1 |
| `controller.events[52].detail.slot` | BACKUP.W0 |
| Recorded status · `controller.events[52].detail.status` | RESERVED |
| Recorded event · `controller.events[52].event` | CAPACITY_RESERVED |
| `controller.events[52].monotonic_ns` | 229161629017 |
| Logical tick · `controller.events[52].tick` | 25 |
| Agreement identity · `controller.events[53].detail.args.agreement_id` | proposal-001 |
| `controller.events[53].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[53].detail.args.lot_id` | DL-200.L002 |
| `controller.events[53].detail.args.supersedes` | Not recorded |
| `controller.events[53].detail.op` | produce |
| Recorded event · `controller.events[53].event` | BROKER_REQUEST |
| `controller.events[53].monotonic_ns` | 229161924001 |
| Logical tick · `controller.events[53].tick` | 26 |
| `controller.events[54].detail.byte_count` | 117865 |
| `controller.events[54].detail.payload_sha256` | 06af74f86a833d46487c4be341ce60a05acd728b12a3dca83b64bb91aa5499bd |
| `controller.events[54].detail.production_id` | proposal-001.DL-200.L002.A1 |
| Required quantity · `controller.events[54].detail.quantity` | 300 |
| Recorded event · `controller.events[54].event` | PRODUCT_MATERIALIZED |
| `controller.events[54].monotonic_ns` | 229180341897 |
| Logical tick · `controller.events[54].tick` | 26 |
| `controller.events[55].detail.args.production_id` | proposal-001.DL-200.L002.A1 |
| `controller.events[55].detail.op` | transfer |
| Recorded event · `controller.events[55].event` | BROKER_REQUEST |
| `controller.events[55].monotonic_ns` | 229180661637 |
| Logical tick · `controller.events[55].tick` | 27 |
| `controller.events[56].detail.byte_count` | 117865 |
| `controller.events[56].detail.delivery_id` | proposal-001.DL-200.L002.A1.D |
| `controller.events[56].detail.produced_sha256` | 06af74f86a833d46487c4be341ce60a05acd728b12a3dca83b64bb91aa5499bd |
| `controller.events[56].detail.production_id` | proposal-001.DL-200.L002.A1 |
| `controller.events[56].detail.received_sha256` | 06af74f86a833d46487c4be341ce60a05acd728b12a3dca83b64bb91aa5499bd |
| Recorded event · `controller.events[56].event` | PRODUCT_TRANSFERRED |
| `controller.events[56].monotonic_ns` | 229186601856 |
| Logical tick · `controller.events[56].tick` | 27 |
| `controller.events[57].detail.args.delivery_id` | proposal-001.DL-200.L002.A1.D |
| `controller.events[57].detail.op` | inspect |
| Recorded event · `controller.events[57].event` | BROKER_REQUEST |
| `controller.events[57].monotonic_ns` | 229186835931 |
| Logical tick · `controller.events[57].tick` | 28 |
| `controller.events[58].detail.accepted_units` | 300 |
| `controller.events[58].detail.delivery_id` | proposal-001.DL-200.L002.A1.D |
| Recorded status · `controller.events[58].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[58].detail.timely` | Yes |
| Recorded event · `controller.events[58].event` | RECIPIENT_INSPECTED |
| `controller.events[58].monotonic_ns` | 229207592157 |
| Logical tick · `controller.events[58].tick` | 28 |
| Agreement identity · `controller.events[59].detail.args.agreement_id` | proposal-001 |
| `controller.events[59].detail.op` | settle |
| Recorded event · `controller.events[59].event` | BROKER_REQUEST |
| `controller.events[59].monotonic_ns` | 229207942032 |
| Logical tick · `controller.events[59].tick` | 29 |
| Acceptance references · `controller.events[60].detail.acceptance_ids[0]` | proposal-001.DL-100.L001.A1.D |
| Acceptance references · `controller.events[60].detail.acceptance_ids[1]` | proposal-001.DL-100.L002.A1.D |
| Acceptance references · `controller.events[60].detail.acceptance_ids[2]` | proposal-001.DL-100.L003.A1.D |
| Acceptance references · `controller.events[60].detail.acceptance_ids[3]` | proposal-001.DL-200.L001.A1.D |
| Acceptance references · `controller.events[60].detail.acceptance_ids[4]` | proposal-001.DL-200.L002.A1.D |
| Agreement identity · `controller.events[60].detail.agreement_id` | proposal-001 |
| Recorded event · `controller.events[60].event` | ARRANGEMENT_SETTLED |
| `controller.events[60].monotonic_ns` | 229213341556 |
| Logical tick · `controller.events[60].tick` | 29 |
| Recorded interventions · `controller.events[61].detail.interventions` | No entries |
| Recorded reason · `controller.events[61].detail.reason` | DIGITAL_PRODUCT_ACCEPTED |
| `controller.events[61].detail.searches[0].assignment_domain` | 243 |
| `controller.events[61].detail.searches[0].candidate_elapsed_ns` | 6880222 |
| `controller.events[61].detail.searches[0].capacity_prunes` | 54 |
| `controller.events[61].detail.searches[0].complete_assignments_observed` | 243 |
| `controller.events[61].detail.searches[0].exhaustive_within_declared_domain` | Yes |
| `controller.events[61].detail.searches[0].feasible_assignments` | 189 |
| `controller.events[61].detail.searches[0].funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Candidate procedure · `controller.events[61].detail.searches[0].method` | conventional |
| `controller.events[61].detail.searches[0].partial_nodes_observed` | 0 |
| `controller.events[61].detail.searches[0].participant_prunes` | 0 |
| `controller.events[61].detail.searches[0].price_prunes` | 0 |
| Component verdict · `controller.events[61].detail.verdict` | Completed (`COMPLETED`) |
| Recorded event · `controller.events[61].event` | CANDIDATE_DONE |
| `controller.events[61].monotonic_ns` | 229213808753 |
| Logical tick · `controller.events[61].tick` | 29 |
| `controller.events[62].detail.database` | participants |
| `controller.events[62].detail.sqlite[0]` | 0 |
| `controller.events[62].detail.sqlite[1]` | 0 |
| `controller.events[62].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[62].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[62].event` | DATABASE_CHECKPOINT |
| `controller.events[62].monotonic_ns` | 229243285133 |
| Logical tick · `controller.events[62].tick` | 29 |
| `controller.events[63].detail.database` | producer |
| `controller.events[63].detail.sqlite[0]` | 0 |
| `controller.events[63].detail.sqlite[1]` | 0 |
| `controller.events[63].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[63].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[63].event` | DATABASE_CHECKPOINT |
| `controller.events[63].monotonic_ns` | 229247395661 |
| Logical tick · `controller.events[63].tick` | 29 |
| `controller.events[64].detail.database` | receiver |
| `controller.events[64].detail.sqlite[0]` | 0 |
| `controller.events[64].detail.sqlite[1]` | 0 |
| `controller.events[64].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[64].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[64].event` | DATABASE_CHECKPOINT |
| `controller.events[64].monotonic_ns` | 229254864329 |
| Logical tick · `controller.events[64].tick` | 29 |
| `controller.events[65].detail.database` | PRIMARY.W0 |
| `controller.events[65].detail.sqlite[0]` | 0 |
| `controller.events[65].detail.sqlite[1]` | 0 |
| `controller.events[65].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[65].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[65].event` | DATABASE_CHECKPOINT |
| `controller.events[65].monotonic_ns` | 229255931238 |
| Logical tick · `controller.events[65].tick` | 29 |
| `controller.events[66].detail.database` | BACKUP.W0 |
| `controller.events[66].detail.sqlite[0]` | 0 |
| `controller.events[66].detail.sqlite[1]` | 0 |
| `controller.events[66].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[66].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[66].event` | DATABASE_CHECKPOINT |
| `controller.events[66].monotonic_ns` | 229257312140 |
| Logical tick · `controller.events[66].tick` | 29 |
| `controller.events[67].detail.database` | COMPAT-A.W0 |
| `controller.events[67].detail.sqlite[0]` | 0 |
| `controller.events[67].detail.sqlite[1]` | 0 |
| `controller.events[67].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[67].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[67].event` | DATABASE_CHECKPOINT |
| `controller.events[67].monotonic_ns` | 229258360182 |
| Logical tick · `controller.events[67].tick` | 29 |
| `controller.events[68].detail.database` | COMPAT-B.W0 |
| `controller.events[68].detail.sqlite[0]` | 0 |
| `controller.events[68].detail.sqlite[1]` | 0 |
| `controller.events[68].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[68].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[68].event` | DATABASE_CHECKPOINT |
| `controller.events[68].monotonic_ns` | 229259513759 |
| Logical tick · `controller.events[68].tick` | 29 |
| `controller.events[69].detail.databases` | 7 |
| `controller.events[69].detail.snapshot_method` | SQLITE_BACKUP_DELETE_FULL_LOGICAL_DIGEST |
| Recorded event · `controller.events[69].event` | EVIDENCE_FINALIZED |
| `controller.events[69].monotonic_ns` | 229392753951 |
| Logical tick · `controller.events[69].tick` | 29 |
| Registered fault schedule · `controller.fault_schedule` | No entries |
| Actually observed faults · `controller.faults_observed` | No entries |
| `controller.finished_monotonic_ns` | 229392757446 |
| Registered fixture identity · `controller.fixture_id` | conventional-better |
| Uncommitted source changes present · `controller.implementation.dirty` | No |
| Exact process arguments · `controller.implementation.environment.argv[0]` | python3 |
| Exact process arguments · `controller.implementation.environment.argv[1]` | -m |
| Exact process arguments · `controller.implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `controller.implementation.environment.argv[3]` | --language |
| Exact process arguments · `controller.implementation.environment.argv[4]` | en |
| Exact process arguments · `controller.implementation.environment.argv[5]` | experiment |
| Exact process arguments · `controller.implementation.environment.argv[6]` | --out |
| Exact process arguments · `controller.implementation.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Operating platform · `controller.implementation.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Python interpreter · `controller.implementation.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| SQLite version · `controller.implementation.environment.sqlite_version` | 3.45.1 |
| Execution directory · `controller.implementation.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Actual source commit · `controller.implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Preserved capacity implementation baseline · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Yes |
| `controller.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Yes |
| `controller.isolation.probe.network_denied` | Yes |
| `controller.isolation.probe.process_inspection_denied` | Yes |
| `controller.isolation.probe.spawn_denied` | Yes |
| `controller.isolation.probe.workspace_open_denied` | Yes |
| Candidate procedure · `controller.method` | conventional |
| `controller.policies_sha256` | 32948382a634540c8a5bd065b534c6fa5e35ee3100872aba39dc0ed2d99bbce2 |
| Adaptation labor (seconds; unknown if absent) · `controller.resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `controller.resources.authority_storage_bytes_before_seal` | 30139 |
| Candidate restarts · `controller.resources.candidate_restarts` | 0 |
| Launched child processes · `controller.resources.child_processes` | 8 |
| Controller system CPU (ns) · `controller.resources.controller_cpu_system_ns` | 22142000 |
| Controller user CPU (ns) · `controller.resources.controller_cpu_user_ns` | 122058000 |
| System CPU (ns) · `controller.resources.cpu_system_ns` | 116676000 |
| User CPU (ns) · `controller.resources.cpu_user_ns` | 541890999 |
| Human interventions · `controller.resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `controller.resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `controller.resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `controller.resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `controller.resources.preparation_labor_seconds` | Not recorded |
| Requests · `controller.resources.requests` | 29 |
| Retries · `controller.resources.retries` | 0 |
| Internal service requests · `controller.resources.service_requests` | 156 |
| Recorded storage (bytes) · `controller.resources.storage_bytes` | 8776801 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `controller.resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `controller.resources.wall_ns` | 1486967564 |
| Worker restarts · `controller.resources.worker_restarts` | 0 |
| Run identity · `controller.run_id` | conventional-better.conventional.faf91ef689 |
| Schema · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 227905789882 |
| `controller.started_utc` | 2026-11-07T00:44:43.876770+00:00 |
| `controller.state` | Complete verification (`COMPLETE`) |
| Target verdict · `controller.target_verdict` | Completed (`COMPLETED`) |
| Registered fault schedule · `fault_schedule` | No entries |
| Actually observed faults · `faults_observed` | No entries |
| Registered fixture identity · `fixture_id` | conventional-better |
| Uncommitted source changes present · `implementation.dirty` | No |
| Exact process arguments · `implementation.environment.argv[0]` | python3 |
| Exact process arguments · `implementation.environment.argv[1]` | -m |
| Exact process arguments · `implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `implementation.environment.argv[3]` | --language |
| Exact process arguments · `implementation.environment.argv[4]` | en |
| Exact process arguments · `implementation.environment.argv[5]` | experiment |
| Exact process arguments · `implementation.environment.argv[6]` | --out |
| Exact process arguments · `implementation.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Operating platform · `implementation.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Python interpreter · `implementation.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| SQLite version · `implementation.environment.sqlite_version` | 3.45.1 |
| Execution directory · `implementation.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Actual source commit · `implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Preserved capacity implementation baseline · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `implementation.version` | 0.2.0 |
| Candidate procedure · `method` | conventional |
| Balance (synthetic SMU minor units) · `policies.buyer.balance_minor` | 30000 |
| `policies.buyer.consent_until_tick` | 800 |
| `policies.buyer.max_price_minor` | 25000 |
| Authored outside-option utility (synthetic SMU minor units) · `policies.buyer.outside_utility_minor` | 2000 |
| Participant identity · `policies.buyer.party_id` | BUYER |
| Authored value upper bound (synthetic SMU minor units) · `policies.buyer.value_max_minor` | 30000 |
| Authored value lower bound (synthetic SMU minor units) · `policies.buyer.value_min_minor` | 30000 |
| Balance (synthetic SMU minor units) · `policies.coordinator.balance_minor` | 10000 |
| `policies.coordinator.consent_until_tick` | 800 |
| `policies.coordinator.liability_limit_minor` | 10000 |
| `policies.coordinator.min_profit_minor` | 100 |
| `policies.coordinator.operating_cost_minor` | 200 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.coordinator.outside_profit_minor` | 100 |
| Participant identity · `policies.coordinator.party_id` | COORDINATOR |
| `policies.coordinator.technical_control_allowed` | Yes |
| Synthetic accounting unit · `policies.currency` | SMU |
| Balance (synthetic SMU minor units) · `policies.providers[0].balance_minor` | 40000 |
| `policies.providers[0].consent_until_tick` | 800 |
| `policies.providers[0].liability_limit_minor` | 40000 |
| `policies.providers[0].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[0].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[0].party_id` | PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 100 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 100 |
| `policies.providers[0].technical_control_allowed` | Yes |
| `policies.providers[0].unit_cost_minor` | 1 |
| Balance (synthetic SMU minor units) · `policies.providers[1].balance_minor` | 40000 |
| `policies.providers[1].consent_until_tick` | 800 |
| `policies.providers[1].liability_limit_minor` | 40000 |
| `policies.providers[1].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[1].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[1].party_id` | BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 150 |
| `policies.providers[1].rework_unit_cost_minor` | 1 |
| `policies.providers[1].setup_cost_minor` | 150 |
| `policies.providers[1].technical_control_allowed` | Yes |
| `policies.providers[1].unit_cost_minor` | 1 |
| Balance (synthetic SMU minor units) · `policies.providers[2].balance_minor` | 40000 |
| `policies.providers[2].consent_until_tick` | 800 |
| `policies.providers[2].liability_limit_minor` | 40000 |
| `policies.providers[2].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[2].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[2].party_id` | COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 200 |
| `policies.providers[2].rework_unit_cost_minor` | 3 |
| `policies.providers[2].setup_cost_minor` | 200 |
| `policies.providers[2].technical_control_allowed` | Yes |
| `policies.providers[2].unit_cost_minor` | 3 |
| Balance (synthetic SMU minor units) · `policies.providers[3].balance_minor` | 40000 |
| `policies.providers[3].consent_until_tick` | 800 |
| `policies.providers[3].liability_limit_minor` | 40000 |
| `policies.providers[3].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[3].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[3].party_id` | COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 300 |
| `policies.providers[3].rework_unit_cost_minor` | 3 |
| `policies.providers[3].setup_cost_minor` | 300 |
| `policies.providers[3].technical_control_allowed` | Yes |
| `policies.providers[3].unit_cost_minor` | 3 |
| Revision · `policies.revision` | 1 |
| Schema · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Yes |
| Balance (synthetic SMU minor units) · `policies.technical_sponsor.balance_minor` | 60000 |
| Participant identity · `policies.technical_sponsor.party_id` | TECHNICAL-SPONSOR |
| External reference pin · `reference_sha256` | 672e48cb25bd39788b0ccdb9ac23ea3e131e29fb8295e60a3d68abdd91bde1d1 |
| `registered_assertion.expected.accepted_units` | 1900 |
| Outcome · `registered_assertion.expected.outcome` | Demonstrated in scope (`DEMONSTRATED`) |
| `registered_assertion.expected.service_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| `registered_assertion.observed.accepted_units` | 1900 |
| Outcome · `registered_assertion.observed.outcome` | Demonstrated in scope (`DEMONSTRATED`) |
| `registered_assertion.observed.service_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Assessment scope · `registered_assertion.scope` | Registered assessment assertion; it does not assert a favorable outcome or trade. |
| Recorded status · `registered_assertion.status` | Passed (`PASSED`) |
| Uncommitted source changes present · `source_version.dirty` | No |
| Exact process arguments · `source_version.environment.argv[0]` | python3 |
| Exact process arguments · `source_version.environment.argv[1]` | -m |
| Exact process arguments · `source_version.environment.argv[2]` | continuity_economy |
| Exact process arguments · `source_version.environment.argv[3]` | --language |
| Exact process arguments · `source_version.environment.argv[4]` | en |
| Exact process arguments · `source_version.environment.argv[5]` | experiment |
| Exact process arguments · `source_version.environment.argv[6]` | --out |
| Exact process arguments · `source_version.environment.argv[7]` | /home/runner/work/_temp/continuity-economy/complete |
| Operating platform · `source_version.environment.platform` | Linux-7.0.0-1017-azure-x86_64-with-glibc2.39 |
| Python interpreter · `source_version.environment.python` | 3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0] |
| SQLite version · `source_version.environment.sqlite_version` | 3.45.1 |
| Execution directory · `source_version.environment.working_directory` | /home/runner/work/CONTINUITY/CONTINUITY |
| Actual source commit · `source_version.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Preserved capacity implementation baseline · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `source_version.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `source_version.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `source_version.version` | 0.2.0 |
| Explicit trust assumptions · `trust_assumptions[0]` | Trusted host, kernel, controller and clock (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Explicit trust assumptions · `trust_assumptions[1]` | Trusted retained synthetic authority (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Explicit trust assumptions · `trust_assumptions[2]` | Shared authorship; no third-party certification (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Explicit trust assumptions · `trust_assumptions[3]` | Semantic digital content only; physical delivery is untested (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Registered faults not triggered · `untriggered_faults` | No entries |

## Complete structured verification record

The same structured record generates both language versions. Machine keys, enum codes and literal evidence values remain unchanged; the localized sections above explain their meaning. No saved result is reused as fresh proof.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 4500,
    "buyer_utility_interval_minor": {
      "maximum": 25500,
      "minimum": 25500
    },
    "campaign": [
      {
        "final_balance_minor": 25500,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 4500,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 200,
        "initial_balance_minor": 10000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 100,
        "revenue_minor": 300,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 42150,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 2050,
        "initial_balance_minor": 40000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 2150,
        "revenue_minor": 4200,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 2250,
    "total_transfers_minor": 4500,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "DEMONSTRATED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "COMPLETED",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "DEMONSTRATED",
    "service_feasibility": "DEMONSTRATED"
  },
  "cohort": "base",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "17d59774966d9805cb46bc3109cb11cec1fea2e78679b777b11ff2197d05f803",
  "evidence_sha256": {
    "evidence/capacity-artifacts/BACKUP.W0/DL-100.L001.A1.json": "bd55fa3e07b271fe45ee6ff7bd3a37ec58c44b0087612a605bceb39c6b1ebd91",
    "evidence/capacity-artifacts/BACKUP.W0/DL-100.L002.A1.json": "89b4a3ef9c2d60fda5b7741f79fc0812d782bf36facc5d54d016351b7607af39",
    "evidence/capacity-artifacts/BACKUP.W0/DL-100.L003.A1.json": "50f4a06406223f10bcc8fb7a9eb44e7e061c7eb69d8362e8c10bb3d9622fc6fd",
    "evidence/capacity-artifacts/BACKUP.W0/DL-200.L001.A1.json": "603b1b44e6a71d6da8e9441bce03991d69826b30f1c3be31db2cc7a3c4e66317",
    "evidence/capacity-artifacts/BACKUP.W0/DL-200.L002.A1.json": "44287db462e61fc37ec8c0a8044807bb0389b1d9d47d0e55a8cfbacc394734db",
    "evidence/capacity/BACKUP.W0.sqlite": "5fa1a32af13a71496a0fc22d000976d503f58c2800ce37905d067def9fbbb0a0",
    "evidence/capacity/COMPAT-A.W0.sqlite": "35d39399f26246f1be5184c4b384abd9278da1d802618ed05dd9803f3e82d00e",
    "evidence/capacity/COMPAT-B.W0.sqlite": "9adf60dbeb3689168582b68d17955441ee8f02b33f23e6da96374f6e9309933f",
    "evidence/capacity/PRIMARY.W0.sqlite": "733b9b7b07c185db3b2ffadcc5d1f3022aa2a78e99c40a6b6e11b5da5a8f339e",
    "evidence/inbox/proposal-001.DL-100.L001.A1.D.json": "676cec40f871a790d01d6b3c15a9e7ab5e103c0c5a27c561e760377040ce2000",
    "evidence/inbox/proposal-001.DL-100.L002.A1.D.json": "cc712b522686aa6300b242f52668e341ec96ccb19d6a855930b65af0096ef290",
    "evidence/inbox/proposal-001.DL-100.L003.A1.D.json": "aab0645b717d1dc5682ef5a83931b495548a4e14d3490d89f30fbefb2bf0fa9b",
    "evidence/inbox/proposal-001.DL-200.L001.A1.D.json": "36826849d8655193d339556f20cb6109ccee2ae20bf552683eca7ed81fb29afb",
    "evidence/inbox/proposal-001.DL-200.L002.A1.D.json": "06af74f86a833d46487c4be341ce60a05acd728b12a3dca83b64bb91aa5499bd",
    "evidence/participants.sqlite": "14ed77dffc1f1c0f95a6ee61c11109a3fbe0877da599aea05e67962102cfb577",
    "evidence/producer.sqlite": "6f5e35c6c60096bc6811e0876fa1de352b91040f6ffebe2731b36d477b8c6bb9",
    "evidence/products/proposal-001.DL-100.L001.A1.json": "676cec40f871a790d01d6b3c15a9e7ab5e103c0c5a27c561e760377040ce2000",
    "evidence/products/proposal-001.DL-100.L002.A1.json": "cc712b522686aa6300b242f52668e341ec96ccb19d6a855930b65af0096ef290",
    "evidence/products/proposal-001.DL-100.L003.A1.json": "aab0645b717d1dc5682ef5a83931b495548a4e14d3490d89f30fbefb2bf0fa9b",
    "evidence/products/proposal-001.DL-200.L001.A1.json": "36826849d8655193d339556f20cb6109ccee2ae20bf552683eca7ed81fb29afb",
    "evidence/products/proposal-001.DL-200.L002.A1.json": "06af74f86a833d46487c4be341ce60a05acd728b12a3dca83b64bb91aa5499bd",
    "evidence/receiver.sqlite": "0668d9710ba3046f595396a8fb02b7bee35878297e2732f93fdc881356ed0550"
  },
  "failures": [],
  "fault_schedule": [],
  "faults_observed": [],
  "fixture_id": "conventional-better",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/home/runner/work/_temp/continuity-economy/complete"
      ],
      "platform": "Linux-7.0.0-1017-azure-x86_64-with-glibc2.39",
      "python": "3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]",
      "sqlite_version": "3.45.1",
      "working_directory": "/home/runner/work/CONTINUITY/CONTINUITY"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "method": "conventional",
  "per_arrangement": [
    {
      "acceptance_ids": [
        "proposal-001.DL-100.L001.A1.D",
        "proposal-001.DL-100.L002.A1.D",
        "proposal-001.DL-100.L003.A1.D",
        "proposal-001.DL-200.L001.A1.D",
        "proposal-001.DL-200.L002.A1.D"
      ],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 2250,
      "independent_terms": {
        "break_even_value_minor": 6500,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 4500,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 2050,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 4100,
            "minimum_payment_minor": 4200,
            "participation_profit_minor": 100,
            "party_id": "BACKUP",
            "promised_payment_minor": 4200,
            "rework_cost_minor": 2050,
            "units": 1900
          }
        ],
        "rework_budget_minor": 2050,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "BACKUP",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 4500,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 4200,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 4500,
        "cancellation_fee_minor": 0,
        "contract_sha256": "17d59774966d9805cb46bc3109cb11cec1fea2e78679b777b11ff2197d05f803",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2050,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "DEMONSTRATED",
      "settled_tick": 29,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 1100,
      "deadline_tick": 500,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-100",
      "outcome": "COMPLETED",
      "produced_quantity": 1100,
      "production_attempts": 3,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 1100,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 1100,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 1100
    },
    {
      "accepted_quantity": 800,
      "deadline_tick": 500,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-200",
      "outcome": "COMPLETED",
      "produced_quantity": 800,
      "production_attempts": 2,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 800,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 800,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 800
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "672e48cb25bd39788b0ccdb9ac23ea3e131e29fb8295e60a3d68abdd91bde1d1",
  "registered_assertion": {
    "expected": {
      "accepted_units": 1900,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "observed": {
      "accepted_units": 1900,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "PASSED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30139,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 22142000,
    "controller_cpu_user_ns": 122058000,
    "cpu_system_ns": 116676000,
    "cpu_user_ns": 541890999,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 29,
    "retries": 0,
    "service_requests": 156,
    "storage_bytes": 8776801,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 1486967564,
    "worker_restarts": 0
  },
  "run_id": "conventional-better.conventional.faf91ef689",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/home/runner/work/_temp/continuity-economy/complete"
      ],
      "platform": "Linux-7.0.0-1017-azure-x86_64-with-glibc2.39",
      "python": "3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]",
      "sqlite_version": "3.45.1",
      "working_directory": "/home/runner/work/CONTINUITY/CONTINUITY"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 2,
    "accepted_quantity": 1900,
    "delivery_attempts": 5,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 0,
    "produced_quantity": 1900,
    "production_attempts": 5,
    "received_quantity": 1900,
    "recipient_accepted_quantity": 1900,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 1900,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 188758023,
    "evidence_files_read": 22,
    "wall_ns": 188784158
  },
  "verification_status": "COMPLETE",
  "verification_wall_ns": 190379746,
  "verifier_version": "0.2.0"
}
```
