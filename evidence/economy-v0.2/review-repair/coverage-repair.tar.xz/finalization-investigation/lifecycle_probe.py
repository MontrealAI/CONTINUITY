"""One bounded diagnostic; no qualification outcome or retry-until-pass.

Run two independent, owned capacity workers through the exact controller
digest/checkpoint/close/SQLite-backup lifecycle. Each owns a distinct database.
The operation schedule and snapshots are retained, including any failure.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import struct
import sys
import time

SOURCE = Path('/workspace/scratch/b1d5891eb025/economy-post-review-source')
sys.path.insert(0, str(SOURCE))
from continuity_harness.rpc import ServiceClient
from continuity_economy.controller import database_digest, finalized_database

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'lifecycle-probe-1'
INPUT = Path('/workspace/scratch/b1d5891eb025/economy-review-repair/qualification/complete-replay-1/base/authorities/constructed-continuity.conventional/capacity-inputs.json')
OUT.mkdir()
libc = ctypes.CDLL(None, use_errno=True)
fd = libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
if fd < 0:
    raise OSError(ctypes.get_errno(), 'inotify_init1')
watch_names = {}
clients = {}
report = {'schema': 'continuity-economy/diagnostic-lifecycle/v1',
          'source': 'f9e56c7dd9627b322406e05c53b4f6537d434262',
          'single_attempt': True, 'paths_are_distinct': True,
          'operations': [], 'snapshots': [], 'filesystem_events': [], 'errors': []}
data = json.loads(INPUT.read_text())['COMPAT-A.W0']


def drain():
    while True:
        try:
            raw = os.read(fd, 65536)
        except BlockingIOError:
            break
        position = 0
        while position < len(raw):
            wd, mask, cookie, size = struct.unpack_from('iIII', raw, position)
            position += 16
            name = raw[position:position+size].split(b'\0', 1)[0].decode()
            position += size
            report['filesystem_events'].append({'monotonic_ns': time.monotonic_ns(),
                'worker': watch_names.get(wd), 'mask': mask, 'cookie': cookie, 'name': name})


def snap(stage):
    drain()
    item = {'stage': stage, 'monotonic_ns': time.monotonic_ns(), 'files': {}}
    folder = OUT / 'raw' / stage
    folder.mkdir(parents=True)
    for name in clients:
        for suffix in ('', '-wal', '-shm'):
            source = OUT / name / ('service.sqlite' + suffix)
            if not source.exists():
                continue
            raw = source.read_bytes()
            info = source.stat()
            target = folder / (name + '.sqlite' + suffix)
            target.write_bytes(raw)
            item['files'][str(source.relative_to(OUT))] = {
                'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                'mtime_ns': info.st_mtime_ns, 'inode': info.st_ino}
    report['snapshots'].append(item)


def call(name, op, args=None):
    value = clients[name].call(op, args or {})
    report['operations'].append({'worker': name, 'op': op, 'monotonic_ns': time.monotonic_ns(),
        'ok': value.get('ok'), 'code': value.get('code'),
        'result': value.get('result') if op == 'checkpoint' else None})
    if value.get('ok') is not True:
        raise RuntimeError(value)
    return value['result']


try:
    for name in ('a', 'b'):
        folder = OUT / name
        folder.mkdir()
        (folder / 'artifacts').mkdir()
        wd = libc.inotify_add_watch(fd, os.fsencode(folder), 0x00000FFF)
        if wd < 0:
            raise OSError(ctypes.get_errno(), 'inotify_add_watch')
        watch_names[wd] = name
        clients[name] = ServiceClient(SOURCE, folder / 'service.sqlite', folder / 'artifacts', folder / 'service.stderr')
        init = dict(data['init'])
        init['run_id'] = 'lifecycle-' + name
        call(name, 'init', init)
    snap('initialized')
    orders = [order for order in data['init']['allowed_orders']
              if order['order_id'].startswith('DL-100.') and order['order_id'].endswith('.A1')]
    assert len(orders) == 3
    tick = 1
    for index, order in enumerate(orders, 1):
        pending = {}
        for name, client in clients.items():
            request = {k: v for k, v in order.items() if k != 'deadline_tick'}
            request.update(run_id='lifecycle-'+name, contract_sha256=data['init']['contract_sha256'],
                route=data['route'], key=name+'.'+order['order_id'], window_start=data['init']['window_start'],
                window_end=data['init']['window_end'], expires_tick=tick+20, now_tick=tick)
            pending[name] = client.start_request('reserve', request, ['reserve.after_begin'])
        # Both independent workers must hold their own real transactions before
        # either is released; this barrier does not use sleeps.
        for name, client in clients.items():
            event = client.receive()
            assert event.get('id') == pending[name] and event.get('hook') == 'reserve.after_begin', event
        report['operations'].append({'op': 'BOTH_DISTINCT_DB_TRANSACTIONS_HELD', 'lot': index, 'tick': tick})
        for client in clients.values():
            client.send({'continue': True})
        for name, client in clients.items():
            response = client.receive()
            assert response.get('id') == pending[name] and response.get('ok') is True, response
            call(name, 'commit', {'key': name+'.'+order['order_id'], 'now_tick': tick+1})
            call(name, 'fulfill', {'key': name+'.'+order['order_id'], 'now_tick': tick+2})
        snap('lot-'+str(index)+'-fulfilled')
        tick += 3
    expected = {name: database_digest(OUT/name/'service.sqlite') for name in clients}
    report['retained_digests'] = expected
    snap('captured')
    for name in clients:
        checkpoint = call(name, 'checkpoint')
        assert checkpoint == {'status': 'CHECKPOINTED', 'sqlite': [0, 0, 0]}, checkpoint
        snap(name+'-checkpointed')
    for name, client in clients.items():
        client.close()
        code = client.process.poll()
        report['operations'].append({'worker': name, 'op': 'CLOSED', 'exit': code, 'monotonic_ns': time.monotonic_ns()})
        assert code == 0
        snap(name+'-closed')
    for name in clients:
        target = OUT/name/'evidence.sqlite'
        finalized_database(OUT/name/'service.sqlite', target, expected[name])
        observed = database_digest(target)
        assert observed == expected[name]
        report['operations'].append({'worker': name, 'op': 'BACKUP_MATCHED', 'digest': observed})
        snap(name+'-exported')
    report['result'] = 'ANOMALY_NOT_REPRODUCED_IN_ONE_BOUNDED_PROBE'
except Exception as error:
    report['errors'].append({'type': type(error).__name__, 'detail': str(error)})
    report['result'] = 'PROBE_FAILED'
finally:
    for client in clients.values():
        if client.process.poll() is None:
            client.close()
    drain()
    os.close(fd)
    (OUT/'RESULT.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    print(json.dumps({'result': report.get('result'), 'errors': report['errors'],
        'snapshots': len(report['snapshots']), 'filesystem_events': len(report['filesystem_events']),
        'path': str(OUT/'RESULT.json')}))
