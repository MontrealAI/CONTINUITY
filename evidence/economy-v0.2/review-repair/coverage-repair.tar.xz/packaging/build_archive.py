"""Seal all post-review attempts without overwriting the original experiment."""
from pathlib import Path
import hashlib
import io
import json
import lzma
import os
import tarfile

SOURCE = Path('/workspace/scratch/b1d5891eb025/economy-review-repair')
OUTPUT = Path('/workspace/scratch/b1d5891eb025/continuity-economy/evidence/economy-v0.2/review-repair/coverage-repair.tar.xz')
PACKAGING = Path(__file__).parent
assert not OUTPUT.exists()
payload = {
    path.relative_to(SOURCE).as_posix(): path
    for path in sorted(SOURCE.rglob('*'))
    if path.is_file() and '__pycache__' not in path.parts
    and path.relative_to(SOURCE).as_posix() != 'ci-positive/artifact.zip'
}
payload['packaging/build_archive.py'] = Path(__file__)
files = {}
for name, path in sorted(payload.items()):
    if path.is_symlink(): raise ValueError('Unexpected link: ' + name)
    raw = path.read_bytes()
    files[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
manifest = {
    'schema': 'continuity-economy/post-review-archive/v1',
    'source_commit': 'f9e56c7dd9627b322406e05c53b4f6537d434262',
    'files': files,
    'scope': {
        'en': 'All retained post-review counterexamples, source snapshots, focused controls, full regression, failed local replay, raw forensic copies, one bounded lifecycle probe, downloaded CI evidence, and one preregistered /tmp confirmation. Excludes only Python caches and the redundant original CI ZIP container; its digest and all extracted payload files are retained. No earlier failure is replaced.',
        'fr': 'Tous les contre-exemples après revue, instantanés source, contrôles ciblés, régression complète, reproduction locale échouée, copies forensiques brutes, contrôle borné du cycle de vie, preuves CI téléchargées et unique confirmation préenregistrée dans /tmp. Seuls les caches Python et le conteneur ZIP CI redondant sont exclus ; son empreinte et tous ses fichiers extraits sont conservés. Aucun échec antérieur n’est remplacé.',
    },
}
manifest_raw = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
(PACKAGING / 'MANIFEST.json').write_bytes(manifest_raw)
temporary = OUTPUT.with_suffix(OUTPUT.suffix + '.tmp')
assert not temporary.exists()
with lzma.open(temporary, 'wb', preset=6) as compressed:
    with tarfile.open(fileobj=compressed, mode='w|') as archive:
        def add(name, raw):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = 0
            info.uid = info.gid = 0
            archive.addfile(info, io.BytesIO(raw))
        add('MANIFEST.json', manifest_raw)
        for name, path in sorted(payload.items()):
            raw = path.read_bytes()
            if hashlib.sha256(raw).hexdigest() != files[name]['sha256']:
                raise ValueError('Evidence changed while packaging: ' + name)
            add(name, raw)
os.replace(temporary, OUTPUT)
raw = OUTPUT.read_bytes()
record = {
    'schema': 'continuity-economy/post-review-archive-build/v1',
    'archive': str(OUTPUT),
    'archive_bytes': len(raw),
    'archive_sha256': hashlib.sha256(raw).hexdigest(),
    'archive_git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
    'manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(),
    'payload_files': len(files),
    'regular_archive_members': len(files) + 1,
    'payload_bytes': sum(v['bytes'] for v in files.values()),
}
(PACKAGING / 'BUILD.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
