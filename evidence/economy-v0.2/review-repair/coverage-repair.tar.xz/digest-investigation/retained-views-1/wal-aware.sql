BEGIN TRANSACTION;
CREATE TABLE authorized_orders (
 order_id TEXT PRIMARY KEY, recipient TEXT NOT NULL, product TEXT NOT NULL, spec_sha256 TEXT NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity>0), deadline_tick INTEGER NOT NULL);
INSERT INTO "authorized_orders" VALUES('DL-100.L001.A1','RECIPIENT-A','DIGITAL_LABEL_JOB','0ce0c927329490b3403ca7f881b2ba9c2f865537d351067c1e6651e90744524d',500,500);
INSERT INTO "authorized_orders" VALUES('DL-100.L001.A2','RECIPIENT-A','DIGITAL_LABEL_JOB','6fe3808c6330fb2db3673521e652948924f8c555afc610b0e78873d9ef61edd9',500,500);
INSERT INTO "authorized_orders" VALUES('DL-100.L002.A1','RECIPIENT-A','DIGITAL_LABEL_JOB','01377191393ba6fb978606cb41357e485292a05e2a2a77e9aec4e97551235c20',500,500);
INSERT INTO "authorized_orders" VALUES('DL-100.L002.A2','RECIPIENT-A','DIGITAL_LABEL_JOB','892674062b767b5b5efcf2160673300047609d12caf93332f89fb62434d7e365',500,500);
INSERT INTO "authorized_orders" VALUES('DL-100.L003.A1','RECIPIENT-A','DIGITAL_LABEL_JOB','bfb63e9fd3ebc3624c3210f3dc0535c3e5fc92f467f85ad2964de6d02bb2c179',100,500);
INSERT INTO "authorized_orders" VALUES('DL-100.L003.A2','RECIPIENT-A','DIGITAL_LABEL_JOB','1ca1bd8223d623d8eafdb6fb8ae5f77fa02ecc2a51d36cc3631a512312fa13fd',100,500);
INSERT INTO "authorized_orders" VALUES('DL-200.L001.A1','RECIPIENT-B','DIGITAL_LABEL_JOB','7d552549bdaaab81595fb5c59fa92730f9f6dd0332cd6bde658538cdf406a63d',500,500);
INSERT INTO "authorized_orders" VALUES('DL-200.L001.A2','RECIPIENT-B','DIGITAL_LABEL_JOB','a8156981b369acbcdfa306fed3ae81d100cb5a3fe4c415f7da26d04296280649',500,500);
INSERT INTO "authorized_orders" VALUES('DL-200.L002.A1','RECIPIENT-B','DIGITAL_LABEL_JOB','b6b0008bfdf6661981a76f1ec8997aa4b6ea765b12b5e3176047f1ce11c073a4',300,500);
INSERT INTO "authorized_orders" VALUES('DL-200.L002.A2','RECIPIENT-B','DIGITAL_LABEL_JOB','7c3672b1ca6a0e8e1a1308df34f462f0c248d695ac265b2a11aaa87c1d738216',300,500);
CREATE TABLE history (
 sequence INTEGER PRIMARY KEY AUTOINCREMENT, operation TEXT NOT NULL, key TEXT, order_id TEXT, route TEXT,
 tick INTEGER NOT NULL, monotonic_ns INTEGER NOT NULL, detail TEXT NOT NULL);
INSERT INTO "history" VALUES(1,'INIT',NULL,NULL,NULL,0,40081481508006,'{"allowed_orders_sha256":"d4e6920f213679296013177dc55212fc29112f1a4b77950fa1d8ca8344479bd7","capacities":{"backup":1200,"primary":0},"window_end":800,"window_start":0}');
INSERT INTO "history" VALUES(2,'RESERVED','proposal-002.DL-100.L001.A1','DL-100.L001.A1','backup',11,40081643213291,'{"reservation":{"contract_sha256":"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1","created_tick":11,"expires_tick":31,"key":"proposal-002.DL-100.L001.A1","order_id":"DL-100.L001.A1","product":"DIGITAL_LABEL_JOB","quantity":500,"recipient":"RECIPIENT-A","request_sha256":"290f2fe20183c308c77e5abffc5ada41d061ae9647048ee91bbd6d1f8d52867e","route":"backup","run_id":"constructed-continuity.conventional.f189246caf","spec_sha256":"0ce0c927329490b3403ca7f881b2ba9c2f865537d351067c1e6651e90744524d","status":"RESERVED","updated_tick":11,"window_end":800,"window_start":0}}');
INSERT INTO "history" VALUES(3,'COMMITTED','proposal-002.DL-100.L001.A1','DL-100.L001.A1','backup',12,40081652224085,'{"reservation":{"contract_sha256":"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1","created_tick":11,"expires_tick":31,"key":"proposal-002.DL-100.L001.A1","order_id":"DL-100.L001.A1","product":"DIGITAL_LABEL_JOB","quantity":500,"recipient":"RECIPIENT-A","request_sha256":"290f2fe20183c308c77e5abffc5ada41d061ae9647048ee91bbd6d1f8d52867e","route":"backup","run_id":"constructed-continuity.conventional.f189246caf","spec_sha256":"0ce0c927329490b3403ca7f881b2ba9c2f865537d351067c1e6651e90744524d","status":"COMMITTED","updated_tick":12,"window_end":800,"window_start":0}}');
INSERT INTO "history" VALUES(4,'FULFILLED','proposal-002.DL-100.L001.A1','DL-100.L001.A1','backup',12,40081679317688,'{"reservation":{"contract_sha256":"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1","created_tick":11,"expires_tick":31,"key":"proposal-002.DL-100.L001.A1","order_id":"DL-100.L001.A1","product":"DIGITAL_LABEL_JOB","quantity":500,"recipient":"RECIPIENT-A","request_sha256":"290f2fe20183c308c77e5abffc5ada41d061ae9647048ee91bbd6d1f8d52867e","route":"backup","run_id":"constructed-continuity.conventional.f189246caf","spec_sha256":"0ce0c927329490b3403ca7f881b2ba9c2f865537d351067c1e6651e90744524d","status":"FULFILLED","updated_tick":12,"window_end":800,"window_start":0}}');
INSERT INTO "history" VALUES(5,'RESERVED','proposal-002.DL-100.L002.A1','DL-100.L002.A1','backup',19,40081838637151,'{"reservation":{"contract_sha256":"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1","created_tick":19,"expires_tick":39,"key":"proposal-002.DL-100.L002.A1","order_id":"DL-100.L002.A1","product":"DIGITAL_LABEL_JOB","quantity":500,"recipient":"RECIPIENT-A","request_sha256":"7c98ff3728e36c7f995d41fcd9e3255dd34c6493b7afd8af4378523a32920ced","route":"backup","run_id":"constructed-continuity.conventional.f189246caf","spec_sha256":"01377191393ba6fb978606cb41357e485292a05e2a2a77e9aec4e97551235c20","status":"RESERVED","updated_tick":19,"window_end":800,"window_start":0}}');
INSERT INTO "history" VALUES(6,'COMMITTED','proposal-002.DL-100.L002.A1','DL-100.L002.A1','backup',20,40081849708826,'{"reservation":{"contract_sha256":"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1","created_tick":19,"expires_tick":39,"key":"proposal-002.DL-100.L002.A1","order_id":"DL-100.L002.A1","product":"DIGITAL_LABEL_JOB","quantity":500,"recipient":"RECIPIENT-A","request_sha256":"7c98ff3728e36c7f995d41fcd9e3255dd34c6493b7afd8af4378523a32920ced","route":"backup","run_id":"constructed-continuity.conventional.f189246caf","spec_sha256":"01377191393ba6fb978606cb41357e485292a05e2a2a77e9aec4e97551235c20","status":"COMMITTED","updated_tick":20,"window_end":800,"window_start":0}}');
INSERT INTO "history" VALUES(7,'FULFILLED','proposal-002.DL-100.L002.A1','DL-100.L002.A1','backup',20,40081877051105,'{"reservation":{"contract_sha256":"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1","created_tick":19,"expires_tick":39,"key":"proposal-002.DL-100.L002.A1","order_id":"DL-100.L002.A1","product":"DIGITAL_LABEL_JOB","quantity":500,"recipient":"RECIPIENT-A","request_sha256":"7c98ff3728e36c7f995d41fcd9e3255dd34c6493b7afd8af4378523a32920ced","route":"backup","run_id":"constructed-continuity.conventional.f189246caf","spec_sha256":"01377191393ba6fb978606cb41357e485292a05e2a2a77e9aec4e97551235c20","status":"FULFILLED","updated_tick":20,"window_end":800,"window_start":0}}');
CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
INSERT INTO "metadata" VALUES('schema','"continuity-harness/service/v1"');
INSERT INTO "metadata" VALUES('run_id','"constructed-continuity.conventional.f189246caf"');
INSERT INTO "metadata" VALUES('contract_sha256','"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1"');
INSERT INTO "metadata" VALUES('init_sha256','"0316c17175009df7d346c98877c99b37b4bedc1bf94a8acaa6557a1ab88760e2"');
INSERT INTO "metadata" VALUES('last_tick','20');
INSERT INTO "metadata" VALUES('window_start','0');
INSERT INTO "metadata" VALUES('window_end','800');
INSERT INTO "metadata" VALUES('source_sha256','"1cdd477818bd945a1b6ec75f174d37e1e6e57af7807281de0d8818475a8b5e39"');
CREATE TABLE orders (
 order_id TEXT PRIMARY KEY, recipient TEXT NOT NULL, product TEXT NOT NULL, spec_sha256 TEXT NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity>0), fulfilled INTEGER NOT NULL DEFAULT 0,
 state TEXT NOT NULL, deadline_tick INTEGER NOT NULL, source_sequence INTEGER NOT NULL);
INSERT INTO "orders" VALUES('DL-100.L001.A1','RECIPIENT-A','DIGITAL_LABEL_JOB','feb4a7f3289b4b0e510a195e8e029e358471eca70357f490f2094d8e0e51e2b5',500,0,'ACTIVE',500,0);
INSERT INTO "orders" VALUES('CANCELLED-SNAPSHOT-GHOST','RECIPIENT-A','DIGITAL_LABEL_JOB','0ce0c927329490b3403ca7f881b2ba9c2f865537d351067c1e6651e90744524d',1,0,'ACTIVE',500,0);
CREATE TABLE receipts (
 key TEXT PRIMARY KEY REFERENCES reservations(key), order_id TEXT UNIQUE NOT NULL,
 payload TEXT NOT NULL, sha256 TEXT NOT NULL, completed_tick INTEGER NOT NULL, completed_monotonic_ns INTEGER NOT NULL);
INSERT INTO "receipts" VALUES('proposal-002.DL-100.L001.A1','DL-100.L001.A1','{"completed_monotonic_ns":40081679265349,"completed_tick":12,"contract_sha256":"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1","key":"proposal-002.DL-100.L001.A1","order_id":"DL-100.L001.A1","product":"DIGITAL_LABEL_JOB","quantity":500,"recipient":"RECIPIENT-A","route":"backup","run_id":"constructed-continuity.conventional.f189246caf","schema":"continuity-harness/artifact/v1","spec_sha256":"0ce0c927329490b3403ca7f881b2ba9c2f865537d351067c1e6651e90744524d","state":"COMPLETED"}','1bb6c8e331ae11eb88bc11cde372cd8fda0d5e7bd0a5381ae2aa336e104067bb',12,40081679265349);
INSERT INTO "receipts" VALUES('proposal-002.DL-100.L002.A1','DL-100.L002.A1','{"completed_monotonic_ns":40081877016652,"completed_tick":20,"contract_sha256":"f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1","key":"proposal-002.DL-100.L002.A1","order_id":"DL-100.L002.A1","product":"DIGITAL_LABEL_JOB","quantity":500,"recipient":"RECIPIENT-A","route":"backup","run_id":"constructed-continuity.conventional.f189246caf","schema":"continuity-harness/artifact/v1","spec_sha256":"01377191393ba6fb978606cb41357e485292a05e2a2a77e9aec4e97551235c20","state":"COMPLETED"}','76eec5c95430b457591e91fecfcd28fe9e8f84b6fb41b8f8e7531b2412f16f5a',20,40081877016652);
CREATE TABLE reservations (
 key TEXT PRIMARY KEY, run_id TEXT NOT NULL, contract_sha256 TEXT NOT NULL, order_id TEXT NOT NULL,
 recipient TEXT NOT NULL, product TEXT NOT NULL, spec_sha256 TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>0),
 route TEXT NOT NULL REFERENCES routes(route), window_start INTEGER NOT NULL, window_end INTEGER NOT NULL,
 expires_tick INTEGER NOT NULL, status TEXT NOT NULL CHECK(status IN ('RESERVED','COMMITTED','FULFILLED','RELEASED','EXPIRED')),
 request_sha256 TEXT NOT NULL, created_tick INTEGER NOT NULL, updated_tick INTEGER NOT NULL,
 CHECK(window_start<window_end));
INSERT INTO "reservations" VALUES('proposal-002.DL-100.L001.A1','constructed-continuity.conventional.f189246caf','f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1','DL-100.L001.A1','RECIPIENT-A','DIGITAL_LABEL_JOB','0ce0c927329490b3403ca7f881b2ba9c2f865537d351067c1e6651e90744524d',500,'backup',0,800,31,'FULFILLED','290f2fe20183c308c77e5abffc5ada41d061ae9647048ee91bbd6d1f8d52867e',11,12);
INSERT INTO "reservations" VALUES('proposal-002.DL-100.L002.A1','constructed-continuity.conventional.f189246caf','f2c5a3168b4521622520c77c6a7328ab2586c961efffabfb18b323a848561fe1','DL-100.L002.A1','RECIPIENT-A','DIGITAL_LABEL_JOB','01377191393ba6fb978606cb41357e485292a05e2a2a77e9aec4e97551235c20',500,'backup',0,800,39,'FULFILLED','7c98ff3728e36c7f995d41fcd9e3255dd34c6493b7afd8af4378523a32920ced',19,20);
CREATE TABLE routes (route TEXT PRIMARY KEY, capacity INTEGER NOT NULL CHECK(capacity>=0),
                                  available INTEGER NOT NULL CHECK(available IN (0,1)));
INSERT INTO "routes" VALUES('backup',1200,1);
INSERT INTO "routes" VALUES('primary',0,1);
CREATE UNIQUE INDEX one_live_obligation ON reservations(order_id)
 WHERE status IN ('RESERVED','COMMITTED','FULFILLED');
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('history',7);
COMMIT;
