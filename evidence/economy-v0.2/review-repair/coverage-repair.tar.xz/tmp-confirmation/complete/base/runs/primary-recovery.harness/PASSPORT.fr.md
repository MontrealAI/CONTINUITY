# CONTINUITÉ Ω — Économie de la continuité

**Expérience de produit numérique · version 0.2.0**

Préserver un engagement grâce à une solution de continuité viable et volontairement acceptée.

**Portée : processus locaux jetables et produit numérique spécifié. Les politiques, consentements, valeurs, financements et flux SMU synthétiques sont des hypothèses et observations du modèle. Ils n’établissent ni contrats réels, ni demande, paiements, ventes, biens imprimés, apparence rendue ou qualité d’impression.**

Ce passeport présente l’évaluation consignée. Une vérification fraîche doit inspecter l’autorité conservée, le résultat durable réel et les preuves du destinataire ; ce document ne constitue jamais son oracle.

<!-- structured-result-sha256: f9851762483f2ae761b47ac339e620f9cd29365e42f373f4e08926a36662f180 -->

## Trois affirmations distinctes

| Affirmation | État consigné |
| --- | --- |
| Travail numérique requis accepté dans les conditions figées | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Faisabilité du service selon le modèle synthétique défini | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Avantage de méthode face à des solutions compétentes | Non établi (`NOT_ESTABLISHED`) |
| Sûreté dans le modèle de défaillance éprouvé | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

## Champs d’évaluation distincts

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | Réussi (`PASSED`) |
| Verdict du composant | Réalisé (`COMPLETED`) |
| Stade de preuve | Exécution locale d’un produit numérique (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| État de l’affirmation évaluée | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

## Identité, autorité et versions

| Champ | Valeur consignée |
| --- | --- |
| État des preuves d’autorité · `authority_status` | Établi uniquement pour l’exercice synthétique (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Valeur commerciale réelle · `commercial_value` | Non établi (`NOT_ESTABLISHED`) |
| Identité du contrat · `contract_id` | DIGITAL-001 |
| SHA-256 du contrat conservé · `contract_sha256` | 189954752d4fa215405dfb4798a1a679a1adaf6ef8669434612a093c2b732e0f |
| Authenticité d’un client réel · `real_customer_authenticity` | Non établi (`NOT_ESTABLISHED`) |
| Empreinte externe de référence · `reference_sha256` | 6c7daea9be2b15c2aec00037cb0177570de9be2c205ba0483578f00af25dba93 |
| Identité de l’exécution · `run_id` | primary-recovery.harness.491f973465 |
| Schéma · `schema` | continuity-economy/verification/v1 |
| État d’achèvement de la vérification · `verification_status` | Vérification complète (`COMPLETE`) |
| Version du vérificateur · `verifier_version` | 0.2.0 |

## Exécution et acceptation par obligation

Les quantités décrivent le stade consigné. Les tentatives refusées et corrigées restent distinctes. Une unité produite ou reçue n’est pas automatiquement acceptée. Les mesures absentes ne sont pas présentées comme nulles.

| Obligation | Destinataire | Révision | Requis | Produit | Reçu | Refusé | Accepté selon le contrat | Résultat |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 1100 | 1100 | 0 | 1100 | Réalisé (`COMPLETED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 800 | 800 | 0 | 800 | Réalisé (`COMPLETED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Annulé (`CANCELLED`) |

### Obligation `DL-100`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 1100 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 3 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-100 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 1100 |
| Tentatives de production durables · `production_attempts` | 3 |
| Quantité requise · `quantity` | 1100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 1100 |
| Destinataire · `recipient` | RECIPIENT-A |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 1100 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 1100 |
| Révision · `revision` | 2 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 1100 |

### Obligation `DL-200`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 800 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 2 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-200 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 800 |
| Tentatives de production durables · `production_attempts` | 2 |
| Quantité requise · `quantity` | 800 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 800 |
| Destinataire · `recipient` | RECIPIENT-B |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 800 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 800 |
| Révision · `revision` | 1 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 800 |

### Obligation `DL-300`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-300 |
| Résultat · `outcome` | Annulé (`CANCELLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-C |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 0 |
| Révision · `revision` | 1 |
| État consigné · `status` | Annulé (`CANCELLED`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

## Propositions, décisions modélisées et solutions

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

### Solution `proposal-001`

| Champ | Valeur consignée |
| --- | --- |
| Références d’acceptation · `acceptance_ids[0]` | proposal-001.DL-100.L001.A1.D |
| Références d’acceptation · `acceptance_ids[1]` | proposal-001.DL-100.L002.A1.D |
| Références d’acceptation · `acceptance_ids[2]` | proposal-001.DL-100.L003.A1.D |
| Références d’acceptation · `acceptance_ids[3]` | proposal-001.DL-200.L001.A1.D |
| Références d’acceptation · `acceptance_ids[4]` | proposal-001.DL-200.L002.A1.D |
| Instant d’acceptation de l’accord · `accepted_tick` | 3 |
| Identité de l’accord · `agreement_id` | proposal-001 |
| Instant d’annulation · `cancelled_tick` | Non consigné |
| Coût de correction engagé (unités mineures SMU synthétiques) · `correction_cost_minor` | 0 |
| Faisabilité modélisée au moment de l’accord · `ex_ante_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Coût engagé (unités mineures SMU synthétiques) · `incurred_cost_minor` | 2200 |
| Valeur d’équilibre de l’acheteur (unités mineures SMU synthétiques) · `independent_terms.break_even_value_minor` | 6400 |
| Plafond acheteur à la borne de valeur inférieure (unités mineures SMU synthétiques) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Plafond acheteur à la borne de valeur supérieure (unités mineures SMU synthétiques) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Unité de compte synthétique · `independent_terms.currency` | SMU |
| Prix acheteur minimal réalisable (unités mineures SMU synthétiques) · `independent_terms.minimum_buyer_price_minor` | 4400 |
| Rémunération minimale du coordonnateur (unités mineures SMU synthétiques) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Coût de production initiale (unités mineures SMU synthétiques) · `independent_terms.providers[0].base_cost_minor` | 2000 |
| Profit modélisé après correction maximale spécifiée (unités mineures SMU synthétiques) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Exposition maximale aux coûts impayés (unités mineures SMU synthétiques) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 4000 |
| Paiement minimal au fournisseur (unités mineures SMU synthétiques) · `independent_terms.providers[0].minimum_payment_minor` | 4100 |
| Profit requis de participation (unités mineures SMU synthétiques) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Identité du participant · `independent_terms.providers[0].party_id` | PRIMARY |
| Paiement promis au fournisseur (unités mineures SMU synthétiques) · `independent_terms.providers[0].promised_payment_minor` | 4100 |
| Coût maximal de correction (unités mineures SMU synthétiques) · `independent_terms.providers[0].rework_cost_minor` | 2000 |
| Unités · `independent_terms.providers[0].units` | 1900 |
| Réserve de correction (unités mineures SMU synthétiques) · `independent_terms.rework_budget_minor` | 2000 |
| Portée de l’évaluation · `independent_terms.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Nature de la solution · `kind` | Accord d’échange modélisé (`TRADE`) |
| Code stable · `participant_decisions[0].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[0].party_id` | BUYER |
| Rôle · `participant_decisions[0].role` | buyer |
| Verdict du composant · `participant_decisions[0].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[1].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[1].party_id` | PRIMARY |
| Rôle · `participant_decisions[1].role` | provider |
| Verdict du composant · `participant_decisions[1].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[2].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[2].party_id` | COORDINATOR |
| Rôle · `participant_decisions[2].role` | coordinator |
| Verdict du composant · `participant_decisions[2].verdict` | Accepté (`ACCEPTED`) |
| Paiements modélisés (unités mineures SMU synthétiques) · `payments_minor` | 4400 |
| Identité de la proposition · `proposal_id` | proposal-001 |
| Premier ordinal inclus · `proposed_terms.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[0].last_unit` | 500 |
| Identité du lot fixe · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[0].pay_minor` | 4100 |
| Identité du fournisseur · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[1].first_unit` | 501 |
| Dernier ordinal inclus · `proposed_terms.allocations[1].last_unit` | 1000 |
| Identité du lot fixe · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[2].first_unit` | 1001 |
| Dernier ordinal inclus · `proposed_terms.allocations[2].last_unit` | 1100 |
| Identité du lot fixe · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Identité de l’obligation · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[3].last_unit` | 500 |
| Identité du lot fixe · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Identité de l’obligation · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[3].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[4].first_unit` | 501 |
| Dernier ordinal inclus · `proposed_terms.allocations[4].last_unit` | 800 |
| Identité du lot fixe · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Identité de l’obligation · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[4].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `proposed_terms.buyer_price_minor` | 4400 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `proposed_terms.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `proposed_terms.contract_sha256` | 189954752d4fa215405dfb4798a1a679a1adaf6ef8669434612a093c2b732e0f |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `proposed_terms.coordinator_fee_minor` | 300 |
| Instant exclusif d’expiration · `proposed_terms.expires_tick` | 500 |
| Révision des politiques · `proposed_terms.policy_revision` | 1 |
| Identité de la proposition · `proposed_terms.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `proposed_terms.rework_budget_minor` | 2000 |
| Schéma · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Faisabilité modélisée après exécution · `realized_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Instant de règlement modélisé · `settled_tick` | 30 |
| État consigné · `status` | Réglé dans le registre synthétique (`SETTLED`) |

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.


## Transferts, coûts, responsabilités et options externes modélisés

Modèle uniquement : les montants sont des unités mineures synthétiques exactes ; 100 unités mineures valent 1 SMU fictive. Les valeurs sont affichées sans changement d’échelle. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

| Champ | Valeur consignée |
| --- | --- |
| Total des transferts acheteur (unités mineures SMU synthétiques) · `accounting.buyer_total_paid_minor` | 4400 |
| Borne supérieure · `accounting.buyer_utility_interval_minor.maximum` | 25600 |
| Borne inférieure · `accounting.buyer_utility_interval_minor.minimum` | 25600 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[0].final_balance_minor` | 25600 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Seuil de participation modélisé couvert · `accounting.campaign[0].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[0].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[0].party_id` | BUYER |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[0].purchase_payments_minor` | 4400 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[0].realized_profit_minor` | Non consigné |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[0].revenue_minor` | 0 |
| Rôle · `accounting.campaign[0].role` | buyer |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[1].final_balance_minor` | 10100 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[1].incurred_cost_minor` | 200 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Seuil de participation modélisé couvert · `accounting.campaign[1].participation_covered` | Oui |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[1].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[1].party_id` | COORDINATOR |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[1].realized_profit_minor` | 100 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[1].revenue_minor` | 300 |
| Rôle · `accounting.campaign[1].role` | coordinator |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Seuil de participation modélisé couvert · `accounting.campaign[2].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[2].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[2].realized_profit_minor` | Non consigné |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[2].revenue_minor` | 0 |
| Rôle · `accounting.campaign[2].role` | technical_sponsor |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[3].final_balance_minor` | 42100 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[3].incurred_cost_minor` | 2000 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[3].participation_covered` | Oui |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[3].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[3].party_id` | PRIMARY |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[3].realized_profit_minor` | 2100 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[3].revenue_minor` | 4100 |
| Rôle · `accounting.campaign[3].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[4].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[4].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[4].party_id` | BACKUP |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[4].revenue_minor` | 0 |
| Rôle · `accounting.campaign[4].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[5].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[5].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[5].party_id` | COMPAT-A |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[5].revenue_minor` | 0 |
| Rôle · `accounting.campaign[5].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Solde modélisé final (unités mineures SMU synthétiques) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Fonds encore retenus (unités mineures SMU synthétiques) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Coût engagé (unités mineures SMU synthétiques) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Solde modélisé initial (unités mineures SMU synthétiques) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[6].participation_covered` | Non consigné |
| Seuil de participation applicable (unités mineures SMU synthétiques) · `accounting.campaign[6].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[6].party_id` | COMPAT-B |
| Transferts d’achat (unités mineures SMU synthétiques) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (unités mineures SMU synthétiques) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Encaissements modélisés (unités mineures SMU synthétiques) · `accounting.campaign[6].revenue_minor` | 0 |
| Rôle · `accounting.campaign[6].role` | provider |
| Retraits vers le compte extérieur (unités mineures SMU synthétiques) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Unité de compte synthétique · `accounting.currency` | SMU |
| Total final du registre (unités mineures SMU synthétiques) · `accounting.final_total_minor` | 260000 |
| Total initial du registre (unités mineures SMU synthétiques) · `accounting.initial_total_minor` | 260000 |
| Contrats, paiements ou demande réels · `accounting.real_contracts_payments_or_demand` | Non établi (`NOT_ESTABLISHED`) |
| Faisabilité modélisée réalisée pour l’acheteur · `accounting.realized_buyer` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Portée de l’évaluation · `accounting.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Tous les coûts de correction (unités mineures SMU synthétiques) · `accounting.total_correction_cost_minor` | 0 |
| Tous les coûts engagés de campagne (unités mineures SMU synthétiques) · `accounting.total_incurred_cost_minor` | 2200 |
| Tous les transferts de règlement modélisés (unités mineures SMU synthétiques) · `accounting.total_transfers_minor` | 4400 |
| Transaction modélisée réglée · `accounting.trade_settled` | Oui |
| Obligations acceptées · `totals.accepted_obligations` | 2 |
| Quantité acceptée selon le contrat · `totals.accepted_quantity` | 1900 |
| Tentatives de livraison · `totals.delivery_attempts` | 5 |
| Unités acceptées en double · `totals.duplicate_acceptances` | 0 |
| Quantité tardive · `totals.late_quantity` | 0 |
| Quantité manquante · `totals.missing_quantity` | 0 |
| Quantité produite · `totals.produced_quantity` | 1900 |
| Tentatives de production durables · `totals.production_attempts` | 5 |
| Quantité reçue · `totals.received_quantity` | 1900 |
| Unités acceptées par le composant destinataire · `totals.recipient_accepted_quantity` | 1900 |
| Quantité refusée · `totals.rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `totals.rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `totals.rejection_count` | 0 |
| Obligations actives requises · `totals.required_obligations` | 2 |
| Quantité requise · `totals.required_quantity` | 1900 |
| Unités sémantiquement correctes observées à temps · `totals.timely_semantic_quantity` | 1900 |
| Engagements non sûrs ou non autorisés · `totals.unsafe_or_unsupported_commitments` | 0 |

## Ressources mesurées et lacunes de comptabilisation

Les ressources de processus mesurées et les montants synthétiques configurés ont des significations différentes. Les efforts de préparation, d’intégration, d’adaptation, de vérification ou d’intervention non consignés restent inconnus. Les catégories absentes ne permettent aucune conclusion de coût complet ou de méthode moins coûteuse.

| Champ | Valeur consignée |
| --- | --- |
| Lacunes de comptabilisation · `accounting_gaps[0]` | Le travail de préparation n’a pas été mesuré (`PREPARATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[1]` | Le travail d’intégration n’a pas été mesuré (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[2]` | Le travail d’adaptation n’a pas été mesuré (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[3]` | Le travail humain de vérification n’a pas été mesuré (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[4]` | Les tarifs monétaires n’ont pas été mesurés (`MONETARY_RATES_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Travail d’adaptation (secondes ; inconnu si absent) · `resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `resources.authority_storage_bytes_before_seal` | 30076 |
| Redémarrages du candidat · `resources.candidate_restarts` | 0 |
| Processus enfants lancés · `resources.child_processes` | 8 |
| Processeur système du contrôleur (ns) · `resources.controller_cpu_system_ns` | 19696000 |
| Processeur utilisateur du contrôleur (ns) · `resources.controller_cpu_user_ns` | 142562999 |
| Processeur système (ns) · `resources.cpu_system_ns` | 112427999 |
| Processeur utilisateur (ns) · `resources.cpu_user_ns` | 542315000 |
| Interventions humaines · `resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `resources.requests` | 30 |
| Nouvelles tentatives · `resources.retries` | 0 |
| Requêtes internes aux services · `resources.service_requests` | 158 |
| Stockage consigné (octets) · `resources.storage_bytes` | 8776696 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `resources.wall_ns` | 961780174 |
| Redémarrages des services · `resources.worker_restarts` | 0 |
| Temps processeur (ns) · `verification_resources.cpu_ns` | 199389543 |
| Fichiers de preuve examinés · `verification_resources.evidence_files_read` | 22 |
| Durée écoulée (ns) · `verification_resources.wall_ns` | 199410031 |

## Échecs et contre-exemples observés

Aucune entrée d’échec n’a été consignée dans cette évaluation. Il s’agit de preuves bornées, non d’une démonstration générale.

## Preuves absentes et affirmations non établies

Aucune entrée non résolue supplémentaire n’a été consignée. Les limites de portée et de coûts inconnus restent applicables.

## Références des preuves et intégrité des octets

Les empreintes identifient les octets. Elles n’authentifient pas les instructions réelles d’un client, n’établissent pas l’exhaustivité des sources et ne remplacent pas une empreinte de référence conservée séparément.

| Champ | Valeur consignée |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json` | 7ed6fb9ae68a4af34ee396794a3e8859fd31ca04d937f4e458a08ef4dcd29d02 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L002.A1.json` | fe19e50ca57de94f7f0476a29decf2b7e8480e6219ef713c7ce232ba875b217f |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L003.A1.json` | 4995a3b3fc2d2719eaf27314273a450c85e64fec4ecd1eb277d9a3d5f35dead8 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-200.L001.A1.json` | 8ce995d21c77849effa362bb10c84fbdc763a51e09f8fde71e217cd16752ecac |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-200.L002.A1.json` | 4da17389739cfef11354d4b05a93d15388d220140fe7e20bc6e69337e5cc3cce |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 8e6df929ecb72f26c118c9c506d63aeb5e4ff29c37233aefa70017e0400a395c |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | 2186469eb6466195f1fcabfd1a09bf9029459d1226653dc032f011442be5b1b2 |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | d4bd8c04ed8adc42e33e264ba35638d9131c4c6e8104584fc12b3518827a5b0e |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | 49d1a85b5d51ff3219ce6b38d8de0561496408a4c3fa79bdd43ab2c550cb710e |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L001.A1.D.json` | 5445d40e4140ba39e7a43abbb71e95b8089dccaf72533b1e9c6ebee8b137c4ac |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L002.A1.D.json` | bd5ff9d1eb17cea8f7e2afc816af5492d9458acc1c7fabe0b342a8ffc4962fd1 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L003.A1.D.json` | c81609a0b4b80ebe7aa96a3c85269da755f8255354a481046775cc92c1a5dc7a |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L001.A1.D.json` | 9426c5aa5e8c79122f099dda388d6f1674aebc7c201c92153e03c889171d50c0 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L002.A1.D.json` | 04aeb1a4274ef99a13b39ac2fb1e1631379e9de9c2052023b1f0b7db7758e3cb |
| `evidence_sha256.evidence/participants.sqlite` | 5d1c89de53cd714663dae1dbbdc686eb97e2669396c590a9442949ab2f6c4252 |
| `evidence_sha256.evidence/producer.sqlite` | 07f784e3ebb0dc836528898c22aa8256cd707e2c4e7817dc061c89c2142233e5 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L001.A1.json` | 5445d40e4140ba39e7a43abbb71e95b8089dccaf72533b1e9c6ebee8b137c4ac |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L002.A1.json` | bd5ff9d1eb17cea8f7e2afc816af5492d9458acc1c7fabe0b342a8ffc4962fd1 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L003.A1.json` | c81609a0b4b80ebe7aa96a3c85269da755f8255354a481046775cc92c1a5dc7a |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L001.A1.json` | 9426c5aa5e8c79122f099dda388d6f1674aebc7c201c92153e03c889171d50c0 |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L002.A1.json` | 04aeb1a4274ef99a13b39ac2fb1e1631379e9de9c2052023b1f0b7db7758e3cb |
| `evidence_sha256.evidence/receiver.sqlite` | 059ae364dbbba88433eba19057cbf8c938f3709baf83c06c1bcd6260af80e7a5 |
| SHA-256 du résultat structuré · `structured_result_sha256` | f9851762483f2ae761b47ac339e620f9cd29365e42f373f4e08926a36662f180 |

## Exécution, pannes, commandes et provenance consignées

Les identifiants stables, commandes exactes, chemins et diagnostics machine originaux sont conservés littéralement. Ce sont des données, non des preuves d’acceptation supplémentaires. La confiance dans les sources et l’hôte est explicitée dans l’architecture et le modèle de menace.

| Champ | Valeur consignée |
| --- | --- |
| `authority_dir` | /tmp/continuity-economy-post-review-b1d5891eb025-001/base/authorities/primary-recovery.harness |
| Cohorte d’expérience · `cohort` | base |
| `contract.allow_split` | Oui |
| `contract.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies` | Aucune entrée |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Cohorte d’expérience · `contract.cohort` | base |
| Identité du contrat · `contract.contract_id` | DIGITAL-001 |
| `contract.cutoff_sequence` | 5 |
| Échéance logique · `contract.deadline_tick` | 500 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-001 |
| Programme de pannes préenregistré · `contract.fault_schedule` | Aucune entrée |
| Identité du cas préenregistré · `contract.fixture_id` | primary-recovery |
| `contract.lease_ticks` | 20 |
| `contract.lot_size` | 500 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Échéance logique · `contract.obligations[0].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[0].obligation_id` | DL-100 |
| Quantité requise · `contract.obligations[0].quantity` | 1100 |
| Destinataire · `contract.obligations[0].recipient` | RECIPIENT-A |
| Révision · `contract.obligations[0].revision` | 2 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[0].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[0].spec.lot` | BATCH-20261106 |
| `contract.obligations[0].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[0].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[0].spec.serial_prefix` | DL-100- |
| `contract.obligations[0].spec.sku` | KIT-DL-100 |
| État consigné · `contract.obligations[0].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[1].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[1].obligation_id` | DL-200 |
| Quantité requise · `contract.obligations[1].quantity` | 800 |
| Destinataire · `contract.obligations[1].recipient` | RECIPIENT-B |
| Révision · `contract.obligations[1].revision` | 1 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[1].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[1].spec.lot` | BATCH-20261106 |
| `contract.obligations[1].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[1].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[1].spec.serial_prefix` | DL-200- |
| `contract.obligations[1].spec.sku` | KIT-DL-200 |
| État consigné · `contract.obligations[1].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[2].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[2].obligation_id` | DL-300 |
| Quantité requise · `contract.obligations[2].quantity` | 100 |
| Destinataire · `contract.obligations[2].recipient` | RECIPIENT-C |
| Révision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[2].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[2].spec.lot` | BATCH-20261106 |
| `contract.obligations[2].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[2].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[2].spec.serial_prefix` | DL-300- |
| `contract.obligations[2].spec.sku` | KIT-DL-300 |
| État consigné · `contract.obligations[2].status` | Annulé (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 800 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | PRIMARY-HOST |
| `contract.providers[0].permissions.disclosure` | Oui |
| `contract.providers[0].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[0].provider_id` | PRIMARY |
| Rôle · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 2400 |
| `contract.providers[0].windows[0].end` | 800 |
| `contract.providers[0].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[0].windows[0].window_id` | W0 |
| `contract.providers[1].dependency` | BACKUP-HOST |
| `contract.providers[1].permissions.disclosure` | Oui |
| `contract.providers[1].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[1].provider_id` | BACKUP |
| Rôle · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 2400 |
| `contract.providers[1].windows[0].end` | 800 |
| `contract.providers[1].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[1].windows[0].window_id` | W0 |
| `contract.providers[2].dependency` | COMPAT-A-HOST |
| `contract.providers[2].permissions.disclosure` | Oui |
| `contract.providers[2].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[2].provider_id` | COMPAT-A |
| Rôle · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 1200 |
| `contract.providers[2].windows[0].end` | 800 |
| `contract.providers[2].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[2].windows[0].window_id` | W0 |
| `contract.providers[3].dependency` | COMPAT-B-HOST |
| `contract.providers[3].permissions.disclosure` | Oui |
| `contract.providers[3].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[3].provider_id` | COMPAT-B |
| Rôle · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 1100 |
| `contract.providers[3].windows[0].end` | 800 |
| `contract.providers[3].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[3].windows[0].window_id` | W0 |
| Révision · `contract.revision` | 1 |
| `contract.revocations` | Aucune entrée |
| Identité de l’exécution · `contract.run_id` | primary-recovery.harness.491f973465 |
| Schéma · `contract.schema` | continuity-economy/contract/v1 |
| Graine consignée · `contract.seed` | 701 |
| `contract.source_complete` | Oui |
| Échéance logique · `contract.source_events[0].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[0].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[0].obligation.quantity` | 1000 |
| Destinataire · `contract.source_events[0].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Obsolete instruction. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Instruction périmée. |
| `contract.source_events[0].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[0].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[0].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[0].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[0].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[0].obligation_id` | DL-100 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Échéance logique · `contract.source_events[1].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[1].obligation.obligation_id` | DL-200 |
| Quantité requise · `contract.source_events[1].obligation.quantity` | 800 |
| Destinataire · `contract.source_events[1].obligation.recipient` | RECIPIENT-B |
| Révision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[1].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[1].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[1].obligation.spec.serial_prefix` | DL-200- |
| `contract.source_events[1].obligation.spec.sku` | KIT-DL-200 |
| État consigné · `contract.source_events[1].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[1].obligation_id` | DL-200 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Échéance logique · `contract.source_events[2].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[2].obligation.obligation_id` | DL-300 |
| Quantité requise · `contract.source_events[2].obligation.quantity` | 100 |
| Destinataire · `contract.source_events[2].obligation.recipient` | RECIPIENT-C |
| Révision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[2].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[2].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[2].obligation.spec.serial_prefix` | DL-300- |
| `contract.source_events[2].obligation.spec.sku` | KIT-DL-300 |
| État consigné · `contract.source_events[2].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[2].obligation_id` | DL-300 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Échéance logique · `contract.source_events[3].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[3].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[3].obligation.quantity` | 1100 |
| Destinataire · `contract.source_events[3].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[3].obligation.revision` | 2 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[3].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[3].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[3].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[3].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[3].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[3].obligation_id` | DL-100 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | AMEND |
| Identité de l’obligation · `contract.source_events[4].obligation_id` | DL-300 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | CANCEL |
| `contract.source_id` | AUTHORED-DIGITAL-EVENTS |
| Empreintes des octets sources · `contract.source_sha256` | 8d6a71fd1c26021120a5283bd7cf3eb7812b5c34ae6a4da3eec94dceaf8f7b81 |
| Horloge de départ (ns) · `contract.start_ns` | 40926009013112 |
| Échéance en temps écoulé (ms) · `contract.wall_deadline_ms` | 60000 |
| `controller.capacity_databases[0].path` | evidence/capacity/PRIMARY.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[0].provider_id` | PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Identité de la fenêtre de capacité · `controller.capacity_databases[0].window_id` | W0 |
| `controller.capacity_databases[1].path` | evidence/capacity/BACKUP.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[1].provider_id` | BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[1].window_id` | W0 |
| `controller.capacity_databases[2].path` | evidence/capacity/COMPAT-A.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[2].provider_id` | COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[2].window_id` | W0 |
| `controller.capacity_databases[3].path` | evidence/capacity/COMPAT-B.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[3].provider_id` | COMPAT-B |
| `controller.capacity_databases[3].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[3].window_id` | W0 |
| `controller.clock_tick` | 30 |
| Cohorte d’expérience · `controller.cohort` | base |
| SHA-256 du contrat conservé · `controller.contract_sha256` | 189954752d4fa215405dfb4798a1a679a1adaf6ef8669434612a093c2b732e0f |
| `controller.db_snapshots.evidence/capacity/BACKUP.W0.sqlite` | fb95fd87c2631198ced6d86871bcb165c7fbb813f4a97d4bc04255b4d1a61848 |
| `controller.db_snapshots.evidence/capacity/COMPAT-A.W0.sqlite` | 1bf3c22a07649cea324ebdcfead5873eaf6d8eed263a100b4f07191cc6bf57d0 |
| `controller.db_snapshots.evidence/capacity/COMPAT-B.W0.sqlite` | ea84f72c17065a4f832e198420f4e0d3dac5ce5e58fd52c7fea48d40b23b8f72 |
| `controller.db_snapshots.evidence/capacity/PRIMARY.W0.sqlite` | 694458f54867c9b5ac7c86e0587d50cb670299dcd143495bfcd828b682dfcab4 |
| `controller.db_snapshots.evidence/participants.sqlite` | 1d097c3383c93fb50771713b86d23fef6f1cbe4b420de819ff46bc409fccf268 |
| `controller.db_snapshots.evidence/producer.sqlite` | 23f9ddff4be20a45af5ba45cd746ad85b29ff65b4c45285faad3463bd6a6edbe |
| `controller.db_snapshots.evidence/receiver.sqlite` | ad01304876608650351e6d5928e9321c3d8c1e2ca00e7b02a6a22ac9b7836eb2 |
| `controller.errors` | Aucune entrée |
| `controller.events[0].detail.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| Empreinte externe de référence · `controller.events[0].detail.reference_sha256` | 6c7daea9be2b15c2aec00037cb0177570de9be2c205ba0483578f00af25dba93 |
| Graine consignée · `controller.events[0].detail.seed` | 701 |
| Événement consigné · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 40926029872408 |
| Instant logique · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 19 |
| `controller.events[1].detail.restart` | Non |
| `controller.events[1].detail.service` | participants |
| Événement consigné · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 40926078252861 |
| Instant logique · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 20 |
| `controller.events[2].detail.restart` | Non |
| `controller.events[2].detail.service` | producer |
| Événement consigné · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 40926121947309 |
| Instant logique · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 21 |
| `controller.events[3].detail.restart` | Non |
| `controller.events[3].detail.service` | receiver |
| Événement consigné · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 40926160840591 |
| Instant logique · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 22 |
| Identité du fournisseur · `controller.events[4].detail.provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[4].detail.window_id` | W0 |
| Événement consigné · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 40926200558008 |
| Instant logique · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 23 |
| Identité du fournisseur · `controller.events[5].detail.provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[5].detail.window_id` | W0 |
| Événement consigné · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 40926243058660 |
| Instant logique · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 24 |
| Identité du fournisseur · `controller.events[6].detail.provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[6].detail.window_id` | W0 |
| Événement consigné · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 40926283971744 |
| Instant logique · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 25 |
| Identité du fournisseur · `controller.events[7].detail.provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[7].detail.window_id` | W0 |
| Événement consigné · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 40926322456649 |
| Instant logique · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.isolation.applied` | Oui |
| `controller.events[8].detail.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.events[8].detail.isolation.probe.authority_open_denied` | Oui |
| `controller.events[8].detail.isolation.probe.network_denied` | Oui |
| `controller.events[8].detail.isolation.probe.process_inspection_denied` | Oui |
| `controller.events[8].detail.isolation.probe.spawn_denied` | Oui |
| `controller.events[8].detail.isolation.probe.workspace_open_denied` | Oui |
| `controller.events[8].detail.pid` | 26 |
| `controller.events[8].detail.restart` | Non |
| Événement consigné · `controller.events[8].event` | CANDIDATE_STARTED |
| `controller.events[8].monotonic_ns` | 40926366338600 |
| Instant logique · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.args` | Aucune entrée |
| `controller.events[9].detail.op` | status |
| Événement consigné · `controller.events[9].event` | BROKER_REQUEST |
| `controller.events[9].monotonic_ns` | 40926368324721 |
| Instant logique · `controller.events[9].tick` | 1 |
| `controller.events[10].detail.measurement_kind` | Mesure déclarée par le candidat (`CANDIDATE_REPORTED`) |
| `controller.events[10].detail.pid` | 26 |
| `controller.events[10].detail.report.assignment_domain` | 1024 |
| `controller.events[10].detail.report.candidate_elapsed_ns` | 4693242 |
| `controller.events[10].detail.report.capacity_prunes` | 0 |
| `controller.events[10].detail.report.complete_assignments_observed` | 52 |
| `controller.events[10].detail.report.exhaustive_within_declared_domain` | Oui |
| `controller.events[10].detail.report.feasible_assignments` | 52 |
| `controller.events[10].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Procédure candidate · `controller.events[10].detail.report.method` | harness |
| `controller.events[10].detail.report.partial_nodes_observed` | 217 |
| `controller.events[10].detail.report.participant_prunes` | 0 |
| `controller.events[10].detail.report.price_prunes` | 111 |
| Événement consigné · `controller.events[10].event` | CANDIDATE_PLANNING |
| `controller.events[10].monotonic_ns` | 40926377406364 |
| Instant logique · `controller.events[10].tick` | 1 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[0].last_unit` | 500 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[0].pay_minor` | 4100 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[0].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[1].first_unit` | 501 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[1].last_unit` | 1000 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[1].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[2].first_unit` | 1001 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[2].last_unit` | 1100 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[2].lot_id` | DL-100.L003 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[2].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[2].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[3].last_unit` | 500 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[3].lot_id` | DL-200.L001 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[3].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[3].window_id` | W0 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[4].first_unit` | 501 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[4].last_unit` | 800 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[4].lot_id` | DL-200.L002 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[4].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[4].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[4].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.buyer_price_minor` | 4400 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `controller.events[11].detail.args.proposal.contract_sha256` | 189954752d4fa215405dfb4798a1a679a1adaf6ef8669434612a093c2b732e0f |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.coordinator_fee_minor` | 300 |
| Instant exclusif d’expiration · `controller.events[11].detail.args.proposal.expires_tick` | 500 |
| Révision des politiques · `controller.events[11].detail.args.proposal.policy_revision` | 1 |
| Identité de la proposition · `controller.events[11].detail.args.proposal.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.rework_budget_minor` | 2000 |
| Schéma · `controller.events[11].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[11].detail.op` | propose |
| Événement consigné · `controller.events[11].event` | BROKER_REQUEST |
| `controller.events[11].monotonic_ns` | 40926378039331 |
| Instant logique · `controller.events[11].tick` | 2 |
| Identité de la proposition · `controller.events[12].detail.args.proposal_id` | proposal-001 |
| `controller.events[12].detail.op` | decide |
| Événement consigné · `controller.events[12].event` | BROKER_REQUEST |
| `controller.events[12].monotonic_ns` | 40926382486401 |
| Instant logique · `controller.events[12].tick` | 3 |
| `controller.events[13].detail.args` | Aucune entrée |
| `controller.events[13].detail.op` | status |
| Événement consigné · `controller.events[13].event` | BROKER_REQUEST |
| `controller.events[13].monotonic_ns` | 40926386731275 |
| Instant logique · `controller.events[13].tick` | 4 |
| Identité du fournisseur · `controller.events[14].detail.args.provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[14].detail.args.window_id` | W0 |
| `controller.events[14].detail.op` | restore |
| Événement consigné · `controller.events[14].event` | BROKER_REQUEST |
| `controller.events[14].monotonic_ns` | 40926392022441 |
| Instant logique · `controller.events[14].tick` | 5 |
| Code stable · `controller.events[15].detail.discrepancies[0].code` | RESURRECTED_CANCELLATION |
| `controller.events[15].detail.discrepancies[0].order_id` | CANCELLED-SNAPSHOT-GHOST |
| Code stable · `controller.events[15].detail.discrepancies[1].code` | STALE_ORDER |
| `controller.events[15].detail.discrepancies[1].order_id` | DL-100.L001.A1 |
| Code stable · `controller.events[15].detail.discrepancies[2].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[2].order_id` | DL-100.L001.A2 |
| Code stable · `controller.events[15].detail.discrepancies[3].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[3].order_id` | DL-100.L002.A1 |
| Code stable · `controller.events[15].detail.discrepancies[4].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[4].order_id` | DL-100.L002.A2 |
| Code stable · `controller.events[15].detail.discrepancies[5].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[5].order_id` | DL-100.L003.A1 |
| Code stable · `controller.events[15].detail.discrepancies[6].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[6].order_id` | DL-100.L003.A2 |
| Code stable · `controller.events[15].detail.discrepancies[7].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[7].order_id` | DL-200.L001.A1 |
| Code stable · `controller.events[15].detail.discrepancies[8].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[8].order_id` | DL-200.L001.A2 |
| Code stable · `controller.events[15].detail.discrepancies[9].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[9].order_id` | DL-200.L002.A1 |
| Code stable · `controller.events[15].detail.discrepancies[10].code` | MISSING_ORDER |
| `controller.events[15].detail.discrepancies[10].order_id` | DL-200.L002.A2 |
| Identité du fournisseur · `controller.events[15].detail.provider_id` | PRIMARY |
| `controller.events[15].detail.recovery_ns` | 2675974 |
| Identité de la fenêtre de capacité · `controller.events[15].detail.window_id` | W0 |
| Événement consigné · `controller.events[15].event` | PRIMARY_RESTORED |
| `controller.events[15].monotonic_ns` | 40926395466926 |
| Instant logique · `controller.events[15].tick` | 5 |
| Identité de l’accord · `controller.events[16].detail.args.agreement_id` | proposal-001 |
| `controller.events[16].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[16].detail.args.lot_id` | DL-100.L001 |
| `controller.events[16].detail.op` | reserve |
| Événement consigné · `controller.events[16].event` | BROKER_REQUEST |
| `controller.events[16].monotonic_ns` | 40926396522801 |
| Instant logique · `controller.events[16].tick` | 6 |
| `controller.events[17].detail.key` | proposal-001.DL-100.L001.A1 |
| `controller.events[17].detail.slot` | PRIMARY.W0 |
| État consigné · `controller.events[17].detail.status` | RESERVED |
| Événement consigné · `controller.events[17].event` | CAPACITY_RESERVED |
| `controller.events[17].monotonic_ns` | 40926403057211 |
| Instant logique · `controller.events[17].tick` | 6 |
| Identité de l’accord · `controller.events[18].detail.args.agreement_id` | proposal-001 |
| `controller.events[18].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[18].detail.args.lot_id` | DL-100.L001 |
| `controller.events[18].detail.args.supersedes` | Non consigné |
| `controller.events[18].detail.op` | produce |
| Événement consigné · `controller.events[18].event` | BROKER_REQUEST |
| `controller.events[18].monotonic_ns` | 40926403442493 |
| Instant logique · `controller.events[18].tick` | 7 |
| `controller.events[19].detail.byte_count` | 195948 |
| `controller.events[19].detail.payload_sha256` | 5445d40e4140ba39e7a43abbb71e95b8089dccaf72533b1e9c6ebee8b137c4ac |
| `controller.events[19].detail.production_id` | proposal-001.DL-100.L001.A1 |
| Quantité requise · `controller.events[19].detail.quantity` | 500 |
| Événement consigné · `controller.events[19].event` | PRODUCT_MATERIALIZED |
| `controller.events[19].monotonic_ns` | 40926431585976 |
| Instant logique · `controller.events[19].tick` | 7 |
| `controller.events[20].detail.args.production_id` | proposal-001.DL-100.L001.A1 |
| `controller.events[20].detail.op` | transfer |
| Événement consigné · `controller.events[20].event` | BROKER_REQUEST |
| `controller.events[20].monotonic_ns` | 40926431978529 |
| Instant logique · `controller.events[20].tick` | 8 |
| `controller.events[21].detail.byte_count` | 195948 |
| `controller.events[21].detail.delivery_id` | proposal-001.DL-100.L001.A1.D |
| `controller.events[21].detail.produced_sha256` | 5445d40e4140ba39e7a43abbb71e95b8089dccaf72533b1e9c6ebee8b137c4ac |
| `controller.events[21].detail.production_id` | proposal-001.DL-100.L001.A1 |
| `controller.events[21].detail.received_sha256` | 5445d40e4140ba39e7a43abbb71e95b8089dccaf72533b1e9c6ebee8b137c4ac |
| Événement consigné · `controller.events[21].event` | PRODUCT_TRANSFERRED |
| `controller.events[21].monotonic_ns` | 40926439094803 |
| Instant logique · `controller.events[21].tick` | 8 |
| `controller.events[22].detail.args.delivery_id` | proposal-001.DL-100.L001.A1.D |
| `controller.events[22].detail.op` | inspect |
| Événement consigné · `controller.events[22].event` | BROKER_REQUEST |
| `controller.events[22].monotonic_ns` | 40926439361356 |
| Instant logique · `controller.events[22].tick` | 9 |
| `controller.events[23].detail.accepted_units` | 500 |
| `controller.events[23].detail.delivery_id` | proposal-001.DL-100.L001.A1.D |
| État consigné · `controller.events[23].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[23].detail.timely` | Oui |
| Événement consigné · `controller.events[23].event` | RECIPIENT_INSPECTED |
| `controller.events[23].monotonic_ns` | 40926474942632 |
| Instant logique · `controller.events[23].tick` | 9 |
| `controller.events[24].detail.args` | Aucune entrée |
| `controller.events[24].detail.op` | status |
| Événement consigné · `controller.events[24].event` | BROKER_REQUEST |
| `controller.events[24].monotonic_ns` | 40926475446314 |
| Instant logique · `controller.events[24].tick` | 10 |
| Identité de l’accord · `controller.events[25].detail.args.agreement_id` | proposal-001 |
| `controller.events[25].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[25].detail.args.lot_id` | DL-100.L002 |
| `controller.events[25].detail.op` | reserve |
| Événement consigné · `controller.events[25].event` | BROKER_REQUEST |
| `controller.events[25].monotonic_ns` | 40926482086067 |
| Instant logique · `controller.events[25].tick` | 11 |
| `controller.events[26].detail.key` | proposal-001.DL-100.L002.A1 |
| `controller.events[26].detail.slot` | PRIMARY.W0 |
| État consigné · `controller.events[26].detail.status` | RESERVED |
| Événement consigné · `controller.events[26].event` | CAPACITY_RESERVED |
| `controller.events[26].monotonic_ns` | 40926489164093 |
| Instant logique · `controller.events[26].tick` | 11 |
| Identité de l’accord · `controller.events[27].detail.args.agreement_id` | proposal-001 |
| `controller.events[27].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[27].detail.args.lot_id` | DL-100.L002 |
| `controller.events[27].detail.args.supersedes` | Non consigné |
| `controller.events[27].detail.op` | produce |
| Événement consigné · `controller.events[27].event` | BROKER_REQUEST |
| `controller.events[27].monotonic_ns` | 40926489712271 |
| Instant logique · `controller.events[27].tick` | 12 |
| `controller.events[28].detail.byte_count` | 196060 |
| `controller.events[28].detail.payload_sha256` | bd5ff9d1eb17cea8f7e2afc816af5492d9458acc1c7fabe0b342a8ffc4962fd1 |
| `controller.events[28].detail.production_id` | proposal-001.DL-100.L002.A1 |
| Quantité requise · `controller.events[28].detail.quantity` | 500 |
| Événement consigné · `controller.events[28].event` | PRODUCT_MATERIALIZED |
| `controller.events[28].monotonic_ns` | 40926519415165 |
| Instant logique · `controller.events[28].tick` | 12 |
| `controller.events[29].detail.args.production_id` | proposal-001.DL-100.L002.A1 |
| `controller.events[29].detail.op` | transfer |
| Événement consigné · `controller.events[29].event` | BROKER_REQUEST |
| `controller.events[29].monotonic_ns` | 40926520513054 |
| Instant logique · `controller.events[29].tick` | 13 |
| `controller.events[30].detail.byte_count` | 196060 |
| `controller.events[30].detail.delivery_id` | proposal-001.DL-100.L002.A1.D |
| `controller.events[30].detail.produced_sha256` | bd5ff9d1eb17cea8f7e2afc816af5492d9458acc1c7fabe0b342a8ffc4962fd1 |
| `controller.events[30].detail.production_id` | proposal-001.DL-100.L002.A1 |
| `controller.events[30].detail.received_sha256` | bd5ff9d1eb17cea8f7e2afc816af5492d9458acc1c7fabe0b342a8ffc4962fd1 |
| Événement consigné · `controller.events[30].event` | PRODUCT_TRANSFERRED |
| `controller.events[30].monotonic_ns` | 40926528393302 |
| Instant logique · `controller.events[30].tick` | 13 |
| `controller.events[31].detail.args.delivery_id` | proposal-001.DL-100.L002.A1.D |
| `controller.events[31].detail.op` | inspect |
| Événement consigné · `controller.events[31].event` | BROKER_REQUEST |
| `controller.events[31].monotonic_ns` | 40926528670300 |
| Instant logique · `controller.events[31].tick` | 14 |
| `controller.events[32].detail.accepted_units` | 500 |
| `controller.events[32].detail.delivery_id` | proposal-001.DL-100.L002.A1.D |
| État consigné · `controller.events[32].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[32].detail.timely` | Oui |
| Événement consigné · `controller.events[32].event` | RECIPIENT_INSPECTED |
| `controller.events[32].monotonic_ns` | 40926565829001 |
| Instant logique · `controller.events[32].tick` | 14 |
| `controller.events[33].detail.args` | Aucune entrée |
| `controller.events[33].detail.op` | status |
| Événement consigné · `controller.events[33].event` | BROKER_REQUEST |
| `controller.events[33].monotonic_ns` | 40926566264670 |
| Instant logique · `controller.events[33].tick` | 15 |
| Identité de l’accord · `controller.events[34].detail.args.agreement_id` | proposal-001 |
| `controller.events[34].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[34].detail.args.lot_id` | DL-100.L003 |
| `controller.events[34].detail.op` | reserve |
| Événement consigné · `controller.events[34].event` | BROKER_REQUEST |
| `controller.events[34].monotonic_ns` | 40926574238639 |
| Instant logique · `controller.events[34].tick` | 16 |
| `controller.events[35].detail.key` | proposal-001.DL-100.L003.A1 |
| `controller.events[35].detail.slot` | PRIMARY.W0 |
| État consigné · `controller.events[35].detail.status` | RESERVED |
| Événement consigné · `controller.events[35].event` | CAPACITY_RESERVED |
| `controller.events[35].monotonic_ns` | 40926581157204 |
| Instant logique · `controller.events[35].tick` | 16 |
| Identité de l’accord · `controller.events[36].detail.args.agreement_id` | proposal-001 |
| `controller.events[36].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[36].detail.args.lot_id` | DL-100.L003 |
| `controller.events[36].detail.args.supersedes` | Non consigné |
| `controller.events[36].detail.op` | produce |
| Événement consigné · `controller.events[36].event` | BROKER_REQUEST |
| `controller.events[36].monotonic_ns` | 40926581482325 |
| Instant logique · `controller.events[36].tick` | 17 |
| `controller.events[37].detail.byte_count` | 39760 |
| `controller.events[37].detail.payload_sha256` | c81609a0b4b80ebe7aa96a3c85269da755f8255354a481046775cc92c1a5dc7a |
| `controller.events[37].detail.production_id` | proposal-001.DL-100.L003.A1 |
| Quantité requise · `controller.events[37].detail.quantity` | 100 |
| Événement consigné · `controller.events[37].event` | PRODUCT_MATERIALIZED |
| `controller.events[37].monotonic_ns` | 40926602609075 |
| Instant logique · `controller.events[37].tick` | 17 |
| `controller.events[38].detail.args.production_id` | proposal-001.DL-100.L003.A1 |
| `controller.events[38].detail.op` | transfer |
| Événement consigné · `controller.events[38].event` | BROKER_REQUEST |
| `controller.events[38].monotonic_ns` | 40926603048729 |
| Instant logique · `controller.events[38].tick` | 18 |
| `controller.events[39].detail.byte_count` | 39760 |
| `controller.events[39].detail.delivery_id` | proposal-001.DL-100.L003.A1.D |
| `controller.events[39].detail.produced_sha256` | c81609a0b4b80ebe7aa96a3c85269da755f8255354a481046775cc92c1a5dc7a |
| `controller.events[39].detail.production_id` | proposal-001.DL-100.L003.A1 |
| `controller.events[39].detail.received_sha256` | c81609a0b4b80ebe7aa96a3c85269da755f8255354a481046775cc92c1a5dc7a |
| Événement consigné · `controller.events[39].event` | PRODUCT_TRANSFERRED |
| `controller.events[39].monotonic_ns` | 40926611954262 |
| Instant logique · `controller.events[39].tick` | 18 |
| `controller.events[40].detail.args.delivery_id` | proposal-001.DL-100.L003.A1.D |
| `controller.events[40].detail.op` | inspect |
| Événement consigné · `controller.events[40].event` | BROKER_REQUEST |
| `controller.events[40].monotonic_ns` | 40926612303419 |
| Instant logique · `controller.events[40].tick` | 19 |
| `controller.events[41].detail.accepted_units` | 100 |
| `controller.events[41].detail.delivery_id` | proposal-001.DL-100.L003.A1.D |
| État consigné · `controller.events[41].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[41].detail.timely` | Oui |
| Événement consigné · `controller.events[41].event` | RECIPIENT_INSPECTED |
| `controller.events[41].monotonic_ns` | 40926622376010 |
| Instant logique · `controller.events[41].tick` | 19 |
| `controller.events[42].detail.args` | Aucune entrée |
| `controller.events[42].detail.op` | status |
| Événement consigné · `controller.events[42].event` | BROKER_REQUEST |
| `controller.events[42].monotonic_ns` | 40926622860192 |
| Instant logique · `controller.events[42].tick` | 20 |
| Identité de l’accord · `controller.events[43].detail.args.agreement_id` | proposal-001 |
| `controller.events[43].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[43].detail.args.lot_id` | DL-200.L001 |
| `controller.events[43].detail.op` | reserve |
| Événement consigné · `controller.events[43].event` | BROKER_REQUEST |
| `controller.events[43].monotonic_ns` | 40926630700780 |
| Instant logique · `controller.events[43].tick` | 21 |
| `controller.events[44].detail.key` | proposal-001.DL-200.L001.A1 |
| `controller.events[44].detail.slot` | PRIMARY.W0 |
| État consigné · `controller.events[44].detail.status` | RESERVED |
| Événement consigné · `controller.events[44].event` | CAPACITY_RESERVED |
| `controller.events[44].monotonic_ns` | 40926637067866 |
| Instant logique · `controller.events[44].tick` | 21 |
| Identité de l’accord · `controller.events[45].detail.args.agreement_id` | proposal-001 |
| `controller.events[45].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[45].detail.args.lot_id` | DL-200.L001 |
| `controller.events[45].detail.args.supersedes` | Non consigné |
| `controller.events[45].detail.op` | produce |
| Événement consigné · `controller.events[45].event` | BROKER_REQUEST |
| `controller.events[45].monotonic_ns` | 40926637353127 |
| Instant logique · `controller.events[45].tick` | 22 |
| `controller.events[46].detail.byte_count` | 195948 |
| `controller.events[46].detail.payload_sha256` | 9426c5aa5e8c79122f099dda388d6f1674aebc7c201c92153e03c889171d50c0 |
| `controller.events[46].detail.production_id` | proposal-001.DL-200.L001.A1 |
| Quantité requise · `controller.events[46].detail.quantity` | 500 |
| Événement consigné · `controller.events[46].event` | PRODUCT_MATERIALIZED |
| `controller.events[46].monotonic_ns` | 40926663750987 |
| Instant logique · `controller.events[46].tick` | 22 |
| `controller.events[47].detail.args.production_id` | proposal-001.DL-200.L001.A1 |
| `controller.events[47].detail.op` | transfer |
| Événement consigné · `controller.events[47].event` | BROKER_REQUEST |
| `controller.events[47].monotonic_ns` | 40926664135338 |
| Instant logique · `controller.events[47].tick` | 23 |
| `controller.events[48].detail.byte_count` | 195948 |
| `controller.events[48].detail.delivery_id` | proposal-001.DL-200.L001.A1.D |
| `controller.events[48].detail.produced_sha256` | 9426c5aa5e8c79122f099dda388d6f1674aebc7c201c92153e03c889171d50c0 |
| `controller.events[48].detail.production_id` | proposal-001.DL-200.L001.A1 |
| `controller.events[48].detail.received_sha256` | 9426c5aa5e8c79122f099dda388d6f1674aebc7c201c92153e03c889171d50c0 |
| Événement consigné · `controller.events[48].event` | PRODUCT_TRANSFERRED |
| `controller.events[48].monotonic_ns` | 40926679453551 |
| Instant logique · `controller.events[48].tick` | 23 |
| `controller.events[49].detail.args.delivery_id` | proposal-001.DL-200.L001.A1.D |
| `controller.events[49].detail.op` | inspect |
| Événement consigné · `controller.events[49].event` | BROKER_REQUEST |
| `controller.events[49].monotonic_ns` | 40926679826765 |
| Instant logique · `controller.events[49].tick` | 24 |
| `controller.events[50].detail.accepted_units` | 500 |
| `controller.events[50].detail.delivery_id` | proposal-001.DL-200.L001.A1.D |
| État consigné · `controller.events[50].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[50].detail.timely` | Oui |
| Événement consigné · `controller.events[50].event` | RECIPIENT_INSPECTED |
| `controller.events[50].monotonic_ns` | 40926715009414 |
| Instant logique · `controller.events[50].tick` | 24 |
| `controller.events[51].detail.args` | Aucune entrée |
| `controller.events[51].detail.op` | status |
| Événement consigné · `controller.events[51].event` | BROKER_REQUEST |
| `controller.events[51].monotonic_ns` | 40926715493415 |
| Instant logique · `controller.events[51].tick` | 25 |
| Identité de l’accord · `controller.events[52].detail.args.agreement_id` | proposal-001 |
| `controller.events[52].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[52].detail.args.lot_id` | DL-200.L002 |
| `controller.events[52].detail.op` | reserve |
| Événement consigné · `controller.events[52].event` | BROKER_REQUEST |
| `controller.events[52].monotonic_ns` | 40926724144624 |
| Instant logique · `controller.events[52].tick` | 26 |
| `controller.events[53].detail.key` | proposal-001.DL-200.L002.A1 |
| `controller.events[53].detail.slot` | PRIMARY.W0 |
| État consigné · `controller.events[53].detail.status` | RESERVED |
| Événement consigné · `controller.events[53].event` | CAPACITY_RESERVED |
| `controller.events[53].monotonic_ns` | 40926730453722 |
| Instant logique · `controller.events[53].tick` | 26 |
| Identité de l’accord · `controller.events[54].detail.args.agreement_id` | proposal-001 |
| `controller.events[54].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[54].detail.args.lot_id` | DL-200.L002 |
| `controller.events[54].detail.args.supersedes` | Non consigné |
| `controller.events[54].detail.op` | produce |
| Événement consigné · `controller.events[54].event` | BROKER_REQUEST |
| `controller.events[54].monotonic_ns` | 40926730834888 |
| Instant logique · `controller.events[54].tick` | 27 |
| `controller.events[55].detail.byte_count` | 117858 |
| `controller.events[55].detail.payload_sha256` | 04aeb1a4274ef99a13b39ac2fb1e1631379e9de9c2052023b1f0b7db7758e3cb |
| `controller.events[55].detail.production_id` | proposal-001.DL-200.L002.A1 |
| Quantité requise · `controller.events[55].detail.quantity` | 300 |
| Événement consigné · `controller.events[55].event` | PRODUCT_MATERIALIZED |
| `controller.events[55].monotonic_ns` | 40926753965646 |
| Instant logique · `controller.events[55].tick` | 27 |
| `controller.events[56].detail.args.production_id` | proposal-001.DL-200.L002.A1 |
| `controller.events[56].detail.op` | transfer |
| Événement consigné · `controller.events[56].event` | BROKER_REQUEST |
| `controller.events[56].monotonic_ns` | 40926754392040 |
| Instant logique · `controller.events[56].tick` | 28 |
| `controller.events[57].detail.byte_count` | 117858 |
| `controller.events[57].detail.delivery_id` | proposal-001.DL-200.L002.A1.D |
| `controller.events[57].detail.produced_sha256` | 04aeb1a4274ef99a13b39ac2fb1e1631379e9de9c2052023b1f0b7db7758e3cb |
| `controller.events[57].detail.production_id` | proposal-001.DL-200.L002.A1 |
| `controller.events[57].detail.received_sha256` | 04aeb1a4274ef99a13b39ac2fb1e1631379e9de9c2052023b1f0b7db7758e3cb |
| Événement consigné · `controller.events[57].event` | PRODUCT_TRANSFERRED |
| `controller.events[57].monotonic_ns` | 40926763588437 |
| Instant logique · `controller.events[57].tick` | 28 |
| `controller.events[58].detail.args.delivery_id` | proposal-001.DL-200.L002.A1.D |
| `controller.events[58].detail.op` | inspect |
| Événement consigné · `controller.events[58].event` | BROKER_REQUEST |
| `controller.events[58].monotonic_ns` | 40926763901210 |
| Instant logique · `controller.events[58].tick` | 29 |
| `controller.events[59].detail.accepted_units` | 300 |
| `controller.events[59].detail.delivery_id` | proposal-001.DL-200.L002.A1.D |
| État consigné · `controller.events[59].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[59].detail.timely` | Oui |
| Événement consigné · `controller.events[59].event` | RECIPIENT_INSPECTED |
| `controller.events[59].monotonic_ns` | 40926785613379 |
| Instant logique · `controller.events[59].tick` | 29 |
| Identité de l’accord · `controller.events[60].detail.args.agreement_id` | proposal-001 |
| `controller.events[60].detail.op` | settle |
| Événement consigné · `controller.events[60].event` | BROKER_REQUEST |
| `controller.events[60].monotonic_ns` | 40926786052242 |
| Instant logique · `controller.events[60].tick` | 30 |
| Références d’acceptation · `controller.events[61].detail.acceptance_ids[0]` | proposal-001.DL-100.L001.A1.D |
| Références d’acceptation · `controller.events[61].detail.acceptance_ids[1]` | proposal-001.DL-100.L002.A1.D |
| Références d’acceptation · `controller.events[61].detail.acceptance_ids[2]` | proposal-001.DL-100.L003.A1.D |
| Références d’acceptation · `controller.events[61].detail.acceptance_ids[3]` | proposal-001.DL-200.L001.A1.D |
| Références d’acceptation · `controller.events[61].detail.acceptance_ids[4]` | proposal-001.DL-200.L002.A1.D |
| Identité de l’accord · `controller.events[61].detail.agreement_id` | proposal-001 |
| Événement consigné · `controller.events[61].event` | ARRANGEMENT_SETTLED |
| `controller.events[61].monotonic_ns` | 40926791526925 |
| Instant logique · `controller.events[61].tick` | 30 |
| Interventions consignées · `controller.events[62].detail.interventions` | Aucune entrée |
| Motif consigné · `controller.events[62].detail.reason` | DIGITAL_PRODUCT_ACCEPTED |
| `controller.events[62].detail.searches[0].assignment_domain` | 1024 |
| `controller.events[62].detail.searches[0].candidate_elapsed_ns` | 4693242 |
| `controller.events[62].detail.searches[0].capacity_prunes` | 0 |
| `controller.events[62].detail.searches[0].complete_assignments_observed` | 52 |
| `controller.events[62].detail.searches[0].exhaustive_within_declared_domain` | Oui |
| `controller.events[62].detail.searches[0].feasible_assignments` | 52 |
| `controller.events[62].detail.searches[0].funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Procédure candidate · `controller.events[62].detail.searches[0].method` | harness |
| `controller.events[62].detail.searches[0].partial_nodes_observed` | 217 |
| `controller.events[62].detail.searches[0].participant_prunes` | 0 |
| `controller.events[62].detail.searches[0].price_prunes` | 111 |
| Verdict du composant · `controller.events[62].detail.verdict` | Réalisé (`COMPLETED`) |
| Événement consigné · `controller.events[62].event` | CANDIDATE_DONE |
| `controller.events[62].monotonic_ns` | 40926792026771 |
| Instant logique · `controller.events[62].tick` | 30 |
| `controller.events[63].detail.database` | participants |
| `controller.events[63].detail.sqlite[0]` | 0 |
| `controller.events[63].detail.sqlite[1]` | 0 |
| `controller.events[63].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[63].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[63].event` | DATABASE_CHECKPOINT |
| `controller.events[63].monotonic_ns` | 40926821662714 |
| Instant logique · `controller.events[63].tick` | 30 |
| `controller.events[64].detail.database` | producer |
| `controller.events[64].detail.sqlite[0]` | 0 |
| `controller.events[64].detail.sqlite[1]` | 0 |
| `controller.events[64].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[64].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[64].event` | DATABASE_CHECKPOINT |
| `controller.events[64].monotonic_ns` | 40926824540422 |
| Instant logique · `controller.events[64].tick` | 30 |
| `controller.events[65].detail.database` | receiver |
| `controller.events[65].detail.sqlite[0]` | 0 |
| `controller.events[65].detail.sqlite[1]` | 0 |
| `controller.events[65].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[65].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[65].event` | DATABASE_CHECKPOINT |
| `controller.events[65].monotonic_ns` | 40926827642480 |
| Instant logique · `controller.events[65].tick` | 30 |
| `controller.events[66].detail.database` | PRIMARY.W0 |
| `controller.events[66].detail.sqlite[0]` | 0 |
| `controller.events[66].detail.sqlite[1]` | 0 |
| `controller.events[66].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[66].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[66].event` | DATABASE_CHECKPOINT |
| `controller.events[66].monotonic_ns` | 40926829098575 |
| Instant logique · `controller.events[66].tick` | 30 |
| `controller.events[67].detail.database` | BACKUP.W0 |
| `controller.events[67].detail.sqlite[0]` | 0 |
| `controller.events[67].detail.sqlite[1]` | 0 |
| `controller.events[67].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[67].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[67].event` | DATABASE_CHECKPOINT |
| `controller.events[67].monotonic_ns` | 40926830396086 |
| Instant logique · `controller.events[67].tick` | 30 |
| `controller.events[68].detail.database` | COMPAT-A.W0 |
| `controller.events[68].detail.sqlite[0]` | 0 |
| `controller.events[68].detail.sqlite[1]` | 0 |
| `controller.events[68].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[68].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[68].event` | DATABASE_CHECKPOINT |
| `controller.events[68].monotonic_ns` | 40926831706877 |
| Instant logique · `controller.events[68].tick` | 30 |
| `controller.events[69].detail.database` | COMPAT-B.W0 |
| `controller.events[69].detail.sqlite[0]` | 0 |
| `controller.events[69].detail.sqlite[1]` | 0 |
| `controller.events[69].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[69].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[69].event` | DATABASE_CHECKPOINT |
| `controller.events[69].monotonic_ns` | 40926832772637 |
| Instant logique · `controller.events[69].tick` | 30 |
| `controller.events[70].detail.databases` | 7 |
| `controller.events[70].detail.snapshot_method` | SQLITE_BACKUP_DELETE_FULL_LOGICAL_DIGEST |
| Événement consigné · `controller.events[70].event` | EVIDENCE_FINALIZED |
| `controller.events[70].monotonic_ns` | 40926970821849 |
| Instant logique · `controller.events[70].tick` | 30 |
| Programme de pannes préenregistré · `controller.fault_schedule` | Aucune entrée |
| Pannes effectivement observées · `controller.faults_observed` | Aucune entrée |
| `controller.finished_monotonic_ns` | 40926970826907 |
| Identité du cas préenregistré · `controller.fixture_id` | primary-recovery |
| Modifications sources non consignées présentes · `controller.implementation.dirty` | Non |
| Arguments exacts du processus · `controller.implementation.environment.argv[0]` | python3 |
| Arguments exacts du processus · `controller.implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `controller.implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `controller.implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `controller.implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `controller.implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `controller.implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `controller.implementation.environment.argv[7]` | /tmp/continuity-economy-post-review-b1d5891eb025-001 |
| Plateforme d’exécution · `controller.implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `controller.implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `controller.implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `controller.implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `controller.implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Oui |
| `controller.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Oui |
| `controller.isolation.probe.network_denied` | Oui |
| `controller.isolation.probe.process_inspection_denied` | Oui |
| `controller.isolation.probe.spawn_denied` | Oui |
| `controller.isolation.probe.workspace_open_denied` | Oui |
| Procédure candidate · `controller.method` | harness |
| `controller.policies_sha256` | aec5d1e78061188f95f835bb9ccb752d4522ca5592f62a9e436543c7f6af107f |
| Travail d’adaptation (secondes ; inconnu si absent) · `controller.resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `controller.resources.authority_storage_bytes_before_seal` | 30076 |
| Redémarrages du candidat · `controller.resources.candidate_restarts` | 0 |
| Processus enfants lancés · `controller.resources.child_processes` | 8 |
| Processeur système du contrôleur (ns) · `controller.resources.controller_cpu_system_ns` | 19696000 |
| Processeur utilisateur du contrôleur (ns) · `controller.resources.controller_cpu_user_ns` | 142562999 |
| Processeur système (ns) · `controller.resources.cpu_system_ns` | 112427999 |
| Processeur utilisateur (ns) · `controller.resources.cpu_user_ns` | 542315000 |
| Interventions humaines · `controller.resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `controller.resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Coût monétaire réel mesuré · `controller.resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `controller.resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `controller.resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `controller.resources.requests` | 30 |
| Nouvelles tentatives · `controller.resources.retries` | 0 |
| Requêtes internes aux services · `controller.resources.service_requests` | 158 |
| Stockage consigné (octets) · `controller.resources.storage_bytes` | 8776696 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Travail humain de vérification (secondes ; inconnu si absent) · `controller.resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `controller.resources.wall_ns` | 961780174 |
| Redémarrages des services · `controller.resources.worker_restarts` | 0 |
| Identité de l’exécution · `controller.run_id` | primary-recovery.harness.491f973465 |
| Schéma · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 40926009046733 |
| `controller.started_utc` | 2026-11-07T00:58:48.123490+00:00 |
| `controller.state` | Vérification complète (`COMPLETE`) |
| Verdict du composant · `controller.target_verdict` | Réalisé (`COMPLETED`) |
| Programme de pannes préenregistré · `fault_schedule` | Aucune entrée |
| Pannes effectivement observées · `faults_observed` | Aucune entrée |
| Identité du cas préenregistré · `fixture_id` | primary-recovery |
| Modifications sources non consignées présentes · `implementation.dirty` | Non |
| Arguments exacts du processus · `implementation.environment.argv[0]` | python3 |
| Arguments exacts du processus · `implementation.environment.argv[1]` | -m |
| Arguments exacts du processus · `implementation.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `implementation.environment.argv[3]` | --language |
| Arguments exacts du processus · `implementation.environment.argv[4]` | en |
| Arguments exacts du processus · `implementation.environment.argv[5]` | experiment |
| Arguments exacts du processus · `implementation.environment.argv[6]` | --out |
| Arguments exacts du processus · `implementation.environment.argv[7]` | /tmp/continuity-economy-post-review-b1d5891eb025-001 |
| Plateforme d’exécution · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `implementation.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `implementation.version` | 0.2.0 |
| Procédure candidate · `method` | harness |
| Solde (unités mineures SMU synthétiques) · `policies.buyer.balance_minor` | 30000 |
| `policies.buyer.consent_until_tick` | 800 |
| `policies.buyer.max_price_minor` | 25000 |
| Utilité d’option externe définie (unités mineures SMU synthétiques) · `policies.buyer.outside_utility_minor` | 2000 |
| Identité du participant · `policies.buyer.party_id` | BUYER |
| Borne supérieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_max_minor` | 30000 |
| Borne inférieure de valeur définie (unités mineures SMU synthétiques) · `policies.buyer.value_min_minor` | 30000 |
| Solde (unités mineures SMU synthétiques) · `policies.coordinator.balance_minor` | 10000 |
| `policies.coordinator.consent_until_tick` | 800 |
| `policies.coordinator.liability_limit_minor` | 10000 |
| `policies.coordinator.min_profit_minor` | 100 |
| `policies.coordinator.operating_cost_minor` | 200 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.coordinator.outside_profit_minor` | 100 |
| Identité du participant · `policies.coordinator.party_id` | COORDINATOR |
| `policies.coordinator.technical_control_allowed` | Oui |
| Unité de compte synthétique · `policies.currency` | SMU |
| Solde (unités mineures SMU synthétiques) · `policies.providers[0].balance_minor` | 40000 |
| `policies.providers[0].consent_until_tick` | 800 |
| `policies.providers[0].liability_limit_minor` | 40000 |
| `policies.providers[0].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[0].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[0].party_id` | PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 100 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 100 |
| `policies.providers[0].technical_control_allowed` | Oui |
| `policies.providers[0].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[1].balance_minor` | 40000 |
| `policies.providers[1].consent_until_tick` | 800 |
| `policies.providers[1].liability_limit_minor` | 40000 |
| `policies.providers[1].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[1].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[1].party_id` | BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 150 |
| `policies.providers[1].rework_unit_cost_minor` | 2 |
| `policies.providers[1].setup_cost_minor` | 150 |
| `policies.providers[1].technical_control_allowed` | Oui |
| `policies.providers[1].unit_cost_minor` | 2 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[2].balance_minor` | 40000 |
| `policies.providers[2].consent_until_tick` | 800 |
| `policies.providers[2].liability_limit_minor` | 40000 |
| `policies.providers[2].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[2].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[2].party_id` | COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 200 |
| `policies.providers[2].rework_unit_cost_minor` | 3 |
| `policies.providers[2].setup_cost_minor` | 200 |
| `policies.providers[2].technical_control_allowed` | Oui |
| `policies.providers[2].unit_cost_minor` | 3 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[3].balance_minor` | 40000 |
| `policies.providers[3].consent_until_tick` | 800 |
| `policies.providers[3].liability_limit_minor` | 40000 |
| `policies.providers[3].min_profit_minor` | 100 |
| Profit d’option externe défini (unités mineures SMU synthétiques) · `policies.providers[3].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[3].party_id` | COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 300 |
| `policies.providers[3].rework_unit_cost_minor` | 3 |
| `policies.providers[3].setup_cost_minor` | 300 |
| `policies.providers[3].technical_control_allowed` | Oui |
| `policies.providers[3].unit_cost_minor` | 3 |
| Révision · `policies.revision` | 1 |
| Schéma · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Oui |
| Solde (unités mineures SMU synthétiques) · `policies.technical_sponsor.balance_minor` | 60000 |
| Identité du participant · `policies.technical_sponsor.party_id` | TECHNICAL-SPONSOR |
| Empreinte externe de référence · `reference_sha256` | 6c7daea9be2b15c2aec00037cb0177570de9be2c205ba0483578f00af25dba93 |
| `registered_assertion.expected.accepted_units` | 1900 |
| Résultat · `registered_assertion.expected.outcome` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `registered_assertion.expected.service_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `registered_assertion.observed.accepted_units` | 1900 |
| Résultat · `registered_assertion.observed.outcome` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `registered_assertion.observed.service_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Portée de l’évaluation · `registered_assertion.scope` | Assertion d’évaluation préenregistrée ; elle n’affirme ni résultat favorable ni transaction acceptable. |
| État consigné · `registered_assertion.status` | Réussi (`PASSED`) |
| Modifications sources non consignées présentes · `source_version.dirty` | Non |
| Arguments exacts du processus · `source_version.environment.argv[0]` | python3 |
| Arguments exacts du processus · `source_version.environment.argv[1]` | -m |
| Arguments exacts du processus · `source_version.environment.argv[2]` | continuity_economy |
| Arguments exacts du processus · `source_version.environment.argv[3]` | --language |
| Arguments exacts du processus · `source_version.environment.argv[4]` | en |
| Arguments exacts du processus · `source_version.environment.argv[5]` | experiment |
| Arguments exacts du processus · `source_version.environment.argv[6]` | --out |
| Arguments exacts du processus · `source_version.environment.argv[7]` | /tmp/continuity-economy-post-review-b1d5891eb025-001 |
| Plateforme d’exécution · `source_version.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `source_version.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `source_version.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `source_version.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-post-review-source |
| Commit source effectif · `source_version.git_commit` | f9e56c7dd9627b322406e05c53b4f6537d434262 |
| Base conservée de l’implémentation de capacité · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `source_version.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `source_version.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Version d’implémentation · `source_version.version` | 0.2.0 |
| Hypothèses de confiance explicites · `trust_assumptions[0]` | Hôte, noyau, contrôleur et horloge de confiance (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Hypothèses de confiance explicites · `trust_assumptions[1]` | Autorité synthétique conservée de confiance (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Hypothèses de confiance explicites · `trust_assumptions[2]` | Auteur commun ; aucune certification par un tiers (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Hypothèses de confiance explicites · `trust_assumptions[3]` | Contenu numérique sémantique uniquement ; livraison physique non éprouvée (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Pannes préenregistrées non déclenchées · `untriggered_faults` | Aucune entrée |

## Enregistrement structuré complet de vérification

Le même enregistrement structuré génère les deux versions linguistiques. Les clés machine, codes d’état et valeurs littérales des preuves restent inchangés ; les sections localisées ci-dessus expliquent leur sens. Aucun résultat sauvegardé n’est réutilisé comme preuve fraîche.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 4400,
    "buyer_utility_interval_minor": {
      "maximum": 25600,
      "minimum": 25600
    },
    "campaign": [
      {
        "final_balance_minor": 25600,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 4400,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 200,
        "initial_balance_minor": 10000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 100,
        "revenue_minor": 300,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 42100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 2000,
        "initial_balance_minor": 40000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 2100,
        "revenue_minor": 4100,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 2200,
    "total_transfers_minor": 4400,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "DEMONSTRATED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "COMPLETED",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "DEMONSTRATED",
    "service_feasibility": "DEMONSTRATED"
  },
  "cohort": "base",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "189954752d4fa215405dfb4798a1a679a1adaf6ef8669434612a093c2b732e0f",
  "evidence_sha256": {
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json": "7ed6fb9ae68a4af34ee396794a3e8859fd31ca04d937f4e458a08ef4dcd29d02",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L002.A1.json": "fe19e50ca57de94f7f0476a29decf2b7e8480e6219ef713c7ce232ba875b217f",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L003.A1.json": "4995a3b3fc2d2719eaf27314273a450c85e64fec4ecd1eb277d9a3d5f35dead8",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-200.L001.A1.json": "8ce995d21c77849effa362bb10c84fbdc763a51e09f8fde71e217cd16752ecac",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-200.L002.A1.json": "4da17389739cfef11354d4b05a93d15388d220140fe7e20bc6e69337e5cc3cce",
    "evidence/capacity/BACKUP.W0.sqlite": "8e6df929ecb72f26c118c9c506d63aeb5e4ff29c37233aefa70017e0400a395c",
    "evidence/capacity/COMPAT-A.W0.sqlite": "2186469eb6466195f1fcabfd1a09bf9029459d1226653dc032f011442be5b1b2",
    "evidence/capacity/COMPAT-B.W0.sqlite": "d4bd8c04ed8adc42e33e264ba35638d9131c4c6e8104584fc12b3518827a5b0e",
    "evidence/capacity/PRIMARY.W0.sqlite": "49d1a85b5d51ff3219ce6b38d8de0561496408a4c3fa79bdd43ab2c550cb710e",
    "evidence/inbox/proposal-001.DL-100.L001.A1.D.json": "5445d40e4140ba39e7a43abbb71e95b8089dccaf72533b1e9c6ebee8b137c4ac",
    "evidence/inbox/proposal-001.DL-100.L002.A1.D.json": "bd5ff9d1eb17cea8f7e2afc816af5492d9458acc1c7fabe0b342a8ffc4962fd1",
    "evidence/inbox/proposal-001.DL-100.L003.A1.D.json": "c81609a0b4b80ebe7aa96a3c85269da755f8255354a481046775cc92c1a5dc7a",
    "evidence/inbox/proposal-001.DL-200.L001.A1.D.json": "9426c5aa5e8c79122f099dda388d6f1674aebc7c201c92153e03c889171d50c0",
    "evidence/inbox/proposal-001.DL-200.L002.A1.D.json": "04aeb1a4274ef99a13b39ac2fb1e1631379e9de9c2052023b1f0b7db7758e3cb",
    "evidence/participants.sqlite": "5d1c89de53cd714663dae1dbbdc686eb97e2669396c590a9442949ab2f6c4252",
    "evidence/producer.sqlite": "07f784e3ebb0dc836528898c22aa8256cd707e2c4e7817dc061c89c2142233e5",
    "evidence/products/proposal-001.DL-100.L001.A1.json": "5445d40e4140ba39e7a43abbb71e95b8089dccaf72533b1e9c6ebee8b137c4ac",
    "evidence/products/proposal-001.DL-100.L002.A1.json": "bd5ff9d1eb17cea8f7e2afc816af5492d9458acc1c7fabe0b342a8ffc4962fd1",
    "evidence/products/proposal-001.DL-100.L003.A1.json": "c81609a0b4b80ebe7aa96a3c85269da755f8255354a481046775cc92c1a5dc7a",
    "evidence/products/proposal-001.DL-200.L001.A1.json": "9426c5aa5e8c79122f099dda388d6f1674aebc7c201c92153e03c889171d50c0",
    "evidence/products/proposal-001.DL-200.L002.A1.json": "04aeb1a4274ef99a13b39ac2fb1e1631379e9de9c2052023b1f0b7db7758e3cb",
    "evidence/receiver.sqlite": "059ae364dbbba88433eba19057cbf8c938f3709baf83c06c1bcd6260af80e7a5"
  },
  "failures": [],
  "fault_schedule": [],
  "faults_observed": [],
  "fixture_id": "primary-recovery",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/tmp/continuity-economy-post-review-b1d5891eb025-001"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-post-review-source"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "method": "harness",
  "per_arrangement": [
    {
      "acceptance_ids": [
        "proposal-001.DL-100.L001.A1.D",
        "proposal-001.DL-100.L002.A1.D",
        "proposal-001.DL-100.L003.A1.D",
        "proposal-001.DL-200.L001.A1.D",
        "proposal-001.DL-200.L002.A1.D"
      ],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 2200,
      "independent_terms": {
        "break_even_value_minor": 6400,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 4400,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 2000,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 4000,
            "minimum_payment_minor": 4100,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 4100,
            "rework_cost_minor": 2000,
            "units": 1900
          }
        ],
        "rework_budget_minor": 2000,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 4400,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 4100,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 4400,
        "cancellation_fee_minor": 0,
        "contract_sha256": "189954752d4fa215405dfb4798a1a679a1adaf6ef8669434612a093c2b732e0f",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2000,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "DEMONSTRATED",
      "settled_tick": 30,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 1100,
      "deadline_tick": 500,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-100",
      "outcome": "COMPLETED",
      "produced_quantity": 1100,
      "production_attempts": 3,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 1100,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 1100,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 1100
    },
    {
      "accepted_quantity": 800,
      "deadline_tick": 500,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-200",
      "outcome": "COMPLETED",
      "produced_quantity": 800,
      "production_attempts": 2,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 800,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 800,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 800
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "6c7daea9be2b15c2aec00037cb0177570de9be2c205ba0483578f00af25dba93",
  "registered_assertion": {
    "expected": {
      "accepted_units": 1900,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "observed": {
      "accepted_units": 1900,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "PASSED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30076,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 19696000,
    "controller_cpu_user_ns": 142562999,
    "cpu_system_ns": 112427999,
    "cpu_user_ns": 542315000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 30,
    "retries": 0,
    "service_requests": 158,
    "storage_bytes": 8776696,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 961780174,
    "worker_restarts": 0
  },
  "run_id": "primary-recovery.harness.491f973465",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/tmp/continuity-economy-post-review-b1d5891eb025-001"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-post-review-source"
    },
    "git_commit": "f9e56c7dd9627b322406e05c53b4f6537d434262",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "0243538787725a393b2839be6d88b032cb641f041b347994390d27f09476060f",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 2,
    "accepted_quantity": 1900,
    "delivery_attempts": 5,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 0,
    "produced_quantity": 1900,
    "production_attempts": 5,
    "received_quantity": 1900,
    "recipient_accepted_quantity": 1900,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 1900,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 199389543,
    "evidence_files_read": 22,
    "wall_ns": 199410031
  },
  "verification_status": "COMPLETE",
  "verification_wall_ns": 201097621,
  "verifier_version": "0.2.0"
}
```
