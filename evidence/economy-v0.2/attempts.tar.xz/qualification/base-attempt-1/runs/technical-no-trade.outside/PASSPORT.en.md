# CONTINUITY Ω Harness — Economy of continuity

**Digital-product experiment · version 0.2.0**

Preserve a promise through a viable, voluntarily accepted continuity arrangement.

**Scope: disposable local processes and a specified digital product. Authored synthetic policies, consent, values, funding and SMU cash flows are model inputs and observations. They do not establish real contracts, demand, payments, sales, printed goods, rendered appearance or print quality.**

This Passport presents the recorded assessment. Fresh verification must inspect retained authority, actual durable output and recipient evidence; this document is never its oracle.

<!-- structured-result-sha256: 0b682ed01318982713f0c10bd1e97fd72eb1f1809945ae8b3e3f868bd0796f46 -->

## Three distinct claims

| Claim | Recorded status |
| --- | --- |
| Required digital work accepted within the frozen conditions | Failed (`FAILED`) |
| Service feasibility under the authored synthetic model | Not established (`NOT_ESTABLISHED`) |
| Method advantage over competent alternatives | Not established (`NOT_ESTABLISHED`) |
| Safety within the exercised failure model | Demonstrated in scope (`DEMONSTRATED`) |

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

## Assessment fields kept separate

| Field | Recorded value |
| --- | --- |
| Test assertion | Passed (`PASSED`) |
| Component verdict | OUTSIDE_OPTION |
| Evidence stage | Local digital-product execution (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| Assessed claim status | Failed (`FAILED`) |

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

## Identity, authority and versions

| Field | Recorded value |
| --- | --- |
| Authority evidence status · `authority_status` | Established for the synthetic exercise only (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Real commercial value · `commercial_value` | Not established (`NOT_ESTABLISHED`) |
| Contract identity · `contract_id` | DIGITAL-005 |
| Retained contract SHA-256 · `contract_sha256` | 92ac3697cf25ee31dd9c1b7b0abb27204ab4c48565d1d48da80f3f67c0579e04 |
| Real customer authenticity · `real_customer_authenticity` | Not established (`NOT_ESTABLISHED`) |
| External reference pin · `reference_sha256` | 96eb35b0f8176f788922dee81a135a23be0cc14ea4f4e6bef98025d227ff0b81 |
| Run identity · `run_id` | technical-no-trade.outside.f27925053d |
| Schema · `schema` | continuity-economy/verification/v1 |
| Verification completion status · `verification_status` | Complete verification (`COMPLETE`) |
| Verifier version · `verifier_version` | 0.2.0 |

## Per-obligation execution and acceptance

Counts describe the recorded stage. Rejected and corrected attempts remain distinct. A produced or received unit is not automatically accepted. Missing measurements are not displayed as zero.

| Obligation | Recipient | Revision | Required | Produced | Received | Rejected | Accepted within contract | Outcome |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 0 | 0 | 0 | 0 | Unfulfilled (`UNFULFILLED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 0 | 0 | 0 | 0 | Unfulfilled (`UNFULFILLED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Cancelled (`CANCELLED`) |

### Obligation `DL-100`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 1100 |
| Obligation identity · `obligation_id` | DL-100 |
| Outcome · `outcome` | Unfulfilled (`UNFULFILLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 1100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-A |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 1100 |
| Revision · `revision` | 2 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

### Obligation `DL-200`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 800 |
| Obligation identity · `obligation_id` | DL-200 |
| Outcome · `outcome` | Unfulfilled (`UNFULFILLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 800 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-B |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 800 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

### Obligation `DL-300`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | DL-300 |
| Outcome · `outcome` | Cancelled (`CANCELLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-C |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 0 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Cancelled (`CANCELLED`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

## Proposals, modeled decisions and arrangements

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

No arrangement record is present. This absence is not evidence of an accepted or economically viable deal.

## Modeled transfers, costs, liabilities and outside options

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

| Field | Recorded value |
| --- | --- |
| Total buyer transfers (synthetic SMU minor units) · `accounting.buyer_total_paid_minor` | 0 |
| Upper bound · `accounting.buyer_utility_interval_minor.maximum` | Not recorded |
| Lower bound · `accounting.buyer_utility_interval_minor.minimum` | Not recorded |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[0].final_balance_minor` | 100 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[0].initial_balance_minor` | 100 |
| Modeled participation threshold covered · `accounting.campaign[0].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[0].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[0].party_id` | BUYER |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[0].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[0].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[0].revenue_minor` | 0 |
| Role · `accounting.campaign[0].role` | buyer |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[1].final_balance_minor` | 10000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[1].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Modeled participation threshold covered · `accounting.campaign[1].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[1].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[1].party_id` | COORDINATOR |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[1].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[1].revenue_minor` | 0 |
| Role · `accounting.campaign[1].role` | coordinator |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Modeled participation threshold covered · `accounting.campaign[2].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[2].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[2].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[2].revenue_minor` | 0 |
| Role · `accounting.campaign[2].role` | technical_sponsor |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[3].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[3].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[3].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[3].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[3].party_id` | PRIMARY |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[3].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[3].revenue_minor` | 0 |
| Role · `accounting.campaign[3].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[4].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[4].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[4].party_id` | BACKUP |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[4].revenue_minor` | 0 |
| Role · `accounting.campaign[4].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[5].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[5].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[5].party_id` | COMPAT-A |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[5].revenue_minor` | 0 |
| Role · `accounting.campaign[5].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[6].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[6].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[6].party_id` | COMPAT-B |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[6].revenue_minor` | 0 |
| Role · `accounting.campaign[6].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Synthetic accounting unit · `accounting.currency` | SMU |
| Final ledger total (synthetic SMU minor units) · `accounting.final_total_minor` | 230100 |
| Initial ledger total (synthetic SMU minor units) · `accounting.initial_total_minor` | 230100 |
| Real contracts, payments or demand · `accounting.real_contracts_payments_or_demand` | Not established (`NOT_ESTABLISHED`) |
| Realized modeled buyer feasibility · `accounting.realized_buyer` | Not established (`NOT_ESTABLISHED`) |
| Assessment scope · `accounting.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| All correction costs (synthetic SMU minor units) · `accounting.total_correction_cost_minor` | 0 |
| All incurred campaign costs (synthetic SMU minor units) · `accounting.total_incurred_cost_minor` | 0 |
| All modeled settlement transfers (synthetic SMU minor units) · `accounting.total_transfers_minor` | 0 |
| Modeled trade settled · `accounting.trade_settled` | No |
| Accepted obligations · `totals.accepted_obligations` | 0 |
| Accepted quantity within contract · `totals.accepted_quantity` | 0 |
| Delivery attempts · `totals.delivery_attempts` | 0 |
| Duplicate accepted units · `totals.duplicate_acceptances` | 0 |
| Late quantity · `totals.late_quantity` | 0 |
| Missing quantity · `totals.missing_quantity` | 1900 |
| Produced quantity · `totals.produced_quantity` | 0 |
| Durable production attempts · `totals.production_attempts` | 0 |
| Received quantity · `totals.received_quantity` | 0 |
| Units accepted by the recipient component · `totals.recipient_accepted_quantity` | 0 |
| Rejected quantity · `totals.rejected_quantity` | 0 |
| Requested units in rejected deliveries · `totals.rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `totals.rejection_count` | 0 |
| Required active obligations · `totals.required_obligations` | 2 |
| Required quantity · `totals.required_quantity` | 1900 |
| Semantically correct units observed in time · `totals.timely_semantic_quantity` | 0 |
| Unsafe or unsupported commitments · `totals.unsafe_or_unsupported_commitments` | 0 |

## Measured resources and accounting gaps

Measured process resources and configured synthetic amounts have different meanings. Unrecorded preparation, integration, adaptation, verification or intervention effort remains unknown. Missing categories cannot support a complete-cost or cheaper-method conclusion.

| Field | Recorded value |
| --- | --- |
| Accounting gaps · `accounting_gaps[0]` | Preparation labor was not measured (`PREPARATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[1]` | Integration labor was not measured (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[2]` | Adaptation labor was not measured (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[3]` | Human verification labor was not measured (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[4]` | Monetary rates were not measured (`MONETARY_RATES_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Adaptation labor (seconds; unknown if absent) · `resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `resources.authority_storage_bytes_before_seal` | 30107 |
| Candidate restarts · `resources.candidate_restarts` | 0 |
| Launched child processes · `resources.child_processes` | 8 |
| Controller system CPU (ns) · `resources.controller_cpu_system_ns` | 11435999 |
| Controller user CPU (ns) · `resources.controller_cpu_user_ns` | 33210999 |
| System CPU (ns) · `resources.cpu_system_ns` | 85538000 |
| User CPU (ns) · `resources.cpu_user_ns` | 275463999 |
| Human interventions · `resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `resources.preparation_labor_seconds` | Not recorded |
| Requests · `resources.requests` | 0 |
| Retries · `resources.retries` | 0 |
| Internal service requests · `resources.service_requests` | 18 |
| Recorded storage (bytes) · `resources.storage_bytes` | 1216214 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `resources.wall_ns` | 468841508 |
| Worker restarts · `resources.worker_restarts` | 0 |
| Process CPU (ns) · `verification_resources.cpu_ns` | 31939113 |
| Evidence files inspected · `verification_resources.evidence_files_read` | 7 |
| Wall duration (ns) · `verification_resources.wall_ns` | 31939015 |

## Observed failures and counterexamples

No failure entry was recorded in this assessment. This is bounded evidence, not a general proof.

## Missing evidence and unresolved claims

No additional unresolved entry was recorded. Scope and unknown-cost limits still apply.

## Evidence references and byte integrity

Hashes identify bytes. They do not authenticate real customer instructions, establish source completeness, or replace an externally retained reference pin.

| Field | Recorded value |
| --- | --- |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 12e9efdb1268fda79504a6d9573e43f8014f1a6373807be4a1d16d7f145a9eb3 |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | de37a74d6fa131f6dee5f428fb5f0dbfde64f00ebd07d00be997741457899b50 |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | 632fe2c8fd78b3a6ad78e133589fd00780d3d557394c6fbd85e51b19df763daf |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | da4884b1418b6d539422fea233a3f1b72bc528a1becf4699118e8c771567c534 |
| `evidence_sha256.evidence/participants.sqlite` | ba8d1ad36c3de2b8547a9e42450d9d380cec95cbbc8f43f287f22aa2a0a27044 |
| `evidence_sha256.evidence/producer.sqlite` | 2d74dd8117e4114fd63b3e9064df388056aeff6ce777f504d8446f34172f070a |
| `evidence_sha256.evidence/receiver.sqlite` | 2462a01400ee006d1fb394e4533280926b1894802d73251aac92c5318ab992b9 |
| Structured result SHA-256 · `structured_result_sha256` | 0b682ed01318982713f0c10bd1e97fd72eb1f1809945ae8b3e3f868bd0796f46 |

## Recorded execution, faults, commands and provenance

Stable identifiers, exact commands, paths and original machine diagnostics are retained literally. They are data, not additional acceptance evidence. Source and host trust remain explicit in the architecture and threat model.

| Field | Recorded value |
| --- | --- |
| `authority_dir` | /workspace/scratch/b1d5891eb025/economy-qualification/base-attempt-1/authorities/technical-no-trade.outside |
| Experiment cohort · `cohort` | base |
| `contract.allow_split` | Yes |
| `contract.authority_kind` | Synthetic exercise authority (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | PRIMARY-HOST |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Experiment cohort · `contract.cohort` | base |
| Contract identity · `contract.contract_id` | DIGITAL-005 |
| `contract.cutoff_sequence` | 5 |
| Logical deadline · `contract.deadline_tick` | 500 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-001 |
| Registered fault schedule · `contract.fault_schedule` | No entries |
| Registered fixture identity · `contract.fixture_id` | technical-no-trade |
| `contract.lease_ticks` | 20 |
| `contract.lot_size` | 500 |
| `contract.max_attempts` | 2 |
| `contract.mode` | technical_control |
| Logical deadline · `contract.obligations[0].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[0].obligation_id` | DL-100 |
| Required quantity · `contract.obligations[0].quantity` | 1100 |
| Recipient · `contract.obligations[0].recipient` | RECIPIENT-A |
| Revision · `contract.obligations[0].revision` | 2 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[0].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[0].spec.lot` | BATCH-20261106 |
| `contract.obligations[0].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[0].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[0].spec.serial_prefix` | DL-100- |
| `contract.obligations[0].spec.sku` | KIT-DL-100 |
| Recorded status · `contract.obligations[0].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[1].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[1].obligation_id` | DL-200 |
| Required quantity · `contract.obligations[1].quantity` | 800 |
| Recipient · `contract.obligations[1].recipient` | RECIPIENT-B |
| Revision · `contract.obligations[1].revision` | 1 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[1].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[1].spec.lot` | BATCH-20261106 |
| `contract.obligations[1].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[1].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[1].spec.serial_prefix` | DL-200- |
| `contract.obligations[1].spec.sku` | KIT-DL-200 |
| Recorded status · `contract.obligations[1].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[2].deadline_tick` | 500 |
| Obligation identity · `contract.obligations[2].obligation_id` | DL-300 |
| Required quantity · `contract.obligations[2].quantity` | 100 |
| Recipient · `contract.obligations[2].recipient` | RECIPIENT-C |
| Revision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[2].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[2].spec.lot` | BATCH-20261106 |
| `contract.obligations[2].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[2].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[2].spec.serial_prefix` | DL-300- |
| `contract.obligations[2].spec.sku` | KIT-DL-300 |
| Recorded status · `contract.obligations[2].status` | Cancelled (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 800 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | PRIMARY-HOST |
| `contract.providers[0].permissions.disclosure` | Yes |
| `contract.providers[0].permissions.production` | Yes |
| Provider identity · `contract.providers[0].provider_id` | PRIMARY |
| Role · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 2400 |
| `contract.providers[0].windows[0].end` | 800 |
| `contract.providers[0].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[0].windows[0].window_id` | W0 |
| `contract.providers[1].dependency` | BACKUP-HOST |
| `contract.providers[1].permissions.disclosure` | Yes |
| `contract.providers[1].permissions.production` | Yes |
| Provider identity · `contract.providers[1].provider_id` | BACKUP |
| Role · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 2400 |
| `contract.providers[1].windows[0].end` | 800 |
| `contract.providers[1].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[1].windows[0].window_id` | W0 |
| `contract.providers[2].dependency` | COMPAT-A-HOST |
| `contract.providers[2].permissions.disclosure` | Yes |
| `contract.providers[2].permissions.production` | Yes |
| Provider identity · `contract.providers[2].provider_id` | COMPAT-A |
| Role · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 1200 |
| `contract.providers[2].windows[0].end` | 800 |
| `contract.providers[2].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[2].windows[0].window_id` | W0 |
| `contract.providers[3].dependency` | COMPAT-B-HOST |
| `contract.providers[3].permissions.disclosure` | Yes |
| `contract.providers[3].permissions.production` | Yes |
| Provider identity · `contract.providers[3].provider_id` | COMPAT-B |
| Role · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 1100 |
| `contract.providers[3].windows[0].end` | 800 |
| `contract.providers[3].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[3].windows[0].window_id` | W0 |
| Revision · `contract.revision` | 1 |
| `contract.revocations` | No entries |
| Run identity · `contract.run_id` | technical-no-trade.outside.f27925053d |
| Schema · `contract.schema` | continuity-economy/contract/v1 |
| Recorded seed · `contract.seed` | 705 |
| `contract.source_complete` | Yes |
| Logical deadline · `contract.source_events[0].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[0].obligation.obligation_id` | DL-100 |
| Required quantity · `contract.source_events[0].obligation.quantity` | 1000 |
| Recipient · `contract.source_events[0].obligation.recipient` | RECIPIENT-A |
| Revision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Obsolete instruction. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Instruction périmée. |
| `contract.source_events[0].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[0].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[0].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[0].obligation.spec.sku` | KIT-DL-100 |
| Recorded status · `contract.source_events[0].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[0].obligation_id` | DL-100 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Logical deadline · `contract.source_events[1].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[1].obligation.obligation_id` | DL-200 |
| Required quantity · `contract.source_events[1].obligation.quantity` | 800 |
| Recipient · `contract.source_events[1].obligation.recipient` | RECIPIENT-B |
| Revision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[1].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[1].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[1].obligation.spec.serial_prefix` | DL-200- |
| `contract.source_events[1].obligation.spec.sku` | KIT-DL-200 |
| Recorded status · `contract.source_events[1].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[1].obligation_id` | DL-200 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Logical deadline · `contract.source_events[2].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[2].obligation.obligation_id` | DL-300 |
| Required quantity · `contract.source_events[2].obligation.quantity` | 100 |
| Recipient · `contract.source_events[2].obligation.recipient` | RECIPIENT-C |
| Revision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[2].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[2].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[2].obligation.spec.serial_prefix` | DL-300- |
| `contract.source_events[2].obligation.spec.sku` | KIT-DL-300 |
| Recorded status · `contract.source_events[2].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[2].obligation_id` | DL-300 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Logical deadline · `contract.source_events[3].obligation.deadline_tick` | 500 |
| Obligation identity · `contract.source_events[3].obligation.obligation_id` | DL-100 |
| Required quantity · `contract.source_events[3].obligation.quantity` | 1100 |
| Recipient · `contract.source_events[3].obligation.recipient` | RECIPIENT-A |
| Revision · `contract.source_events[3].obligation.revision` | 2 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[3].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[3].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[3].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[3].obligation.spec.sku` | KIT-DL-100 |
| Recorded status · `contract.source_events[3].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[3].obligation_id` | DL-100 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | AMEND |
| Obligation identity · `contract.source_events[4].obligation_id` | DL-300 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | CANCEL |
| `contract.source_id` | AUTHORED-DIGITAL-EVENTS |
| Source byte hashes · `contract.source_sha256` | 8d6a71fd1c26021120a5283bd7cf3eb7812b5c34ae6a4da3eec94dceaf8f7b81 |
| Start clock (ns) · `contract.start_ns` | 33707656765272 |
| Elapsed-time deadline (ms) · `contract.wall_deadline_ms` | 60000 |
| `controller.capacity_databases[0].path` | evidence/capacity/PRIMARY.W0.sqlite |
| Provider identity · `controller.capacity_databases[0].provider_id` | PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Capacity-window identity · `controller.capacity_databases[0].window_id` | W0 |
| `controller.capacity_databases[1].path` | evidence/capacity/BACKUP.W0.sqlite |
| Provider identity · `controller.capacity_databases[1].provider_id` | BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Capacity-window identity · `controller.capacity_databases[1].window_id` | W0 |
| `controller.capacity_databases[2].path` | evidence/capacity/COMPAT-A.W0.sqlite |
| Provider identity · `controller.capacity_databases[2].provider_id` | COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Capacity-window identity · `controller.capacity_databases[2].window_id` | W0 |
| `controller.capacity_databases[3].path` | evidence/capacity/COMPAT-B.W0.sqlite |
| Provider identity · `controller.capacity_databases[3].provider_id` | COMPAT-B |
| `controller.capacity_databases[3].route` | backup |
| Capacity-window identity · `controller.capacity_databases[3].window_id` | W0 |
| `controller.clock_tick` | 0 |
| Experiment cohort · `controller.cohort` | base |
| Retained contract SHA-256 · `controller.contract_sha256` | 92ac3697cf25ee31dd9c1b7b0abb27204ab4c48565d1d48da80f3f67c0579e04 |
| `controller.db_snapshots.evidence/capacity/BACKUP.W0.sqlite` | fdf419a66157fc36cecded24bf98e803bd250f3b7e9d58cd9fa6e411fa6b1433 |
| `controller.db_snapshots.evidence/capacity/COMPAT-A.W0.sqlite` | baf94db52aa24ab7aba36b22c68ac7a33901d22579082ba13fcca21a171009bc |
| `controller.db_snapshots.evidence/capacity/COMPAT-B.W0.sqlite` | 4dcf546728a6a15eb98f46c45811a7826c404e74468b83fa9efb3f5f10c29621 |
| `controller.db_snapshots.evidence/capacity/PRIMARY.W0.sqlite` | c7f30609b4b229b98428f91998bf41aa16108d41458237e25a7fc02397470213 |
| `controller.db_snapshots.evidence/participants.sqlite` | 9efff035234e732211d72c5dd685978089a56ccbff47eb6f7de289edb3d71e71 |
| `controller.db_snapshots.evidence/producer.sqlite` | c59cc63eb482cb39bc4e41c4a55cb741fc11b918a3031638fe798659afdd3e8e |
| `controller.db_snapshots.evidence/receiver.sqlite` | da046cc340c4fa4dd6cac281b7b1a87f2ccbca9e9dd763a189cb1d4e18d81cd1 |
| `controller.errors` | No entries |
| `controller.events[0].detail.authority_kind` | Synthetic exercise authority (`SYNTHETIC_EXERCISE`) |
| External reference pin · `controller.events[0].detail.reference_sha256` | 96eb35b0f8176f788922dee81a135a23be0cc14ea4f4e6bef98025d227ff0b81 |
| Recorded seed · `controller.events[0].detail.seed` | 705 |
| Recorded event · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 33707674860426 |
| Logical tick · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 167 |
| `controller.events[1].detail.restart` | No |
| `controller.events[1].detail.service` | participants |
| Recorded event · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 33707717096407 |
| Logical tick · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 168 |
| `controller.events[2].detail.restart` | No |
| `controller.events[2].detail.service` | producer |
| Recorded event · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 33707752566518 |
| Logical tick · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 169 |
| `controller.events[3].detail.restart` | No |
| `controller.events[3].detail.service` | receiver |
| Recorded event · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 33707789803785 |
| Logical tick · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 170 |
| Provider identity · `controller.events[4].detail.provider_id` | PRIMARY |
| Capacity-window identity · `controller.events[4].detail.window_id` | W0 |
| Recorded event · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 33707835432187 |
| Logical tick · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 171 |
| Provider identity · `controller.events[5].detail.provider_id` | BACKUP |
| Capacity-window identity · `controller.events[5].detail.window_id` | W0 |
| Recorded event · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 33707883883510 |
| Logical tick · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 172 |
| Provider identity · `controller.events[6].detail.provider_id` | COMPAT-A |
| Capacity-window identity · `controller.events[6].detail.window_id` | W0 |
| Recorded event · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 33707926516200 |
| Logical tick · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 173 |
| Provider identity · `controller.events[7].detail.provider_id` | COMPAT-B |
| Capacity-window identity · `controller.events[7].detail.window_id` | W0 |
| Recorded event · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 33707969510537 |
| Logical tick · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.affected[0]` | PRIMARY.W0 |
| `controller.events[8].detail.dependency` | PRIMARY-HOST |
| Recorded event · `controller.events[8].event` | DEPENDENCY_DISABLED |
| `controller.events[8].monotonic_ns` | 33707970623118 |
| Logical tick · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.isolation.applied` | Yes |
| `controller.events[9].detail.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.events[9].detail.isolation.probe.authority_open_denied` | Yes |
| `controller.events[9].detail.isolation.probe.network_denied` | Yes |
| `controller.events[9].detail.isolation.probe.process_inspection_denied` | Yes |
| `controller.events[9].detail.isolation.probe.spawn_denied` | Yes |
| `controller.events[9].detail.isolation.probe.workspace_open_denied` | Yes |
| `controller.events[9].detail.pid` | 174 |
| `controller.events[9].detail.restart` | No |
| Recorded event · `controller.events[9].event` | CANDIDATE_STARTED |
| `controller.events[9].monotonic_ns` | 33708013211606 |
| Logical tick · `controller.events[9].tick` | 0 |
| Recorded interventions · `controller.events[10].detail.interventions` | No entries |
| Recorded reason · `controller.events[10].detail.reason` | VOLUNTARY_NO_PURCHASE |
| `controller.events[10].detail.searches` | No entries |
| Component verdict · `controller.events[10].detail.verdict` | OUTSIDE_OPTION |
| Recorded event · `controller.events[10].event` | CANDIDATE_DONE |
| `controller.events[10].monotonic_ns` | 33708014904845 |
| Logical tick · `controller.events[10].tick` | 0 |
| `controller.events[11].detail.database` | participants |
| `controller.events[11].detail.sqlite[0]` | 0 |
| `controller.events[11].detail.sqlite[1]` | 0 |
| `controller.events[11].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[11].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[11].event` | DATABASE_CHECKPOINT |
| `controller.events[11].monotonic_ns` | 33708024426984 |
| Logical tick · `controller.events[11].tick` | 0 |
| `controller.events[12].detail.database` | producer |
| `controller.events[12].detail.sqlite[0]` | 0 |
| `controller.events[12].detail.sqlite[1]` | 0 |
| `controller.events[12].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[12].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[12].event` | DATABASE_CHECKPOINT |
| `controller.events[12].monotonic_ns` | 33708025290439 |
| Logical tick · `controller.events[12].tick` | 0 |
| `controller.events[13].detail.database` | receiver |
| `controller.events[13].detail.sqlite[0]` | 0 |
| `controller.events[13].detail.sqlite[1]` | 0 |
| `controller.events[13].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[13].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[13].event` | DATABASE_CHECKPOINT |
| `controller.events[13].monotonic_ns` | 33708026297161 |
| Logical tick · `controller.events[13].tick` | 0 |
| `controller.events[14].detail.database` | PRIMARY.W0 |
| `controller.events[14].detail.sqlite[0]` | 0 |
| `controller.events[14].detail.sqlite[1]` | 0 |
| `controller.events[14].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[14].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[14].event` | DATABASE_CHECKPOINT |
| `controller.events[14].monotonic_ns` | 33708027284312 |
| Logical tick · `controller.events[14].tick` | 0 |
| `controller.events[15].detail.database` | BACKUP.W0 |
| `controller.events[15].detail.sqlite[0]` | 0 |
| `controller.events[15].detail.sqlite[1]` | 0 |
| `controller.events[15].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[15].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[15].event` | DATABASE_CHECKPOINT |
| `controller.events[15].monotonic_ns` | 33708028316652 |
| Logical tick · `controller.events[15].tick` | 0 |
| `controller.events[16].detail.database` | COMPAT-A.W0 |
| `controller.events[16].detail.sqlite[0]` | 0 |
| `controller.events[16].detail.sqlite[1]` | 0 |
| `controller.events[16].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[16].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[16].event` | DATABASE_CHECKPOINT |
| `controller.events[16].monotonic_ns` | 33708029175180 |
| Logical tick · `controller.events[16].tick` | 0 |
| `controller.events[17].detail.database` | COMPAT-B.W0 |
| `controller.events[17].detail.sqlite[0]` | 0 |
| `controller.events[17].detail.sqlite[1]` | 0 |
| `controller.events[17].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[17].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[17].event` | DATABASE_CHECKPOINT |
| `controller.events[17].monotonic_ns` | 33708030962420 |
| Logical tick · `controller.events[17].tick` | 0 |
| `controller.events[18].detail.databases` | 7 |
| `controller.events[18].detail.snapshot_method` | SQLITE_BACKUP_DELETE_FULL_LOGICAL_DIGEST |
| Recorded event · `controller.events[18].event` | EVIDENCE_FINALIZED |
| `controller.events[18].monotonic_ns` | 33708125638717 |
| Logical tick · `controller.events[18].tick` | 0 |
| Registered fault schedule · `controller.fault_schedule` | No entries |
| Actually observed faults · `controller.faults_observed` | No entries |
| `controller.finished_monotonic_ns` | 33708125641762 |
| Registered fixture identity · `controller.fixture_id` | technical-no-trade |
| Uncommitted source changes present · `controller.implementation.dirty` | No |
| Exact process arguments · `controller.implementation.environment.argv[0]` | python3 |
| Exact process arguments · `controller.implementation.environment.argv[1]` | -m |
| Exact process arguments · `controller.implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `controller.implementation.environment.argv[3]` | --language |
| Exact process arguments · `controller.implementation.environment.argv[4]` | en |
| Exact process arguments · `controller.implementation.environment.argv[5]` | compare |
| Exact process arguments · `controller.implementation.environment.argv[6]` | --out |
| Exact process arguments · `controller.implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-qualification/base-attempt-1 |
| Operating platform · `controller.implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `controller.implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `controller.implementation.environment.sqlite_version` | 3.53.1 |
| Execution directory · `controller.implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-qualified-base |
| Actual source commit · `controller.implementation.git_commit` | 080a5484d1ff26fe04aac32078d9ea9ef2f739f4 |
| Preserved capacity implementation baseline · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Implementation version · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Yes |
| `controller.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Yes |
| `controller.isolation.probe.network_denied` | Yes |
| `controller.isolation.probe.process_inspection_denied` | Yes |
| `controller.isolation.probe.spawn_denied` | Yes |
| `controller.isolation.probe.workspace_open_denied` | Yes |
| Candidate procedure · `controller.method` | outside |
| `controller.policies_sha256` | 54ea9c4129a699ed11437e26752eaeda009319dc0dacc85d68615e36e38fd21b |
| Adaptation labor (seconds; unknown if absent) · `controller.resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `controller.resources.authority_storage_bytes_before_seal` | 30107 |
| Candidate restarts · `controller.resources.candidate_restarts` | 0 |
| Launched child processes · `controller.resources.child_processes` | 8 |
| Controller system CPU (ns) · `controller.resources.controller_cpu_system_ns` | 11435999 |
| Controller user CPU (ns) · `controller.resources.controller_cpu_user_ns` | 33210999 |
| System CPU (ns) · `controller.resources.cpu_system_ns` | 85538000 |
| User CPU (ns) · `controller.resources.cpu_user_ns` | 275463999 |
| Human interventions · `controller.resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `controller.resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `controller.resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `controller.resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `controller.resources.preparation_labor_seconds` | Not recorded |
| Requests · `controller.resources.requests` | 0 |
| Retries · `controller.resources.retries` | 0 |
| Internal service requests · `controller.resources.service_requests` | 18 |
| Recorded storage (bytes) · `controller.resources.storage_bytes` | 1216214 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `controller.resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `controller.resources.wall_ns` | 468841508 |
| Worker restarts · `controller.resources.worker_restarts` | 0 |
| Run identity · `controller.run_id` | technical-no-trade.outside.f27925053d |
| Schema · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 33707656800254 |
| `controller.started_utc` | 2026-11-06T22:58:29.769666+00:00 |
| `controller.state` | Complete verification (`COMPLETE`) |
| Target verdict · `controller.target_verdict` | OUTSIDE_OPTION |
| Registered fault schedule · `fault_schedule` | No entries |
| Actually observed faults · `faults_observed` | No entries |
| Registered fixture identity · `fixture_id` | technical-no-trade |
| Uncommitted source changes present · `implementation.dirty` | No |
| Exact process arguments · `implementation.environment.argv[0]` | python3 |
| Exact process arguments · `implementation.environment.argv[1]` | -m |
| Exact process arguments · `implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `implementation.environment.argv[3]` | --language |
| Exact process arguments · `implementation.environment.argv[4]` | en |
| Exact process arguments · `implementation.environment.argv[5]` | compare |
| Exact process arguments · `implementation.environment.argv[6]` | --out |
| Exact process arguments · `implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-qualification/base-attempt-1 |
| Operating platform · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `implementation.environment.sqlite_version` | 3.53.1 |
| Execution directory · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-qualified-base |
| Actual source commit · `implementation.git_commit` | 080a5484d1ff26fe04aac32078d9ea9ef2f739f4 |
| Preserved capacity implementation baseline · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Implementation version · `implementation.version` | 0.2.0 |
| Candidate procedure · `method` | outside |
| Balance (synthetic SMU minor units) · `policies.buyer.balance_minor` | 100 |
| `policies.buyer.consent_until_tick` | 800 |
| `policies.buyer.max_price_minor` | 100 |
| Authored outside-option utility (synthetic SMU minor units) · `policies.buyer.outside_utility_minor` | 2000 |
| Participant identity · `policies.buyer.party_id` | BUYER |
| Authored value upper bound (synthetic SMU minor units) · `policies.buyer.value_max_minor` | 100 |
| Authored value lower bound (synthetic SMU minor units) · `policies.buyer.value_min_minor` | 100 |
| Balance (synthetic SMU minor units) · `policies.coordinator.balance_minor` | 10000 |
| `policies.coordinator.consent_until_tick` | 800 |
| `policies.coordinator.liability_limit_minor` | 10000 |
| `policies.coordinator.min_profit_minor` | 100 |
| `policies.coordinator.operating_cost_minor` | 200 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.coordinator.outside_profit_minor` | 100 |
| Participant identity · `policies.coordinator.party_id` | COORDINATOR |
| `policies.coordinator.technical_control_allowed` | Yes |
| Synthetic accounting unit · `policies.currency` | SMU |
| Balance (synthetic SMU minor units) · `policies.providers[0].balance_minor` | 40000 |
| `policies.providers[0].consent_until_tick` | 800 |
| `policies.providers[0].liability_limit_minor` | 40000 |
| `policies.providers[0].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[0].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[0].party_id` | PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 100 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 100 |
| `policies.providers[0].technical_control_allowed` | Yes |
| `policies.providers[0].unit_cost_minor` | 1 |
| Balance (synthetic SMU minor units) · `policies.providers[1].balance_minor` | 40000 |
| `policies.providers[1].consent_until_tick` | 800 |
| `policies.providers[1].liability_limit_minor` | 40000 |
| `policies.providers[1].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[1].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[1].party_id` | BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 150 |
| `policies.providers[1].rework_unit_cost_minor` | 2 |
| `policies.providers[1].setup_cost_minor` | 150 |
| `policies.providers[1].technical_control_allowed` | Yes |
| `policies.providers[1].unit_cost_minor` | 2 |
| Balance (synthetic SMU minor units) · `policies.providers[2].balance_minor` | 40000 |
| `policies.providers[2].consent_until_tick` | 800 |
| `policies.providers[2].liability_limit_minor` | 40000 |
| `policies.providers[2].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[2].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[2].party_id` | COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 200 |
| `policies.providers[2].rework_unit_cost_minor` | 3 |
| `policies.providers[2].setup_cost_minor` | 200 |
| `policies.providers[2].technical_control_allowed` | Yes |
| `policies.providers[2].unit_cost_minor` | 3 |
| Balance (synthetic SMU minor units) · `policies.providers[3].balance_minor` | 40000 |
| `policies.providers[3].consent_until_tick` | 800 |
| `policies.providers[3].liability_limit_minor` | 40000 |
| `policies.providers[3].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[3].outside_profit_minor` | 100 |
| Participant identity · `policies.providers[3].party_id` | COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 300 |
| `policies.providers[3].rework_unit_cost_minor` | 3 |
| `policies.providers[3].setup_cost_minor` | 300 |
| `policies.providers[3].technical_control_allowed` | Yes |
| `policies.providers[3].unit_cost_minor` | 3 |
| Revision · `policies.revision` | 1 |
| Schema · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Yes |
| Balance (synthetic SMU minor units) · `policies.technical_sponsor.balance_minor` | 60000 |
| Participant identity · `policies.technical_sponsor.party_id` | TECHNICAL-SPONSOR |
| External reference pin · `reference_sha256` | 96eb35b0f8176f788922dee81a135a23be0cc14ea4f4e6bef98025d227ff0b81 |
| `registered_assertion.expected.accepted_units` | 0 |
| Outcome · `registered_assertion.expected.outcome` | Failed (`FAILED`) |
| `registered_assertion.expected.service_feasibility` | Not established (`NOT_ESTABLISHED`) |
| `registered_assertion.observed.accepted_units` | 0 |
| Outcome · `registered_assertion.observed.outcome` | Failed (`FAILED`) |
| `registered_assertion.observed.service_feasibility` | Not established (`NOT_ESTABLISHED`) |
| Assessment scope · `registered_assertion.scope` | Registered assessment assertion; it does not assert a favorable outcome or trade. |
| Recorded status · `registered_assertion.status` | Passed (`PASSED`) |
| Uncommitted source changes present · `source_version.dirty` | No |
| Exact process arguments · `source_version.environment.argv[0]` | python3 |
| Exact process arguments · `source_version.environment.argv[1]` | -m |
| Exact process arguments · `source_version.environment.argv[2]` | continuity_economy |
| Exact process arguments · `source_version.environment.argv[3]` | --language |
| Exact process arguments · `source_version.environment.argv[4]` | en |
| Exact process arguments · `source_version.environment.argv[5]` | compare |
| Exact process arguments · `source_version.environment.argv[6]` | --out |
| Exact process arguments · `source_version.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-qualification/base-attempt-1 |
| Operating platform · `source_version.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `source_version.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `source_version.environment.sqlite_version` | 3.53.1 |
| Execution directory · `source_version.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-qualified-base |
| Actual source commit · `source_version.git_commit` | 080a5484d1ff26fe04aac32078d9ea9ef2f739f4 |
| Preserved capacity implementation baseline · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Implementation version · `source_version.version` | 0.2.0 |
| Explicit trust assumptions · `trust_assumptions[0]` | Trusted host, kernel, controller and clock (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Explicit trust assumptions · `trust_assumptions[1]` | Trusted retained synthetic authority (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Explicit trust assumptions · `trust_assumptions[2]` | Shared authorship; no third-party certification (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Explicit trust assumptions · `trust_assumptions[3]` | Semantic digital content only; physical delivery is untested (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Registered faults not triggered · `untriggered_faults` | No entries |

## Complete structured verification record

The same structured record generates both language versions. Machine keys, enum codes and literal evidence values remain unchanged; the localized sections above explain their meaning. No saved result is reused as fresh proof.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 0,
    "buyer_utility_interval_minor": {
      "maximum": null,
      "minimum": null
    },
    "campaign": [
      {
        "final_balance_minor": 100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 100,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 10000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 230100,
    "initial_total_minor": 230100,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "NOT_ESTABLISHED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 0,
    "total_transfers_minor": 0,
    "trade_settled": false
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "FAILED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "OUTSIDE_OPTION",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "FAILED",
    "service_feasibility": "NOT_ESTABLISHED"
  },
  "cohort": "base",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "92ac3697cf25ee31dd9c1b7b0abb27204ab4c48565d1d48da80f3f67c0579e04",
  "evidence_sha256": {
    "evidence/capacity/BACKUP.W0.sqlite": "12e9efdb1268fda79504a6d9573e43f8014f1a6373807be4a1d16d7f145a9eb3",
    "evidence/capacity/COMPAT-A.W0.sqlite": "de37a74d6fa131f6dee5f428fb5f0dbfde64f00ebd07d00be997741457899b50",
    "evidence/capacity/COMPAT-B.W0.sqlite": "632fe2c8fd78b3a6ad78e133589fd00780d3d557394c6fbd85e51b19df763daf",
    "evidence/capacity/PRIMARY.W0.sqlite": "da4884b1418b6d539422fea233a3f1b72bc528a1becf4699118e8c771567c534",
    "evidence/participants.sqlite": "ba8d1ad36c3de2b8547a9e42450d9d380cec95cbbc8f43f287f22aa2a0a27044",
    "evidence/producer.sqlite": "2d74dd8117e4114fd63b3e9064df388056aeff6ce777f504d8446f34172f070a",
    "evidence/receiver.sqlite": "2462a01400ee006d1fb394e4533280926b1894802d73251aac92c5318ab992b9"
  },
  "failures": [],
  "fault_schedule": [],
  "faults_observed": [],
  "fixture_id": "technical-no-trade",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "compare",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-qualification/base-attempt-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-qualified-base"
    },
    "git_commit": "080a5484d1ff26fe04aac32078d9ea9ef2f739f4",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b"
    },
    "version": "0.2.0"
  },
  "method": "outside",
  "per_arrangement": [],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "UNFULFILLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNFULFILLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "96eb35b0f8176f788922dee81a135a23be0cc14ea4f4e6bef98025d227ff0b81",
  "registered_assertion": {
    "expected": {
      "accepted_units": 0,
      "outcome": "FAILED",
      "service_feasibility": "NOT_ESTABLISHED"
    },
    "observed": {
      "accepted_units": 0,
      "outcome": "FAILED",
      "service_feasibility": "NOT_ESTABLISHED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "PASSED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30107,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 11435999,
    "controller_cpu_user_ns": 33210999,
    "cpu_system_ns": 85538000,
    "cpu_user_ns": 275463999,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 0,
    "retries": 0,
    "service_requests": 18,
    "storage_bytes": 1216214,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 468841508,
    "worker_restarts": 0
  },
  "run_id": "technical-no-trade.outside.f27925053d",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "compare",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-qualification/base-attempt-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-qualified-base"
    },
    "git_commit": "080a5484d1ff26fe04aac32078d9ea9ef2f739f4",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 0,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 0,
    "production_attempts": 0,
    "received_quantity": 0,
    "recipient_accepted_quantity": 0,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 0,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 31939113,
    "evidence_files_read": 7,
    "wall_ns": 31939015
  },
  "verification_status": "COMPLETE",
  "verification_wall_ns": 31996802,
  "verifier_version": "0.2.0"
}
```
