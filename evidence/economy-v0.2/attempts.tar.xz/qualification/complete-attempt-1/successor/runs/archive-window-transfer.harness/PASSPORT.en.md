# CONTINUITY Ω Harness — Economy of continuity

**Digital-product experiment · version 0.2.0**

Preserve a promise through a viable, voluntarily accepted continuity arrangement.

**Scope: disposable local processes and a specified digital product. Authored synthetic policies, consent, values, funding and SMU cash flows are model inputs and observations. They do not establish real contracts, demand, payments, sales, printed goods, rendered appearance or print quality.**

This Passport presents the recorded assessment. Fresh verification must inspect retained authority, actual durable output and recipient evidence; this document is never its oracle.

<!-- structured-result-sha256: ada2d60a3c9935da6c0cac0766419c12bcafa9e4e596123aaf896155941bd18c -->

## Three distinct claims

| Claim | Recorded status |
| --- | --- |
| Required digital work accepted within the frozen conditions | Demonstrated in scope (`DEMONSTRATED`) |
| Service feasibility under the authored synthetic model | Demonstrated in scope (`DEMONSTRATED`) |
| Method advantage over competent alternatives | Not established (`NOT_ESTABLISHED`) |
| Safety within the exercised failure model | Demonstrated in scope (`DEMONSTRATED`) |

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

## Assessment fields kept separate

| Field | Recorded value |
| --- | --- |
| Test assertion | Passed (`PASSED`) |
| Component verdict | Completed (`COMPLETED`) |
| Evidence stage | Local digital-product execution (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| Assessed claim status | Demonstrated in scope (`DEMONSTRATED`) |

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

## Identity, authority and versions

| Field | Recorded value |
| --- | --- |
| Authority evidence status · `authority_status` | Established for the synthetic exercise only (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Real commercial value · `commercial_value` | Not established (`NOT_ESTABLISHED`) |
| Contract identity · `contract_id` | DIGITAL-ARCHIVE-001 |
| Retained contract SHA-256 · `contract_sha256` | da2441381af31c8e77df5382e02000b5af8132310fe7e6f533f9f0d252d5782e |
| Real customer authenticity · `real_customer_authenticity` | Not established (`NOT_ESTABLISHED`) |
| External reference pin · `reference_sha256` | 52f77f91846c3eae93acdc9efdd7faa52f499f7eb2df5be8443fda2fc43af369 |
| Run identity · `run_id` | archive-window-transfer.harness.938d770fd7 |
| Schema · `schema` | continuity-economy/verification/v1 |
| Verification completion status · `verification_status` | Complete verification (`COMPLETE`) |
| Verifier version · `verifier_version` | 0.2.0 |

## Per-obligation execution and acceptance

Counts describe the recorded stage. Rejected and corrected attempts remain distinct. A produced or received unit is not automatically accepted. Missing measurements are not displayed as zero.

| Obligation | Recipient | Revision | Required | Produced | Received | Rejected | Accepted within contract | Outcome |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ARC-410 | RECIPIENT-NORD | 3 | 420 | 420 | 420 | 0 | 420 | Completed (`COMPLETED`) |
| ARC-520 | RECIPIENT-EST | 2 | 330 | 330 | 330 | 0 | 330 | Completed (`COMPLETED`) |
| ARC-630 | RECIPIENT-SUD | 1 | 270 | 270 | 270 | 0 | 270 | Completed (`COMPLETED`) |
| ARC-740 | RECIPIENT-OUEST | 1 | 0 | 0 | 0 | 0 | 0 | Cancelled (`CANCELLED`) |

### Obligation `ARC-410`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 420 |
| Logical deadline · `deadline_tick` | 130 |
| Delivery attempts · `delivery_attempts` | 3 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | ARC-410 |
| Outcome · `outcome` | Completed (`COMPLETED`) |
| Produced quantity · `produced_quantity` | 420 |
| Durable production attempts · `production_attempts` | 3 |
| Required quantity · `quantity` | 420 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 420 |
| Recipient · `recipient` | RECIPIENT-NORD |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 420 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 420 |
| Revision · `revision` | 3 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 420 |

### Obligation `ARC-520`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 330 |
| Logical deadline · `deadline_tick` | 440 |
| Delivery attempts · `delivery_attempts` | 3 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | ARC-520 |
| Outcome · `outcome` | Completed (`COMPLETED`) |
| Produced quantity · `produced_quantity` | 330 |
| Durable production attempts · `production_attempts` | 3 |
| Required quantity · `quantity` | 330 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 330 |
| Recipient · `recipient` | RECIPIENT-EST |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 330 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 330 |
| Revision · `revision` | 2 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 330 |

### Obligation `ARC-630`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 270 |
| Logical deadline · `deadline_tick` | 520 |
| Delivery attempts · `delivery_attempts` | 2 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | ARC-630 |
| Outcome · `outcome` | Completed (`COMPLETED`) |
| Produced quantity · `produced_quantity` | 270 |
| Durable production attempts · `production_attempts` | 2 |
| Required quantity · `quantity` | 270 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 270 |
| Recipient · `recipient` | RECIPIENT-SUD |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 270 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 270 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 270 |

### Obligation `ARC-740`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 360 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | ARC-740 |
| Outcome · `outcome` | Cancelled (`CANCELLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 90 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-OUEST |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 0 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Cancelled (`CANCELLED`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

## Proposals, modeled decisions and arrangements

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-001`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids[0]` | proposal-001.ARC-410.L001.A1.D |
| Acceptance references · `acceptance_ids[1]` | proposal-001.ARC-410.L002.A1.D |
| Acceptance references · `acceptance_ids[2]` | proposal-001.ARC-410.L003.A1.D |
| Acceptance references · `acceptance_ids[3]` | proposal-001.ARC-520.L001.A1.D |
| Acceptance references · `acceptance_ids[4]` | proposal-001.ARC-520.L002.A1.D |
| Acceptance references · `acceptance_ids[5]` | proposal-001.ARC-520.L003.A1.D |
| Acceptance references · `acceptance_ids[6]` | proposal-001.ARC-630.L001.A1.D |
| Acceptance references · `acceptance_ids[7]` | proposal-001.ARC-630.L002.A1.D |
| Agreement acceptance tick · `accepted_tick` | 3 |
| Agreement identity · `agreement_id` | proposal-001 |
| Cancellation tick · `cancelled_tick` | Not recorded |
| Incurred correction cost (synthetic SMU minor units) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Incurred cost (synthetic SMU minor units) · `incurred_cost_minor` | 2790 |
| Break-even buyer value (synthetic SMU minor units) · `independent_terms.break_even_value_minor` | 7500 |
| Buyer price ceiling at the lower value bound (synthetic SMU minor units) · `independent_terms.buyer_definite_max_price_minor` | 6400 |
| Buyer price ceiling at the upper value bound (synthetic SMU minor units) · `independent_terms.buyer_possible_max_price_minor` | 7000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU minor units) · `independent_terms.minimum_buyer_price_minor` | 5700 |
| Minimum coordinator fee (synthetic SMU minor units) · `independent_terms.minimum_coordinator_fee_minor` | 290 |
| Base production cost (synthetic SMU minor units) · `independent_terms.providers[0].base_cost_minor` | 2040 |
| Modeled profit after maximum specified rework (synthetic SMU minor units) · `independent_terms.providers[0].guaranteed_profit_minor` | 260 |
| Maximum unpaid cost exposure (synthetic SMU minor units) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 3960 |
| Minimum provider payment (synthetic SMU minor units) · `independent_terms.providers[0].minimum_payment_minor` | 4220 |
| Required participation profit (synthetic SMU minor units) · `independent_terms.providers[0].participation_profit_minor` | 260 |
| Participant identity · `independent_terms.providers[0].party_id` | ARCHIVE-COMPAT-A |
| Promised provider payment (synthetic SMU minor units) · `independent_terms.providers[0].promised_payment_minor` | 4220 |
| Maximum correction cost (synthetic SMU minor units) · `independent_terms.providers[0].rework_cost_minor` | 1920 |
| Units · `independent_terms.providers[0].units` | 900 |
| Base production cost (synthetic SMU minor units) · `independent_terms.providers[1].base_cost_minor` | 570 |
| Modeled profit after maximum specified rework (synthetic SMU minor units) · `independent_terms.providers[1].guaranteed_profit_minor` | 200 |
| Maximum unpaid cost exposure (synthetic SMU minor units) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 990 |
| Minimum provider payment (synthetic SMU minor units) · `independent_terms.providers[1].minimum_payment_minor` | 1190 |
| Required participation profit (synthetic SMU minor units) · `independent_terms.providers[1].participation_profit_minor` | 200 |
| Participant identity · `independent_terms.providers[1].party_id` | ARCHIVE-COMPAT-B |
| Promised provider payment (synthetic SMU minor units) · `independent_terms.providers[1].promised_payment_minor` | 1190 |
| Maximum correction cost (synthetic SMU minor units) · `independent_terms.providers[1].rework_cost_minor` | 420 |
| Units · `independent_terms.providers[1].units` | 120 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2340 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | Modeled trade agreement (`TRADE`) |
| Stable code · `participant_decisions[0].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[0].party_id` | BUYER-ARCHIVE |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[1].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[1].party_id` | ARCHIVE-COMPAT-A |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[2].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[2].party_id` | ARCHIVE-COMPAT-B |
| Role · `participant_decisions[2].role` | provider |
| Component verdict · `participant_decisions[2].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[3].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[3].party_id` | COORDINATOR-ARCHIVE |
| Role · `participant_decisions[3].role` | coordinator |
| Component verdict · `participant_decisions[3].verdict` | Accepted (`ACCEPTED`) |
| Modeled payments (synthetic SMU minor units) · `payments_minor` | 5700 |
| Proposal identity · `proposal_id` | proposal-001 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 150 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | ARC-410.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | ARC-410 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 4220 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | EARLY |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 151 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 300 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | ARC-410.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | ARC-410 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | EARLY |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 301 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 420 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | ARC-410.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | ARC-410 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | EARLY |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 150 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | ARC-520.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | ARC-520 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | EARLY |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 151 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 300 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | ARC-520.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | ARC-520 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | Late (`LATE`) |
| First ordinal, inclusive · `proposed_terms.allocations[5].first_unit` | 301 |
| Last ordinal, inclusive · `proposed_terms.allocations[5].last_unit` | 330 |
| Fixed lot identity · `proposed_terms.allocations[5].lot_id` | ARC-520.L003 |
| Obligation identity · `proposed_terms.allocations[5].obligation_id` | ARC-520 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[5].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[5].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `proposed_terms.allocations[5].window_id` | Late (`LATE`) |
| First ordinal, inclusive · `proposed_terms.allocations[6].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[6].last_unit` | 150 |
| Fixed lot identity · `proposed_terms.allocations[6].lot_id` | ARC-630.L001 |
| Obligation identity · `proposed_terms.allocations[6].obligation_id` | ARC-630 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[6].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[6].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `proposed_terms.allocations[6].window_id` | Late (`LATE`) |
| First ordinal, inclusive · `proposed_terms.allocations[7].first_unit` | 151 |
| Last ordinal, inclusive · `proposed_terms.allocations[7].last_unit` | 270 |
| Fixed lot identity · `proposed_terms.allocations[7].lot_id` | ARC-630.L002 |
| Obligation identity · `proposed_terms.allocations[7].obligation_id` | ARC-630 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[7].pay_minor` | 1190 |
| Provider identity · `proposed_terms.allocations[7].provider_id` | ARCHIVE-COMPAT-B |
| Capacity-window identity · `proposed_terms.allocations[7].window_id` | Late (`LATE`) |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 5700 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | da2441381af31c8e77df5382e02000b5af8132310fe7e6f533f9f0d252d5782e |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 290 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 560 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-001 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2340 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Modeled settlement tick · `settled_tick` | 279 |
| Recorded status · `status` | Settled in the synthetic ledger (`SETTLED`) |

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.


## Modeled transfers, costs, liabilities and outside options

Model only: monetary amounts are exact synthetic minor units; 100 minor units equal 1 fictional SMU. Values are displayed without rescaling. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

| Field | Recorded value |
| --- | --- |
| Total buyer transfers (synthetic SMU minor units) · `accounting.buyer_total_paid_minor` | 5700 |
| Upper bound · `accounting.buyer_utility_interval_minor.maximum` | 3900 |
| Lower bound · `accounting.buyer_utility_interval_minor.minimum` | 2500 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[0].final_balance_minor` | 1900 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[0].initial_balance_minor` | 7600 |
| Modeled participation threshold covered · `accounting.campaign[0].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[0].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[0].party_id` | BUYER-ARCHIVE |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[0].purchase_payments_minor` | 5700 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[0].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[0].revenue_minor` | 0 |
| Role · `accounting.campaign[0].role` | buyer |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[1].final_balance_minor` | 1110 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[1].incurred_cost_minor` | 180 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[1].initial_balance_minor` | 1000 |
| Modeled participation threshold covered · `accounting.campaign[1].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[1].participation_threshold_minor` | 110 |
| Participant identity · `accounting.campaign[1].party_id` | COORDINATOR-ARCHIVE |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[1].realized_profit_minor` | 110 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[1].revenue_minor` | 290 |
| Role · `accounting.campaign[1].role` | coordinator |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[2].final_balance_minor` | 0 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[2].initial_balance_minor` | 0 |
| Modeled participation threshold covered · `accounting.campaign[2].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[2].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[2].party_id` | UNUSED-SPONSOR |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[2].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[2].revenue_minor` | 0 |
| Role · `accounting.campaign[2].role` | technical_sponsor |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[3].final_balance_minor` | 4500 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[3].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[3].initial_balance_minor` | 4500 |
| Modeled participation threshold covered · `accounting.campaign[3].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[3].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[3].party_id` | ARCHIVE-PRIMARY |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[3].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[3].revenue_minor` | 0 |
| Role · `accounting.campaign[3].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[4].final_balance_minor` | 4500 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[4].initial_balance_minor` | 4500 |
| Modeled participation threshold covered · `accounting.campaign[4].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[4].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[4].party_id` | ARCHIVE-BACKUP |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[4].revenue_minor` | 0 |
| Role · `accounting.campaign[4].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[5].final_balance_minor` | 8180 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[5].incurred_cost_minor` | 2040 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[5].initial_balance_minor` | 6000 |
| Modeled participation threshold covered · `accounting.campaign[5].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[5].participation_threshold_minor` | 260 |
| Participant identity · `accounting.campaign[5].party_id` | ARCHIVE-COMPAT-A |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[5].realized_profit_minor` | 2180 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[5].revenue_minor` | 4220 |
| Role · `accounting.campaign[5].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU minor units) · `accounting.campaign[6].final_balance_minor` | 3120 |
| Funds still encumbered (synthetic SMU minor units) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU minor units) · `accounting.campaign[6].incurred_cost_minor` | 570 |
| Initial modeled balance (synthetic SMU minor units) · `accounting.campaign[6].initial_balance_minor` | 2500 |
| Modeled participation threshold covered · `accounting.campaign[6].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU minor units) · `accounting.campaign[6].participation_threshold_minor` | 200 |
| Participant identity · `accounting.campaign[6].party_id` | ARCHIVE-COMPAT-B |
| Purchase transfers (synthetic SMU minor units) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU minor units) · `accounting.campaign[6].realized_profit_minor` | 620 |
| Modeled receipts (synthetic SMU minor units) · `accounting.campaign[6].revenue_minor` | 1190 |
| Role · `accounting.campaign[6].role` | provider |
| Withdrawals to outside account (synthetic SMU minor units) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Synthetic accounting unit · `accounting.currency` | SMU |
| Final ledger total (synthetic SMU minor units) · `accounting.final_total_minor` | 26100 |
| Initial ledger total (synthetic SMU minor units) · `accounting.initial_total_minor` | 26100 |
| Real contracts, payments or demand · `accounting.real_contracts_payments_or_demand` | Not established (`NOT_ESTABLISHED`) |
| Realized modeled buyer feasibility · `accounting.realized_buyer` | Demonstrated in scope (`DEMONSTRATED`) |
| Assessment scope · `accounting.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| All correction costs (synthetic SMU minor units) · `accounting.total_correction_cost_minor` | 0 |
| All incurred campaign costs (synthetic SMU minor units) · `accounting.total_incurred_cost_minor` | 2790 |
| All modeled settlement transfers (synthetic SMU minor units) · `accounting.total_transfers_minor` | 5700 |
| Modeled trade settled · `accounting.trade_settled` | Yes |
| Accepted obligations · `totals.accepted_obligations` | 3 |
| Accepted quantity within contract · `totals.accepted_quantity` | 1020 |
| Delivery attempts · `totals.delivery_attempts` | 8 |
| Duplicate accepted units · `totals.duplicate_acceptances` | 0 |
| Late quantity · `totals.late_quantity` | 0 |
| Missing quantity · `totals.missing_quantity` | 0 |
| Produced quantity · `totals.produced_quantity` | 1020 |
| Durable production attempts · `totals.production_attempts` | 8 |
| Received quantity · `totals.received_quantity` | 1020 |
| Units accepted by the recipient component · `totals.recipient_accepted_quantity` | 1020 |
| Rejected quantity · `totals.rejected_quantity` | 0 |
| Requested units in rejected deliveries · `totals.rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `totals.rejection_count` | 0 |
| Required active obligations · `totals.required_obligations` | 3 |
| Required quantity · `totals.required_quantity` | 1020 |
| Semantically correct units observed in time · `totals.timely_semantic_quantity` | 1020 |
| Unsafe or unsupported commitments · `totals.unsafe_or_unsupported_commitments` | 0 |

## Measured resources and accounting gaps

Measured process resources and configured synthetic amounts have different meanings. Unrecorded preparation, integration, adaptation, verification or intervention effort remains unknown. Missing categories cannot support a complete-cost or cheaper-method conclusion.

| Field | Recorded value |
| --- | --- |
| Accounting gaps · `accounting_gaps[0]` | Preparation labor was not measured (`PREPARATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[1]` | Integration labor was not measured (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[2]` | Adaptation labor was not measured (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[3]` | Human verification labor was not measured (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[4]` | Monetary rates were not measured (`MONETARY_RATES_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[5]` | REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED |
| Adaptation labor (seconds; unknown if absent) · `resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `resources.authority_storage_bytes_before_seal` | 52832 |
| Candidate restarts · `resources.candidate_restarts` | 0 |
| Launched child processes · `resources.child_processes` | 10 |
| Controller system CPU (ns) · `resources.controller_cpu_system_ns` | 25835000 |
| Controller user CPU (ns) · `resources.controller_cpu_user_ns` | 201382999 |
| System CPU (ns) · `resources.cpu_system_ns` | 112332000 |
| User CPU (ns) · `resources.cpu_user_ns` | 701510000 |
| Human interventions · `resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `resources.preparation_labor_seconds` | Not recorded |
| Requests · `resources.requests` | 45 |
| Retries · `resources.retries` | 1 |
| Internal service requests · `resources.service_requests` | 239 |
| Recorded storage (bytes) · `resources.storage_bytes` | 6498354 |
| `resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `resources.wall_ns` | 1302063181 |
| Worker restarts · `resources.worker_restarts` | 1 |
| Process CPU (ns) · `verification_resources.cpu_ns` | 193997262 |
| Evidence files inspected · `verification_resources.evidence_files_read` | 32 |
| Wall duration (ns) · `verification_resources.wall_ns` | 194249523 |

## Observed failures and counterexamples

No failure entry was recorded in this assessment. This is bounded evidence, not a general proof.

## Missing evidence and unresolved claims

No additional unresolved entry was recorded. Scope and unknown-cost limits still apply.

## Evidence references and byte integrity

Hashes identify bytes. They do not authenticate real customer instructions, establish source completeness, or replace an externally retained reference pin.

| Field | Recorded value |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L001.A1.json` | e100b4479f868d193b71358f2c6f10edb744c5de7c1ca78bd1d365e6022d39af |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L002.A1.json` | 951cdb48174ae30a2aae6eca5eb9f68568a8c4815545f4dbd24dae0af2a007ee |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L003.A1.json` | b39781084b1c48f289f919219cbfe1811f0cb6053c77cb43476f55a92c486d7f |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-520.L001.A1.json` | cabef13db17adae40232531c28c3e97c6de7375e4c309166fccb6794de1dbe6c |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-520.L002.A1.json` | 8a74ef4255bb90ebd374824548a39d828d9760872fc9c44b1921aeaa63cba741 |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-520.L003.A1.json` | f80504c2738725846fb8680810cae3be5decea9d02d6a053f6dc57a9b1cb5dfc |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-630.L001.A1.json` | fcc54615801f5f44ca666a6810680bd6cd6089551a9c2c3d207d927b6cecc2a8 |
| `evidence_sha256.evidence/capacity-artifacts/ARCHIVE-COMPAT-B.LATE/ARC-630.L002.A1.json` | 840668399d49cc0aa84f9350d62d04076c0425b993e808c69bb77ec808248683 |
| `evidence_sha256.evidence/capacity/ARCHIVE-BACKUP.ALL.sqlite` | b224b59db970daf94e8af0bf56e532c7ba0a2943bc3a3767a0021502869ee676 |
| `evidence_sha256.evidence/capacity/ARCHIVE-COMPAT-A.EARLY.sqlite` | 0561f2c896df1591ae63eb5448f76f2c15c3e402cbceba8566f9a6e2bea3915c |
| `evidence_sha256.evidence/capacity/ARCHIVE-COMPAT-A.LATE.sqlite` | 5765184407750b23144a2a24d105b2bc23d0b8e2cc0e4717259cc9460b574d98 |
| `evidence_sha256.evidence/capacity/ARCHIVE-COMPAT-B.LATE.sqlite` | c5a790052e5c4bae942965de058dc2d52fc90e61160805c744a091ace281343d |
| `evidence_sha256.evidence/capacity/ARCHIVE-PRIMARY.ALL.sqlite` | 357774986962cc674778ef276a4b2d21d5cddc76e22697b1292fcb47769800d4 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-410.L001.A1.D.json` | eb8cf0d4e5f3fe84d735abdb939c338e9a2911f333e3b405edbab29685a6e0d9 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-410.L002.A1.D.json` | 01ee70c72691afa8f92481eccf44ad17bd35a97a7ca2ae928a77369c9193318f |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-410.L003.A1.D.json` | 4d7dd08c6a2cffbb0148372e5207a9916bb769975637e00eb8d453bdd69f795e |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-520.L001.A1.D.json` | 266bc54bb52c94598c1a8b5dc2b8a0b1a1586c9ad8f8347f43a23b0c539a7621 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-520.L002.A1.D.json` | 0b1cc0459fe370f0bcb2e15f75d26c638bdc422c6c44bba1cc68f22303d940b5 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-520.L003.A1.D.json` | a4962f39948eef9cbd58efd357e6bd49120297729008d520fec62643ec1ab379 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-630.L001.A1.D.json` | 284e242baae7d5db86bc7201a48e9c2a2c7686e61a38047317f84a60d6b437a1 |
| `evidence_sha256.evidence/inbox/proposal-001.ARC-630.L002.A1.D.json` | 64333b26a7e0f3ee23d25c025e22ecc5efef422eaeded448d9a3d79128e5d68a |
| `evidence_sha256.evidence/participants.sqlite` | dbb0905d7c7fd2b614746af4a0c729048d5f9e9018a44f49fa5a8c1ea7df188c |
| `evidence_sha256.evidence/producer.sqlite` | b70213da0fa762f5f77e13dc624b946afecba1c13c7687887a20b37011d2566c |
| `evidence_sha256.evidence/products/proposal-001.ARC-410.L001.A1.json` | eb8cf0d4e5f3fe84d735abdb939c338e9a2911f333e3b405edbab29685a6e0d9 |
| `evidence_sha256.evidence/products/proposal-001.ARC-410.L002.A1.json` | 01ee70c72691afa8f92481eccf44ad17bd35a97a7ca2ae928a77369c9193318f |
| `evidence_sha256.evidence/products/proposal-001.ARC-410.L003.A1.json` | 4d7dd08c6a2cffbb0148372e5207a9916bb769975637e00eb8d453bdd69f795e |
| `evidence_sha256.evidence/products/proposal-001.ARC-520.L001.A1.json` | 266bc54bb52c94598c1a8b5dc2b8a0b1a1586c9ad8f8347f43a23b0c539a7621 |
| `evidence_sha256.evidence/products/proposal-001.ARC-520.L002.A1.json` | 0b1cc0459fe370f0bcb2e15f75d26c638bdc422c6c44bba1cc68f22303d940b5 |
| `evidence_sha256.evidence/products/proposal-001.ARC-520.L003.A1.json` | a4962f39948eef9cbd58efd357e6bd49120297729008d520fec62643ec1ab379 |
| `evidence_sha256.evidence/products/proposal-001.ARC-630.L001.A1.json` | 284e242baae7d5db86bc7201a48e9c2a2c7686e61a38047317f84a60d6b437a1 |
| `evidence_sha256.evidence/products/proposal-001.ARC-630.L002.A1.json` | 64333b26a7e0f3ee23d25c025e22ecc5efef422eaeded448d9a3d79128e5d68a |
| `evidence_sha256.evidence/receiver.sqlite` | cdf3b2221cae46d44c5fb410cea9325f2f434c7225d7ba395c2d12f8108b7f60 |
| Structured result SHA-256 · `structured_result_sha256` | ada2d60a3c9935da6c0cac0766419c12bcafa9e4e596123aaf896155941bd18c |

## Recorded execution, faults, commands and provenance

Stable identifiers, exact commands, paths and original machine diagnostics are retained literally. They are data, not additional acceptance evidence. Source and host trust remain explicit in the architecture and threat model.

| Field | Recorded value |
| --- | --- |
| `authority_dir` | /workspace/scratch/b1d5891eb025/economy-qualification/complete-attempt-1/successor/authorities/archive-window-transfer.harness |
| Experiment cohort · `cohort` | successor |
| `contract.allow_split` | Yes |
| `contract.authority_kind` | Synthetic exercise authority (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | SHARED-INDEX-NETWORK |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Experiment cohort · `contract.cohort` | successor |
| Contract identity · `contract.contract_id` | DIGITAL-ARCHIVE-001 |
| `contract.cutoff_sequence` | 8 |
| Logical deadline · `contract.deadline_tick` | 560 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-SUCCESSOR-001 |
| Recorded event · `contract.fault_schedule[0].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `contract.fault_schedule[0].occurrence` | 2 |
| Fault target · `contract.fault_schedule[0].target` | ANY |
| Trigger operation · `contract.fault_schedule[0].trigger` | inspect |
| Configured value · `contract.fault_schedule[0].value` | 0 |
| Registered fixture identity · `contract.fixture_id` | archive-window-transfer |
| `contract.lease_ticks` | 15 |
| `contract.lot_size` | 150 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Logical deadline · `contract.obligations[0].deadline_tick` | 130 |
| Obligation identity · `contract.obligations[0].obligation_id` | ARC-410 |
| Required quantity · `contract.obligations[0].quantity` | 420 |
| Recipient · `contract.obligations[0].recipient` | RECIPIENT-NORD |
| Revision · `contract.obligations[0].revision` | 3 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Import this serial under accession N26 with shelf code B-14; retain the revision shown in the job. |
| `contract.obligations[0].spec.instructions_fr` | Importer ce numéro sous l’entrée N26 avec le code d’étagère B-14 ; conserver la révision indiquée dans le dossier. |
| `contract.obligations[0].spec.lot` | ARC-N26-20261106 |
| `contract.obligations[0].spec.name_en` | Digital archive box index |
| `contract.obligations[0].spec.name_fr` | Index numérique de boîte d’archives |
| `contract.obligations[0].spec.serial_prefix` | ARC410-N26- |
| `contract.obligations[0].spec.sku` | ARCHIVE-BOX-A7 |
| Recorded status · `contract.obligations[0].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[1].deadline_tick` | 440 |
| Obligation identity · `contract.obligations[1].obligation_id` | ARC-520 |
| Required quantity · `contract.obligations[1].quantity` | 330 |
| Recipient · `contract.obligations[1].recipient` | RECIPIENT-EST |
| Revision · `contract.obligations[1].revision` | 2 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Import this serial for return bin R-08 and recipient reference EAST-27; preserve both identifiers. |
| `contract.obligations[1].spec.instructions_fr` | Importer ce numéro pour le bac de retour R-08 et la référence destinataire EAST-27 ; conserver les deux identifiants. |
| `contract.obligations[1].spec.lot` | ARC-E27-20261106 |
| `contract.obligations[1].spec.name_en` | Digital loan return record |
| `contract.obligations[1].spec.name_fr` | Fiche numérique de retour de prêt |
| `contract.obligations[1].spec.serial_prefix` | ARC520-E27- |
| `contract.obligations[1].spec.sku` | ARCHIVE-RETURN-B4 |
| Recorded status · `contract.obligations[1].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[2].deadline_tick` | 520 |
| Obligation identity · `contract.obligations[2].obligation_id` | ARC-630 |
| Required quantity · `contract.obligations[2].quantity` | 270 |
| Recipient · `contract.obligations[2].recipient` | RECIPIENT-SUD |
| Revision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep accession S19 and category PAPER in the imported unit; do not substitute another accession. |
| `contract.obligations[2].spec.instructions_fr` | Conserver l’entrée S19 et la catégorie PAPER dans l’unité importée ; ne pas substituer une autre entrée. |
| `contract.obligations[2].spec.lot` | ARC-S19-20261106 |
| `contract.obligations[2].spec.name_en` | Digital conservation index record |
| `contract.obligations[2].spec.name_fr` | Fiche numérique d’index de conservation |
| `contract.obligations[2].spec.serial_prefix` | ARC630-S19- |
| `contract.obligations[2].spec.sku` | ARCHIVE-INDEX-C2 |
| Recorded status · `contract.obligations[2].status` | Active (`ACTIVE`) |
| Logical deadline · `contract.obligations[3].deadline_tick` | 360 |
| Obligation identity · `contract.obligations[3].obligation_id` | ARC-740 |
| Required quantity · `contract.obligations[3].quantity` | 90 |
| Recipient · `contract.obligations[3].recipient` | RECIPIENT-OUEST |
| Revision · `contract.obligations[3].revision` | 1 |
| `contract.obligations[3].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[3].spec.instructions_en` | Import return route WEST-09 with this exact serial. |
| `contract.obligations[3].spec.instructions_fr` | Importer la voie de retour WEST-09 avec ce numéro exact. |
| `contract.obligations[3].spec.lot` | ARC-W09-20261106 |
| `contract.obligations[3].spec.name_en` | Digital west return-route record |
| `contract.obligations[3].spec.name_fr` | Fiche numérique de retour ouest |
| `contract.obligations[3].spec.serial_prefix` | ARC740-W09- |
| `contract.obligations[3].spec.sku` | ARCHIVE-RETURN-D9 |
| Recorded status · `contract.obligations[3].status` | Cancelled (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 650 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | SHARED-INDEX-NETWORK |
| `contract.providers[0].permissions.disclosure` | No |
| `contract.providers[0].permissions.production` | Yes |
| Provider identity · `contract.providers[0].provider_id` | ARCHIVE-PRIMARY |
| Role · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 1600 |
| `contract.providers[0].windows[0].end` | 600 |
| `contract.providers[0].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[0].windows[0].window_id` | ALL |
| `contract.providers[1].dependency` | SHARED-INDEX-NETWORK |
| `contract.providers[1].permissions.disclosure` | Yes |
| `contract.providers[1].permissions.production` | Yes |
| Provider identity · `contract.providers[1].provider_id` | ARCHIVE-BACKUP |
| Role · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 1600 |
| `contract.providers[1].windows[0].end` | 600 |
| `contract.providers[1].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[1].windows[0].window_id` | ALL |
| `contract.providers[2].dependency` | ARCHIVE-OFFLINE-A |
| `contract.providers[2].permissions.disclosure` | Yes |
| `contract.providers[2].permissions.production` | Yes |
| Provider identity · `contract.providers[2].provider_id` | ARCHIVE-COMPAT-A |
| Role · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 570 |
| `contract.providers[2].windows[0].end` | 140 |
| `contract.providers[2].windows[0].start` | 0 |
| Capacity-window identity · `contract.providers[2].windows[0].window_id` | EARLY |
| `contract.providers[2].windows[1].capacity` | 330 |
| `contract.providers[2].windows[1].end` | 560 |
| `contract.providers[2].windows[1].start` | 260 |
| Capacity-window identity · `contract.providers[2].windows[1].window_id` | Late (`LATE`) |
| `contract.providers[3].dependency` | ARCHIVE-OFFLINE-B |
| `contract.providers[3].permissions.disclosure` | Yes |
| `contract.providers[3].permissions.production` | Yes |
| Provider identity · `contract.providers[3].provider_id` | ARCHIVE-COMPAT-B |
| Role · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 330 |
| `contract.providers[3].windows[0].end` | 560 |
| `contract.providers[3].windows[0].start` | 260 |
| Capacity-window identity · `contract.providers[3].windows[0].window_id` | Late (`LATE`) |
| Revision · `contract.revision` | 1 |
| `contract.revocations` | No entries |
| Run identity · `contract.run_id` | archive-window-transfer.harness.938d770fd7 |
| Schema · `contract.schema` | continuity-economy/contract/v1 |
| Recorded seed · `contract.seed` | 7919 |
| `contract.source_complete` | Yes |
| Logical deadline · `contract.source_events[0].obligation.deadline_tick` | 130 |
| Obligation identity · `contract.source_events[0].obligation.obligation_id` | ARC-410 |
| Required quantity · `contract.source_events[0].obligation.quantity` | 390 |
| Recipient · `contract.source_events[0].obligation.recipient` | RECIPIENT-NORD |
| Revision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Import this serial under accession N26 with shelf code B-09; retain the revision shown in the job. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Importer ce numéro sous l’entrée N26 avec le code d’étagère B-09 ; conserver la révision indiquée dans le dossier. |
| `contract.source_events[0].obligation.spec.lot` | ARC-N26-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Digital archive box index |
| `contract.source_events[0].obligation.spec.name_fr` | Index numérique de boîte d’archives |
| `contract.source_events[0].obligation.spec.serial_prefix` | ARC410-N26- |
| `contract.source_events[0].obligation.spec.sku` | ARCHIVE-BOX-A7 |
| Recorded status · `contract.source_events[0].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[0].obligation_id` | ARC-410 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Logical deadline · `contract.source_events[1].obligation.deadline_tick` | 440 |
| Obligation identity · `contract.source_events[1].obligation.obligation_id` | ARC-520 |
| Required quantity · `contract.source_events[1].obligation.quantity` | 300 |
| Recipient · `contract.source_events[1].obligation.recipient` | RECIPIENT-CENTRE |
| Revision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Import this serial for return bin R-03 and recipient reference CENTRE-11; preserve both identifiers. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Importer ce numéro pour le bac de retour R-03 et la référence destinataire CENTRE-11 ; conserver les deux identifiants. |
| `contract.source_events[1].obligation.spec.lot` | ARC-E27-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Digital loan return record |
| `contract.source_events[1].obligation.spec.name_fr` | Fiche numérique de retour de prêt |
| `contract.source_events[1].obligation.spec.serial_prefix` | ARC520-E27- |
| `contract.source_events[1].obligation.spec.sku` | ARCHIVE-RETURN-B4 |
| Recorded status · `contract.source_events[1].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[1].obligation_id` | ARC-520 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Logical deadline · `contract.source_events[2].obligation.deadline_tick` | 520 |
| Obligation identity · `contract.source_events[2].obligation.obligation_id` | ARC-630 |
| Required quantity · `contract.source_events[2].obligation.quantity` | 270 |
| Recipient · `contract.source_events[2].obligation.recipient` | RECIPIENT-SUD |
| Revision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep accession S19 and category PAPER in the imported unit; do not substitute another accession. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Conserver l’entrée S19 et la catégorie PAPER dans l’unité importée ; ne pas substituer une autre entrée. |
| `contract.source_events[2].obligation.spec.lot` | ARC-S19-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Digital conservation index record |
| `contract.source_events[2].obligation.spec.name_fr` | Fiche numérique d’index de conservation |
| `contract.source_events[2].obligation.spec.serial_prefix` | ARC630-S19- |
| `contract.source_events[2].obligation.spec.sku` | ARCHIVE-INDEX-C2 |
| Recorded status · `contract.source_events[2].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[2].obligation_id` | ARC-630 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Logical deadline · `contract.source_events[3].obligation.deadline_tick` | 360 |
| Obligation identity · `contract.source_events[3].obligation.obligation_id` | ARC-740 |
| Required quantity · `contract.source_events[3].obligation.quantity` | 90 |
| Recipient · `contract.source_events[3].obligation.recipient` | RECIPIENT-OUEST |
| Revision · `contract.source_events[3].obligation.revision` | 1 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Import return route WEST-09 with this exact serial. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Importer la voie de retour WEST-09 avec ce numéro exact. |
| `contract.source_events[3].obligation.spec.lot` | ARC-W09-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Digital west return-route record |
| `contract.source_events[3].obligation.spec.name_fr` | Fiche numérique de retour ouest |
| `contract.source_events[3].obligation.spec.serial_prefix` | ARC740-W09- |
| `contract.source_events[3].obligation.spec.sku` | ARCHIVE-RETURN-D9 |
| Recorded status · `contract.source_events[3].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[3].obligation_id` | ARC-740 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | ACCEPT |
| Logical deadline · `contract.source_events[4].obligation.deadline_tick` | 130 |
| Obligation identity · `contract.source_events[4].obligation.obligation_id` | ARC-410 |
| Required quantity · `contract.source_events[4].obligation.quantity` | 420 |
| Recipient · `contract.source_events[4].obligation.recipient` | RECIPIENT-NORD |
| Revision · `contract.source_events[4].obligation.revision` | 2 |
| `contract.source_events[4].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[4].obligation.spec.instructions_en` | Import this serial under accession N26 with shelf code B-12; retain the revision shown in the job. |
| `contract.source_events[4].obligation.spec.instructions_fr` | Importer ce numéro sous l’entrée N26 avec le code d’étagère B-12 ; conserver la révision indiquée dans le dossier. |
| `contract.source_events[4].obligation.spec.lot` | ARC-N26-20261106 |
| `contract.source_events[4].obligation.spec.name_en` | Digital archive box index |
| `contract.source_events[4].obligation.spec.name_fr` | Index numérique de boîte d’archives |
| `contract.source_events[4].obligation.spec.serial_prefix` | ARC410-N26- |
| `contract.source_events[4].obligation.spec.sku` | ARCHIVE-BOX-A7 |
| Recorded status · `contract.source_events[4].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[4].obligation_id` | ARC-410 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | AMEND |
| Logical deadline · `contract.source_events[5].obligation.deadline_tick` | 440 |
| Obligation identity · `contract.source_events[5].obligation.obligation_id` | ARC-520 |
| Required quantity · `contract.source_events[5].obligation.quantity` | 330 |
| Recipient · `contract.source_events[5].obligation.recipient` | RECIPIENT-EST |
| Revision · `contract.source_events[5].obligation.revision` | 2 |
| `contract.source_events[5].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[5].obligation.spec.instructions_en` | Import this serial for return bin R-08 and recipient reference EAST-27; preserve both identifiers. |
| `contract.source_events[5].obligation.spec.instructions_fr` | Importer ce numéro pour le bac de retour R-08 et la référence destinataire EAST-27 ; conserver les deux identifiants. |
| `contract.source_events[5].obligation.spec.lot` | ARC-E27-20261106 |
| `contract.source_events[5].obligation.spec.name_en` | Digital loan return record |
| `contract.source_events[5].obligation.spec.name_fr` | Fiche numérique de retour de prêt |
| `contract.source_events[5].obligation.spec.serial_prefix` | ARC520-E27- |
| `contract.source_events[5].obligation.spec.sku` | ARCHIVE-RETURN-B4 |
| Recorded status · `contract.source_events[5].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[5].obligation_id` | ARC-520 |
| `contract.source_events[5].sequence` | 6 |
| `contract.source_events[5].type` | AMEND |
| Logical deadline · `contract.source_events[6].obligation.deadline_tick` | 130 |
| Obligation identity · `contract.source_events[6].obligation.obligation_id` | ARC-410 |
| Required quantity · `contract.source_events[6].obligation.quantity` | 420 |
| Recipient · `contract.source_events[6].obligation.recipient` | RECIPIENT-NORD |
| Revision · `contract.source_events[6].obligation.revision` | 3 |
| `contract.source_events[6].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[6].obligation.spec.instructions_en` | Import this serial under accession N26 with shelf code B-14; retain the revision shown in the job. |
| `contract.source_events[6].obligation.spec.instructions_fr` | Importer ce numéro sous l’entrée N26 avec le code d’étagère B-14 ; conserver la révision indiquée dans le dossier. |
| `contract.source_events[6].obligation.spec.lot` | ARC-N26-20261106 |
| `contract.source_events[6].obligation.spec.name_en` | Digital archive box index |
| `contract.source_events[6].obligation.spec.name_fr` | Index numérique de boîte d’archives |
| `contract.source_events[6].obligation.spec.serial_prefix` | ARC410-N26- |
| `contract.source_events[6].obligation.spec.sku` | ARCHIVE-BOX-A7 |
| Recorded status · `contract.source_events[6].obligation.status` | Active (`ACTIVE`) |
| Obligation identity · `contract.source_events[6].obligation_id` | ARC-410 |
| `contract.source_events[6].sequence` | 7 |
| `contract.source_events[6].type` | AMEND |
| Obligation identity · `contract.source_events[7].obligation_id` | ARC-740 |
| `contract.source_events[7].sequence` | 8 |
| `contract.source_events[7].type` | CANCEL |
| `contract.source_id` | AUTHORED-ARCHIVE-TRANSFER-EVENTS |
| Source byte hashes · `contract.source_sha256` | bba4d4ad000f97e302cd199c68dd2ff2f6117dd8197b7ae89c1f3872d00d8d4a |
| Start clock (ns) · `contract.start_ns` | 34588784163802 |
| Elapsed-time deadline (ms) · `contract.wall_deadline_ms` | 90000 |
| `controller.capacity_databases[0].path` | evidence/capacity/ARCHIVE-PRIMARY.ALL.sqlite |
| Provider identity · `controller.capacity_databases[0].provider_id` | ARCHIVE-PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Capacity-window identity · `controller.capacity_databases[0].window_id` | ALL |
| `controller.capacity_databases[1].path` | evidence/capacity/ARCHIVE-BACKUP.ALL.sqlite |
| Provider identity · `controller.capacity_databases[1].provider_id` | ARCHIVE-BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Capacity-window identity · `controller.capacity_databases[1].window_id` | ALL |
| `controller.capacity_databases[2].path` | evidence/capacity/ARCHIVE-COMPAT-A.EARLY.sqlite |
| Provider identity · `controller.capacity_databases[2].provider_id` | ARCHIVE-COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Capacity-window identity · `controller.capacity_databases[2].window_id` | EARLY |
| `controller.capacity_databases[3].path` | evidence/capacity/ARCHIVE-COMPAT-A.LATE.sqlite |
| Provider identity · `controller.capacity_databases[3].provider_id` | ARCHIVE-COMPAT-A |
| `controller.capacity_databases[3].route` | backup |
| Capacity-window identity · `controller.capacity_databases[3].window_id` | Late (`LATE`) |
| `controller.capacity_databases[4].path` | evidence/capacity/ARCHIVE-COMPAT-B.LATE.sqlite |
| Provider identity · `controller.capacity_databases[4].provider_id` | ARCHIVE-COMPAT-B |
| `controller.capacity_databases[4].route` | backup |
| Capacity-window identity · `controller.capacity_databases[4].window_id` | Late (`LATE`) |
| `controller.clock_tick` | 279 |
| Experiment cohort · `controller.cohort` | successor |
| Retained contract SHA-256 · `controller.contract_sha256` | da2441381af31c8e77df5382e02000b5af8132310fe7e6f533f9f0d252d5782e |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-BACKUP.ALL.sqlite` | 73f1078fa5b7470ed764e21760533b275239a4ce450e3dca617bcf7afb394b1a |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-COMPAT-A.EARLY.sqlite` | 841522fd92c1c88068f2197c3957cc12227890f7adc0825ea489fcad24025538 |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-COMPAT-A.LATE.sqlite` | 845260d378929af7a6c021803b0c7762580e776c3235ebf97bdf3682e85a60f3 |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-COMPAT-B.LATE.sqlite` | 7d59b7bba11b78e9af2b15fadfb56db03f32350a568e2f166a00e7a1d1006cfd |
| `controller.db_snapshots.evidence/capacity/ARCHIVE-PRIMARY.ALL.sqlite` | 431c3579268a12d9bb464ba37fe275132dcf7e5e0c3d45f4b2fd37f6e613990e |
| `controller.db_snapshots.evidence/participants.sqlite` | d7dfc7bc80f64f54c8cf617faab35dc35f08d449d49ee09749781b193863648b |
| `controller.db_snapshots.evidence/producer.sqlite` | f7ef51b81f85ee7d58ed1615e8d0dc275bf8ab6a8c688b4934ee7d34927eda53 |
| `controller.db_snapshots.evidence/receiver.sqlite` | 114c3c2d6cedb5111e94d90d8952fe4ec352c72f83c977fc33a6b76a5857ab7d |
| `controller.errors` | No entries |
| `controller.events[0].detail.authority_kind` | Synthetic exercise authority (`SYNTHETIC_EXERCISE`) |
| External reference pin · `controller.events[0].detail.reference_sha256` | 52f77f91846c3eae93acdc9efdd7faa52f499f7eb2df5be8443fda2fc43af369 |
| Recorded seed · `controller.events[0].detail.seed` | 7919 |
| Recorded event · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 34588807945447 |
| Logical tick · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 256 |
| `controller.events[1].detail.restart` | No |
| `controller.events[1].detail.service` | participants |
| Recorded event · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 34588849933678 |
| Logical tick · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 257 |
| `controller.events[2].detail.restart` | No |
| `controller.events[2].detail.service` | producer |
| Recorded event · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 34588892441735 |
| Logical tick · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 258 |
| `controller.events[3].detail.restart` | No |
| `controller.events[3].detail.service` | receiver |
| Recorded event · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 34588931350731 |
| Logical tick · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 259 |
| Provider identity · `controller.events[4].detail.provider_id` | ARCHIVE-PRIMARY |
| Capacity-window identity · `controller.events[4].detail.window_id` | ALL |
| Recorded event · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 34588971234051 |
| Logical tick · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 260 |
| Provider identity · `controller.events[5].detail.provider_id` | ARCHIVE-BACKUP |
| Capacity-window identity · `controller.events[5].detail.window_id` | ALL |
| Recorded event · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 34589014725149 |
| Logical tick · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 261 |
| Provider identity · `controller.events[6].detail.provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[6].detail.window_id` | EARLY |
| Recorded event · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 34589057106945 |
| Logical tick · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 262 |
| Provider identity · `controller.events[7].detail.provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[7].detail.window_id` | Late (`LATE`) |
| Recorded event · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 34589101354328 |
| Logical tick · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.pid` | 263 |
| Provider identity · `controller.events[8].detail.provider_id` | ARCHIVE-COMPAT-B |
| Capacity-window identity · `controller.events[8].detail.window_id` | Late (`LATE`) |
| Recorded event · `controller.events[8].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[8].monotonic_ns` | 34589145365177 |
| Logical tick · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.affected[0]` | ARCHIVE-PRIMARY.ALL |
| `controller.events[9].detail.affected[1]` | ARCHIVE-BACKUP.ALL |
| `controller.events[9].detail.dependency` | SHARED-INDEX-NETWORK |
| Recorded event · `controller.events[9].event` | DEPENDENCY_DISABLED |
| `controller.events[9].monotonic_ns` | 34589147470800 |
| Logical tick · `controller.events[9].tick` | 0 |
| `controller.events[10].detail.isolation.applied` | Yes |
| `controller.events[10].detail.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.events[10].detail.isolation.probe.authority_open_denied` | Yes |
| `controller.events[10].detail.isolation.probe.network_denied` | Yes |
| `controller.events[10].detail.isolation.probe.process_inspection_denied` | Yes |
| `controller.events[10].detail.isolation.probe.spawn_denied` | Yes |
| `controller.events[10].detail.isolation.probe.workspace_open_denied` | Yes |
| `controller.events[10].detail.pid` | 264 |
| `controller.events[10].detail.restart` | No |
| Recorded event · `controller.events[10].event` | CANDIDATE_STARTED |
| `controller.events[10].monotonic_ns` | 34589192601212 |
| Logical tick · `controller.events[10].tick` | 0 |
| `controller.events[11].detail.args` | No entries |
| `controller.events[11].detail.op` | status |
| Recorded event · `controller.events[11].event` | BROKER_REQUEST |
| `controller.events[11].monotonic_ns` | 34589194512432 |
| Logical tick · `controller.events[11].tick` | 1 |
| `controller.events[12].detail.measurement_kind` | Candidate-reported measurement (`CANDIDATE_REPORTED`) |
| `controller.events[12].detail.pid` | 264 |
| `controller.events[12].detail.report.assignment_domain` | 6561 |
| `controller.events[12].detail.report.candidate_elapsed_ns` | 4442647 |
| `controller.events[12].detail.report.capacity_prunes` | 62 |
| `controller.events[12].detail.report.complete_assignments_observed` | 48 |
| `controller.events[12].detail.report.exhaustive_within_declared_domain` | Yes |
| `controller.events[12].detail.report.feasible_assignments` | 27 |
| `controller.events[12].detail.report.funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Candidate procedure · `controller.events[12].detail.report.method` | harness |
| `controller.events[12].detail.report.partial_nodes_observed` | 125 |
| `controller.events[12].detail.report.participant_prunes` | 21 |
| `controller.events[12].detail.report.price_prunes` | 15 |
| Recorded event · `controller.events[12].event` | CANDIDATE_PLANNING |
| `controller.events[12].monotonic_ns` | 34589203658811 |
| Logical tick · `controller.events[12].tick` | 1 |
| First ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[0].last_unit` | 150 |
| Fixed lot identity · `controller.events[13].detail.args.proposal.allocations[0].lot_id` | ARC-410.L001 |
| Obligation identity · `controller.events[13].detail.args.proposal.allocations[0].obligation_id` | ARC-410 |
| Provider payment (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.allocations[0].pay_minor` | 4220 |
| Provider identity · `controller.events[13].detail.args.proposal.allocations[0].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[13].detail.args.proposal.allocations[0].window_id` | EARLY |
| First ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[1].first_unit` | 151 |
| Last ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[1].last_unit` | 300 |
| Fixed lot identity · `controller.events[13].detail.args.proposal.allocations[1].lot_id` | ARC-410.L002 |
| Obligation identity · `controller.events[13].detail.args.proposal.allocations[1].obligation_id` | ARC-410 |
| Provider payment (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Provider identity · `controller.events[13].detail.args.proposal.allocations[1].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[13].detail.args.proposal.allocations[1].window_id` | EARLY |
| First ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[2].first_unit` | 301 |
| Last ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[2].last_unit` | 420 |
| Fixed lot identity · `controller.events[13].detail.args.proposal.allocations[2].lot_id` | ARC-410.L003 |
| Obligation identity · `controller.events[13].detail.args.proposal.allocations[2].obligation_id` | ARC-410 |
| Provider payment (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Provider identity · `controller.events[13].detail.args.proposal.allocations[2].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[13].detail.args.proposal.allocations[2].window_id` | EARLY |
| First ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[3].last_unit` | 150 |
| Fixed lot identity · `controller.events[13].detail.args.proposal.allocations[3].lot_id` | ARC-520.L001 |
| Obligation identity · `controller.events[13].detail.args.proposal.allocations[3].obligation_id` | ARC-520 |
| Provider payment (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.allocations[3].pay_minor` | 0 |
| Provider identity · `controller.events[13].detail.args.proposal.allocations[3].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[13].detail.args.proposal.allocations[3].window_id` | EARLY |
| First ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[4].first_unit` | 151 |
| Last ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[4].last_unit` | 300 |
| Fixed lot identity · `controller.events[13].detail.args.proposal.allocations[4].lot_id` | ARC-520.L002 |
| Obligation identity · `controller.events[13].detail.args.proposal.allocations[4].obligation_id` | ARC-520 |
| Provider payment (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.allocations[4].pay_minor` | 0 |
| Provider identity · `controller.events[13].detail.args.proposal.allocations[4].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[13].detail.args.proposal.allocations[4].window_id` | Late (`LATE`) |
| First ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[5].first_unit` | 301 |
| Last ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[5].last_unit` | 330 |
| Fixed lot identity · `controller.events[13].detail.args.proposal.allocations[5].lot_id` | ARC-520.L003 |
| Obligation identity · `controller.events[13].detail.args.proposal.allocations[5].obligation_id` | ARC-520 |
| Provider payment (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.allocations[5].pay_minor` | 0 |
| Provider identity · `controller.events[13].detail.args.proposal.allocations[5].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[13].detail.args.proposal.allocations[5].window_id` | Late (`LATE`) |
| First ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[6].first_unit` | 1 |
| Last ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[6].last_unit` | 150 |
| Fixed lot identity · `controller.events[13].detail.args.proposal.allocations[6].lot_id` | ARC-630.L001 |
| Obligation identity · `controller.events[13].detail.args.proposal.allocations[6].obligation_id` | ARC-630 |
| Provider payment (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.allocations[6].pay_minor` | 0 |
| Provider identity · `controller.events[13].detail.args.proposal.allocations[6].provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[13].detail.args.proposal.allocations[6].window_id` | Late (`LATE`) |
| First ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[7].first_unit` | 151 |
| Last ordinal, inclusive · `controller.events[13].detail.args.proposal.allocations[7].last_unit` | 270 |
| Fixed lot identity · `controller.events[13].detail.args.proposal.allocations[7].lot_id` | ARC-630.L002 |
| Obligation identity · `controller.events[13].detail.args.proposal.allocations[7].obligation_id` | ARC-630 |
| Provider payment (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.allocations[7].pay_minor` | 1190 |
| Provider identity · `controller.events[13].detail.args.proposal.allocations[7].provider_id` | ARCHIVE-COMPAT-B |
| Capacity-window identity · `controller.events[13].detail.args.proposal.allocations[7].window_id` | Late (`LATE`) |
| Buyer price (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.buyer_price_minor` | 5700 |
| Cancellation liability (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `controller.events[13].detail.args.proposal.contract_sha256` | da2441381af31c8e77df5382e02000b5af8132310fe7e6f533f9f0d252d5782e |
| Coordinator fee (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.coordinator_fee_minor` | 290 |
| Exclusive expiry tick · `controller.events[13].detail.args.proposal.expires_tick` | 560 |
| Policy revision · `controller.events[13].detail.args.proposal.policy_revision` | 1 |
| Proposal identity · `controller.events[13].detail.args.proposal.proposal_id` | proposal-001 |
| Correction reserve (synthetic SMU minor units) · `controller.events[13].detail.args.proposal.rework_budget_minor` | 2340 |
| Schema · `controller.events[13].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[13].detail.op` | propose |
| Recorded event · `controller.events[13].event` | BROKER_REQUEST |
| `controller.events[13].monotonic_ns` | 34589204908660 |
| Logical tick · `controller.events[13].tick` | 2 |
| Proposal identity · `controller.events[14].detail.args.proposal_id` | proposal-001 |
| `controller.events[14].detail.op` | decide |
| Recorded event · `controller.events[14].event` | BROKER_REQUEST |
| `controller.events[14].monotonic_ns` | 34589210455797 |
| Logical tick · `controller.events[14].tick` | 3 |
| `controller.events[15].detail.args` | No entries |
| `controller.events[15].detail.op` | status |
| Recorded event · `controller.events[15].event` | BROKER_REQUEST |
| `controller.events[15].monotonic_ns` | 34589216554397 |
| Logical tick · `controller.events[15].tick` | 4 |
| Agreement identity · `controller.events[16].detail.args.agreement_id` | proposal-001 |
| `controller.events[16].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[16].detail.args.lot_id` | ARC-410.L001 |
| `controller.events[16].detail.op` | reserve |
| Recorded event · `controller.events[16].event` | BROKER_REQUEST |
| `controller.events[16].monotonic_ns` | 34589222733349 |
| Logical tick · `controller.events[16].tick` | 5 |
| `controller.events[17].detail.key` | proposal-001.ARC-410.L001.A1 |
| `controller.events[17].detail.slot` | ARCHIVE-COMPAT-A.EARLY |
| Recorded status · `controller.events[17].detail.status` | RESERVED |
| Recorded event · `controller.events[17].event` | CAPACITY_RESERVED |
| `controller.events[17].monotonic_ns` | 34589230106456 |
| Logical tick · `controller.events[17].tick` | 5 |
| Agreement identity · `controller.events[18].detail.args.agreement_id` | proposal-001 |
| `controller.events[18].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[18].detail.args.lot_id` | ARC-410.L001 |
| `controller.events[18].detail.args.supersedes` | Not recorded |
| `controller.events[18].detail.op` | produce |
| Recorded event · `controller.events[18].event` | BROKER_REQUEST |
| `controller.events[18].monotonic_ns` | 34589230589387 |
| Logical tick · `controller.events[18].tick` | 6 |
| `controller.events[19].detail.byte_count` | 73680 |
| `controller.events[19].detail.payload_sha256` | eb8cf0d4e5f3fe84d735abdb939c338e9a2911f333e3b405edbab29685a6e0d9 |
| `controller.events[19].detail.production_id` | proposal-001.ARC-410.L001.A1 |
| Required quantity · `controller.events[19].detail.quantity` | 150 |
| Recorded event · `controller.events[19].event` | PRODUCT_MATERIALIZED |
| `controller.events[19].monotonic_ns` | 34589260409176 |
| Logical tick · `controller.events[19].tick` | 6 |
| `controller.events[20].detail.args.production_id` | proposal-001.ARC-410.L001.A1 |
| `controller.events[20].detail.op` | transfer |
| Recorded event · `controller.events[20].event` | BROKER_REQUEST |
| `controller.events[20].monotonic_ns` | 34589261002833 |
| Logical tick · `controller.events[20].tick` | 7 |
| `controller.events[21].detail.byte_count` | 73680 |
| `controller.events[21].detail.delivery_id` | proposal-001.ARC-410.L001.A1.D |
| `controller.events[21].detail.produced_sha256` | eb8cf0d4e5f3fe84d735abdb939c338e9a2911f333e3b405edbab29685a6e0d9 |
| `controller.events[21].detail.production_id` | proposal-001.ARC-410.L001.A1 |
| `controller.events[21].detail.received_sha256` | eb8cf0d4e5f3fe84d735abdb939c338e9a2911f333e3b405edbab29685a6e0d9 |
| Recorded event · `controller.events[21].event` | PRODUCT_TRANSFERRED |
| `controller.events[21].monotonic_ns` | 34589268603004 |
| Logical tick · `controller.events[21].tick` | 7 |
| `controller.events[22].detail.args.delivery_id` | proposal-001.ARC-410.L001.A1.D |
| `controller.events[22].detail.op` | inspect |
| Recorded event · `controller.events[22].event` | BROKER_REQUEST |
| `controller.events[22].monotonic_ns` | 34589268927665 |
| Logical tick · `controller.events[22].tick` | 8 |
| `controller.events[23].detail.accepted_units` | 150 |
| `controller.events[23].detail.delivery_id` | proposal-001.ARC-410.L001.A1.D |
| Recorded status · `controller.events[23].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[23].detail.timely` | Yes |
| Recorded event · `controller.events[23].event` | RECIPIENT_INSPECTED |
| `controller.events[23].monotonic_ns` | 34589285031732 |
| Logical tick · `controller.events[23].tick` | 8 |
| `controller.events[24].detail.args` | No entries |
| `controller.events[24].detail.op` | status |
| Recorded event · `controller.events[24].event` | BROKER_REQUEST |
| `controller.events[24].monotonic_ns` | 34589285466970 |
| Logical tick · `controller.events[24].tick` | 9 |
| Agreement identity · `controller.events[25].detail.args.agreement_id` | proposal-001 |
| `controller.events[25].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[25].detail.args.lot_id` | ARC-410.L002 |
| `controller.events[25].detail.op` | reserve |
| Recorded event · `controller.events[25].event` | BROKER_REQUEST |
| `controller.events[25].monotonic_ns` | 34589293614703 |
| Logical tick · `controller.events[25].tick` | 10 |
| `controller.events[26].detail.key` | proposal-001.ARC-410.L002.A1 |
| `controller.events[26].detail.slot` | ARCHIVE-COMPAT-A.EARLY |
| Recorded status · `controller.events[26].detail.status` | RESERVED |
| Recorded event · `controller.events[26].event` | CAPACITY_RESERVED |
| `controller.events[26].monotonic_ns` | 34589300254622 |
| Logical tick · `controller.events[26].tick` | 10 |
| Agreement identity · `controller.events[27].detail.args.agreement_id` | proposal-001 |
| `controller.events[27].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[27].detail.args.lot_id` | ARC-410.L002 |
| `controller.events[27].detail.args.supersedes` | Not recorded |
| `controller.events[27].detail.op` | produce |
| Recorded event · `controller.events[27].event` | BROKER_REQUEST |
| `controller.events[27].monotonic_ns` | 34589300581526 |
| Logical tick · `controller.events[27].tick` | 11 |
| `controller.events[28].detail.byte_count` | 73790 |
| `controller.events[28].detail.payload_sha256` | 01ee70c72691afa8f92481eccf44ad17bd35a97a7ca2ae928a77369c9193318f |
| `controller.events[28].detail.production_id` | proposal-001.ARC-410.L002.A1 |
| Required quantity · `controller.events[28].detail.quantity` | 150 |
| Recorded event · `controller.events[28].event` | PRODUCT_MATERIALIZED |
| `controller.events[28].monotonic_ns` | 34589336306844 |
| Logical tick · `controller.events[28].tick` | 11 |
| `controller.events[29].detail.args.production_id` | proposal-001.ARC-410.L002.A1 |
| `controller.events[29].detail.op` | transfer |
| Recorded event · `controller.events[29].event` | BROKER_REQUEST |
| `controller.events[29].monotonic_ns` | 34589336749152 |
| Logical tick · `controller.events[29].tick` | 12 |
| `controller.events[30].detail.byte_count` | 73790 |
| `controller.events[30].detail.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[30].detail.produced_sha256` | 01ee70c72691afa8f92481eccf44ad17bd35a97a7ca2ae928a77369c9193318f |
| `controller.events[30].detail.production_id` | proposal-001.ARC-410.L002.A1 |
| `controller.events[30].detail.received_sha256` | 01ee70c72691afa8f92481eccf44ad17bd35a97a7ca2ae928a77369c9193318f |
| Recorded event · `controller.events[30].event` | PRODUCT_TRANSFERRED |
| `controller.events[30].monotonic_ns` | 34589344329313 |
| Logical tick · `controller.events[30].tick` | 12 |
| `controller.events[31].detail.args.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[31].detail.op` | inspect |
| Recorded event · `controller.events[31].event` | BROKER_REQUEST |
| `controller.events[31].monotonic_ns` | 34589344702727 |
| Logical tick · `controller.events[31].tick` | 13 |
| `controller.events[32].detail.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[32].detail.hook` | inspect.after_observation |
| Recorded event · `controller.events[32].detail.schedule.event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.events[32].detail.schedule.occurrence` | 2 |
| Fault target · `controller.events[32].detail.schedule.target` | ANY |
| Trigger operation · `controller.events[32].detail.schedule.trigger` | inspect |
| Configured value · `controller.events[32].detail.schedule.value` | 0 |
| Recorded event · `controller.events[32].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| `controller.events[32].monotonic_ns` | 34589361614396 |
| Logical tick · `controller.events[32].tick` | 13 |
| `controller.events[33].detail.pid` | 258 |
| `controller.events[33].detail.service` | receiver |
| Recorded event · `controller.events[33].event` | SERVICE_TERMINATED |
| `controller.events[33].monotonic_ns` | 34589362786778 |
| Logical tick · `controller.events[33].tick` | 13 |
| `controller.events[34].detail.pid` | 265 |
| `controller.events[34].detail.restart` | Yes |
| `controller.events[34].detail.service` | receiver |
| Recorded event · `controller.events[34].event` | SERVICE_STARTED |
| `controller.events[34].monotonic_ns` | 34589403144580 |
| Logical tick · `controller.events[34].tick` | 13 |
| `controller.events[35].detail.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| Recorded event · `controller.events[35].event` | ACKNOWLEDGMENT_UNCERTAIN |
| `controller.events[35].monotonic_ns` | 34589403151931 |
| Logical tick · `controller.events[35].tick` | 13 |
| Stable code · `controller.events[36].detail.code` | ACK_UNKNOWN |
| `controller.events[36].detail.detail` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[36].detail.op` | inspect |
| Recorded event · `controller.events[36].event` | BROKER_REFUSED |
| `controller.events[36].monotonic_ns` | 34589403165972 |
| Logical tick · `controller.events[36].tick` | 13 |
| `controller.events[37].detail.args.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[37].detail.op` | inspect |
| Recorded event · `controller.events[37].event` | BROKER_REQUEST |
| `controller.events[37].monotonic_ns` | 34589405720063 |
| Logical tick · `controller.events[37].tick` | 14 |
| `controller.events[38].detail.delivery_id` | proposal-001.ARC-410.L002.A1.D |
| Recorded status · `controller.events[38].detail.status` | Accepted (`ACCEPTED`) |
| Recorded event · `controller.events[38].event` | ACCEPTANCE_RECONCILED |
| `controller.events[38].monotonic_ns` | 34589406188742 |
| Logical tick · `controller.events[38].tick` | 14 |
| `controller.events[39].detail.args` | No entries |
| `controller.events[39].detail.op` | status |
| Recorded event · `controller.events[39].event` | BROKER_REQUEST |
| `controller.events[39].monotonic_ns` | 34589406634556 |
| Logical tick · `controller.events[39].tick` | 15 |
| Agreement identity · `controller.events[40].detail.args.agreement_id` | proposal-001 |
| `controller.events[40].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[40].detail.args.lot_id` | ARC-410.L003 |
| `controller.events[40].detail.op` | reserve |
| Recorded event · `controller.events[40].event` | BROKER_REQUEST |
| `controller.events[40].monotonic_ns` | 34589415145474 |
| Logical tick · `controller.events[40].tick` | 16 |
| `controller.events[41].detail.key` | proposal-001.ARC-410.L003.A1 |
| `controller.events[41].detail.slot` | ARCHIVE-COMPAT-A.EARLY |
| Recorded status · `controller.events[41].detail.status` | RESERVED |
| Recorded event · `controller.events[41].event` | CAPACITY_RESERVED |
| `controller.events[41].monotonic_ns` | 34589424778878 |
| Logical tick · `controller.events[41].tick` | 16 |
| Agreement identity · `controller.events[42].detail.args.agreement_id` | proposal-001 |
| `controller.events[42].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[42].detail.args.lot_id` | ARC-410.L003 |
| `controller.events[42].detail.args.supersedes` | Not recorded |
| `controller.events[42].detail.op` | produce |
| Recorded event · `controller.events[42].event` | BROKER_REQUEST |
| `controller.events[42].monotonic_ns` | 34589425161988 |
| Logical tick · `controller.events[42].tick` | 17 |
| `controller.events[43].detail.byte_count` | 59150 |
| `controller.events[43].detail.payload_sha256` | 4d7dd08c6a2cffbb0148372e5207a9916bb769975637e00eb8d453bdd69f795e |
| `controller.events[43].detail.production_id` | proposal-001.ARC-410.L003.A1 |
| Required quantity · `controller.events[43].detail.quantity` | 120 |
| Recorded event · `controller.events[43].event` | PRODUCT_MATERIALIZED |
| `controller.events[43].monotonic_ns` | 34589451280321 |
| Logical tick · `controller.events[43].tick` | 17 |
| `controller.events[44].detail.args.production_id` | proposal-001.ARC-410.L003.A1 |
| `controller.events[44].detail.op` | transfer |
| Recorded event · `controller.events[44].event` | BROKER_REQUEST |
| `controller.events[44].monotonic_ns` | 34589451710512 |
| Logical tick · `controller.events[44].tick` | 18 |
| `controller.events[45].detail.byte_count` | 59150 |
| `controller.events[45].detail.delivery_id` | proposal-001.ARC-410.L003.A1.D |
| `controller.events[45].detail.produced_sha256` | 4d7dd08c6a2cffbb0148372e5207a9916bb769975637e00eb8d453bdd69f795e |
| `controller.events[45].detail.production_id` | proposal-001.ARC-410.L003.A1 |
| `controller.events[45].detail.received_sha256` | 4d7dd08c6a2cffbb0148372e5207a9916bb769975637e00eb8d453bdd69f795e |
| Recorded event · `controller.events[45].event` | PRODUCT_TRANSFERRED |
| `controller.events[45].monotonic_ns` | 34589461487207 |
| Logical tick · `controller.events[45].tick` | 18 |
| `controller.events[46].detail.args.delivery_id` | proposal-001.ARC-410.L003.A1.D |
| `controller.events[46].detail.op` | inspect |
| Recorded event · `controller.events[46].event` | BROKER_REQUEST |
| `controller.events[46].monotonic_ns` | 34589461883567 |
| Logical tick · `controller.events[46].tick` | 19 |
| `controller.events[47].detail.accepted_units` | 120 |
| `controller.events[47].detail.delivery_id` | proposal-001.ARC-410.L003.A1.D |
| Recorded status · `controller.events[47].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[47].detail.timely` | Yes |
| Recorded event · `controller.events[47].event` | RECIPIENT_INSPECTED |
| `controller.events[47].monotonic_ns` | 34589480126798 |
| Logical tick · `controller.events[47].tick` | 19 |
| `controller.events[48].detail.args` | No entries |
| `controller.events[48].detail.op` | status |
| Recorded event · `controller.events[48].event` | BROKER_REQUEST |
| `controller.events[48].monotonic_ns` | 34589480541115 |
| Logical tick · `controller.events[48].tick` | 20 |
| Agreement identity · `controller.events[49].detail.args.agreement_id` | proposal-001 |
| `controller.events[49].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[49].detail.args.lot_id` | ARC-520.L001 |
| `controller.events[49].detail.op` | reserve |
| Recorded event · `controller.events[49].event` | BROKER_REQUEST |
| `controller.events[49].monotonic_ns` | 34589489580221 |
| Logical tick · `controller.events[49].tick` | 21 |
| `controller.events[50].detail.key` | proposal-001.ARC-520.L001.A1 |
| `controller.events[50].detail.slot` | ARCHIVE-COMPAT-A.EARLY |
| Recorded status · `controller.events[50].detail.status` | RESERVED |
| Recorded event · `controller.events[50].event` | CAPACITY_RESERVED |
| `controller.events[50].monotonic_ns` | 34589499183710 |
| Logical tick · `controller.events[50].tick` | 21 |
| Agreement identity · `controller.events[51].detail.args.agreement_id` | proposal-001 |
| `controller.events[51].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[51].detail.args.lot_id` | ARC-520.L001 |
| `controller.events[51].detail.args.supersedes` | Not recorded |
| `controller.events[51].detail.op` | produce |
| Recorded event · `controller.events[51].event` | BROKER_REQUEST |
| `controller.events[51].monotonic_ns` | 34589499582563 |
| Logical tick · `controller.events[51].tick` | 22 |
| `controller.events[52].detail.byte_count` | 69929 |
| `controller.events[52].detail.payload_sha256` | 266bc54bb52c94598c1a8b5dc2b8a0b1a1586c9ad8f8347f43a23b0c539a7621 |
| `controller.events[52].detail.production_id` | proposal-001.ARC-520.L001.A1 |
| Required quantity · `controller.events[52].detail.quantity` | 150 |
| Recorded event · `controller.events[52].event` | PRODUCT_MATERIALIZED |
| `controller.events[52].monotonic_ns` | 34589532484848 |
| Logical tick · `controller.events[52].tick` | 22 |
| `controller.events[53].detail.args.production_id` | proposal-001.ARC-520.L001.A1 |
| `controller.events[53].detail.op` | transfer |
| Recorded event · `controller.events[53].event` | BROKER_REQUEST |
| `controller.events[53].monotonic_ns` | 34589532947427 |
| Logical tick · `controller.events[53].tick` | 23 |
| `controller.events[54].detail.byte_count` | 69929 |
| `controller.events[54].detail.delivery_id` | proposal-001.ARC-520.L001.A1.D |
| `controller.events[54].detail.produced_sha256` | 266bc54bb52c94598c1a8b5dc2b8a0b1a1586c9ad8f8347f43a23b0c539a7621 |
| `controller.events[54].detail.production_id` | proposal-001.ARC-520.L001.A1 |
| `controller.events[54].detail.received_sha256` | 266bc54bb52c94598c1a8b5dc2b8a0b1a1586c9ad8f8347f43a23b0c539a7621 |
| Recorded event · `controller.events[54].event` | PRODUCT_TRANSFERRED |
| `controller.events[54].monotonic_ns` | 34589543072154 |
| Logical tick · `controller.events[54].tick` | 23 |
| `controller.events[55].detail.args.delivery_id` | proposal-001.ARC-520.L001.A1.D |
| `controller.events[55].detail.op` | inspect |
| Recorded event · `controller.events[55].event` | BROKER_REQUEST |
| `controller.events[55].monotonic_ns` | 34589543414402 |
| Logical tick · `controller.events[55].tick` | 24 |
| `controller.events[56].detail.accepted_units` | 150 |
| `controller.events[56].detail.delivery_id` | proposal-001.ARC-520.L001.A1.D |
| Recorded status · `controller.events[56].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[56].detail.timely` | Yes |
| Recorded event · `controller.events[56].event` | RECIPIENT_INSPECTED |
| `controller.events[56].monotonic_ns` | 34589570958796 |
| Logical tick · `controller.events[56].tick` | 24 |
| `controller.events[57].detail.args` | No entries |
| `controller.events[57].detail.op` | status |
| Recorded event · `controller.events[57].event` | BROKER_REQUEST |
| `controller.events[57].monotonic_ns` | 34589572182877 |
| Logical tick · `controller.events[57].tick` | 25 |
| Agreement identity · `controller.events[58].detail.args.agreement_id` | proposal-001 |
| `controller.events[58].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[58].detail.args.lot_id` | ARC-520.L002 |
| `controller.events[58].detail.op` | reserve |
| Recorded event · `controller.events[58].event` | BROKER_REQUEST |
| `controller.events[58].monotonic_ns` | 34589583340330 |
| Logical tick · `controller.events[58].tick` | 26 |
| Provider identity · `controller.events[59].detail.provider_id` | ARCHIVE-COMPAT-A |
| Capacity-window identity · `controller.events[59].detail.window_id` | Late (`LATE`) |
| Recorded event · `controller.events[59].event` | WINDOW_ADVANCED |
| `controller.events[59].monotonic_ns` | 34589588516717 |
| Logical tick · `controller.events[59].tick` | 260 |
| `controller.events[60].detail.key` | proposal-001.ARC-520.L002.A1 |
| `controller.events[60].detail.slot` | ARCHIVE-COMPAT-A.LATE |
| Recorded status · `controller.events[60].detail.status` | RESERVED |
| Recorded event · `controller.events[60].event` | CAPACITY_RESERVED |
| `controller.events[60].monotonic_ns` | 34589592631963 |
| Logical tick · `controller.events[60].tick` | 260 |
| Agreement identity · `controller.events[61].detail.args.agreement_id` | proposal-001 |
| `controller.events[61].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[61].detail.args.lot_id` | ARC-520.L002 |
| `controller.events[61].detail.args.supersedes` | Not recorded |
| `controller.events[61].detail.op` | produce |
| Recorded event · `controller.events[61].event` | BROKER_REQUEST |
| `controller.events[61].monotonic_ns` | 34589593039349 |
| Logical tick · `controller.events[61].tick` | 261 |
| `controller.events[62].detail.byte_count` | 70039 |
| `controller.events[62].detail.payload_sha256` | 0b1cc0459fe370f0bcb2e15f75d26c638bdc422c6c44bba1cc68f22303d940b5 |
| `controller.events[62].detail.production_id` | proposal-001.ARC-520.L002.A1 |
| Required quantity · `controller.events[62].detail.quantity` | 150 |
| Recorded event · `controller.events[62].event` | PRODUCT_MATERIALIZED |
| `controller.events[62].monotonic_ns` | 34589622348922 |
| Logical tick · `controller.events[62].tick` | 261 |
| `controller.events[63].detail.args.production_id` | proposal-001.ARC-520.L002.A1 |
| `controller.events[63].detail.op` | transfer |
| Recorded event · `controller.events[63].event` | BROKER_REQUEST |
| `controller.events[63].monotonic_ns` | 34589622985124 |
| Logical tick · `controller.events[63].tick` | 262 |
| `controller.events[64].detail.byte_count` | 70039 |
| `controller.events[64].detail.delivery_id` | proposal-001.ARC-520.L002.A1.D |
| `controller.events[64].detail.produced_sha256` | 0b1cc0459fe370f0bcb2e15f75d26c638bdc422c6c44bba1cc68f22303d940b5 |
| `controller.events[64].detail.production_id` | proposal-001.ARC-520.L002.A1 |
| `controller.events[64].detail.received_sha256` | 0b1cc0459fe370f0bcb2e15f75d26c638bdc422c6c44bba1cc68f22303d940b5 |
| Recorded event · `controller.events[64].event` | PRODUCT_TRANSFERRED |
| `controller.events[64].monotonic_ns` | 34589631483837 |
| Logical tick · `controller.events[64].tick` | 262 |
| `controller.events[65].detail.args.delivery_id` | proposal-001.ARC-520.L002.A1.D |
| `controller.events[65].detail.op` | inspect |
| Recorded event · `controller.events[65].event` | BROKER_REQUEST |
| `controller.events[65].monotonic_ns` | 34589631965025 |
| Logical tick · `controller.events[65].tick` | 263 |
| `controller.events[66].detail.accepted_units` | 150 |
| `controller.events[66].detail.delivery_id` | proposal-001.ARC-520.L002.A1.D |
| Recorded status · `controller.events[66].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[66].detail.timely` | Yes |
| Recorded event · `controller.events[66].event` | RECIPIENT_INSPECTED |
| `controller.events[66].monotonic_ns` | 34589650809021 |
| Logical tick · `controller.events[66].tick` | 263 |
| `controller.events[67].detail.args` | No entries |
| `controller.events[67].detail.op` | status |
| Recorded event · `controller.events[67].event` | BROKER_REQUEST |
| `controller.events[67].monotonic_ns` | 34589651364811 |
| Logical tick · `controller.events[67].tick` | 264 |
| Agreement identity · `controller.events[68].detail.args.agreement_id` | proposal-001 |
| `controller.events[68].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[68].detail.args.lot_id` | ARC-520.L003 |
| `controller.events[68].detail.op` | reserve |
| Recorded event · `controller.events[68].event` | BROKER_REQUEST |
| `controller.events[68].monotonic_ns` | 34589663870548 |
| Logical tick · `controller.events[68].tick` | 265 |
| `controller.events[69].detail.key` | proposal-001.ARC-520.L003.A1 |
| `controller.events[69].detail.slot` | ARCHIVE-COMPAT-A.LATE |
| Recorded status · `controller.events[69].detail.status` | RESERVED |
| Recorded event · `controller.events[69].event` | CAPACITY_RESERVED |
| `controller.events[69].monotonic_ns` | 34589672954462 |
| Logical tick · `controller.events[69].tick` | 265 |
| Agreement identity · `controller.events[70].detail.args.agreement_id` | proposal-001 |
| `controller.events[70].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[70].detail.args.lot_id` | ARC-520.L003 |
| `controller.events[70].detail.args.supersedes` | Not recorded |
| `controller.events[70].detail.op` | produce |
| Recorded event · `controller.events[70].event` | BROKER_REQUEST |
| `controller.events[70].monotonic_ns` | 34589673365754 |
| Logical tick · `controller.events[70].tick` | 266 |
| `controller.events[71].detail.byte_count` | 14479 |
| `controller.events[71].detail.payload_sha256` | a4962f39948eef9cbd58efd357e6bd49120297729008d520fec62643ec1ab379 |
| `controller.events[71].detail.production_id` | proposal-001.ARC-520.L003.A1 |
| Required quantity · `controller.events[71].detail.quantity` | 30 |
| Recorded event · `controller.events[71].event` | PRODUCT_MATERIALIZED |
| `controller.events[71].monotonic_ns` | 34589698388215 |
| Logical tick · `controller.events[71].tick` | 266 |
| `controller.events[72].detail.args.production_id` | proposal-001.ARC-520.L003.A1 |
| `controller.events[72].detail.op` | transfer |
| Recorded event · `controller.events[72].event` | BROKER_REQUEST |
| `controller.events[72].monotonic_ns` | 34589698915151 |
| Logical tick · `controller.events[72].tick` | 267 |
| `controller.events[73].detail.byte_count` | 14479 |
| `controller.events[73].detail.delivery_id` | proposal-001.ARC-520.L003.A1.D |
| `controller.events[73].detail.produced_sha256` | a4962f39948eef9cbd58efd357e6bd49120297729008d520fec62643ec1ab379 |
| `controller.events[73].detail.production_id` | proposal-001.ARC-520.L003.A1 |
| `controller.events[73].detail.received_sha256` | a4962f39948eef9cbd58efd357e6bd49120297729008d520fec62643ec1ab379 |
| Recorded event · `controller.events[73].event` | PRODUCT_TRANSFERRED |
| `controller.events[73].monotonic_ns` | 34589711068546 |
| Logical tick · `controller.events[73].tick` | 267 |
| `controller.events[74].detail.args.delivery_id` | proposal-001.ARC-520.L003.A1.D |
| `controller.events[74].detail.op` | inspect |
| Recorded event · `controller.events[74].event` | BROKER_REQUEST |
| `controller.events[74].monotonic_ns` | 34589711426337 |
| Logical tick · `controller.events[74].tick` | 268 |
| `controller.events[75].detail.accepted_units` | 30 |
| `controller.events[75].detail.delivery_id` | proposal-001.ARC-520.L003.A1.D |
| Recorded status · `controller.events[75].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[75].detail.timely` | Yes |
| Recorded event · `controller.events[75].event` | RECIPIENT_INSPECTED |
| `controller.events[75].monotonic_ns` | 34589719217857 |
| Logical tick · `controller.events[75].tick` | 268 |
| `controller.events[76].detail.args` | No entries |
| `controller.events[76].detail.op` | status |
| Recorded event · `controller.events[76].event` | BROKER_REQUEST |
| `controller.events[76].monotonic_ns` | 34589719637071 |
| Logical tick · `controller.events[76].tick` | 269 |
| Agreement identity · `controller.events[77].detail.args.agreement_id` | proposal-001 |
| `controller.events[77].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[77].detail.args.lot_id` | ARC-630.L001 |
| `controller.events[77].detail.op` | reserve |
| Recorded event · `controller.events[77].event` | BROKER_REQUEST |
| `controller.events[77].monotonic_ns` | 34589732096468 |
| Logical tick · `controller.events[77].tick` | 270 |
| `controller.events[78].detail.key` | proposal-001.ARC-630.L001.A1 |
| `controller.events[78].detail.slot` | ARCHIVE-COMPAT-A.LATE |
| Recorded status · `controller.events[78].detail.status` | RESERVED |
| Recorded event · `controller.events[78].event` | CAPACITY_RESERVED |
| `controller.events[78].monotonic_ns` | 34589740748008 |
| Logical tick · `controller.events[78].tick` | 270 |
| Agreement identity · `controller.events[79].detail.args.agreement_id` | proposal-001 |
| `controller.events[79].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[79].detail.args.lot_id` | ARC-630.L001 |
| `controller.events[79].detail.args.supersedes` | Not recorded |
| `controller.events[79].detail.op` | produce |
| Recorded event · `controller.events[79].event` | BROKER_REQUEST |
| `controller.events[79].monotonic_ns` | 34589741333092 |
| Logical tick · `controller.events[79].tick` | 271 |
| `controller.events[80].detail.byte_count` | 72479 |
| `controller.events[80].detail.payload_sha256` | 284e242baae7d5db86bc7201a48e9c2a2c7686e61a38047317f84a60d6b437a1 |
| `controller.events[80].detail.production_id` | proposal-001.ARC-630.L001.A1 |
| Required quantity · `controller.events[80].detail.quantity` | 150 |
| Recorded event · `controller.events[80].event` | PRODUCT_MATERIALIZED |
| `controller.events[80].monotonic_ns` | 34589766555515 |
| Logical tick · `controller.events[80].tick` | 271 |
| `controller.events[81].detail.args.production_id` | proposal-001.ARC-630.L001.A1 |
| `controller.events[81].detail.op` | transfer |
| Recorded event · `controller.events[81].event` | BROKER_REQUEST |
| `controller.events[81].monotonic_ns` | 34589766968920 |
| Logical tick · `controller.events[81].tick` | 272 |
| `controller.events[82].detail.byte_count` | 72479 |
| `controller.events[82].detail.delivery_id` | proposal-001.ARC-630.L001.A1.D |
| `controller.events[82].detail.produced_sha256` | 284e242baae7d5db86bc7201a48e9c2a2c7686e61a38047317f84a60d6b437a1 |
| `controller.events[82].detail.production_id` | proposal-001.ARC-630.L001.A1 |
| `controller.events[82].detail.received_sha256` | 284e242baae7d5db86bc7201a48e9c2a2c7686e61a38047317f84a60d6b437a1 |
| Recorded event · `controller.events[82].event` | PRODUCT_TRANSFERRED |
| `controller.events[82].monotonic_ns` | 34589776132084 |
| Logical tick · `controller.events[82].tick` | 272 |
| `controller.events[83].detail.args.delivery_id` | proposal-001.ARC-630.L001.A1.D |
| `controller.events[83].detail.op` | inspect |
| Recorded event · `controller.events[83].event` | BROKER_REQUEST |
| `controller.events[83].monotonic_ns` | 34589776446289 |
| Logical tick · `controller.events[83].tick` | 273 |
| `controller.events[84].detail.accepted_units` | 150 |
| `controller.events[84].detail.delivery_id` | proposal-001.ARC-630.L001.A1.D |
| Recorded status · `controller.events[84].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[84].detail.timely` | Yes |
| Recorded event · `controller.events[84].event` | RECIPIENT_INSPECTED |
| `controller.events[84].monotonic_ns` | 34589791587921 |
| Logical tick · `controller.events[84].tick` | 273 |
| `controller.events[85].detail.args` | No entries |
| `controller.events[85].detail.op` | status |
| Recorded event · `controller.events[85].event` | BROKER_REQUEST |
| `controller.events[85].monotonic_ns` | 34589792111233 |
| Logical tick · `controller.events[85].tick` | 274 |
| Agreement identity · `controller.events[86].detail.args.agreement_id` | proposal-001 |
| `controller.events[86].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[86].detail.args.lot_id` | ARC-630.L002 |
| `controller.events[86].detail.op` | reserve |
| Recorded event · `controller.events[86].event` | BROKER_REQUEST |
| `controller.events[86].monotonic_ns` | 34589805752637 |
| Logical tick · `controller.events[86].tick` | 275 |
| `controller.events[87].detail.key` | proposal-001.ARC-630.L002.A1 |
| `controller.events[87].detail.slot` | ARCHIVE-COMPAT-B.LATE |
| Recorded status · `controller.events[87].detail.status` | RESERVED |
| Recorded event · `controller.events[87].event` | CAPACITY_RESERVED |
| `controller.events[87].monotonic_ns` | 34589814156833 |
| Logical tick · `controller.events[87].tick` | 275 |
| Agreement identity · `controller.events[88].detail.args.agreement_id` | proposal-001 |
| `controller.events[88].detail.args.attempt` | 1 |
| Fixed lot identity · `controller.events[88].detail.args.lot_id` | ARC-630.L002 |
| `controller.events[88].detail.args.supersedes` | Not recorded |
| `controller.events[88].detail.op` | produce |
| Recorded event · `controller.events[88].event` | BROKER_REQUEST |
| `controller.events[88].monotonic_ns` | 34589814974149 |
| Logical tick · `controller.events[88].tick` | 276 |
| `controller.events[89].detail.byte_count` | 58189 |
| `controller.events[89].detail.payload_sha256` | 64333b26a7e0f3ee23d25c025e22ecc5efef422eaeded448d9a3d79128e5d68a |
| `controller.events[89].detail.production_id` | proposal-001.ARC-630.L002.A1 |
| Required quantity · `controller.events[89].detail.quantity` | 120 |
| Recorded event · `controller.events[89].event` | PRODUCT_MATERIALIZED |
| `controller.events[89].monotonic_ns` | 34589849711337 |
| Logical tick · `controller.events[89].tick` | 276 |
| `controller.events[90].detail.args.production_id` | proposal-001.ARC-630.L002.A1 |
| `controller.events[90].detail.op` | transfer |
| Recorded event · `controller.events[90].event` | BROKER_REQUEST |
| `controller.events[90].monotonic_ns` | 34589850142709 |
| Logical tick · `controller.events[90].tick` | 277 |
| `controller.events[91].detail.byte_count` | 58189 |
| `controller.events[91].detail.delivery_id` | proposal-001.ARC-630.L002.A1.D |
| `controller.events[91].detail.produced_sha256` | 64333b26a7e0f3ee23d25c025e22ecc5efef422eaeded448d9a3d79128e5d68a |
| `controller.events[91].detail.production_id` | proposal-001.ARC-630.L002.A1 |
| `controller.events[91].detail.received_sha256` | 64333b26a7e0f3ee23d25c025e22ecc5efef422eaeded448d9a3d79128e5d68a |
| Recorded event · `controller.events[91].event` | PRODUCT_TRANSFERRED |
| `controller.events[91].monotonic_ns` | 34589861950222 |
| Logical tick · `controller.events[91].tick` | 277 |
| `controller.events[92].detail.args.delivery_id` | proposal-001.ARC-630.L002.A1.D |
| `controller.events[92].detail.op` | inspect |
| Recorded event · `controller.events[92].event` | BROKER_REQUEST |
| `controller.events[92].monotonic_ns` | 34589862431880 |
| Logical tick · `controller.events[92].tick` | 278 |
| `controller.events[93].detail.accepted_units` | 120 |
| `controller.events[93].detail.delivery_id` | proposal-001.ARC-630.L002.A1.D |
| Recorded status · `controller.events[93].detail.status` | Accepted (`ACCEPTED`) |
| `controller.events[93].detail.timely` | Yes |
| Recorded event · `controller.events[93].event` | RECIPIENT_INSPECTED |
| `controller.events[93].monotonic_ns` | 34589875741383 |
| Logical tick · `controller.events[93].tick` | 278 |
| Agreement identity · `controller.events[94].detail.args.agreement_id` | proposal-001 |
| `controller.events[94].detail.op` | settle |
| Recorded event · `controller.events[94].event` | BROKER_REQUEST |
| `controller.events[94].monotonic_ns` | 34589876416253 |
| Logical tick · `controller.events[94].tick` | 279 |
| Acceptance references · `controller.events[95].detail.acceptance_ids[0]` | proposal-001.ARC-410.L001.A1.D |
| Acceptance references · `controller.events[95].detail.acceptance_ids[1]` | proposal-001.ARC-410.L002.A1.D |
| Acceptance references · `controller.events[95].detail.acceptance_ids[2]` | proposal-001.ARC-410.L003.A1.D |
| Acceptance references · `controller.events[95].detail.acceptance_ids[3]` | proposal-001.ARC-520.L001.A1.D |
| Acceptance references · `controller.events[95].detail.acceptance_ids[4]` | proposal-001.ARC-520.L002.A1.D |
| Acceptance references · `controller.events[95].detail.acceptance_ids[5]` | proposal-001.ARC-520.L003.A1.D |
| Acceptance references · `controller.events[95].detail.acceptance_ids[6]` | proposal-001.ARC-630.L001.A1.D |
| Acceptance references · `controller.events[95].detail.acceptance_ids[7]` | proposal-001.ARC-630.L002.A1.D |
| Agreement identity · `controller.events[95].detail.agreement_id` | proposal-001 |
| Recorded event · `controller.events[95].event` | ARRANGEMENT_SETTLED |
| `controller.events[95].monotonic_ns` | 34589887938098 |
| Logical tick · `controller.events[95].tick` | 279 |
| `controller.events[96].detail.interventions[0].delivery_id` | proposal-001.ARC-410.L002.A1.D |
| `controller.events[96].detail.interventions[0].type` | AUTOMATIC_IDEMPOTENT_RETRY |
| Recorded reason · `controller.events[96].detail.reason` | DIGITAL_PRODUCT_ACCEPTED |
| `controller.events[96].detail.searches[0].assignment_domain` | 6561 |
| `controller.events[96].detail.searches[0].candidate_elapsed_ns` | 4442647 |
| `controller.events[96].detail.searches[0].capacity_prunes` | 62 |
| `controller.events[96].detail.searches[0].complete_assignments_observed` | 48 |
| `controller.events[96].detail.searches[0].exhaustive_within_declared_domain` | Yes |
| `controller.events[96].detail.searches[0].feasible_assignments` | 27 |
| `controller.events[96].detail.searches[0].funding_basis` | CURRENT_UNENCUMBERED_BALANCES |
| Candidate procedure · `controller.events[96].detail.searches[0].method` | harness |
| `controller.events[96].detail.searches[0].partial_nodes_observed` | 125 |
| `controller.events[96].detail.searches[0].participant_prunes` | 21 |
| `controller.events[96].detail.searches[0].price_prunes` | 15 |
| Component verdict · `controller.events[96].detail.verdict` | Completed (`COMPLETED`) |
| Recorded event · `controller.events[96].event` | CANDIDATE_DONE |
| `controller.events[96].monotonic_ns` | 34589888811368 |
| Logical tick · `controller.events[96].tick` | 279 |
| `controller.events[97].detail.database` | participants |
| `controller.events[97].detail.sqlite[0]` | 0 |
| `controller.events[97].detail.sqlite[1]` | 0 |
| `controller.events[97].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[97].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[97].event` | DATABASE_CHECKPOINT |
| `controller.events[97].monotonic_ns` | 34589924263463 |
| Logical tick · `controller.events[97].tick` | 279 |
| `controller.events[98].detail.database` | producer |
| `controller.events[98].detail.sqlite[0]` | 0 |
| `controller.events[98].detail.sqlite[1]` | 0 |
| `controller.events[98].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[98].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[98].event` | DATABASE_CHECKPOINT |
| `controller.events[98].monotonic_ns` | 34589928895465 |
| Logical tick · `controller.events[98].tick` | 279 |
| `controller.events[99].detail.database` | receiver |
| `controller.events[99].detail.sqlite[0]` | 0 |
| `controller.events[99].detail.sqlite[1]` | 0 |
| `controller.events[99].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[99].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[99].event` | DATABASE_CHECKPOINT |
| `controller.events[99].monotonic_ns` | 34589931407022 |
| Logical tick · `controller.events[99].tick` | 279 |
| `controller.events[100].detail.database` | ARCHIVE-PRIMARY.ALL |
| `controller.events[100].detail.sqlite[0]` | 0 |
| `controller.events[100].detail.sqlite[1]` | 0 |
| `controller.events[100].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[100].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[100].event` | DATABASE_CHECKPOINT |
| `controller.events[100].monotonic_ns` | 34589932620727 |
| Logical tick · `controller.events[100].tick` | 279 |
| `controller.events[101].detail.database` | ARCHIVE-BACKUP.ALL |
| `controller.events[101].detail.sqlite[0]` | 0 |
| `controller.events[101].detail.sqlite[1]` | 0 |
| `controller.events[101].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[101].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[101].event` | DATABASE_CHECKPOINT |
| `controller.events[101].monotonic_ns` | 34589934115367 |
| Logical tick · `controller.events[101].tick` | 279 |
| `controller.events[102].detail.database` | ARCHIVE-COMPAT-A.EARLY |
| `controller.events[102].detail.sqlite[0]` | 0 |
| `controller.events[102].detail.sqlite[1]` | 0 |
| `controller.events[102].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[102].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[102].event` | DATABASE_CHECKPOINT |
| `controller.events[102].monotonic_ns` | 34589935359198 |
| Logical tick · `controller.events[102].tick` | 279 |
| `controller.events[103].detail.database` | ARCHIVE-COMPAT-A.LATE |
| `controller.events[103].detail.sqlite[0]` | 0 |
| `controller.events[103].detail.sqlite[1]` | 0 |
| `controller.events[103].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[103].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[103].event` | DATABASE_CHECKPOINT |
| `controller.events[103].monotonic_ns` | 34589936664822 |
| Logical tick · `controller.events[103].tick` | 279 |
| `controller.events[104].detail.database` | ARCHIVE-COMPAT-B.LATE |
| `controller.events[104].detail.sqlite[0]` | 0 |
| `controller.events[104].detail.sqlite[1]` | 0 |
| `controller.events[104].detail.sqlite[2]` | 0 |
| Recorded status · `controller.events[104].detail.status` | CHECKPOINTED |
| Recorded event · `controller.events[104].event` | DATABASE_CHECKPOINT |
| `controller.events[104].monotonic_ns` | 34589937894972 |
| Logical tick · `controller.events[104].tick` | 279 |
| `controller.events[105].detail.databases` | 8 |
| `controller.events[105].detail.snapshot_method` | SQLITE_BACKUP_DELETE_FULL_LOGICAL_DIGEST |
| Recorded event · `controller.events[105].event` | EVIDENCE_FINALIZED |
| `controller.events[105].monotonic_ns` | 34590086254805 |
| Logical tick · `controller.events[105].tick` | 279 |
| Recorded event · `controller.fault_schedule[0].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.fault_schedule[0].occurrence` | 2 |
| Fault target · `controller.fault_schedule[0].target` | ANY |
| Trigger operation · `controller.fault_schedule[0].trigger` | inspect |
| Configured value · `controller.fault_schedule[0].value` | 0 |
| Recorded event · `controller.faults_observed[0].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `controller.faults_observed[0].occurrence` | 2 |
| Fault target · `controller.faults_observed[0].target` | ANY |
| Trigger operation · `controller.faults_observed[0].trigger` | inspect |
| Configured value · `controller.faults_observed[0].value` | 0 |
| `controller.finished_monotonic_ns` | 34590086260694 |
| Registered fixture identity · `controller.fixture_id` | archive-window-transfer |
| Uncommitted source changes present · `controller.implementation.dirty` | No |
| Exact process arguments · `controller.implementation.environment.argv[0]` | python3 |
| Exact process arguments · `controller.implementation.environment.argv[1]` | -m |
| Exact process arguments · `controller.implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `controller.implementation.environment.argv[3]` | --language |
| Exact process arguments · `controller.implementation.environment.argv[4]` | en |
| Exact process arguments · `controller.implementation.environment.argv[5]` | experiment |
| Exact process arguments · `controller.implementation.environment.argv[6]` | --out |
| Exact process arguments · `controller.implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-qualification/complete-attempt-1 |
| Operating platform · `controller.implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `controller.implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `controller.implementation.environment.sqlite_version` | 3.53.1 |
| Execution directory · `controller.implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-qualified-complete |
| Actual source commit · `controller.implementation.git_commit` | 3494becbbfaf15ae571a71df05a49b9ce982cc84 |
| Preserved capacity implementation baseline · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `controller.implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `controller.implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Yes |
| `controller.isolation.mechanism` | Observed seccomp-BPF process confinement (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Yes |
| `controller.isolation.probe.network_denied` | Yes |
| `controller.isolation.probe.process_inspection_denied` | Yes |
| `controller.isolation.probe.spawn_denied` | Yes |
| `controller.isolation.probe.workspace_open_denied` | Yes |
| Candidate procedure · `controller.method` | harness |
| `controller.policies_sha256` | 70dd87bf5d2d57357abeb0a5d537324b3aba1560a3fe3d9a23e442fd05b710b9 |
| Adaptation labor (seconds; unknown if absent) · `controller.resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `controller.resources.authority_storage_bytes_before_seal` | 52832 |
| Candidate restarts · `controller.resources.candidate_restarts` | 0 |
| Launched child processes · `controller.resources.child_processes` | 10 |
| Controller system CPU (ns) · `controller.resources.controller_cpu_system_ns` | 25835000 |
| Controller user CPU (ns) · `controller.resources.controller_cpu_user_ns` | 201382999 |
| System CPU (ns) · `controller.resources.cpu_system_ns` | 112332000 |
| User CPU (ns) · `controller.resources.cpu_user_ns` | 701510000 |
| Human interventions · `controller.resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `controller.resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `controller.resources.measurement_scope` | controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process |
| Measured real monetary cost · `controller.resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `controller.resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `controller.resources.preparation_labor_seconds` | Not recorded |
| Requests · `controller.resources.requests` | 45 |
| Retries · `controller.resources.retries` | 1 |
| Internal service requests · `controller.resources.service_requests` | 239 |
| Recorded storage (bytes) · `controller.resources.storage_bytes` | 6498354 |
| `controller.resources.storage_scope` | files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately |
| Human verification labor (seconds; unknown if absent) · `controller.resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `controller.resources.wall_ns` | 1302063181 |
| Worker restarts · `controller.resources.worker_restarts` | 1 |
| Run identity · `controller.run_id` | archive-window-transfer.harness.938d770fd7 |
| Schema · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 34588784197513 |
| `controller.started_utc` | 2026-11-06T23:13:10.902798+00:00 |
| `controller.state` | Complete verification (`COMPLETE`) |
| Target verdict · `controller.target_verdict` | Completed (`COMPLETED`) |
| Recorded event · `fault_schedule[0].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `fault_schedule[0].occurrence` | 2 |
| Fault target · `fault_schedule[0].target` | ANY |
| Trigger operation · `fault_schedule[0].trigger` | inspect |
| Configured value · `fault_schedule[0].value` | 0 |
| Recorded event · `faults_observed[0].event` | Acknowledgment lost after durable acceptance (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Trigger occurrence · `faults_observed[0].occurrence` | 2 |
| Fault target · `faults_observed[0].target` | ANY |
| Trigger operation · `faults_observed[0].trigger` | inspect |
| Configured value · `faults_observed[0].value` | 0 |
| Registered fixture identity · `fixture_id` | archive-window-transfer |
| Uncommitted source changes present · `implementation.dirty` | No |
| Exact process arguments · `implementation.environment.argv[0]` | python3 |
| Exact process arguments · `implementation.environment.argv[1]` | -m |
| Exact process arguments · `implementation.environment.argv[2]` | continuity_economy |
| Exact process arguments · `implementation.environment.argv[3]` | --language |
| Exact process arguments · `implementation.environment.argv[4]` | en |
| Exact process arguments · `implementation.environment.argv[5]` | experiment |
| Exact process arguments · `implementation.environment.argv[6]` | --out |
| Exact process arguments · `implementation.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-qualification/complete-attempt-1 |
| Operating platform · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `implementation.environment.sqlite_version` | 3.53.1 |
| Execution directory · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-qualified-complete |
| Actual source commit · `implementation.git_commit` | 3494becbbfaf15ae571a71df05a49b9ce982cc84 |
| Preserved capacity implementation baseline · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `implementation.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `implementation.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `implementation.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `implementation.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `implementation.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `implementation.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `implementation.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `implementation.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `implementation.version` | 0.2.0 |
| Candidate procedure · `method` | harness |
| Balance (synthetic SMU minor units) · `policies.buyer.balance_minor` | 7600 |
| `policies.buyer.consent_until_tick` | 650 |
| `policies.buyer.max_price_minor` | 7000 |
| Authored outside-option utility (synthetic SMU minor units) · `policies.buyer.outside_utility_minor` | 1800 |
| Participant identity · `policies.buyer.party_id` | BUYER-ARCHIVE |
| Authored value upper bound (synthetic SMU minor units) · `policies.buyer.value_max_minor` | 9600 |
| Authored value lower bound (synthetic SMU minor units) · `policies.buyer.value_min_minor` | 8200 |
| Balance (synthetic SMU minor units) · `policies.coordinator.balance_minor` | 1000 |
| `policies.coordinator.consent_until_tick` | 650 |
| `policies.coordinator.liability_limit_minor` | 600 |
| `policies.coordinator.min_profit_minor` | 70 |
| `policies.coordinator.operating_cost_minor` | 180 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.coordinator.outside_profit_minor` | 110 |
| Participant identity · `policies.coordinator.party_id` | COORDINATOR-ARCHIVE |
| `policies.coordinator.technical_control_allowed` | No |
| Synthetic accounting unit · `policies.currency` | SMU |
| Balance (synthetic SMU minor units) · `policies.providers[0].balance_minor` | 4500 |
| `policies.providers[0].consent_until_tick` | 600 |
| `policies.providers[0].liability_limit_minor` | 4500 |
| `policies.providers[0].min_profit_minor` | 100 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[0].outside_profit_minor` | 150 |
| Participant identity · `policies.providers[0].party_id` | ARCHIVE-PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 80 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 80 |
| `policies.providers[0].technical_control_allowed` | No |
| `policies.providers[0].unit_cost_minor` | 1 |
| Balance (synthetic SMU minor units) · `policies.providers[1].balance_minor` | 4500 |
| `policies.providers[1].consent_until_tick` | 600 |
| `policies.providers[1].liability_limit_minor` | 4500 |
| `policies.providers[1].min_profit_minor` | 120 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[1].outside_profit_minor` | 160 |
| Participant identity · `policies.providers[1].party_id` | ARCHIVE-BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 100 |
| `policies.providers[1].rework_unit_cost_minor` | 1 |
| `policies.providers[1].setup_cost_minor` | 60 |
| `policies.providers[1].technical_control_allowed` | No |
| `policies.providers[1].unit_cost_minor` | 1 |
| Balance (synthetic SMU minor units) · `policies.providers[2].balance_minor` | 6000 |
| `policies.providers[2].consent_until_tick` | 600 |
| `policies.providers[2].liability_limit_minor` | 4200 |
| `policies.providers[2].min_profit_minor` | 180 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[2].outside_profit_minor` | 260 |
| Participant identity · `policies.providers[2].party_id` | ARCHIVE-COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 120 |
| `policies.providers[2].rework_unit_cost_minor` | 2 |
| `policies.providers[2].setup_cost_minor` | 240 |
| `policies.providers[2].technical_control_allowed` | No |
| `policies.providers[2].unit_cost_minor` | 2 |
| Balance (synthetic SMU minor units) · `policies.providers[3].balance_minor` | 2500 |
| `policies.providers[3].consent_until_tick` | 600 |
| `policies.providers[3].liability_limit_minor` | 1600 |
| `policies.providers[3].min_profit_minor` | 150 |
| Authored outside-option profit (synthetic SMU minor units) · `policies.providers[3].outside_profit_minor` | 200 |
| Participant identity · `policies.providers[3].party_id` | ARCHIVE-COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 60 |
| `policies.providers[3].rework_unit_cost_minor` | 3 |
| `policies.providers[3].setup_cost_minor` | 90 |
| `policies.providers[3].technical_control_allowed` | No |
| `policies.providers[3].unit_cost_minor` | 4 |
| Revision · `policies.revision` | 1 |
| Schema · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | No |
| Balance (synthetic SMU minor units) · `policies.technical_sponsor.balance_minor` | 0 |
| Participant identity · `policies.technical_sponsor.party_id` | UNUSED-SPONSOR |
| External reference pin · `reference_sha256` | 52f77f91846c3eae93acdc9efdd7faa52f499f7eb2df5be8443fda2fc43af369 |
| `registered_assertion.expected.accepted_units` | 1020 |
| Outcome · `registered_assertion.expected.outcome` | Demonstrated in scope (`DEMONSTRATED`) |
| `registered_assertion.expected.service_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| `registered_assertion.observed.accepted_units` | 1020 |
| Outcome · `registered_assertion.observed.outcome` | Demonstrated in scope (`DEMONSTRATED`) |
| `registered_assertion.observed.service_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Assessment scope · `registered_assertion.scope` | Registered assessment assertion; it does not assert a favorable outcome or trade. |
| Recorded status · `registered_assertion.status` | Passed (`PASSED`) |
| Uncommitted source changes present · `source_version.dirty` | No |
| Exact process arguments · `source_version.environment.argv[0]` | python3 |
| Exact process arguments · `source_version.environment.argv[1]` | -m |
| Exact process arguments · `source_version.environment.argv[2]` | continuity_economy |
| Exact process arguments · `source_version.environment.argv[3]` | --language |
| Exact process arguments · `source_version.environment.argv[4]` | en |
| Exact process arguments · `source_version.environment.argv[5]` | experiment |
| Exact process arguments · `source_version.environment.argv[6]` | --out |
| Exact process arguments · `source_version.environment.argv[7]` | /workspace/scratch/b1d5891eb025/economy-qualification/complete-attempt-1 |
| Operating platform · `source_version.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `source_version.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `source_version.environment.sqlite_version` | 3.53.1 |
| Execution directory · `source_version.environment.working_directory` | /workspace/scratch/b1d5891eb025/economy-qualified-complete |
| Actual source commit · `source_version.git_commit` | 3494becbbfaf15ae571a71df05a49b9ce982cc84 |
| Preserved capacity implementation baseline · `source_version.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `source_version.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `source_version.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `source_version.source_sha256.continuity_economy/adapters.py` | 61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39 |
| `source_version.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `source_version.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `source_version.source_sha256.continuity_economy/controller.py` | 5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9 |
| `source_version.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `source_version.source_sha256.continuity_economy/participants.py` | 372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b |
| `source_version.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `source_version.source_sha256.continuity_economy/policy_schema.py` | 42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6 |
| `source_version.source_sha256.continuity_economy/producer.py` | 3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a |
| `source_version.source_sha256.continuity_economy/receiver.py` | 9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f |
| `source_version.source_sha256.continuity_economy/reporting.py` | fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea |
| `source_version.source_sha256.continuity_economy/schema.py` | 2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7 |
| `source_version.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `source_version.source_sha256.continuity_economy/verifier.py` | 59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de |
| `source_version.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `source_version.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `source_version.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `source_version.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `source_version.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `source_version.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `source_version.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `source_version.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `source_version.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `source_version.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `source_version.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `source_version.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `source_version.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `source_version.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `source_version.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `source_version.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `source_version.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `source_version.source_sha256.experiments/economy-v0.2/reuse-freeze.json` | 319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13 |
| `source_version.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| `source_version.source_sha256.experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json` | 6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c |
| `source_version.source_sha256.experiments/economy-v0.2/successor.json` | 011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc |
| Implementation version · `source_version.version` | 0.2.0 |
| Explicit trust assumptions · `trust_assumptions[0]` | Trusted host, kernel, controller and clock (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Explicit trust assumptions · `trust_assumptions[1]` | Trusted retained synthetic authority (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Explicit trust assumptions · `trust_assumptions[2]` | Shared authorship; no third-party certification (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Explicit trust assumptions · `trust_assumptions[3]` | Semantic digital content only; physical delivery is untested (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Registered faults not triggered · `untriggered_faults` | No entries |

## Complete structured verification record

The same structured record generates both language versions. Machine keys, enum codes and literal evidence values remain unchanged; the localized sections above explain their meaning. No saved result is reused as fresh proof.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 5700,
    "buyer_utility_interval_minor": {
      "maximum": 3900,
      "minimum": 2500
    },
    "campaign": [
      {
        "final_balance_minor": 1900,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 7600,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER-ARCHIVE",
        "purchase_payments_minor": 5700,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 1110,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 180,
        "initial_balance_minor": 1000,
        "participation_covered": true,
        "participation_threshold_minor": 110,
        "party_id": "COORDINATOR-ARCHIVE",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 110,
        "revenue_minor": 290,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 0,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 0,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "UNUSED-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 4500,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 4500,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "ARCHIVE-PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 4500,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 4500,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "ARCHIVE-BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 8180,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 2040,
        "initial_balance_minor": 6000,
        "participation_covered": true,
        "participation_threshold_minor": 260,
        "party_id": "ARCHIVE-COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 2180,
        "revenue_minor": 4220,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 3120,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 570,
        "initial_balance_minor": 2500,
        "participation_covered": true,
        "participation_threshold_minor": 200,
        "party_id": "ARCHIVE-COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 620,
        "revenue_minor": 1190,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 26100,
    "initial_total_minor": 26100,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 2790,
    "total_transfers_minor": 5700,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED",
    "REPORTING_AND_FINAL_SEAL_OVERHEAD_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "DEMONSTRATED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "COMPLETED",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "DEMONSTRATED",
    "service_feasibility": "DEMONSTRATED"
  },
  "cohort": "successor",
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "da2441381af31c8e77df5382e02000b5af8132310fe7e6f533f9f0d252d5782e",
  "evidence_sha256": {
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L001.A1.json": "e100b4479f868d193b71358f2c6f10edb744c5de7c1ca78bd1d365e6022d39af",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L002.A1.json": "951cdb48174ae30a2aae6eca5eb9f68568a8c4815545f4dbd24dae0af2a007ee",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-410.L003.A1.json": "b39781084b1c48f289f919219cbfe1811f0cb6053c77cb43476f55a92c486d7f",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.EARLY/ARC-520.L001.A1.json": "cabef13db17adae40232531c28c3e97c6de7375e4c309166fccb6794de1dbe6c",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-520.L002.A1.json": "8a74ef4255bb90ebd374824548a39d828d9760872fc9c44b1921aeaa63cba741",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-520.L003.A1.json": "f80504c2738725846fb8680810cae3be5decea9d02d6a053f6dc57a9b1cb5dfc",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-A.LATE/ARC-630.L001.A1.json": "fcc54615801f5f44ca666a6810680bd6cd6089551a9c2c3d207d927b6cecc2a8",
    "evidence/capacity-artifacts/ARCHIVE-COMPAT-B.LATE/ARC-630.L002.A1.json": "840668399d49cc0aa84f9350d62d04076c0425b993e808c69bb77ec808248683",
    "evidence/capacity/ARCHIVE-BACKUP.ALL.sqlite": "b224b59db970daf94e8af0bf56e532c7ba0a2943bc3a3767a0021502869ee676",
    "evidence/capacity/ARCHIVE-COMPAT-A.EARLY.sqlite": "0561f2c896df1591ae63eb5448f76f2c15c3e402cbceba8566f9a6e2bea3915c",
    "evidence/capacity/ARCHIVE-COMPAT-A.LATE.sqlite": "5765184407750b23144a2a24d105b2bc23d0b8e2cc0e4717259cc9460b574d98",
    "evidence/capacity/ARCHIVE-COMPAT-B.LATE.sqlite": "c5a790052e5c4bae942965de058dc2d52fc90e61160805c744a091ace281343d",
    "evidence/capacity/ARCHIVE-PRIMARY.ALL.sqlite": "357774986962cc674778ef276a4b2d21d5cddc76e22697b1292fcb47769800d4",
    "evidence/inbox/proposal-001.ARC-410.L001.A1.D.json": "eb8cf0d4e5f3fe84d735abdb939c338e9a2911f333e3b405edbab29685a6e0d9",
    "evidence/inbox/proposal-001.ARC-410.L002.A1.D.json": "01ee70c72691afa8f92481eccf44ad17bd35a97a7ca2ae928a77369c9193318f",
    "evidence/inbox/proposal-001.ARC-410.L003.A1.D.json": "4d7dd08c6a2cffbb0148372e5207a9916bb769975637e00eb8d453bdd69f795e",
    "evidence/inbox/proposal-001.ARC-520.L001.A1.D.json": "266bc54bb52c94598c1a8b5dc2b8a0b1a1586c9ad8f8347f43a23b0c539a7621",
    "evidence/inbox/proposal-001.ARC-520.L002.A1.D.json": "0b1cc0459fe370f0bcb2e15f75d26c638bdc422c6c44bba1cc68f22303d940b5",
    "evidence/inbox/proposal-001.ARC-520.L003.A1.D.json": "a4962f39948eef9cbd58efd357e6bd49120297729008d520fec62643ec1ab379",
    "evidence/inbox/proposal-001.ARC-630.L001.A1.D.json": "284e242baae7d5db86bc7201a48e9c2a2c7686e61a38047317f84a60d6b437a1",
    "evidence/inbox/proposal-001.ARC-630.L002.A1.D.json": "64333b26a7e0f3ee23d25c025e22ecc5efef422eaeded448d9a3d79128e5d68a",
    "evidence/participants.sqlite": "dbb0905d7c7fd2b614746af4a0c729048d5f9e9018a44f49fa5a8c1ea7df188c",
    "evidence/producer.sqlite": "b70213da0fa762f5f77e13dc624b946afecba1c13c7687887a20b37011d2566c",
    "evidence/products/proposal-001.ARC-410.L001.A1.json": "eb8cf0d4e5f3fe84d735abdb939c338e9a2911f333e3b405edbab29685a6e0d9",
    "evidence/products/proposal-001.ARC-410.L002.A1.json": "01ee70c72691afa8f92481eccf44ad17bd35a97a7ca2ae928a77369c9193318f",
    "evidence/products/proposal-001.ARC-410.L003.A1.json": "4d7dd08c6a2cffbb0148372e5207a9916bb769975637e00eb8d453bdd69f795e",
    "evidence/products/proposal-001.ARC-520.L001.A1.json": "266bc54bb52c94598c1a8b5dc2b8a0b1a1586c9ad8f8347f43a23b0c539a7621",
    "evidence/products/proposal-001.ARC-520.L002.A1.json": "0b1cc0459fe370f0bcb2e15f75d26c638bdc422c6c44bba1cc68f22303d940b5",
    "evidence/products/proposal-001.ARC-520.L003.A1.json": "a4962f39948eef9cbd58efd357e6bd49120297729008d520fec62643ec1ab379",
    "evidence/products/proposal-001.ARC-630.L001.A1.json": "284e242baae7d5db86bc7201a48e9c2a2c7686e61a38047317f84a60d6b437a1",
    "evidence/products/proposal-001.ARC-630.L002.A1.json": "64333b26a7e0f3ee23d25c025e22ecc5efef422eaeded448d9a3d79128e5d68a",
    "evidence/receiver.sqlite": "cdf3b2221cae46d44c5fb410cea9325f2f434c7225d7ba395c2d12f8108b7f60"
  },
  "failures": [],
  "fault_schedule": [
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 2,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "faults_observed": [
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 2,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "fixture_id": "archive-window-transfer",
  "implementation": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-qualification/complete-attempt-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-qualified-complete"
    },
    "git_commit": "3494becbbfaf15ae571a71df05a49b9ce982cc84",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "method": "harness",
  "per_arrangement": [
    {
      "acceptance_ids": [
        "proposal-001.ARC-410.L001.A1.D",
        "proposal-001.ARC-410.L002.A1.D",
        "proposal-001.ARC-410.L003.A1.D",
        "proposal-001.ARC-520.L001.A1.D",
        "proposal-001.ARC-520.L002.A1.D",
        "proposal-001.ARC-520.L003.A1.D",
        "proposal-001.ARC-630.L001.A1.D",
        "proposal-001.ARC-630.L002.A1.D"
      ],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 2790,
      "independent_terms": {
        "break_even_value_minor": 7500,
        "buyer_definite_max_price_minor": 6400,
        "buyer_possible_max_price_minor": 7000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5700,
        "minimum_coordinator_fee_minor": 290,
        "providers": [
          {
            "base_cost_minor": 2040,
            "guaranteed_profit_minor": 260,
            "maximum_unpaid_cost_exposure_minor": 3960,
            "minimum_payment_minor": 4220,
            "participation_profit_minor": 260,
            "party_id": "ARCHIVE-COMPAT-A",
            "promised_payment_minor": 4220,
            "rework_cost_minor": 1920,
            "units": 900
          },
          {
            "base_cost_minor": 570,
            "guaranteed_profit_minor": 200,
            "maximum_unpaid_cost_exposure_minor": 990,
            "minimum_payment_minor": 1190,
            "participation_profit_minor": 200,
            "party_id": "ARCHIVE-COMPAT-B",
            "promised_payment_minor": 1190,
            "rework_cost_minor": 420,
            "units": 120
          }
        ],
        "rework_budget_minor": 2340,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER-ARCHIVE",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "ARCHIVE-COMPAT-A",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "ARCHIVE-COMPAT-B",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR-ARCHIVE",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 5700,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 150,
            "lot_id": "ARC-410.L001",
            "obligation_id": "ARC-410",
            "pay_minor": 4220,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "EARLY"
          },
          {
            "first_unit": 151,
            "last_unit": 300,
            "lot_id": "ARC-410.L002",
            "obligation_id": "ARC-410",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "EARLY"
          },
          {
            "first_unit": 301,
            "last_unit": 420,
            "lot_id": "ARC-410.L003",
            "obligation_id": "ARC-410",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "EARLY"
          },
          {
            "first_unit": 1,
            "last_unit": 150,
            "lot_id": "ARC-520.L001",
            "obligation_id": "ARC-520",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "EARLY"
          },
          {
            "first_unit": 151,
            "last_unit": 300,
            "lot_id": "ARC-520.L002",
            "obligation_id": "ARC-520",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "LATE"
          },
          {
            "first_unit": 301,
            "last_unit": 330,
            "lot_id": "ARC-520.L003",
            "obligation_id": "ARC-520",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "LATE"
          },
          {
            "first_unit": 1,
            "last_unit": 150,
            "lot_id": "ARC-630.L001",
            "obligation_id": "ARC-630",
            "pay_minor": 0,
            "provider_id": "ARCHIVE-COMPAT-A",
            "window_id": "LATE"
          },
          {
            "first_unit": 151,
            "last_unit": 270,
            "lot_id": "ARC-630.L002",
            "obligation_id": "ARC-630",
            "pay_minor": 1190,
            "provider_id": "ARCHIVE-COMPAT-B",
            "window_id": "LATE"
          }
        ],
        "buyer_price_minor": 5700,
        "cancellation_fee_minor": 0,
        "contract_sha256": "da2441381af31c8e77df5382e02000b5af8132310fe7e6f533f9f0d252d5782e",
        "coordinator_fee_minor": 290,
        "expires_tick": 560,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2340,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "DEMONSTRATED",
      "settled_tick": 279,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 420,
      "deadline_tick": 130,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "ARC-410",
      "outcome": "COMPLETED",
      "produced_quantity": 420,
      "production_attempts": 3,
      "quantity": 420,
      "reason_codes": [],
      "received_quantity": 420,
      "recipient": "RECIPIENT-NORD",
      "recipient_accepted_quantity": 420,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 420,
      "revision": 3,
      "status": "ACTIVE",
      "timely_semantic_quantity": 420
    },
    {
      "accepted_quantity": 330,
      "deadline_tick": 440,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "ARC-520",
      "outcome": "COMPLETED",
      "produced_quantity": 330,
      "production_attempts": 3,
      "quantity": 330,
      "reason_codes": [],
      "received_quantity": 330,
      "recipient": "RECIPIENT-EST",
      "recipient_accepted_quantity": 330,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 330,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 330
    },
    {
      "accepted_quantity": 270,
      "deadline_tick": 520,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "ARC-630",
      "outcome": "COMPLETED",
      "produced_quantity": 270,
      "production_attempts": 2,
      "quantity": 270,
      "reason_codes": [],
      "received_quantity": 270,
      "recipient": "RECIPIENT-SUD",
      "recipient_accepted_quantity": 270,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 270,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 270
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 360,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "ARC-740",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 90,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-OUEST",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "52f77f91846c3eae93acdc9efdd7faa52f499f7eb2df5be8443fda2fc43af369",
  "registered_assertion": {
    "expected": {
      "accepted_units": 1020,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "observed": {
      "accepted_units": 1020,
      "outcome": "DEMONSTRATED",
      "service_feasibility": "DEMONSTRATED"
    },
    "scope": "Registered assessment assertion; not a favorable outcome or trade claim.",
    "status": "PASSED"
  },
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 52832,
    "candidate_restarts": 0,
    "child_processes": 10,
    "controller_cpu_system_ns": 25835000,
    "controller_cpu_user_ns": 201382999,
    "cpu_system_ns": 112332000,
    "cpu_user_ns": 701510000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes through closed evidence finalization; excludes final controller record, execution seal, result and Passport publication overhead; child CPU may include concurrent exercises launched by this same controller process",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 45,
    "retries": 1,
    "service_requests": 239,
    "storage_bytes": 6498354,
    "storage_scope": "files present in run directory before final controller record and authority execution seal; excludes later result and Passport files; authority_storage_bytes_before_seal is reported separately",
    "verification_labor_seconds": null,
    "wall_ns": 1302063181,
    "worker_restarts": 1
  },
  "run_id": "archive-window-transfer.harness.938d770fd7",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "source_version": {
    "dirty": false,
    "environment": {
      "argv": [
        "python3",
        "-m",
        "continuity_economy",
        "--language",
        "en",
        "experiment",
        "--out",
        "/workspace/scratch/b1d5891eb025/economy-qualification/complete-attempt-1"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/economy-qualified-complete"
    },
    "git_commit": "3494becbbfaf15ae571a71df05a49b9ce982cc84",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "61daa443a313a13caaec039060603123ae584065a38eaf7debd3414d29d45d39",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5c6b45367f6dde220b039a0f67f309f14e72007bcd96a28a48e811c782a6cff9",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "372ad6d4902d739b0ff962f29a58f605967067920b4dec5a99542bf8d241087b",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "42667fead619a1681c10f59aff38e78f25559c935b3d64763057cd707b2f17a6",
      "continuity_economy/producer.py": "3172126b675c232aba49999ea6c2adc68efdb04ff9854000d871a351afcc248a",
      "continuity_economy/receiver.py": "9783bb2320a1a2cea82e1a8ca80434e1ad1cb6dfdd169ea8e8f393ed1a924b5f",
      "continuity_economy/reporting.py": "fc8efdcd61915a62e52d0cff4d4cb74f41850615631b024f26c492cec74046ea",
      "continuity_economy/schema.py": "2c09cbe30439abb941cf2aa079bb7c49e90dcfb4c036d5def2f74dde748a46f7",
      "continuity_economy/suite.py": "1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3",
      "continuity_economy/verifier.py": "59bed9a68a14c8e5000638a8727c0abd236e7e12dfc017548f77395614e7b3de",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/reuse-freeze.json": "319c64e10f83f90f78b72e2c0d844030d7076afe6f7270db98b4cf81b6cdba13",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b",
      "experiments/economy-v0.2/successor-fixtures/archive-window-transfer.json": "6dabdfc04a704767d86e6ba68bde0c6e4a374893b82056ee596b30371f4b306c",
      "experiments/economy-v0.2/successor.json": "011964162e65d657a1d8dd3028b28c699e856ba4e6905489f1dbebf66f1775dc"
    },
    "version": "0.2.0"
  },
  "totals": {
    "accepted_obligations": 3,
    "accepted_quantity": 1020,
    "delivery_attempts": 8,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 0,
    "produced_quantity": 1020,
    "production_attempts": 8,
    "received_quantity": 1020,
    "recipient_accepted_quantity": 1020,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 3,
    "required_quantity": 1020,
    "timely_semantic_quantity": 1020,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 193997262,
    "evidence_files_read": 32,
    "wall_ns": 194249523
  },
  "verification_status": "COMPLETE",
  "verification_wall_ns": 196109454,
  "verifier_version": "0.2.0"
}
```
