"""Package retained synthetic evidence; no evidence is altered or deleted."""
import hashlib, io, json, tarfile
from pathlib import Path
base=Path('/workspace/scratch/b1d5891eb025')
roots={'qualification':base/'economy-qualification'}
for name in ('economy-development','economy-controller-development','economy-participant-development','economy-product-validation','economy-verifier-development'):
    roots['development/'+name]=base/name
output=base/'continuity-economy/evidence/economy-v0.2/attempts.tar.xz'
if output.exists():raise SystemExit('Existing archive retained; choose a separately named attempt.')
files={}
for prefix,folder in roots.items():
    for p in sorted(folder.rglob('*')):
        if p.is_symlink():raise SystemExit('Refusing evidence symlink: '+str(p))
        if p.is_file():files[prefix+'/'+p.relative_to(folder).as_posix()]=p
files['packaging/build_archive.py']=Path(__file__)
manifest={'schema':'continuity-economy/evidence-manifest/v1','scope':'Synthetic local execution; original file bytes, including failed and incomplete attempts. Hashes establish byte identity, not real customer authority.','files':{name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for name,p in sorted(files.items())}}
raw=(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
(base/'economy-packaging/MANIFEST.json').write_bytes(raw)
with tarfile.open(output,'x:xz',preset=6) as archive:
    info=tarfile.TarInfo('MANIFEST.json');info.size=len(raw);info.mode=0o644
    archive.addfile(info,io.BytesIO(raw))
    for name,p in sorted(files.items()):
        info=archive.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname=''
        with p.open('rb') as stream:archive.addfile(info,stream)
result={'schema':'continuity-economy/archive-build/v1','archive':str(output),'archive_bytes':output.stat().st_size,'archive_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(raw).hexdigest(),'file_count':len(files),'uncompressed_file_bytes':sum(v['bytes'] for v in manifest['files'].values()),'source_commit':'3494becbbfaf15ae571a71df05a49b9ce982cc84'}
(base/'economy-packaging/BUILD.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
