# CONTINUITÉ Ω — Économie de la continuité

**Expérience de produit numérique · version 0.2.0**

Préserver un engagement grâce à une solution de continuité viable et volontairement acceptée.

**Portée : processus locaux jetables et produit numérique spécifié. Les politiques, consentements, valeurs, financements et flux SMU synthétiques sont des hypothèses et observations du modèle. Ils n’établissent ni contrats réels, ni demande, paiements, ventes, biens imprimés, apparence rendue ou qualité d’impression.**

Ce passeport présente l’évaluation consignée. Une vérification fraîche doit inspecter l’autorité conservée, le résultat durable réel et les preuves du destinataire ; ce document ne constitue jamais son oracle.

<!-- structured-result-sha256: ba1927f2e72304a9530736a6164eeec10dcbe830d453e37b65064aff7b6c43a2 -->

## Trois affirmations distinctes

| Affirmation | État consigné |
| --- | --- |
| Travail numérique requis accepté dans les conditions figées | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Faisabilité du service selon le modèle synthétique défini | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Avantage de méthode face à des solutions compétentes | Non établi (`NOT_ESTABLISHED`) |
| Sûreté dans le modèle de défaillance éprouvé | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

## Champs d’évaluation distincts

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | Non évalué (`NOT_EVALUATED`) |
| Verdict du composant | Réalisé (`COMPLETED`) |
| Stade de preuve | Exécution locale d’un produit numérique (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| État de l’affirmation de résultat | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

## Identité, autorité et versions

| Champ | Valeur consignée |
| --- | --- |
| État des preuves d’autorité · `authority_status` | Établi uniquement pour l’exercice synthétique (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Valeur commerciale réelle · `commercial_value` | Non établi (`NOT_ESTABLISHED`) |
| Identité du contrat · `contract_id` | DIGITAL-003 |
| SHA-256 du contrat conservé · `contract_sha256` | e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7 |
| Authenticité d’un client réel · `real_customer_authenticity` | Non établi (`NOT_ESTABLISHED`) |
| Empreinte externe de référence · `reference_sha256` | 681e94181af58f0e10b8acbd82e401227640065bb07f78e1beab0d228d9ebeff |
| Identité de l’exécution · `run_id` | component-integration-3 |
| Schéma · `schema` | continuity-economy/verification/v1 |
| État d’achèvement de la vérification · `verification_status` | Vérification complète (`COMPLETE`) |
| Version du vérificateur · `verifier_version` | 0.2.0 |

## Exécution et acceptation par obligation

Les quantités décrivent le stade consigné. Les tentatives refusées et corrigées restent distinctes. Une unité produite ou reçue n’est pas automatiquement acceptée. Les mesures absentes ne sont pas présentées comme nulles.

| Obligation | Destinataire | Révision | Requis | Produit | Reçu | Refusé | Accepté selon le contrat | Résultat |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 4 | 4 | 4 | 0 | 4 | Réalisé (`COMPLETED`) |
| DL-200 | RECIPIENT-B | 1 | 3 | 3 | 3 | 0 | 3 | Réalisé (`COMPLETED`) |
| DL-300 | RECIPIENT-C | 1 | 100 | 0 | 0 | 0 | 0 | Annulé (`CANCELLED`) |

### Obligation `DL-100`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 4 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 2 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-100 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 4 |
| Tentatives de production durables · `production_attempts` | 2 |
| Quantité requise · `quantity` | 4 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 4 |
| Destinataire · `recipient` | RECIPIENT-A |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 4 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 4 |
| Révision · `revision` | 2 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 4 |

### Obligation `DL-200`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 3 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 2 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-200 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 3 |
| Tentatives de production durables · `production_attempts` | 2 |
| Quantité requise · `quantity` | 3 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 3 |
| Destinataire · `recipient` | RECIPIENT-B |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 3 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 3 |
| Révision · `revision` | 1 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 3 |

### Obligation `DL-300`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-300 |
| Résultat · `outcome` | Annulé (`CANCELLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-C |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 0 |
| Révision · `revision` | 1 |
| État consigné · `status` | Annulé (`CANCELLED`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

## Propositions, décisions modélisées et solutions

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

### Solution `proposal-001`

| Champ | Valeur consignée |
| --- | --- |
| Références d’acceptation · `acceptance_ids` | Aucune entrée |
| Instant d’acceptation de l’accord · `accepted_tick` | 3 |
| Identité de l’accord · `agreement_id` | proposal-001 |
| Instant d’annulation · `cancelled_tick` | 6 |
| Coût de correction engagé (SMU synthétiques) · `correction_cost_minor` | 0 |
| Faisabilité modélisée au moment de l’accord · `ex_ante_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Coût engagé (SMU synthétiques) · `incurred_cost_minor` | 200 |
| Valeur d’équilibre de l’acheteur (SMU synthétiques) · `independent_terms.break_even_value_minor` | 2714 |
| Plafond acheteur à la borne de valeur inférieure (SMU synthétiques) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Plafond acheteur à la borne de valeur supérieure (SMU synthétiques) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Unité de compte synthétique · `independent_terms.currency` | SMU |
| Prix acheteur minimal réalisable (SMU synthétiques) · `independent_terms.minimum_buyer_price_minor` | 714 |
| Rémunération minimale du coordonnateur (SMU synthétiques) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Coût de production initiale (SMU synthétiques) · `independent_terms.providers[0].base_cost_minor` | 157 |
| Profit modélisé après correction maximale spécifiée (SMU synthétiques) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Exposition maximale aux coûts impayés (SMU synthétiques) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 314 |
| Paiement minimal au fournisseur (SMU synthétiques) · `independent_terms.providers[0].minimum_payment_minor` | 414 |
| Profit requis de participation (SMU synthétiques) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Identité du participant · `independent_terms.providers[0].party_id` | BACKUP |
| Paiement promis au fournisseur (SMU synthétiques) · `independent_terms.providers[0].promised_payment_minor` | 414 |
| Coût maximal de correction (SMU synthétiques) · `independent_terms.providers[0].rework_cost_minor` | 157 |
| Unités · `independent_terms.providers[0].units` | 7 |
| Réserve de correction (unités mineures SMU synthétiques) · `independent_terms.rework_budget_minor` | 157 |
| Portée de l’évaluation · `independent_terms.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Nature de la solution · `kind` | Accord d’échange modélisé (`TRADE`) |
| Code stable · `participant_decisions[0].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[0].party_id` | BUYER |
| Rôle · `participant_decisions[0].role` | buyer |
| Verdict du composant · `participant_decisions[0].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[1].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[1].party_id` | BACKUP |
| Rôle · `participant_decisions[1].role` | provider |
| Verdict du composant · `participant_decisions[1].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[2].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[2].party_id` | COORDINATOR |
| Rôle · `participant_decisions[2].role` | coordinator |
| Verdict du composant · `participant_decisions[2].verdict` | Accepté (`ACCEPTED`) |
| Paiements modélisés (SMU synthétiques) · `payments_minor` | 0 |
| Identité de la proposition · `proposal_id` | proposal-001 |
| Premier ordinal inclus · `proposed_terms.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[0].last_unit` | 2 |
| Identité du lot fixe · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[0].pay_minor` | 414 |
| Identité du fournisseur · `proposed_terms.allocations[0].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[1].first_unit` | 3 |
| Dernier ordinal inclus · `proposed_terms.allocations[1].last_unit` | 4 |
| Identité du lot fixe · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[1].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[2].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[2].last_unit` | 2 |
| Identité du lot fixe · `proposed_terms.allocations[2].lot_id` | DL-200.L001 |
| Identité de l’obligation · `proposed_terms.allocations[2].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[2].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[3].first_unit` | 3 |
| Dernier ordinal inclus · `proposed_terms.allocations[3].last_unit` | 3 |
| Identité du lot fixe · `proposed_terms.allocations[3].lot_id` | DL-200.L002 |
| Identité de l’obligation · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[3].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[3].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `proposed_terms.buyer_price_minor` | 714 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `proposed_terms.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `proposed_terms.contract_sha256` | e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7 |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `proposed_terms.coordinator_fee_minor` | 300 |
| Instant exclusif d’expiration · `proposed_terms.expires_tick` | 500 |
| Révision des politiques · `proposed_terms.policy_revision` | 1 |
| Identité de la proposition · `proposed_terms.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `proposed_terms.rework_budget_minor` | 157 |
| Schéma · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Faisabilité modélisée après exécution · `realized_feasibility` | Échec (`FAILED`) |
| Instant de règlement modélisé · `settled_tick` | Non consigné |
| État consigné · `status` | Annulé (`CANCELLED`) |

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

### Solution `proposal-002`

| Champ | Valeur consignée |
| --- | --- |
| Références d’acceptation · `acceptance_ids[0]` | proposal-002.DL-100.L001.A1.D |
| Références d’acceptation · `acceptance_ids[1]` | proposal-002.DL-100.L002.A1.D |
| Références d’acceptation · `acceptance_ids[2]` | proposal-002.DL-200.L001.A1.D |
| Références d’acceptation · `acceptance_ids[3]` | proposal-002.DL-200.L002.A1.D |
| Instant d’acceptation de l’accord · `accepted_tick` | 9 |
| Identité de l’accord · `agreement_id` | proposal-002 |
| Instant d’annulation · `cancelled_tick` | Non consigné |
| Coût de correction engagé (SMU synthétiques) · `correction_cost_minor` | 0 |
| Faisabilité modélisée au moment de l’accord · `ex_ante_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Coût engagé (SMU synthétiques) · `incurred_cost_minor` | 707 |
| Valeur d’équilibre de l’acheteur (SMU synthétiques) · `independent_terms.break_even_value_minor` | 3514 |
| Plafond acheteur à la borne de valeur inférieure (SMU synthétiques) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Plafond acheteur à la borne de valeur supérieure (SMU synthétiques) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Unité de compte synthétique · `independent_terms.currency` | SMU |
| Prix acheteur minimal réalisable (SMU synthétiques) · `independent_terms.minimum_buyer_price_minor` | 1514 |
| Rémunération minimale du coordonnateur (SMU synthétiques) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Coût de production initiale (SMU synthétiques) · `independent_terms.providers[0].base_cost_minor` | 206 |
| Profit modélisé après correction maximale spécifiée (SMU synthétiques) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Exposition maximale aux coûts impayés (SMU synthétiques) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 412 |
| Paiement minimal au fournisseur (SMU synthétiques) · `independent_terms.providers[0].minimum_payment_minor` | 512 |
| Profit requis de participation (SMU synthétiques) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Identité du participant · `independent_terms.providers[0].party_id` | COMPAT-A |
| Paiement promis au fournisseur (SMU synthétiques) · `independent_terms.providers[0].promised_payment_minor` | 512 |
| Coût maximal de correction (SMU synthétiques) · `independent_terms.providers[0].rework_cost_minor` | 206 |
| Unités · `independent_terms.providers[0].units` | 6 |
| Coût de production initiale (SMU synthétiques) · `independent_terms.providers[1].base_cost_minor` | 301 |
| Profit modélisé après correction maximale spécifiée (SMU synthétiques) · `independent_terms.providers[1].guaranteed_profit_minor` | 100 |
| Exposition maximale aux coûts impayés (SMU synthétiques) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 602 |
| Paiement minimal au fournisseur (SMU synthétiques) · `independent_terms.providers[1].minimum_payment_minor` | 702 |
| Profit requis de participation (SMU synthétiques) · `independent_terms.providers[1].participation_profit_minor` | 100 |
| Identité du participant · `independent_terms.providers[1].party_id` | COMPAT-B |
| Paiement promis au fournisseur (SMU synthétiques) · `independent_terms.providers[1].promised_payment_minor` | 702 |
| Coût maximal de correction (SMU synthétiques) · `independent_terms.providers[1].rework_cost_minor` | 301 |
| Unités · `independent_terms.providers[1].units` | 1 |
| Réserve de correction (unités mineures SMU synthétiques) · `independent_terms.rework_budget_minor` | 507 |
| Portée de l’évaluation · `independent_terms.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Nature de la solution · `kind` | Accord d’échange modélisé (`TRADE`) |
| Code stable · `participant_decisions[0].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[0].party_id` | BUYER |
| Rôle · `participant_decisions[0].role` | buyer |
| Verdict du composant · `participant_decisions[0].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[1].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[1].party_id` | COMPAT-A |
| Rôle · `participant_decisions[1].role` | provider |
| Verdict du composant · `participant_decisions[1].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[2].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[2].party_id` | COMPAT-B |
| Rôle · `participant_decisions[2].role` | provider |
| Verdict du composant · `participant_decisions[2].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[3].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[3].party_id` | COORDINATOR |
| Rôle · `participant_decisions[3].role` | coordinator |
| Verdict du composant · `participant_decisions[3].verdict` | Accepté (`ACCEPTED`) |
| Paiements modélisés (SMU synthétiques) · `payments_minor` | 1714 |
| Identité de la proposition · `proposal_id` | proposal-002 |
| Premier ordinal inclus · `proposed_terms.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[0].last_unit` | 2 |
| Identité du lot fixe · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[0].pay_minor` | 512 |
| Identité du fournisseur · `proposed_terms.allocations[0].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[1].first_unit` | 3 |
| Dernier ordinal inclus · `proposed_terms.allocations[1].last_unit` | 4 |
| Identité du lot fixe · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[1].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[2].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[2].last_unit` | 2 |
| Identité du lot fixe · `proposed_terms.allocations[2].lot_id` | DL-200.L001 |
| Identité de l’obligation · `proposed_terms.allocations[2].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[2].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[3].first_unit` | 3 |
| Dernier ordinal inclus · `proposed_terms.allocations[3].last_unit` | 3 |
| Identité du lot fixe · `proposed_terms.allocations[3].lot_id` | DL-200.L002 |
| Identité de l’obligation · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[3].pay_minor` | 702 |
| Identité du fournisseur · `proposed_terms.allocations[3].provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[3].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `proposed_terms.buyer_price_minor` | 1714 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `proposed_terms.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `proposed_terms.contract_sha256` | e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7 |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `proposed_terms.coordinator_fee_minor` | 500 |
| Instant exclusif d’expiration · `proposed_terms.expires_tick` | 500 |
| Révision des politiques · `proposed_terms.policy_revision` | 1 |
| Identité de la proposition · `proposed_terms.proposal_id` | proposal-002 |
| Réserve de correction (unités mineures SMU synthétiques) · `proposed_terms.rework_budget_minor` | 507 |
| Schéma · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Faisabilité modélisée après exécution · `realized_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Instant de règlement modélisé · `settled_tick` | 33 |
| État consigné · `status` | Réglé dans le registre synthétique (`SETTLED`) |

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.


## Transferts, coûts, responsabilités et options externes modélisés

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

| Champ | Valeur consignée |
| --- | --- |
| Total des transferts acheteur (SMU synthétiques) · `accounting.buyer_total_paid_minor` | 1714 |
| Borne supérieure · `accounting.buyer_utility_interval_minor.maximum` | 28286 |
| Borne inférieure · `accounting.buyer_utility_interval_minor.minimum` | 28286 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[0].final_balance_minor` | 28286 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Seuil de participation modélisé couvert · `accounting.campaign[0].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[0].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[0].party_id` | BUYER |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[0].purchase_payments_minor` | 1714 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[0].realized_profit_minor` | Non consigné |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[0].revenue_minor` | 0 |
| Rôle · `accounting.campaign[0].role` | buyer |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[1].final_balance_minor` | 10100 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[1].incurred_cost_minor` | 400 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Seuil de participation modélisé couvert · `accounting.campaign[1].participation_covered` | Oui |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[1].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[1].party_id` | COORDINATOR |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[1].realized_profit_minor` | 100 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[1].revenue_minor` | 500 |
| Rôle · `accounting.campaign[1].role` | coordinator |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Seuil de participation modélisé couvert · `accounting.campaign[2].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[2].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[2].realized_profit_minor` | Non consigné |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[2].revenue_minor` | 0 |
| Rôle · `accounting.campaign[2].role` | technical_sponsor |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[3].final_balance_minor` | 40000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[3].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[3].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[3].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[3].party_id` | PRIMARY |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[3].realized_profit_minor` | 0 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[3].revenue_minor` | 0 |
| Rôle · `accounting.campaign[3].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[4].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[4].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[4].party_id` | BACKUP |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[4].revenue_minor` | 0 |
| Rôle · `accounting.campaign[4].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[5].final_balance_minor` | 40306 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[5].incurred_cost_minor` | 206 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[5].participation_covered` | Oui |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[5].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[5].party_id` | COMPAT-A |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[5].realized_profit_minor` | 306 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[5].revenue_minor` | 512 |
| Rôle · `accounting.campaign[5].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[6].final_balance_minor` | 40401 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[6].incurred_cost_minor` | 301 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[6].participation_covered` | Oui |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[6].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[6].party_id` | COMPAT-B |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[6].realized_profit_minor` | 401 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[6].revenue_minor` | 702 |
| Rôle · `accounting.campaign[6].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Unité de compte synthétique · `accounting.currency` | SMU |
| Total final du registre (SMU synthétiques) · `accounting.final_total_minor` | 260000 |
| Total initial du registre (SMU synthétiques) · `accounting.initial_total_minor` | 260000 |
| Contrats, paiements ou demande réels · `accounting.real_contracts_payments_or_demand` | Non établi (`NOT_ESTABLISHED`) |
| Faisabilité modélisée réalisée pour l’acheteur · `accounting.realized_buyer` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Portée de l’évaluation · `accounting.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Tous les coûts de correction (SMU synthétiques) · `accounting.total_correction_cost_minor` | 0 |
| Tous les coûts engagés de campagne (SMU synthétiques) · `accounting.total_incurred_cost_minor` | 907 |
| Tous les transferts de règlement modélisés (SMU synthétiques) · `accounting.total_transfers_minor` | 1714 |
| Transaction modélisée réglée · `accounting.trade_settled` | Oui |
| Obligations acceptées · `totals.accepted_obligations` | 2 |
| Quantité acceptée selon le contrat · `totals.accepted_quantity` | 7 |
| Tentatives de livraison · `totals.delivery_attempts` | 4 |
| Unités acceptées en double · `totals.duplicate_acceptances` | 0 |
| Quantité tardive · `totals.late_quantity` | 0 |
| Quantité manquante · `totals.missing_quantity` | 0 |
| Quantité produite · `totals.produced_quantity` | 7 |
| Tentatives de production durables · `totals.production_attempts` | 4 |
| Quantité reçue · `totals.received_quantity` | 7 |
| Unités acceptées par le composant destinataire · `totals.recipient_accepted_quantity` | 7 |
| Quantité refusée · `totals.rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `totals.rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `totals.rejection_count` | 0 |
| Obligations actives requises · `totals.required_obligations` | 2 |
| Quantité requise · `totals.required_quantity` | 7 |
| Unités sémantiquement correctes observées à temps · `totals.timely_semantic_quantity` | 7 |
| Engagements non sûrs ou non autorisés · `totals.unsafe_or_unsupported_commitments` | 0 |

## Ressources mesurées et lacunes de comptabilisation

Les ressources de processus mesurées et les montants synthétiques configurés ont des significations différentes. Les efforts de préparation, d’intégration, d’adaptation, de vérification ou d’intervention non consignés restent inconnus. Les catégories absentes ne permettent aucune conclusion de coût complet ou de méthode moins coûteuse.

| Champ | Valeur consignée |
| --- | --- |
| Lacunes de comptabilisation · `accounting_gaps[0]` | Le travail de préparation n’a pas été mesuré (`PREPARATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[1]` | Le travail d’intégration n’a pas été mesuré (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[2]` | Le travail d’adaptation n’a pas été mesuré (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[3]` | Le travail humain de vérification n’a pas été mesuré (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[4]` | Les tarifs monétaires n’ont pas été mesurés (`MONETARY_RATES_NOT_MEASURED`) |
| Travail d’adaptation (secondes ; inconnu si absent) · `resources.adaptation_labor_seconds` | Non consigné |
| Redémarrages du candidat · `resources.candidate_restarts` | 1 |
| Processeur système du contrôleur (ns) · `resources.controller_cpu_system_ns` | 39866000 |
| Processeur utilisateur du contrôleur (ns) · `resources.controller_cpu_user_ns` | 100081999 |
| Processeur système (ns) · `resources.cpu_system_ns` | 164571999 |
| Processeur utilisateur (ns) · `resources.cpu_user_ns` | 514619999 |
| Interventions humaines · `resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `resources.measurement_scope` | Contrôleur et processus enfants ; leur mesure processeur sur un hôte partagé peut inclure des exercices concurrents. |
| Coût monétaire réel mesuré · `resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `resources.requests` | 32 |
| Nouvelles tentatives · `resources.retries` | 0 |
| Stockage consigné (octets) · `resources.storage_bytes` | 1337022 |
| Travail humain de vérification (secondes ; inconnu si absent) · `resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `resources.wall_ns` | 957857232 |
| Redémarrages des services · `resources.worker_restarts` | 1 |
| Temps processeur (ns) · `verification_resources.cpu_ns` | 71018721 |
| Fichiers de preuve examinés · `verification_resources.evidence_files_read` | 19 |
| Durée écoulée (ns) · `verification_resources.wall_ns` | 71024590 |

## Échecs et contre-exemples observés

Aucune entrée d’échec n’a été consignée dans cette évaluation. Il s’agit de preuves bornées, non d’une démonstration générale.

## Preuves absentes et affirmations non établies

Aucune entrée non résolue supplémentaire n’a été consignée. Les limites de portée et de coûts inconnus restent applicables.

## Références des preuves et intégrité des octets

Les empreintes identifient les octets. Elles n’authentifient pas les instructions réelles d’un client, n’établissent pas l’exhaustivité des sources et ne remplacent pas une empreinte de référence conservée séparément.

| Champ | Valeur consignée |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/COMPAT-A.W0/DL-100.L001.A1.json` | 949c41781455823d33e1637368961bfc2433a61c14a3c032a6fe22a3009dd778 |
| `evidence_sha256.evidence/capacity-artifacts/COMPAT-A.W0/DL-100.L002.A1.json` | 2ccebbd4797dc6305c65cb37e3a69e5af7581a8978d86cd884d40dad5d95cf4f |
| `evidence_sha256.evidence/capacity-artifacts/COMPAT-A.W0/DL-200.L001.A1.json` | 54272dfe7a7f1205ad6d299afcd1b1b5e8bb596dbe7615e8473eab1d106cd711 |
| `evidence_sha256.evidence/capacity-artifacts/COMPAT-B.W0/DL-200.L002.A1.json` | 540d4b8873796a78458ef753462fc126c979abf3587965d3d9f4cda07ebb8367 |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | fdbfee2648bc6131c3f9fb0c96c782924bc2b5a5ac80817d53f74cbce2bd4cec |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | 3069621b961b368c52efbd3c602dc3c9ff62a309ed764b7a6efc9d1b112a7497 |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | 1555cd5a1087fab803300b84ecf578ee85cd14b2d908ccfd33fb2e830ef34e56 |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | c515f9b37cac621c7f18c135a3bb736deba6c437931f884c5da68485d5807e8c |
| `evidence_sha256.evidence/inbox/proposal-002.DL-100.L001.A1.D.json` | d6d7509b0cbee8fc3343239656241c0a259aecd5bd05abfda82a730e6129e39c |
| `evidence_sha256.evidence/inbox/proposal-002.DL-100.L002.A1.D.json` | 93c0953e59cb35a3d60247e4bdd7e3aac1fc75057c68aaedc085931b862e92f0 |
| `evidence_sha256.evidence/inbox/proposal-002.DL-200.L001.A1.D.json` | 72088ddc19a900d9520f44cb8b59ff1fee918cb45a4834cb15f8c885325c05e9 |
| `evidence_sha256.evidence/inbox/proposal-002.DL-200.L002.A1.D.json` | 7ec4936b4b2854f59121c6b8a39d6818045260ea4b7d1ccaf741c9c7c2e1c9f2 |
| `evidence_sha256.evidence/participants.sqlite` | 0c2316b08fd428f3a4d2b9e80c2ff205cd8d2376c1ae643bde28184010c3111a |
| `evidence_sha256.evidence/producer.sqlite` | 5c4b4975841ef5094614a30d2ddd413f3b09fab8e99340d5c40ce5293d1faec6 |
| `evidence_sha256.evidence/products/proposal-002.DL-100.L001.A1.json` | d6d7509b0cbee8fc3343239656241c0a259aecd5bd05abfda82a730e6129e39c |
| `evidence_sha256.evidence/products/proposal-002.DL-100.L002.A1.json` | 93c0953e59cb35a3d60247e4bdd7e3aac1fc75057c68aaedc085931b862e92f0 |
| `evidence_sha256.evidence/products/proposal-002.DL-200.L001.A1.json` | 72088ddc19a900d9520f44cb8b59ff1fee918cb45a4834cb15f8c885325c05e9 |
| `evidence_sha256.evidence/products/proposal-002.DL-200.L002.A1.json` | 7ec4936b4b2854f59121c6b8a39d6818045260ea4b7d1ccaf741c9c7c2e1c9f2 |
| `evidence_sha256.evidence/receiver.sqlite` | 1ddb9a4e86a9aa108c6a3c193ff6757f455fc37cdb17a2831bed40734211329b |
| SHA-256 du résultat structuré · `structured_result_sha256` | ba1927f2e72304a9530736a6164eeec10dcbe830d453e37b65064aff7b6c43a2 |

## Exécution, pannes, commandes et provenance consignées

Les identifiants stables, commandes exactes, chemins et diagnostics machine originaux sont conservés littéralement. Ce sont des données, non des preuves d’acceptation supplémentaires. La confiance dans les sources et l’hôte est explicitée dans l’architecture et le modèle de menace.

| Champ | Valeur consignée |
| --- | --- |
| `contract.allow_split` | Oui |
| `contract.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| `contract.blocked_dependencies[0]` | PRIMARY-HOST |
| `contract.bounds.max_plans` | 65536 |
| `contract.bounds.max_proposals` | 8 |
| `contract.bounds.max_requests` | 512 |
| `contract.bounds.service_timeout_ms` | 10000 |
| Cohorte d’expérience · `contract.cohort` | challenge |
| Identité du contrat · `contract.contract_id` | DIGITAL-003 |
| `contract.cutoff_sequence` | 5 |
| Échéance logique · `contract.deadline_tick` | 500 |
| `contract.disclosure_fields[0]` | recipient |
| `contract.disclosure_fields[1]` | sku |
| `contract.disclosure_fields[2]` | name_en |
| `contract.disclosure_fields[3]` | name_fr |
| `contract.disclosure_fields[4]` | instructions_en |
| `contract.disclosure_fields[5]` | instructions_fr |
| `contract.disclosure_fields[6]` | lot |
| `contract.disclosure_fields[7]` | serial_prefix |
| `contract.experiment_id` | CONTINUITY-ECONOMY-001 |
| Événement consigné · `contract.fault_schedule[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `contract.fault_schedule[0].occurrence` | 1 |
| Cible de la panne · `contract.fault_schedule[0].target` | BACKUP |
| Opération déclenchante · `contract.fault_schedule[0].trigger` | reserve |
| Valeur configurée · `contract.fault_schedule[0].value` | 0 |
| Événement consigné · `contract.fault_schedule[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `contract.fault_schedule[1].occurrence` | 1 |
| Cible de la panne · `contract.fault_schedule[1].target` | ANY |
| Opération déclenchante · `contract.fault_schedule[1].trigger` | inspect |
| Valeur configurée · `contract.fault_schedule[1].value` | 0 |
| Événement consigné · `contract.fault_schedule[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `contract.fault_schedule[2].occurrence` | 1 |
| Cible de la panne · `contract.fault_schedule[2].target` | ANY |
| Opération déclenchante · `contract.fault_schedule[2].trigger` | inspect |
| Valeur configurée · `contract.fault_schedule[2].value` | 0 |
| Identité du cas préenregistré · `contract.fixture_id` | component-integration |
| `contract.lease_ticks` | 20 |
| `contract.lot_size` | 2 |
| `contract.max_attempts` | 2 |
| `contract.mode` | market |
| Échéance logique · `contract.obligations[0].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[0].obligation_id` | DL-100 |
| Quantité requise · `contract.obligations[0].quantity` | 4 |
| Destinataire · `contract.obligations[0].recipient` | RECIPIENT-A |
| Révision · `contract.obligations[0].revision` | 2 |
| `contract.obligations[0].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[0].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[0].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[0].spec.lot` | BATCH-20261106 |
| `contract.obligations[0].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[0].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[0].spec.serial_prefix` | DL-100- |
| `contract.obligations[0].spec.sku` | KIT-DL-100 |
| État consigné · `contract.obligations[0].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[1].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[1].obligation_id` | DL-200 |
| Quantité requise · `contract.obligations[1].quantity` | 3 |
| Destinataire · `contract.obligations[1].recipient` | RECIPIENT-B |
| Révision · `contract.obligations[1].revision` | 1 |
| `contract.obligations[1].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[1].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[1].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[1].spec.lot` | BATCH-20261106 |
| `contract.obligations[1].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[1].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[1].spec.serial_prefix` | DL-200- |
| `contract.obligations[1].spec.sku` | KIT-DL-200 |
| État consigné · `contract.obligations[1].status` | Actif (`ACTIVE`) |
| Échéance logique · `contract.obligations[2].deadline_tick` | 500 |
| Identité de l’obligation · `contract.obligations[2].obligation_id` | DL-300 |
| Quantité requise · `contract.obligations[2].quantity` | 100 |
| Destinataire · `contract.obligations[2].recipient` | RECIPIENT-C |
| Révision · `contract.obligations[2].revision` | 1 |
| `contract.obligations[2].spec.format` | continuity-economy/label-job/v1 |
| `contract.obligations[2].spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.obligations[2].spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.obligations[2].spec.lot` | BATCH-20261106 |
| `contract.obligations[2].spec.name_en` | Synthetic continuity calibration kit |
| `contract.obligations[2].spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.obligations[2].spec.serial_prefix` | DL-300- |
| `contract.obligations[2].spec.sku` | KIT-DL-300 |
| État consigné · `contract.obligations[2].status` | Annulé (`CANCELLED`) |
| `contract.observation_cutoff_tick` | 800 |
| `contract.permissible_recovery_loss_units` | 0 |
| `contract.permitted_actions[0]` | restore |
| `contract.permitted_actions[1]` | propose |
| `contract.permitted_actions[2]` | decide |
| `contract.permitted_actions[3]` | technical |
| `contract.permitted_actions[4]` | reserve |
| `contract.permitted_actions[5]` | produce |
| `contract.permitted_actions[6]` | transfer |
| `contract.permitted_actions[7]` | inspect |
| `contract.permitted_actions[8]` | settle |
| `contract.permitted_actions[9]` | cancel |
| `contract.permitted_actions[10]` | status |
| `contract.providers[0].dependency` | PRIMARY-HOST |
| `contract.providers[0].permissions.disclosure` | Oui |
| `contract.providers[0].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[0].provider_id` | PRIMARY |
| Rôle · `contract.providers[0].role` | primary |
| `contract.providers[0].windows[0].capacity` | 20 |
| `contract.providers[0].windows[0].end` | 800 |
| `contract.providers[0].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[0].windows[0].window_id` | W0 |
| `contract.providers[1].dependency` | BACKUP-HOST |
| `contract.providers[1].permissions.disclosure` | Oui |
| `contract.providers[1].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[1].provider_id` | BACKUP |
| Rôle · `contract.providers[1].role` | backup |
| `contract.providers[1].windows[0].capacity` | 20 |
| `contract.providers[1].windows[0].end` | 800 |
| `contract.providers[1].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[1].windows[0].window_id` | W0 |
| `contract.providers[2].dependency` | COMPAT-A-HOST |
| `contract.providers[2].permissions.disclosure` | Oui |
| `contract.providers[2].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[2].provider_id` | COMPAT-A |
| Rôle · `contract.providers[2].role` | alternative |
| `contract.providers[2].windows[0].capacity` | 6 |
| `contract.providers[2].windows[0].end` | 800 |
| `contract.providers[2].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[2].windows[0].window_id` | W0 |
| `contract.providers[3].dependency` | COMPAT-B-HOST |
| `contract.providers[3].permissions.disclosure` | Oui |
| `contract.providers[3].permissions.production` | Oui |
| Identité du fournisseur · `contract.providers[3].provider_id` | COMPAT-B |
| Rôle · `contract.providers[3].role` | alternative |
| `contract.providers[3].windows[0].capacity` | 6 |
| `contract.providers[3].windows[0].end` | 800 |
| `contract.providers[3].windows[0].start` | 0 |
| Identité de la fenêtre de capacité · `contract.providers[3].windows[0].window_id` | W0 |
| Révision · `contract.revision` | 1 |
| `contract.revocations` | Aucune entrée |
| Identité de l’exécution · `contract.run_id` | component-integration-3 |
| Schéma · `contract.schema` | continuity-economy/contract/v1 |
| Graine consignée · `contract.seed` | 703 |
| `contract.source_complete` | Oui |
| Échéance logique · `contract.source_events[0].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[0].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[0].obligation.quantity` | 4 |
| Destinataire · `contract.source_events[0].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[0].obligation.revision` | 1 |
| `contract.source_events[0].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[0].obligation.spec.instructions_en` | Obsolete instruction. |
| `contract.source_events[0].obligation.spec.instructions_fr` | Instruction périmée. |
| `contract.source_events[0].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[0].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[0].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[0].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[0].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[0].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[0].obligation_id` | DL-100 |
| `contract.source_events[0].sequence` | 1 |
| `contract.source_events[0].type` | ACCEPT |
| Échéance logique · `contract.source_events[1].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[1].obligation.obligation_id` | DL-200 |
| Quantité requise · `contract.source_events[1].obligation.quantity` | 3 |
| Destinataire · `contract.source_events[1].obligation.recipient` | RECIPIENT-B |
| Révision · `contract.source_events[1].obligation.revision` | 1 |
| `contract.source_events[1].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[1].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[1].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[1].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[1].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[1].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[1].obligation.spec.serial_prefix` | DL-200- |
| `contract.source_events[1].obligation.spec.sku` | KIT-DL-200 |
| État consigné · `contract.source_events[1].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[1].obligation_id` | DL-200 |
| `contract.source_events[1].sequence` | 2 |
| `contract.source_events[1].type` | ACCEPT |
| Échéance logique · `contract.source_events[2].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[2].obligation.obligation_id` | DL-300 |
| Quantité requise · `contract.source_events[2].obligation.quantity` | 100 |
| Destinataire · `contract.source_events[2].obligation.recipient` | RECIPIENT-C |
| Révision · `contract.source_events[2].obligation.revision` | 1 |
| `contract.source_events[2].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[2].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[2].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[2].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[2].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[2].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[2].obligation.spec.serial_prefix` | DL-300- |
| `contract.source_events[2].obligation.spec.sku` | KIT-DL-300 |
| État consigné · `contract.source_events[2].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[2].obligation_id` | DL-300 |
| `contract.source_events[2].sequence` | 3 |
| `contract.source_events[2].type` | ACCEPT |
| Échéance logique · `contract.source_events[3].obligation.deadline_tick` | 500 |
| Identité de l’obligation · `contract.source_events[3].obligation.obligation_id` | DL-100 |
| Quantité requise · `contract.source_events[3].obligation.quantity` | 4 |
| Destinataire · `contract.source_events[3].obligation.recipient` | RECIPIENT-A |
| Révision · `contract.source_events[3].obligation.revision` | 2 |
| `contract.source_events[3].obligation.spec.format` | continuity-economy/label-job/v1 |
| `contract.source_events[3].obligation.spec.instructions_en` | Keep dry. Match this serial to the digital receiving register. |
| `contract.source_events[3].obligation.spec.instructions_fr` | Garder au sec. Associer ce numéro au registre de réception numérique. |
| `contract.source_events[3].obligation.spec.lot` | BATCH-20261106 |
| `contract.source_events[3].obligation.spec.name_en` | Synthetic continuity calibration kit |
| `contract.source_events[3].obligation.spec.name_fr` | Trousse synthétique de calibration de continuité |
| `contract.source_events[3].obligation.spec.serial_prefix` | DL-100- |
| `contract.source_events[3].obligation.spec.sku` | KIT-DL-100 |
| État consigné · `contract.source_events[3].obligation.status` | Actif (`ACTIVE`) |
| Identité de l’obligation · `contract.source_events[3].obligation_id` | DL-100 |
| `contract.source_events[3].sequence` | 4 |
| `contract.source_events[3].type` | AMEND |
| Identité de l’obligation · `contract.source_events[4].obligation_id` | DL-300 |
| `contract.source_events[4].sequence` | 5 |
| `contract.source_events[4].type` | CANCEL |
| `contract.source_id` | AUTHORED-DIGITAL-EVENTS |
| Empreintes des octets sources · `contract.source_sha256` | 146a552eee3b197545d413bd78db2a03c001c1a96077e7ef4237d195a9c09fb5 |
| Horloge de départ (ns) · `contract.start_ns` | 32068707548255 |
| Échéance en temps écoulé (ms) · `contract.wall_deadline_ms` | 60000 |
| `controller.capacity_databases[0].path` | evidence/capacity/PRIMARY.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[0].provider_id` | PRIMARY |
| `controller.capacity_databases[0].route` | primary |
| Identité de la fenêtre de capacité · `controller.capacity_databases[0].window_id` | W0 |
| `controller.capacity_databases[1].path` | evidence/capacity/BACKUP.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[1].provider_id` | BACKUP |
| `controller.capacity_databases[1].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[1].window_id` | W0 |
| `controller.capacity_databases[2].path` | evidence/capacity/COMPAT-A.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[2].provider_id` | COMPAT-A |
| `controller.capacity_databases[2].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[2].window_id` | W0 |
| `controller.capacity_databases[3].path` | evidence/capacity/COMPAT-B.W0.sqlite |
| Identité du fournisseur · `controller.capacity_databases[3].provider_id` | COMPAT-B |
| `controller.capacity_databases[3].route` | backup |
| Identité de la fenêtre de capacité · `controller.capacity_databases[3].window_id` | W0 |
| `controller.clock_tick` | 33 |
| Cohorte d’expérience · `controller.cohort` | challenge |
| SHA-256 du contrat conservé · `controller.contract_sha256` | e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7 |
| `controller.db_snapshots.evidence/capacity/BACKUP.W0.sqlite` | 1bab421a26b6a6811bf17f2c592b649d5c289b77a03abdefe93e085172e29c98 |
| `controller.db_snapshots.evidence/capacity/COMPAT-A.W0.sqlite` | 455e8f8530abfafa9ceacc148790ce9ec221e060e7c93d4617840e9deb9a0f0d |
| `controller.db_snapshots.evidence/capacity/COMPAT-B.W0.sqlite` | e39d3469686f72b86e6c8e904660a6b5945d4212993ca2fa7e6d10bef22e5242 |
| `controller.db_snapshots.evidence/capacity/PRIMARY.W0.sqlite` | fdb95bfe2e2daef38181fa326475b15460a7a0b46f05034dad241c4c0570b591 |
| `controller.db_snapshots.evidence/participants.sqlite` | bf11be28561fe03c26305bed00e8bbf9389c7bbf0804bb4e1fc065e60ab42ded |
| `controller.db_snapshots.evidence/producer.sqlite` | bb53bb4cfc071ed21a00f9b4bdd7cd146442efca1aaa73670fd073e7dbf3e8ac |
| `controller.db_snapshots.evidence/receiver.sqlite` | cfae3683286da33f8cb0437dc67c3e41056b20501b48a0ec90d492f0dfc65fe4 |
| `controller.errors` | Aucune entrée |
| `controller.events[0].detail.authority_kind` | Autorité d’exercice synthétique (`SYNTHETIC_EXERCISE`) |
| Empreinte externe de référence · `controller.events[0].detail.reference_sha256` | 681e94181af58f0e10b8acbd82e401227640065bb07f78e1beab0d228d9ebeff |
| Graine consignée · `controller.events[0].detail.seed` | 703 |
| Événement consigné · `controller.events[0].event` | AUTHORITY_RETAINED |
| `controller.events[0].monotonic_ns` | 32068727042206 |
| Instant logique · `controller.events[0].tick` | 0 |
| `controller.events[1].detail.pid` | 20 |
| `controller.events[1].detail.restart` | Non |
| `controller.events[1].detail.service` | participants |
| Événement consigné · `controller.events[1].event` | SERVICE_STARTED |
| `controller.events[1].monotonic_ns` | 32068838298670 |
| Instant logique · `controller.events[1].tick` | 0 |
| `controller.events[2].detail.pid` | 21 |
| `controller.events[2].detail.restart` | Non |
| `controller.events[2].detail.service` | producer |
| Événement consigné · `controller.events[2].event` | SERVICE_STARTED |
| `controller.events[2].monotonic_ns` | 32068879626888 |
| Instant logique · `controller.events[2].tick` | 0 |
| `controller.events[3].detail.pid` | 22 |
| `controller.events[3].detail.restart` | Non |
| `controller.events[3].detail.service` | receiver |
| Événement consigné · `controller.events[3].event` | SERVICE_STARTED |
| `controller.events[3].monotonic_ns` | 32068920893895 |
| Instant logique · `controller.events[3].tick` | 0 |
| `controller.events[4].detail.pid` | 23 |
| Identité du fournisseur · `controller.events[4].detail.provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `controller.events[4].detail.window_id` | W0 |
| Événement consigné · `controller.events[4].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[4].monotonic_ns` | 32068954485597 |
| Instant logique · `controller.events[4].tick` | 0 |
| `controller.events[5].detail.pid` | 24 |
| Identité du fournisseur · `controller.events[5].detail.provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[5].detail.window_id` | W0 |
| Événement consigné · `controller.events[5].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[5].monotonic_ns` | 32068987278102 |
| Instant logique · `controller.events[5].tick` | 0 |
| `controller.events[6].detail.pid` | 25 |
| Identité du fournisseur · `controller.events[6].detail.provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[6].detail.window_id` | W0 |
| Événement consigné · `controller.events[6].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[6].monotonic_ns` | 32069021793476 |
| Instant logique · `controller.events[6].tick` | 0 |
| `controller.events[7].detail.pid` | 26 |
| Identité du fournisseur · `controller.events[7].detail.provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[7].detail.window_id` | W0 |
| Événement consigné · `controller.events[7].event` | CAPACITY_SERVICE_STARTED |
| `controller.events[7].monotonic_ns` | 32069068498480 |
| Instant logique · `controller.events[7].tick` | 0 |
| `controller.events[8].detail.affected[0]` | PRIMARY.W0 |
| `controller.events[8].detail.dependency` | PRIMARY-HOST |
| Événement consigné · `controller.events[8].event` | DEPENDENCY_DISABLED |
| `controller.events[8].monotonic_ns` | 32069069956534 |
| Instant logique · `controller.events[8].tick` | 0 |
| `controller.events[9].detail.isolation.applied` | Oui |
| `controller.events[9].detail.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.events[9].detail.isolation.probe.authority_open_denied` | Oui |
| `controller.events[9].detail.isolation.probe.network_denied` | Oui |
| `controller.events[9].detail.isolation.probe.process_inspection_denied` | Oui |
| `controller.events[9].detail.isolation.probe.spawn_denied` | Oui |
| `controller.events[9].detail.isolation.probe.workspace_open_denied` | Oui |
| `controller.events[9].detail.pid` | 27 |
| `controller.events[9].detail.restart` | Non |
| Événement consigné · `controller.events[9].event` | CANDIDATE_STARTED |
| `controller.events[9].monotonic_ns` | 32069118344794 |
| Instant logique · `controller.events[9].tick` | 0 |
| `controller.events[10].detail.args` | Aucune entrée |
| `controller.events[10].detail.op` | status |
| Événement consigné · `controller.events[10].event` | BROKER_REQUEST |
| `controller.events[10].monotonic_ns` | 32069119998043 |
| Instant logique · `controller.events[10].tick` | 1 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[0].last_unit` | 2 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[0].pay_minor` | 414 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[0].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[1].first_unit` | 3 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[1].last_unit` | 4 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[1].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[2].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[2].last_unit` | 2 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[2].lot_id` | DL-200.L001 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[2].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[2].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[3].first_unit` | 3 |
| Dernier ordinal inclus · `controller.events[11].detail.args.proposal.allocations[3].last_unit` | 3 |
| Identité du lot fixe · `controller.events[11].detail.args.proposal.allocations[3].lot_id` | DL-200.L002 |
| Identité de l’obligation · `controller.events[11].detail.args.proposal.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[11].detail.args.proposal.allocations[3].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `controller.events[11].detail.args.proposal.allocations[3].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.buyer_price_minor` | 714 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `controller.events[11].detail.args.proposal.contract_sha256` | e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7 |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.coordinator_fee_minor` | 300 |
| Instant exclusif d’expiration · `controller.events[11].detail.args.proposal.expires_tick` | 500 |
| Révision des politiques · `controller.events[11].detail.args.proposal.policy_revision` | 1 |
| Identité de la proposition · `controller.events[11].detail.args.proposal.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `controller.events[11].detail.args.proposal.rework_budget_minor` | 157 |
| Schéma · `controller.events[11].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[11].detail.op` | propose |
| Événement consigné · `controller.events[11].event` | BROKER_REQUEST |
| `controller.events[11].monotonic_ns` | 32069127164586 |
| Instant logique · `controller.events[11].tick` | 2 |
| Identité de la proposition · `controller.events[12].detail.args.proposal_id` | proposal-001 |
| `controller.events[12].detail.op` | decide |
| Événement consigné · `controller.events[12].event` | BROKER_REQUEST |
| `controller.events[12].monotonic_ns` | 32069131570746 |
| Instant logique · `controller.events[12].tick` | 3 |
| `controller.events[13].detail.args` | Aucune entrée |
| `controller.events[13].detail.op` | status |
| Événement consigné · `controller.events[13].event` | BROKER_REQUEST |
| `controller.events[13].monotonic_ns` | 32069135131179 |
| Instant logique · `controller.events[13].tick` | 4 |
| Identité de l’accord · `controller.events[14].detail.args.agreement_id` | proposal-001 |
| `controller.events[14].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[14].detail.args.lot_id` | DL-100.L001 |
| `controller.events[14].detail.op` | reserve |
| Événement consigné · `controller.events[14].event` | BROKER_REQUEST |
| `controller.events[14].monotonic_ns` | 32069140717082 |
| Instant logique · `controller.events[14].tick` | 5 |
| `controller.events[15].detail.affected[0]` | BACKUP.W0 |
| `controller.events[15].detail.dependency` | BACKUP-HOST |
| Événement consigné · `controller.events[15].event` | DEPENDENCY_DISABLED |
| `controller.events[15].monotonic_ns` | 32069143521752 |
| Instant logique · `controller.events[15].tick` | 5 |
| `controller.events[16].detail.dependency` | BACKUP-HOST |
| Événement consigné · `controller.events[16].detail.schedule.event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `controller.events[16].detail.schedule.occurrence` | 1 |
| Cible de la panne · `controller.events[16].detail.schedule.target` | BACKUP |
| Opération déclenchante · `controller.events[16].detail.schedule.trigger` | reserve |
| Valeur configurée · `controller.events[16].detail.schedule.value` | 0 |
| Événement consigné · `controller.events[16].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| `controller.events[16].monotonic_ns` | 32069143533610 |
| Instant logique · `controller.events[16].tick` | 5 |
| Code stable · `controller.events[17].detail.code` | DEPENDENCY_UNAVAILABLE |
| `controller.events[17].detail.detail` | BACKUP |
| `controller.events[17].detail.op` | reserve |
| Événement consigné · `controller.events[17].event` | BROKER_REFUSED |
| `controller.events[17].monotonic_ns` | 32069145101530 |
| Instant logique · `controller.events[17].tick` | 5 |
| Identité de l’accord · `controller.events[18].detail.args.agreement_id` | proposal-001 |
| `controller.events[18].detail.args.reason` | DEPENDENCY_UNAVAILABLE |
| `controller.events[18].detail.op` | cancel |
| Événement consigné · `controller.events[18].event` | BROKER_REQUEST |
| `controller.events[18].monotonic_ns` | 32069145365328 |
| Instant logique · `controller.events[18].tick` | 6 |
| Identité de l’accord · `controller.events[19].detail.agreement_id` | proposal-001 |
| `controller.events[19].detail.reason` | DEPENDENCY_UNAVAILABLE |
| Événement consigné · `controller.events[19].event` | ARRANGEMENT_CANCELLED |
| `controller.events[19].monotonic_ns` | 32069150991973 |
| Instant logique · `controller.events[19].tick` | 6 |
| `controller.events[20].detail.args` | Aucune entrée |
| `controller.events[20].detail.op` | status |
| Événement consigné · `controller.events[20].event` | BROKER_REQUEST |
| `controller.events[20].monotonic_ns` | 32069151318477 |
| Instant logique · `controller.events[20].tick` | 7 |
| Premier ordinal inclus · `controller.events[21].detail.args.proposal.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[21].detail.args.proposal.allocations[0].last_unit` | 2 |
| Identité du lot fixe · `controller.events[21].detail.args.proposal.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `controller.events[21].detail.args.proposal.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[21].detail.args.proposal.allocations[0].pay_minor` | 512 |
| Identité du fournisseur · `controller.events[21].detail.args.proposal.allocations[0].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[21].detail.args.proposal.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `controller.events[21].detail.args.proposal.allocations[1].first_unit` | 3 |
| Dernier ordinal inclus · `controller.events[21].detail.args.proposal.allocations[1].last_unit` | 4 |
| Identité du lot fixe · `controller.events[21].detail.args.proposal.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `controller.events[21].detail.args.proposal.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[21].detail.args.proposal.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[21].detail.args.proposal.allocations[1].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[21].detail.args.proposal.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `controller.events[21].detail.args.proposal.allocations[2].first_unit` | 1 |
| Dernier ordinal inclus · `controller.events[21].detail.args.proposal.allocations[2].last_unit` | 2 |
| Identité du lot fixe · `controller.events[21].detail.args.proposal.allocations[2].lot_id` | DL-200.L001 |
| Identité de l’obligation · `controller.events[21].detail.args.proposal.allocations[2].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[21].detail.args.proposal.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `controller.events[21].detail.args.proposal.allocations[2].provider_id` | COMPAT-A |
| Identité de la fenêtre de capacité · `controller.events[21].detail.args.proposal.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `controller.events[21].detail.args.proposal.allocations[3].first_unit` | 3 |
| Dernier ordinal inclus · `controller.events[21].detail.args.proposal.allocations[3].last_unit` | 3 |
| Identité du lot fixe · `controller.events[21].detail.args.proposal.allocations[3].lot_id` | DL-200.L002 |
| Identité de l’obligation · `controller.events[21].detail.args.proposal.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `controller.events[21].detail.args.proposal.allocations[3].pay_minor` | 702 |
| Identité du fournisseur · `controller.events[21].detail.args.proposal.allocations[3].provider_id` | COMPAT-B |
| Identité de la fenêtre de capacité · `controller.events[21].detail.args.proposal.allocations[3].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `controller.events[21].detail.args.proposal.buyer_price_minor` | 1714 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `controller.events[21].detail.args.proposal.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `controller.events[21].detail.args.proposal.contract_sha256` | e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7 |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `controller.events[21].detail.args.proposal.coordinator_fee_minor` | 500 |
| Instant exclusif d’expiration · `controller.events[21].detail.args.proposal.expires_tick` | 500 |
| Révision des politiques · `controller.events[21].detail.args.proposal.policy_revision` | 1 |
| Identité de la proposition · `controller.events[21].detail.args.proposal.proposal_id` | proposal-002 |
| Réserve de correction (unités mineures SMU synthétiques) · `controller.events[21].detail.args.proposal.rework_budget_minor` | 507 |
| Schéma · `controller.events[21].detail.args.proposal.schema` | continuity-economy/proposal/v1 |
| `controller.events[21].detail.op` | propose |
| Événement consigné · `controller.events[21].event` | BROKER_REQUEST |
| `controller.events[21].monotonic_ns` | 32069158237536 |
| Instant logique · `controller.events[21].tick` | 8 |
| Identité de la proposition · `controller.events[22].detail.args.proposal_id` | proposal-002 |
| `controller.events[22].detail.op` | decide |
| Événement consigné · `controller.events[22].event` | BROKER_REQUEST |
| `controller.events[22].monotonic_ns` | 32069161792139 |
| Instant logique · `controller.events[22].tick` | 9 |
| `controller.events[23].detail.args` | Aucune entrée |
| `controller.events[23].detail.op` | status |
| Événement consigné · `controller.events[23].event` | BROKER_REQUEST |
| `controller.events[23].monotonic_ns` | 32069167126773 |
| Instant logique · `controller.events[23].tick` | 10 |
| Identité de l’accord · `controller.events[24].detail.args.agreement_id` | proposal-002 |
| `controller.events[24].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[24].detail.args.lot_id` | DL-100.L001 |
| `controller.events[24].detail.op` | reserve |
| Événement consigné · `controller.events[24].event` | BROKER_REQUEST |
| `controller.events[24].monotonic_ns` | 32069173101254 |
| Instant logique · `controller.events[24].tick` | 11 |
| `controller.events[25].detail.key` | proposal-002.DL-100.L001.A1 |
| `controller.events[25].detail.slot` | COMPAT-A.W0 |
| État consigné · `controller.events[25].detail.status` | RESERVED |
| Événement consigné · `controller.events[25].event` | CAPACITY_RESERVED |
| `controller.events[25].monotonic_ns` | 32069180621852 |
| Instant logique · `controller.events[25].tick` | 11 |
| Identité de l’accord · `controller.events[26].detail.args.agreement_id` | proposal-002 |
| `controller.events[26].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[26].detail.args.lot_id` | DL-100.L001 |
| `controller.events[26].detail.args.supersedes` | Non consigné |
| `controller.events[26].detail.op` | produce |
| Événement consigné · `controller.events[26].event` | BROKER_REQUEST |
| `controller.events[26].monotonic_ns` | 32069181175750 |
| Instant logique · `controller.events[26].tick` | 12 |
| `controller.events[27].detail.byte_count` | 1321 |
| `controller.events[27].detail.payload_sha256` | d6d7509b0cbee8fc3343239656241c0a259aecd5bd05abfda82a730e6129e39c |
| `controller.events[27].detail.production_id` | proposal-002.DL-100.L001.A1 |
| Quantité requise · `controller.events[27].detail.quantity` | 2 |
| Événement consigné · `controller.events[27].event` | PRODUCT_MATERIALIZED |
| `controller.events[27].monotonic_ns` | 32069196762701 |
| Instant logique · `controller.events[27].tick` | 12 |
| `controller.events[28].detail.args.production_id` | proposal-002.DL-100.L001.A1 |
| `controller.events[28].detail.op` | transfer |
| Événement consigné · `controller.events[28].event` | BROKER_REQUEST |
| `controller.events[28].monotonic_ns` | 32069197081854 |
| Instant logique · `controller.events[28].tick` | 13 |
| `controller.events[29].detail.byte_count` | 1321 |
| `controller.events[29].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[29].detail.produced_sha256` | d6d7509b0cbee8fc3343239656241c0a259aecd5bd05abfda82a730e6129e39c |
| `controller.events[29].detail.production_id` | proposal-002.DL-100.L001.A1 |
| `controller.events[29].detail.received_sha256` | d6d7509b0cbee8fc3343239656241c0a259aecd5bd05abfda82a730e6129e39c |
| Événement consigné · `controller.events[29].event` | PRODUCT_TRANSFERRED |
| `controller.events[29].monotonic_ns` | 32069202930995 |
| Instant logique · `controller.events[29].tick` | 13 |
| `controller.events[30].detail.args.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[30].detail.op` | inspect |
| Événement consigné · `controller.events[30].event` | BROKER_REQUEST |
| `controller.events[30].monotonic_ns` | 32069203195365 |
| Instant logique · `controller.events[30].tick` | 14 |
| `controller.events[31].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[31].detail.hook` | inspect.after_observation |
| Événement consigné · `controller.events[31].detail.schedule.event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.events[31].detail.schedule.occurrence` | 1 |
| Cible de la panne · `controller.events[31].detail.schedule.target` | ANY |
| Opération déclenchante · `controller.events[31].detail.schedule.trigger` | inspect |
| Valeur configurée · `controller.events[31].detail.schedule.value` | 0 |
| Événement consigné · `controller.events[31].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| `controller.events[31].monotonic_ns` | 32069207542967 |
| Instant logique · `controller.events[31].tick` | 14 |
| `controller.events[32].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[32].detail.hook` | inspect.after_observation |
| Événement consigné · `controller.events[32].detail.schedule.event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.events[32].detail.schedule.occurrence` | 1 |
| Cible de la panne · `controller.events[32].detail.schedule.target` | ANY |
| Opération déclenchante · `controller.events[32].detail.schedule.trigger` | inspect |
| Valeur configurée · `controller.events[32].detail.schedule.value` | 0 |
| Événement consigné · `controller.events[32].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| `controller.events[32].monotonic_ns` | 32069207549256 |
| Instant logique · `controller.events[32].tick` | 14 |
| `controller.events[33].detail.pid` | 22 |
| `controller.events[33].detail.service` | receiver |
| Événement consigné · `controller.events[33].event` | SERVICE_TERMINATED |
| `controller.events[33].monotonic_ns` | 32069208850043 |
| Instant logique · `controller.events[33].tick` | 14 |
| `controller.events[34].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| `controller.events[34].detail.pid` | 27 |
| Événement consigné · `controller.events[34].event` | CANDIDATE_TERMINATED |
| `controller.events[34].monotonic_ns` | 32069210102606 |
| Instant logique · `controller.events[34].tick` | 14 |
| `controller.events[35].detail.pid` | 28 |
| `controller.events[35].detail.restart` | Oui |
| `controller.events[35].detail.service` | receiver |
| Événement consigné · `controller.events[35].event` | SERVICE_STARTED |
| `controller.events[35].monotonic_ns` | 32069242938691 |
| Instant logique · `controller.events[35].tick` | 14 |
| `controller.events[36].detail.delivery_id` | proposal-002.DL-100.L001.A1.D |
| Événement consigné · `controller.events[36].event` | ACKNOWLEDGMENT_UNCERTAIN |
| `controller.events[36].monotonic_ns` | 32069242947985 |
| Instant logique · `controller.events[36].tick` | 14 |
| `controller.events[37].detail.isolation.applied` | Oui |
| `controller.events[37].detail.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.events[37].detail.isolation.probe.authority_open_denied` | Oui |
| `controller.events[37].detail.isolation.probe.network_denied` | Oui |
| `controller.events[37].detail.isolation.probe.process_inspection_denied` | Oui |
| `controller.events[37].detail.isolation.probe.spawn_denied` | Oui |
| `controller.events[37].detail.isolation.probe.workspace_open_denied` | Oui |
| `controller.events[37].detail.pid` | 29 |
| `controller.events[37].detail.restart` | Oui |
| Événement consigné · `controller.events[37].event` | CANDIDATE_STARTED |
| `controller.events[37].monotonic_ns` | 32069303219853 |
| Instant logique · `controller.events[37].tick` | 15 |
| `controller.events[38].detail.args` | Aucune entrée |
| `controller.events[38].detail.op` | status |
| Événement consigné · `controller.events[38].event` | BROKER_REQUEST |
| `controller.events[38].monotonic_ns` | 32069306579892 |
| Instant logique · `controller.events[38].tick` | 16 |
| `controller.events[39].detail.args` | Aucune entrée |
| `controller.events[39].detail.op` | status |
| Événement consigné · `controller.events[39].event` | BROKER_REQUEST |
| `controller.events[39].monotonic_ns` | 32069315791356 |
| Instant logique · `controller.events[39].tick` | 17 |
| `controller.events[40].detail.args` | Aucune entrée |
| `controller.events[40].detail.op` | status |
| Événement consigné · `controller.events[40].event` | BROKER_REQUEST |
| `controller.events[40].monotonic_ns` | 32069327404160 |
| Instant logique · `controller.events[40].tick` | 18 |
| Identité de l’accord · `controller.events[41].detail.args.agreement_id` | proposal-002 |
| `controller.events[41].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[41].detail.args.lot_id` | DL-100.L002 |
| `controller.events[41].detail.op` | reserve |
| Événement consigné · `controller.events[41].event` | BROKER_REQUEST |
| `controller.events[41].monotonic_ns` | 32069336632350 |
| Instant logique · `controller.events[41].tick` | 19 |
| `controller.events[42].detail.key` | proposal-002.DL-100.L002.A1 |
| `controller.events[42].detail.slot` | COMPAT-A.W0 |
| État consigné · `controller.events[42].detail.status` | RESERVED |
| Événement consigné · `controller.events[42].event` | CAPACITY_RESERVED |
| `controller.events[42].monotonic_ns` | 32069347886441 |
| Instant logique · `controller.events[42].tick` | 19 |
| Identité de l’accord · `controller.events[43].detail.args.agreement_id` | proposal-002 |
| `controller.events[43].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[43].detail.args.lot_id` | DL-100.L002 |
| `controller.events[43].detail.args.supersedes` | Non consigné |
| `controller.events[43].detail.op` | produce |
| Événement consigné · `controller.events[43].event` | BROKER_REQUEST |
| `controller.events[43].monotonic_ns` | 32069348339436 |
| Instant logique · `controller.events[43].tick` | 20 |
| `controller.events[44].detail.byte_count` | 1321 |
| `controller.events[44].detail.payload_sha256` | 93c0953e59cb35a3d60247e4bdd7e3aac1fc75057c68aaedc085931b862e92f0 |
| `controller.events[44].detail.production_id` | proposal-002.DL-100.L002.A1 |
| Quantité requise · `controller.events[44].detail.quantity` | 2 |
| Événement consigné · `controller.events[44].event` | PRODUCT_MATERIALIZED |
| `controller.events[44].monotonic_ns` | 32069369620765 |
| Instant logique · `controller.events[44].tick` | 20 |
| `controller.events[45].detail.args.production_id` | proposal-002.DL-100.L002.A1 |
| `controller.events[45].detail.op` | transfer |
| Événement consigné · `controller.events[45].event` | BROKER_REQUEST |
| `controller.events[45].monotonic_ns` | 32069370061421 |
| Instant logique · `controller.events[45].tick` | 21 |
| `controller.events[46].detail.byte_count` | 1321 |
| `controller.events[46].detail.delivery_id` | proposal-002.DL-100.L002.A1.D |
| `controller.events[46].detail.produced_sha256` | 93c0953e59cb35a3d60247e4bdd7e3aac1fc75057c68aaedc085931b862e92f0 |
| `controller.events[46].detail.production_id` | proposal-002.DL-100.L002.A1 |
| `controller.events[46].detail.received_sha256` | 93c0953e59cb35a3d60247e4bdd7e3aac1fc75057c68aaedc085931b862e92f0 |
| Événement consigné · `controller.events[46].event` | PRODUCT_TRANSFERRED |
| `controller.events[46].monotonic_ns` | 32069377030325 |
| Instant logique · `controller.events[46].tick` | 21 |
| `controller.events[47].detail.args.delivery_id` | proposal-002.DL-100.L002.A1.D |
| `controller.events[47].detail.op` | inspect |
| Événement consigné · `controller.events[47].event` | BROKER_REQUEST |
| `controller.events[47].monotonic_ns` | 32069377304420 |
| Instant logique · `controller.events[47].tick` | 22 |
| `controller.events[48].detail.accepted_units` | 2 |
| `controller.events[48].detail.delivery_id` | proposal-002.DL-100.L002.A1.D |
| État consigné · `controller.events[48].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[48].detail.timely` | Oui |
| Événement consigné · `controller.events[48].event` | RECIPIENT_INSPECTED |
| `controller.events[48].monotonic_ns` | 32069381091354 |
| Instant logique · `controller.events[48].tick` | 22 |
| `controller.events[49].detail.args` | Aucune entrée |
| `controller.events[49].detail.op` | status |
| Événement consigné · `controller.events[49].event` | BROKER_REQUEST |
| `controller.events[49].monotonic_ns` | 32069382330457 |
| Instant logique · `controller.events[49].tick` | 23 |
| Identité de l’accord · `controller.events[50].detail.args.agreement_id` | proposal-002 |
| `controller.events[50].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[50].detail.args.lot_id` | DL-200.L001 |
| `controller.events[50].detail.op` | reserve |
| Événement consigné · `controller.events[50].event` | BROKER_REQUEST |
| `controller.events[50].monotonic_ns` | 32069391875526 |
| Instant logique · `controller.events[50].tick` | 24 |
| `controller.events[51].detail.key` | proposal-002.DL-200.L001.A1 |
| `controller.events[51].detail.slot` | COMPAT-A.W0 |
| État consigné · `controller.events[51].detail.status` | RESERVED |
| Événement consigné · `controller.events[51].event` | CAPACITY_RESERVED |
| `controller.events[51].monotonic_ns` | 32069400426697 |
| Instant logique · `controller.events[51].tick` | 24 |
| Identité de l’accord · `controller.events[52].detail.args.agreement_id` | proposal-002 |
| `controller.events[52].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[52].detail.args.lot_id` | DL-200.L001 |
| `controller.events[52].detail.args.supersedes` | Non consigné |
| `controller.events[52].detail.op` | produce |
| Événement consigné · `controller.events[52].event` | BROKER_REQUEST |
| `controller.events[52].monotonic_ns` | 32069400834793 |
| Instant logique · `controller.events[52].tick` | 25 |
| `controller.events[53].detail.byte_count` | 1321 |
| `controller.events[53].detail.payload_sha256` | 72088ddc19a900d9520f44cb8b59ff1fee918cb45a4834cb15f8c885325c05e9 |
| `controller.events[53].detail.production_id` | proposal-002.DL-200.L001.A1 |
| Quantité requise · `controller.events[53].detail.quantity` | 2 |
| Événement consigné · `controller.events[53].event` | PRODUCT_MATERIALIZED |
| `controller.events[53].monotonic_ns` | 32069418586302 |
| Instant logique · `controller.events[53].tick` | 25 |
| `controller.events[54].detail.args.production_id` | proposal-002.DL-200.L001.A1 |
| `controller.events[54].detail.op` | transfer |
| Événement consigné · `controller.events[54].event` | BROKER_REQUEST |
| `controller.events[54].monotonic_ns` | 32069419067299 |
| Instant logique · `controller.events[54].tick` | 26 |
| `controller.events[55].detail.byte_count` | 1321 |
| `controller.events[55].detail.delivery_id` | proposal-002.DL-200.L001.A1.D |
| `controller.events[55].detail.produced_sha256` | 72088ddc19a900d9520f44cb8b59ff1fee918cb45a4834cb15f8c885325c05e9 |
| `controller.events[55].detail.production_id` | proposal-002.DL-200.L001.A1 |
| `controller.events[55].detail.received_sha256` | 72088ddc19a900d9520f44cb8b59ff1fee918cb45a4834cb15f8c885325c05e9 |
| Événement consigné · `controller.events[55].event` | PRODUCT_TRANSFERRED |
| `controller.events[55].monotonic_ns` | 32069426296036 |
| Instant logique · `controller.events[55].tick` | 26 |
| `controller.events[56].detail.args.delivery_id` | proposal-002.DL-200.L001.A1.D |
| `controller.events[56].detail.op` | inspect |
| Événement consigné · `controller.events[56].event` | BROKER_REQUEST |
| `controller.events[56].monotonic_ns` | 32069426602850 |
| Instant logique · `controller.events[56].tick` | 27 |
| `controller.events[57].detail.accepted_units` | 2 |
| `controller.events[57].detail.delivery_id` | proposal-002.DL-200.L001.A1.D |
| État consigné · `controller.events[57].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[57].detail.timely` | Oui |
| Événement consigné · `controller.events[57].event` | RECIPIENT_INSPECTED |
| `controller.events[57].monotonic_ns` | 32069430728311 |
| Instant logique · `controller.events[57].tick` | 27 |
| `controller.events[58].detail.args` | Aucune entrée |
| `controller.events[58].detail.op` | status |
| Événement consigné · `controller.events[58].event` | BROKER_REQUEST |
| `controller.events[58].monotonic_ns` | 32069431080744 |
| Instant logique · `controller.events[58].tick` | 28 |
| Identité de l’accord · `controller.events[59].detail.args.agreement_id` | proposal-002 |
| `controller.events[59].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[59].detail.args.lot_id` | DL-200.L002 |
| `controller.events[59].detail.op` | reserve |
| Événement consigné · `controller.events[59].event` | BROKER_REQUEST |
| `controller.events[59].monotonic_ns` | 32069445268175 |
| Instant logique · `controller.events[59].tick` | 29 |
| `controller.events[60].detail.key` | proposal-002.DL-200.L002.A1 |
| `controller.events[60].detail.slot` | COMPAT-B.W0 |
| État consigné · `controller.events[60].detail.status` | RESERVED |
| Événement consigné · `controller.events[60].event` | CAPACITY_RESERVED |
| `controller.events[60].monotonic_ns` | 32069453553739 |
| Instant logique · `controller.events[60].tick` | 29 |
| Identité de l’accord · `controller.events[61].detail.args.agreement_id` | proposal-002 |
| `controller.events[61].detail.args.attempt` | 1 |
| Identité du lot fixe · `controller.events[61].detail.args.lot_id` | DL-200.L002 |
| `controller.events[61].detail.args.supersedes` | Non consigné |
| `controller.events[61].detail.op` | produce |
| Événement consigné · `controller.events[61].event` | BROKER_REQUEST |
| `controller.events[61].monotonic_ns` | 32069453976368 |
| Instant logique · `controller.events[61].tick` | 30 |
| `controller.events[62].detail.byte_count` | 932 |
| `controller.events[62].detail.payload_sha256` | 7ec4936b4b2854f59121c6b8a39d6818045260ea4b7d1ccaf741c9c7c2e1c9f2 |
| `controller.events[62].detail.production_id` | proposal-002.DL-200.L002.A1 |
| Quantité requise · `controller.events[62].detail.quantity` | 1 |
| Événement consigné · `controller.events[62].event` | PRODUCT_MATERIALIZED |
| `controller.events[62].monotonic_ns` | 32069471932446 |
| Instant logique · `controller.events[62].tick` | 30 |
| `controller.events[63].detail.args.production_id` | proposal-002.DL-200.L002.A1 |
| `controller.events[63].detail.op` | transfer |
| Événement consigné · `controller.events[63].event` | BROKER_REQUEST |
| `controller.events[63].monotonic_ns` | 32069472380002 |
| Instant logique · `controller.events[63].tick` | 31 |
| `controller.events[64].detail.byte_count` | 932 |
| `controller.events[64].detail.delivery_id` | proposal-002.DL-200.L002.A1.D |
| `controller.events[64].detail.produced_sha256` | 7ec4936b4b2854f59121c6b8a39d6818045260ea4b7d1ccaf741c9c7c2e1c9f2 |
| `controller.events[64].detail.production_id` | proposal-002.DL-200.L002.A1 |
| `controller.events[64].detail.received_sha256` | 7ec4936b4b2854f59121c6b8a39d6818045260ea4b7d1ccaf741c9c7c2e1c9f2 |
| Événement consigné · `controller.events[64].event` | PRODUCT_TRANSFERRED |
| `controller.events[64].monotonic_ns` | 32069479716692 |
| Instant logique · `controller.events[64].tick` | 31 |
| `controller.events[65].detail.args.delivery_id` | proposal-002.DL-200.L002.A1.D |
| `controller.events[65].detail.op` | inspect |
| Événement consigné · `controller.events[65].event` | BROKER_REQUEST |
| `controller.events[65].monotonic_ns` | 32069480021012 |
| Instant logique · `controller.events[65].tick` | 32 |
| `controller.events[66].detail.accepted_units` | 1 |
| `controller.events[66].detail.delivery_id` | proposal-002.DL-200.L002.A1.D |
| État consigné · `controller.events[66].detail.status` | Accepté (`ACCEPTED`) |
| `controller.events[66].detail.timely` | Oui |
| Événement consigné · `controller.events[66].event` | RECIPIENT_INSPECTED |
| `controller.events[66].monotonic_ns` | 32069483355738 |
| Instant logique · `controller.events[66].tick` | 32 |
| Identité de l’accord · `controller.events[67].detail.args.agreement_id` | proposal-002 |
| `controller.events[67].detail.op` | settle |
| Événement consigné · `controller.events[67].event` | BROKER_REQUEST |
| `controller.events[67].monotonic_ns` | 32069483658596 |
| Instant logique · `controller.events[67].tick` | 33 |
| Références d’acceptation · `controller.events[68].detail.acceptance_ids[0]` | proposal-002.DL-100.L001.A1.D |
| Références d’acceptation · `controller.events[68].detail.acceptance_ids[1]` | proposal-002.DL-100.L002.A1.D |
| Références d’acceptation · `controller.events[68].detail.acceptance_ids[2]` | proposal-002.DL-200.L001.A1.D |
| Références d’acceptation · `controller.events[68].detail.acceptance_ids[3]` | proposal-002.DL-200.L002.A1.D |
| Identité de l’accord · `controller.events[68].detail.agreement_id` | proposal-002 |
| Événement consigné · `controller.events[68].event` | ARRANGEMENT_SETTLED |
| `controller.events[68].monotonic_ns` | 32069488289116 |
| Instant logique · `controller.events[68].tick` | 33 |
| Interventions consignées · `controller.events[69].detail.interventions` | Aucune entrée |
| `controller.events[69].detail.reason` | DIGITAL_PRODUCT_ACCEPTED |
| `controller.events[69].detail.searches` | Aucune entrée |
| Verdict du composant · `controller.events[69].detail.verdict` | Réalisé (`COMPLETED`) |
| Événement consigné · `controller.events[69].event` | CANDIDATE_DONE |
| `controller.events[69].monotonic_ns` | 32069488834340 |
| Instant logique · `controller.events[69].tick` | 33 |
| `controller.events[70].detail.database` | participants |
| `controller.events[70].detail.sqlite[0]` | 0 |
| `controller.events[70].detail.sqlite[1]` | 0 |
| `controller.events[70].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[70].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[70].event` | DATABASE_CHECKPOINT |
| `controller.events[70].monotonic_ns` | 32069507795271 |
| Instant logique · `controller.events[70].tick` | 33 |
| `controller.events[71].detail.database` | producer |
| `controller.events[71].detail.sqlite[0]` | 0 |
| `controller.events[71].detail.sqlite[1]` | 0 |
| `controller.events[71].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[71].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[71].event` | DATABASE_CHECKPOINT |
| `controller.events[71].monotonic_ns` | 32069509091936 |
| Instant logique · `controller.events[71].tick` | 33 |
| `controller.events[72].detail.database` | receiver |
| `controller.events[72].detail.sqlite[0]` | 0 |
| `controller.events[72].detail.sqlite[1]` | 0 |
| `controller.events[72].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[72].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[72].event` | DATABASE_CHECKPOINT |
| `controller.events[72].monotonic_ns` | 32069510399693 |
| Instant logique · `controller.events[72].tick` | 33 |
| `controller.events[73].detail.database` | PRIMARY.W0 |
| `controller.events[73].detail.sqlite[0]` | 0 |
| `controller.events[73].detail.sqlite[1]` | 0 |
| `controller.events[73].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[73].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[73].event` | DATABASE_CHECKPOINT |
| `controller.events[73].monotonic_ns` | 32069511533247 |
| Instant logique · `controller.events[73].tick` | 33 |
| `controller.events[74].detail.database` | BACKUP.W0 |
| `controller.events[74].detail.sqlite[0]` | 0 |
| `controller.events[74].detail.sqlite[1]` | 0 |
| `controller.events[74].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[74].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[74].event` | DATABASE_CHECKPOINT |
| `controller.events[74].monotonic_ns` | 32069514536216 |
| Instant logique · `controller.events[74].tick` | 33 |
| `controller.events[75].detail.database` | COMPAT-A.W0 |
| `controller.events[75].detail.sqlite[0]` | 0 |
| `controller.events[75].detail.sqlite[1]` | 0 |
| `controller.events[75].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[75].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[75].event` | DATABASE_CHECKPOINT |
| `controller.events[75].monotonic_ns` | 32069515971340 |
| Instant logique · `controller.events[75].tick` | 33 |
| `controller.events[76].detail.database` | COMPAT-B.W0 |
| `controller.events[76].detail.sqlite[0]` | 0 |
| `controller.events[76].detail.sqlite[1]` | 0 |
| `controller.events[76].detail.sqlite[2]` | 0 |
| État consigné · `controller.events[76].detail.status` | CHECKPOINTED |
| Événement consigné · `controller.events[76].event` | DATABASE_CHECKPOINT |
| `controller.events[76].monotonic_ns` | 32069517351426 |
| Instant logique · `controller.events[76].tick` | 33 |
| `controller.events[77].detail.databases` | 7 |
| `controller.events[77].detail.snapshot_method` | SQLITE_BACKUP_DELETE_FULL_LOGICAL_DIGEST |
| Événement consigné · `controller.events[77].event` | EVIDENCE_FINALIZED |
| `controller.events[77].monotonic_ns` | 32069665399608 |
| Instant logique · `controller.events[77].tick` | 33 |
| Événement consigné · `controller.fault_schedule[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `controller.fault_schedule[0].occurrence` | 1 |
| Cible de la panne · `controller.fault_schedule[0].target` | BACKUP |
| Opération déclenchante · `controller.fault_schedule[0].trigger` | reserve |
| Valeur configurée · `controller.fault_schedule[0].value` | 0 |
| Événement consigné · `controller.fault_schedule[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.fault_schedule[1].occurrence` | 1 |
| Cible de la panne · `controller.fault_schedule[1].target` | ANY |
| Opération déclenchante · `controller.fault_schedule[1].trigger` | inspect |
| Valeur configurée · `controller.fault_schedule[1].value` | 0 |
| Événement consigné · `controller.fault_schedule[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.fault_schedule[2].occurrence` | 1 |
| Cible de la panne · `controller.fault_schedule[2].target` | ANY |
| Opération déclenchante · `controller.fault_schedule[2].trigger` | inspect |
| Valeur configurée · `controller.fault_schedule[2].value` | 0 |
| Événement consigné · `controller.faults_observed[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `controller.faults_observed[0].occurrence` | 1 |
| Cible de la panne · `controller.faults_observed[0].target` | BACKUP |
| Opération déclenchante · `controller.faults_observed[0].trigger` | reserve |
| Valeur configurée · `controller.faults_observed[0].value` | 0 |
| Événement consigné · `controller.faults_observed[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.faults_observed[1].occurrence` | 1 |
| Cible de la panne · `controller.faults_observed[1].target` | ANY |
| Opération déclenchante · `controller.faults_observed[1].trigger` | inspect |
| Valeur configurée · `controller.faults_observed[1].value` | 0 |
| Événement consigné · `controller.faults_observed[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `controller.faults_observed[2].occurrence` | 1 |
| Cible de la panne · `controller.faults_observed[2].target` | ANY |
| Opération déclenchante · `controller.faults_observed[2].trigger` | inspect |
| Valeur configurée · `controller.faults_observed[2].value` | 0 |
| `controller.finished_monotonic_ns` | 32069665405487 |
| Identité du cas préenregistré · `controller.fixture_id` | component-integration |
| Modifications sources non consignées présentes · `controller.implementation.dirty` | Oui |
| Arguments exacts du processus · `controller.implementation.environment.argv[0]` | python3 |
| Arguments exacts du processus · `controller.implementation.environment.argv[1]` | - |
| Plateforme d’exécution · `controller.implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `controller.implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `controller.implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `controller.implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/continuity-economy |
| Commit source effectif · `controller.implementation.git_commit` | 1e456a186a497213bbef543105890bc33663bf07 |
| Base conservée de l’implémentation de capacité · `controller.implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `controller.implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `controller.implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `controller.implementation.source_sha256.continuity_economy/adapters.py` | 9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048 |
| `controller.implementation.source_sha256.continuity_economy/candidate.py` | 83d12c8a048548b09a441d1fa71f715eca148d82226241e2f6c808a968bc103b |
| `controller.implementation.source_sha256.continuity_economy/controller.py` | 8fde2dae33ad25e1bf8a7cf906d191b1ba02d380fb5ba7967155b4ec121008ca |
| `controller.implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `controller.implementation.source_sha256.continuity_economy/participants.py` | 6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2 |
| `controller.implementation.source_sha256.continuity_economy/planning.py` | bbb2d7e4d9edc198535922581933c2e8545a23df4e1b29c4af94d395c324c0aa |
| `controller.implementation.source_sha256.continuity_economy/policy_schema.py` | b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b |
| `controller.implementation.source_sha256.continuity_economy/producer.py` | 6abd09dd3c72a5cef8a1a03b401f1cc4abc30b481e7785260b3b61b229e7ee9d |
| `controller.implementation.source_sha256.continuity_economy/receiver.py` | 28da0368d3be9a3976fe39a91678a7d26bbbf13d77f21ab9b1d4f99bbb7dd66e |
| `controller.implementation.source_sha256.continuity_economy/reporting.py` | 7e1104a21611d3da7ddb186b44bc103fe6838cc2618b827ce255f0d2e2e20e8d |
| `controller.implementation.source_sha256.continuity_economy/schema.py` | 7c4dba34b933d9d74288c45ef991e568779569cfda347d749d353f87d27ff4eb |
| `controller.implementation.source_sha256.continuity_economy/suite.py` | d1207e52da59c2d8b5eba63a2634c85a3e0292ef022c46395f046da8f358b268 |
| `controller.implementation.source_sha256.continuity_economy/verifier.py` | a8acfb76796cc9ddcc5c3d836255d621039baf53920896aa6b6aad155b4bd586 |
| `controller.implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `controller.implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `controller.implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `controller.implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `controller.implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `controller.implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `controller.implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `controller.implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `controller.implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `controller.implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `controller.implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `controller.implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `controller.implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `controller.implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 053876ed32464df4a9420632f0f6a9e8692e32093934eafbcdae2aa7ed259075 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `controller.implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Version d’implémentation · `controller.implementation.version` | 0.2.0 |
| `controller.isolation.applied` | Oui |
| `controller.isolation.mechanism` | Confinement du processus seccomp-BPF observé (`SECCOMP_BPF`) |
| `controller.isolation.probe.authority_open_denied` | Oui |
| `controller.isolation.probe.network_denied` | Oui |
| `controller.isolation.probe.process_inspection_denied` | Oui |
| `controller.isolation.probe.spawn_denied` | Oui |
| `controller.isolation.probe.workspace_open_denied` | Oui |
| Procédure candidate · `controller.method` | harness |
| `controller.policies_sha256` | fc701f004c83a9d4a45bc185a65c39b19b509d3ee059c10de93650513f48fae4 |
| Travail d’adaptation (secondes ; inconnu si absent) · `controller.resources.adaptation_labor_seconds` | Non consigné |
| Redémarrages du candidat · `controller.resources.candidate_restarts` | 1 |
| Processeur système du contrôleur (ns) · `controller.resources.controller_cpu_system_ns` | 39866000 |
| Processeur utilisateur du contrôleur (ns) · `controller.resources.controller_cpu_user_ns` | 100081999 |
| Processeur système (ns) · `controller.resources.cpu_system_ns` | 164571999 |
| Processeur utilisateur (ns) · `controller.resources.cpu_user_ns` | 514619999 |
| Interventions humaines · `controller.resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `controller.resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `controller.resources.measurement_scope` | Contrôleur et processus enfants ; leur mesure processeur sur un hôte partagé peut inclure des exercices concurrents. |
| Coût monétaire réel mesuré · `controller.resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `controller.resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `controller.resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `controller.resources.requests` | 32 |
| Nouvelles tentatives · `controller.resources.retries` | 0 |
| Stockage consigné (octets) · `controller.resources.storage_bytes` | 1337022 |
| Travail humain de vérification (secondes ; inconnu si absent) · `controller.resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `controller.resources.wall_ns` | 957857232 |
| Redémarrages des services · `controller.resources.worker_restarts` | 1 |
| Identité de l’exécution · `controller.run_id` | component-integration-3 |
| Schéma · `controller.schema` | continuity-economy/controller/v1 |
| `controller.started_monotonic_ns` | 32068707548255 |
| `controller.started_utc` | 2026-11-06T22:31:10.821082+00:00 |
| `controller.state` | Vérification complète (`COMPLETE`) |
| Verdict du composant · `controller.target_verdict` | Réalisé (`COMPLETED`) |
| Événement consigné · `fault_schedule[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `fault_schedule[0].occurrence` | 1 |
| Cible de la panne · `fault_schedule[0].target` | BACKUP |
| Opération déclenchante · `fault_schedule[0].trigger` | reserve |
| Valeur configurée · `fault_schedule[0].value` | 0 |
| Événement consigné · `fault_schedule[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `fault_schedule[1].occurrence` | 1 |
| Cible de la panne · `fault_schedule[1].target` | ANY |
| Opération déclenchante · `fault_schedule[1].trigger` | inspect |
| Valeur configurée · `fault_schedule[1].value` | 0 |
| Événement consigné · `fault_schedule[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `fault_schedule[2].occurrence` | 1 |
| Cible de la panne · `fault_schedule[2].target` | ANY |
| Opération déclenchante · `fault_schedule[2].trigger` | inspect |
| Valeur configurée · `fault_schedule[2].value` | 0 |
| Événement consigné · `faults_observed[0].event` | Défaillance du secours avant réservation (`BACKUP_FAIL_BEFORE_RESERVE`) |
| Occurrence déclenchante · `faults_observed[0].occurrence` | 1 |
| Cible de la panne · `faults_observed[0].target` | BACKUP |
| Opération déclenchante · `faults_observed[0].trigger` | reserve |
| Valeur configurée · `faults_observed[0].value` | 0 |
| Événement consigné · `faults_observed[1].event` | Accusé perdu après acceptation durable (`ACK_LOST_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `faults_observed[1].occurrence` | 1 |
| Cible de la panne · `faults_observed[1].target` | ANY |
| Opération déclenchante · `faults_observed[1].trigger` | inspect |
| Valeur configurée · `faults_observed[1].value` | 0 |
| Événement consigné · `faults_observed[2].event` | Redémarrage du candidat après acceptation (`CANDIDATE_RESTART_AFTER_ACCEPTANCE`) |
| Occurrence déclenchante · `faults_observed[2].occurrence` | 1 |
| Cible de la panne · `faults_observed[2].target` | ANY |
| Opération déclenchante · `faults_observed[2].trigger` | inspect |
| Valeur configurée · `faults_observed[2].value` | 0 |
| Modifications sources non consignées présentes · `implementation.dirty` | Oui |
| Arguments exacts du processus · `implementation.environment.argv[0]` | python3 |
| Arguments exacts du processus · `implementation.environment.argv[1]` | - |
| Plateforme d’exécution · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/continuity-economy |
| Commit source effectif · `implementation.git_commit` | 1e456a186a497213bbef543105890bc33663bf07 |
| Base conservée de l’implémentation de capacité · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048 |
| `implementation.source_sha256.continuity_economy/candidate.py` | 83d12c8a048548b09a441d1fa71f715eca148d82226241e2f6c808a968bc103b |
| `implementation.source_sha256.continuity_economy/controller.py` | 8fde2dae33ad25e1bf8a7cf906d191b1ba02d380fb5ba7967155b4ec121008ca |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2 |
| `implementation.source_sha256.continuity_economy/planning.py` | bbb2d7e4d9edc198535922581933c2e8545a23df4e1b29c4af94d395c324c0aa |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b |
| `implementation.source_sha256.continuity_economy/producer.py` | 6abd09dd3c72a5cef8a1a03b401f1cc4abc30b481e7785260b3b61b229e7ee9d |
| `implementation.source_sha256.continuity_economy/receiver.py` | 28da0368d3be9a3976fe39a91678a7d26bbbf13d77f21ab9b1d4f99bbb7dd66e |
| `implementation.source_sha256.continuity_economy/reporting.py` | 7e1104a21611d3da7ddb186b44bc103fe6838cc2618b827ce255f0d2e2e20e8d |
| `implementation.source_sha256.continuity_economy/schema.py` | 7c4dba34b933d9d74288c45ef991e568779569cfda347d749d353f87d27ff4eb |
| `implementation.source_sha256.continuity_economy/suite.py` | d1207e52da59c2d8b5eba63a2634c85a3e0292ef022c46395f046da8f358b268 |
| `implementation.source_sha256.continuity_economy/verifier.py` | a8acfb76796cc9ddcc5c3d836255d621039baf53920896aa6b6aad155b4bd586 |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 053876ed32464df4a9420632f0f6a9e8692e32093934eafbcdae2aa7ed259075 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Version d’implémentation · `implementation.version` | 0.2.0 |
| Solde (unités mineures SMU synthétiques) · `policies.buyer.balance_minor` | 30000 |
| `policies.buyer.consent_until_tick` | 800 |
| `policies.buyer.max_price_minor` | 25000 |
| Utilité d’option externe définie (SMU synthétiques) · `policies.buyer.outside_utility_minor` | 2000 |
| Identité du participant · `policies.buyer.party_id` | BUYER |
| Borne supérieure de valeur définie (SMU synthétiques) · `policies.buyer.value_max_minor` | 30000 |
| Borne inférieure de valeur définie (SMU synthétiques) · `policies.buyer.value_min_minor` | 30000 |
| Solde (unités mineures SMU synthétiques) · `policies.coordinator.balance_minor` | 10000 |
| `policies.coordinator.consent_until_tick` | 800 |
| `policies.coordinator.liability_limit_minor` | 10000 |
| `policies.coordinator.min_profit_minor` | 100 |
| `policies.coordinator.operating_cost_minor` | 200 |
| Profit d’option externe défini (SMU synthétiques) · `policies.coordinator.outside_profit_minor` | 100 |
| Identité du participant · `policies.coordinator.party_id` | COORDINATOR |
| `policies.coordinator.technical_control_allowed` | Oui |
| Unité de compte synthétique · `policies.currency` | SMU |
| Solde (unités mineures SMU synthétiques) · `policies.providers[0].balance_minor` | 40000 |
| `policies.providers[0].consent_until_tick` | 800 |
| `policies.providers[0].liability_limit_minor` | 40000 |
| `policies.providers[0].min_profit_minor` | 100 |
| Profit d’option externe défini (SMU synthétiques) · `policies.providers[0].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[0].party_id` | PRIMARY |
| `policies.providers[0].rework_setup_cost_minor` | 100 |
| `policies.providers[0].rework_unit_cost_minor` | 1 |
| `policies.providers[0].setup_cost_minor` | 100 |
| `policies.providers[0].technical_control_allowed` | Oui |
| `policies.providers[0].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[1].balance_minor` | 40000 |
| `policies.providers[1].consent_until_tick` | 800 |
| `policies.providers[1].liability_limit_minor` | 40000 |
| `policies.providers[1].min_profit_minor` | 100 |
| Profit d’option externe défini (SMU synthétiques) · `policies.providers[1].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[1].party_id` | BACKUP |
| `policies.providers[1].rework_setup_cost_minor` | 150 |
| `policies.providers[1].rework_unit_cost_minor` | 1 |
| `policies.providers[1].setup_cost_minor` | 150 |
| `policies.providers[1].technical_control_allowed` | Oui |
| `policies.providers[1].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[2].balance_minor` | 40000 |
| `policies.providers[2].consent_until_tick` | 800 |
| `policies.providers[2].liability_limit_minor` | 40000 |
| `policies.providers[2].min_profit_minor` | 100 |
| Profit d’option externe défini (SMU synthétiques) · `policies.providers[2].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[2].party_id` | COMPAT-A |
| `policies.providers[2].rework_setup_cost_minor` | 200 |
| `policies.providers[2].rework_unit_cost_minor` | 1 |
| `policies.providers[2].setup_cost_minor` | 200 |
| `policies.providers[2].technical_control_allowed` | Oui |
| `policies.providers[2].unit_cost_minor` | 1 |
| Solde (unités mineures SMU synthétiques) · `policies.providers[3].balance_minor` | 40000 |
| `policies.providers[3].consent_until_tick` | 800 |
| `policies.providers[3].liability_limit_minor` | 40000 |
| `policies.providers[3].min_profit_minor` | 100 |
| Profit d’option externe défini (SMU synthétiques) · `policies.providers[3].outside_profit_minor` | 100 |
| Identité du participant · `policies.providers[3].party_id` | COMPAT-B |
| `policies.providers[3].rework_setup_cost_minor` | 300 |
| `policies.providers[3].rework_unit_cost_minor` | 1 |
| `policies.providers[3].setup_cost_minor` | 300 |
| `policies.providers[3].technical_control_allowed` | Oui |
| `policies.providers[3].unit_cost_minor` | 1 |
| Révision · `policies.revision` | 1 |
| Schéma · `policies.schema` | continuity-economy/policies/v1 |
| `policies.technical_sponsor.authorized` | Oui |
| Solde (unités mineures SMU synthétiques) · `policies.technical_sponsor.balance_minor` | 60000 |
| Identité du participant · `policies.technical_sponsor.party_id` | TECHNICAL-SPONSOR |
| `review_stage` | Revue du rendu de développement d’un résultat existant ; aucune nouvelle expérience exécutée. |
| Hypothèses de confiance explicites · `trust_assumptions[0]` | Hôte, noyau, contrôleur et horloge de confiance (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Hypothèses de confiance explicites · `trust_assumptions[1]` | Autorité synthétique conservée de confiance (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Hypothèses de confiance explicites · `trust_assumptions[2]` | Auteur commun ; aucune certification par un tiers (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Hypothèses de confiance explicites · `trust_assumptions[3]` | Contenu numérique sémantique uniquement ; livraison physique non éprouvée (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Pannes préenregistrées non déclenchées · `untriggered_faults` | Aucune entrée |

## Enregistrement structuré complet de vérification

Le même enregistrement structuré génère les deux versions linguistiques. Les clés machine, codes d’état et valeurs littérales des preuves restent inchangés ; les sections localisées ci-dessus expliquent leur sens. Aucun résultat sauvegardé n’est réutilisé comme preuve fraîche.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 1714,
    "buyer_utility_interval_minor": {
      "maximum": 28286,
      "minimum": 28286
    },
    "campaign": [
      {
        "final_balance_minor": 28286,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 1714,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 400,
        "initial_balance_minor": 10000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 100,
        "revenue_minor": 500,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40306,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 206,
        "initial_balance_minor": 40000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 306,
        "revenue_minor": 512,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40401,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 301,
        "initial_balance_minor": 40000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 401,
        "revenue_minor": 702,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 907,
    "total_transfers_minor": 1714,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "DEMONSTRATED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "COMPLETED",
    "test_assertion": "NOT_EVALUATED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "DEMONSTRATED",
    "service_feasibility": "DEMONSTRATED"
  },
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7",
  "evidence_sha256": {
    "evidence/capacity-artifacts/COMPAT-A.W0/DL-100.L001.A1.json": "949c41781455823d33e1637368961bfc2433a61c14a3c032a6fe22a3009dd778",
    "evidence/capacity-artifacts/COMPAT-A.W0/DL-100.L002.A1.json": "2ccebbd4797dc6305c65cb37e3a69e5af7581a8978d86cd884d40dad5d95cf4f",
    "evidence/capacity-artifacts/COMPAT-A.W0/DL-200.L001.A1.json": "54272dfe7a7f1205ad6d299afcd1b1b5e8bb596dbe7615e8473eab1d106cd711",
    "evidence/capacity-artifacts/COMPAT-B.W0/DL-200.L002.A1.json": "540d4b8873796a78458ef753462fc126c979abf3587965d3d9f4cda07ebb8367",
    "evidence/capacity/BACKUP.W0.sqlite": "fdbfee2648bc6131c3f9fb0c96c782924bc2b5a5ac80817d53f74cbce2bd4cec",
    "evidence/capacity/COMPAT-A.W0.sqlite": "3069621b961b368c52efbd3c602dc3c9ff62a309ed764b7a6efc9d1b112a7497",
    "evidence/capacity/COMPAT-B.W0.sqlite": "1555cd5a1087fab803300b84ecf578ee85cd14b2d908ccfd33fb2e830ef34e56",
    "evidence/capacity/PRIMARY.W0.sqlite": "c515f9b37cac621c7f18c135a3bb736deba6c437931f884c5da68485d5807e8c",
    "evidence/inbox/proposal-002.DL-100.L001.A1.D.json": "d6d7509b0cbee8fc3343239656241c0a259aecd5bd05abfda82a730e6129e39c",
    "evidence/inbox/proposal-002.DL-100.L002.A1.D.json": "93c0953e59cb35a3d60247e4bdd7e3aac1fc75057c68aaedc085931b862e92f0",
    "evidence/inbox/proposal-002.DL-200.L001.A1.D.json": "72088ddc19a900d9520f44cb8b59ff1fee918cb45a4834cb15f8c885325c05e9",
    "evidence/inbox/proposal-002.DL-200.L002.A1.D.json": "7ec4936b4b2854f59121c6b8a39d6818045260ea4b7d1ccaf741c9c7c2e1c9f2",
    "evidence/participants.sqlite": "0c2316b08fd428f3a4d2b9e80c2ff205cd8d2376c1ae643bde28184010c3111a",
    "evidence/producer.sqlite": "5c4b4975841ef5094614a30d2ddd413f3b09fab8e99340d5c40ce5293d1faec6",
    "evidence/products/proposal-002.DL-100.L001.A1.json": "d6d7509b0cbee8fc3343239656241c0a259aecd5bd05abfda82a730e6129e39c",
    "evidence/products/proposal-002.DL-100.L002.A1.json": "93c0953e59cb35a3d60247e4bdd7e3aac1fc75057c68aaedc085931b862e92f0",
    "evidence/products/proposal-002.DL-200.L001.A1.json": "72088ddc19a900d9520f44cb8b59ff1fee918cb45a4834cb15f8c885325c05e9",
    "evidence/products/proposal-002.DL-200.L002.A1.json": "7ec4936b4b2854f59121c6b8a39d6818045260ea4b7d1ccaf741c9c7c2e1c9f2",
    "evidence/receiver.sqlite": "1ddb9a4e86a9aa108c6a3c193ff6757f455fc37cdb17a2831bed40734211329b"
  },
  "failures": [],
  "fault_schedule": [
    {
      "event": "BACKUP_FAIL_BEFORE_RESERVE",
      "occurrence": 1,
      "target": "BACKUP",
      "trigger": "reserve",
      "value": 0
    },
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    },
    {
      "event": "CANDIDATE_RESTART_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "faults_observed": [
    {
      "event": "BACKUP_FAIL_BEFORE_RESERVE",
      "occurrence": 1,
      "target": "BACKUP",
      "trigger": "reserve",
      "value": 0
    },
    {
      "event": "ACK_LOST_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    },
    {
      "event": "CANDIDATE_RESTART_AFTER_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 0
    }
  ],
  "implementation": {
    "dirty": true,
    "environment": {
      "argv": [
        "python3",
        "-"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/continuity-economy"
    },
    "git_commit": "1e456a186a497213bbef543105890bc33663bf07",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048",
      "continuity_economy/candidate.py": "83d12c8a048548b09a441d1fa71f715eca148d82226241e2f6c808a968bc103b",
      "continuity_economy/controller.py": "8fde2dae33ad25e1bf8a7cf906d191b1ba02d380fb5ba7967155b4ec121008ca",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2",
      "continuity_economy/planning.py": "bbb2d7e4d9edc198535922581933c2e8545a23df4e1b29c4af94d395c324c0aa",
      "continuity_economy/policy_schema.py": "b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b",
      "continuity_economy/producer.py": "6abd09dd3c72a5cef8a1a03b401f1cc4abc30b481e7785260b3b61b229e7ee9d",
      "continuity_economy/receiver.py": "28da0368d3be9a3976fe39a91678a7d26bbbf13d77f21ab9b1d4f99bbb7dd66e",
      "continuity_economy/reporting.py": "7e1104a21611d3da7ddb186b44bc103fe6838cc2618b827ce255f0d2e2e20e8d",
      "continuity_economy/schema.py": "7c4dba34b933d9d74288c45ef991e568779569cfda347d749d353f87d27ff4eb",
      "continuity_economy/suite.py": "d1207e52da59c2d8b5eba63a2634c85a3e0292ef022c46395f046da8f358b268",
      "continuity_economy/verifier.py": "a8acfb76796cc9ddcc5c3d836255d621039baf53920896aa6b6aad155b4bd586",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "053876ed32464df4a9420632f0f6a9e8692e32093934eafbcdae2aa7ed259075",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b"
    },
    "version": "0.2.0"
  },
  "per_arrangement": [
    {
      "acceptance_ids": [],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": 6,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 200,
      "independent_terms": {
        "break_even_value_minor": 2714,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 714,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 157,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 314,
            "minimum_payment_minor": 414,
            "participation_profit_minor": 100,
            "party_id": "BACKUP",
            "promised_payment_minor": 414,
            "rework_cost_minor": 157,
            "units": 7
          }
        ],
        "rework_budget_minor": 157,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "BACKUP",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 2,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 414,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 3,
            "last_unit": 4,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 2,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 3,
            "last_unit": 3,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 714,
        "cancellation_fee_minor": 0,
        "contract_sha256": "e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 157,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "settled_tick": null,
      "status": "CANCELLED"
    },
    {
      "acceptance_ids": [
        "proposal-002.DL-100.L001.A1.D",
        "proposal-002.DL-100.L002.A1.D",
        "proposal-002.DL-200.L001.A1.D",
        "proposal-002.DL-200.L002.A1.D"
      ],
      "accepted_tick": 9,
      "agreement_id": "proposal-002",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 707,
      "independent_terms": {
        "break_even_value_minor": 3514,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 1514,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 206,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 412,
            "minimum_payment_minor": 512,
            "participation_profit_minor": 100,
            "party_id": "COMPAT-A",
            "promised_payment_minor": 512,
            "rework_cost_minor": 206,
            "units": 6
          },
          {
            "base_cost_minor": 301,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 602,
            "minimum_payment_minor": 702,
            "participation_profit_minor": 100,
            "party_id": "COMPAT-B",
            "promised_payment_minor": 702,
            "rework_cost_minor": 301,
            "units": 1
          }
        ],
        "rework_budget_minor": 507,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COMPAT-A",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COMPAT-B",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 1714,
      "proposal_id": "proposal-002",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 2,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 512,
            "provider_id": "COMPAT-A",
            "window_id": "W0"
          },
          {
            "first_unit": 3,
            "last_unit": 4,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "COMPAT-A",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 2,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "COMPAT-A",
            "window_id": "W0"
          },
          {
            "first_unit": 3,
            "last_unit": 3,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 702,
            "provider_id": "COMPAT-B",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 1714,
        "cancellation_fee_minor": 0,
        "contract_sha256": "e7b65da0edebe8ef9eef062fb5c8a5e6e9cb584801785e1630093c71ddbcd8a7",
        "coordinator_fee_minor": 500,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-002",
        "rework_budget_minor": 507,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "DEMONSTRATED",
      "settled_tick": 33,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 4,
      "deadline_tick": 500,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-100",
      "outcome": "COMPLETED",
      "produced_quantity": 4,
      "production_attempts": 2,
      "quantity": 4,
      "reason_codes": [],
      "received_quantity": 4,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 4,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 4,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 4
    },
    {
      "accepted_quantity": 3,
      "deadline_tick": 500,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-200",
      "outcome": "COMPLETED",
      "produced_quantity": 3,
      "production_attempts": 2,
      "quantity": 3,
      "reason_codes": [],
      "received_quantity": 3,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 3,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 3,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 3
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "681e94181af58f0e10b8acbd82e401227640065bb07f78e1beab0d228d9ebeff",
  "resources": {
    "adaptation_labor_seconds": null,
    "candidate_restarts": 1,
    "controller_cpu_system_ns": 39866000,
    "controller_cpu_user_ns": 100081999,
    "cpu_system_ns": 164571999,
    "cpu_user_ns": 514619999,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes; shared-host child CPU may include concurrent exercises",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 32,
    "retries": 0,
    "storage_bytes": 1337022,
    "verification_labor_seconds": null,
    "wall_ns": 957857232,
    "worker_restarts": 1
  },
  "run_id": "component-integration-3",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "totals": {
    "accepted_obligations": 2,
    "accepted_quantity": 7,
    "delivery_attempts": 4,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 0,
    "produced_quantity": 7,
    "production_attempts": 4,
    "received_quantity": 7,
    "recipient_accepted_quantity": 7,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 7,
    "timely_semantic_quantity": 7,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 71018721,
    "evidence_files_read": 19,
    "wall_ns": 71024590
  },
  "verification_status": "COMPLETE",
  "verifier_version": "0.2.0"
}
```
