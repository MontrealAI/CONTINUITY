# CONTINUITY Ω Harness — Economy of continuity

**Digital-product experiment · version 0.2.0**

Preserve a promise through a viable, voluntarily accepted continuity arrangement.

**Scope: disposable local processes and a specified digital product. Authored synthetic policies, consent, values, funding and SMU cash flows are model inputs and observations. They do not establish real contracts, demand, payments, sales, printed goods, rendered appearance or print quality.**

This Passport presents the recorded assessment. Fresh verification must inspect retained authority, actual durable output and recipient evidence; this document is never its oracle.

<!-- structured-result-sha256: 55fc075d1f3a0857236ff29fa164ce39bbb427d8e98f780a6a43ca5b4afb3573 -->

## Three distinct claims

| Claim | Recorded status |
| --- | --- |
| Required digital work accepted within the frozen conditions | Failed (`FAILED`) |
| Service feasibility under the authored synthetic model | Failed (`FAILED`) |
| Method advantage over competent alternatives | Not established (`NOT_ESTABLISHED`) |
| Safety within the exercised failure model | Demonstrated in scope (`DEMONSTRATED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

## Assessment fields kept separate

| Field | Recorded value |
| --- | --- |
| Test assertion | Failed (`FAILED`) |
| Component verdict | Not established (`NOT_ESTABLISHED`) |
| Evidence stage | Local digital-product execution (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| Outcome claim status | Failed (`FAILED`) |

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

## Identity, authority and versions

| Field | Recorded value |
| --- | --- |
| Authority evidence status · `authority_status` | Established for the synthetic exercise only (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Real commercial value · `commercial_value` | Not established (`NOT_ESTABLISHED`) |
| Contract identity · `contract_id` | Not recorded |
| Retained contract SHA-256 · `contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Real customer authenticity · `real_customer_authenticity` | Not established (`NOT_ESTABLISHED`) |
| External reference pin · `reference_sha256` | ac641085abef21c75d9f250ad072dee17e17f7de8b77876ce32739dfd4d0bb0b |
| Run identity · `run_id` | deadline-expiry.873e1e6512 |
| Schema · `schema` | continuity-economy/verification/v1 |
| Verification completion status · `verification_status` | Complete verification (`COMPLETE`) |
| Verifier version · `verifier_version` | 0.2.0 |

## Per-obligation execution and acceptance

Counts describe the recorded stage. Rejected and corrected attempts remain distinct. A produced or received unit is not automatically accepted. Missing measurements are not displayed as zero.

| Obligation | Recipient | Revision | Required | Produced | Received | Rejected | Accepted within contract | Outcome |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 500 | 500 | 0 | 0 | Unfulfilled (`UNFULFILLED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 0 | 0 | 0 | 0 | Unfulfilled (`UNFULFILLED`) |
| DL-300 | RECIPIENT-C | 1 | 100 | 0 | 0 | 0 | 0 | Cancelled (`CANCELLED`) |

### Obligation `DL-100`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 1 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 1100 |
| Obligation identity · `obligation_id` | DL-100 |
| Outcome · `outcome` | Unfulfilled (`UNFULFILLED`) |
| Produced quantity · `produced_quantity` | 500 |
| Durable production attempts · `production_attempts` | 1 |
| Required quantity · `quantity` | 1100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 500 |
| Recipient · `recipient` | RECIPIENT-A |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 1100 |
| Revision · `revision` | 2 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

### Obligation `DL-200`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 800 |
| Obligation identity · `obligation_id` | DL-200 |
| Outcome · `outcome` | Unfulfilled (`UNFULFILLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 800 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-B |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 800 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

### Obligation `DL-300`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | DL-300 |
| Outcome · `outcome` | Cancelled (`CANCELLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-C |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 0 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Cancelled (`CANCELLED`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

## Proposals, modeled decisions and arrangements

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-001`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids` | No entries |
| Agreement acceptance tick · `accepted_tick` | 3 |
| Agreement identity · `agreement_id` | proposal-001 |
| Cancellation tick · `cancelled_tick` | 502 |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 800 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 6400 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 4400 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 2000 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 4000 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 4100 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 4100 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 2000 |
| Units · `independent_terms.providers[0].units` | 1900 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2000 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | Modeled trade agreement (`TRADE`) |
| Stable code · `participant_decisions[0].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[1].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[2].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[2].party_id` | COORDINATOR |
| Role · `participant_decisions[2].role` | coordinator |
| Component verdict · `participant_decisions[2].verdict` | Accepted (`ACCEPTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 0 |
| Proposal identity · `proposal_id` | proposal-001 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 4100 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 4400 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 300 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-001 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2000 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Failed (`FAILED`) |
| Modeled settlement tick · `settled_tick` | Not recorded |
| Recorded status · `status` | Cancelled (`CANCELLED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-002`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids` | No entries |
| Agreement identity · `agreement_id` | Not recorded |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Failed (`FAILED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 0 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 7000 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 5000 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 350 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 700 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 800 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | BACKUP |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 800 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 350 |
| Units · `independent_terms.providers[0].units` | 100 |
| Base production cost (synthetic SMU) · `independent_terms.providers[1].base_cost_minor` | 1900 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[1].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 3800 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[1].minimum_payment_minor` | 3900 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[1].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[1].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[1].promised_payment_minor` | 3900 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[1].rework_cost_minor` | 1900 |
| Units · `independent_terms.providers[1].units` | 1800 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2250 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | PROPOSAL |
| Stable code · `participant_decisions[0].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[1].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[2].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[2].party_id` | BACKUP |
| Role · `participant_decisions[2].role` | provider |
| Component verdict · `participant_decisions[2].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[3].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[3].party_id` | COORDINATOR |
| Role · `participant_decisions[3].role` | coordinator |
| Component verdict · `participant_decisions[3].verdict` | Rejected (`REJECTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 0 |
| Proposal identity · `proposal_id` | proposal-002 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 3900 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 800 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 5200 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 500 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-002 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2250 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Failed (`FAILED`) |
| Recorded status · `status` | Rejected (`REJECTED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-003`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids` | No entries |
| Agreement identity · `agreement_id` | Not recorded |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Failed (`FAILED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 0 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 7300 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 5300 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 500 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 1000 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 1100 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | COMPAT-A |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 1100 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 500 |
| Units · `independent_terms.providers[0].units` | 100 |
| Base production cost (synthetic SMU) · `independent_terms.providers[1].base_cost_minor` | 1900 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[1].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 3800 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[1].minimum_payment_minor` | 3900 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[1].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[1].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[1].promised_payment_minor` | 3900 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[1].rework_cost_minor` | 1900 |
| Units · `independent_terms.providers[1].units` | 1800 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2400 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | PROPOSAL |
| Stable code · `participant_decisions[0].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[1].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[2].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[2].party_id` | COMPAT-A |
| Role · `participant_decisions[2].role` | provider |
| Component verdict · `participant_decisions[2].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[3].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[3].party_id` | COORDINATOR |
| Role · `participant_decisions[3].role` | coordinator |
| Component verdict · `participant_decisions[3].verdict` | Rejected (`REJECTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 0 |
| Proposal identity · `proposal_id` | proposal-003 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 3900 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 1100 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | COMPAT-A |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 5500 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 500 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-003 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2400 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Failed (`FAILED`) |
| Recorded status · `status` | Rejected (`REJECTED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-004`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids` | No entries |
| Agreement identity · `agreement_id` | Not recorded |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Failed (`FAILED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 0 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 7400 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 5400 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 750 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 1500 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 1600 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | BACKUP |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 1600 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 750 |
| Units · `independent_terms.providers[0].units` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[1].base_cost_minor` | 1700 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[1].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 3400 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[1].minimum_payment_minor` | 3500 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[1].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[1].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[1].promised_payment_minor` | 3500 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[1].rework_cost_minor` | 1700 |
| Units · `independent_terms.providers[1].units` | 1600 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2450 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | PROPOSAL |
| Stable code · `participant_decisions[0].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[1].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[2].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[2].party_id` | BACKUP |
| Role · `participant_decisions[2].role` | provider |
| Component verdict · `participant_decisions[2].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[3].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[3].party_id` | COORDINATOR |
| Role · `participant_decisions[3].role` | coordinator |
| Component verdict · `participant_decisions[3].verdict` | Rejected (`REJECTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 0 |
| Proposal identity · `proposal_id` | proposal-004 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 3500 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 1600 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 5600 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 500 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-004 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2450 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Failed (`FAILED`) |
| Recorded status · `status` | Rejected (`REJECTED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-005`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids` | No entries |
| Agreement identity · `agreement_id` | Not recorded |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Failed (`FAILED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 0 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 7500 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 5500 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 600 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 1200 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 1300 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | COMPAT-B |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 1300 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 600 |
| Units · `independent_terms.providers[0].units` | 100 |
| Base production cost (synthetic SMU) · `independent_terms.providers[1].base_cost_minor` | 1900 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[1].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 3800 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[1].minimum_payment_minor` | 3900 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[1].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[1].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[1].promised_payment_minor` | 3900 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[1].rework_cost_minor` | 1900 |
| Units · `independent_terms.providers[1].units` | 1800 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2500 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | PROPOSAL |
| Stable code · `participant_decisions[0].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[1].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[2].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[2].party_id` | COMPAT-B |
| Role · `participant_decisions[2].role` | provider |
| Component verdict · `participant_decisions[2].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[3].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[3].party_id` | COORDINATOR |
| Role · `participant_decisions[3].role` | coordinator |
| Component verdict · `participant_decisions[3].verdict` | Rejected (`REJECTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 0 |
| Proposal identity · `proposal_id` | proposal-005 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 3900 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 1300 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | COMPAT-B |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 5700 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 500 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-005 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2500 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Failed (`FAILED`) |
| Recorded status · `status` | Rejected (`REJECTED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-006`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids` | No entries |
| Agreement identity · `agreement_id` | Not recorded |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Failed (`FAILED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 0 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 7600 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 5600 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 950 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 1900 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 2000 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | BACKUP |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 2000 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 950 |
| Units · `independent_terms.providers[0].units` | 400 |
| Base production cost (synthetic SMU) · `independent_terms.providers[1].base_cost_minor` | 1600 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[1].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 3200 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[1].minimum_payment_minor` | 3300 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[1].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[1].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[1].promised_payment_minor` | 3300 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[1].rework_cost_minor` | 1600 |
| Units · `independent_terms.providers[1].units` | 1500 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2550 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | PROPOSAL |
| Stable code · `participant_decisions[0].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[1].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[2].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[2].party_id` | BACKUP |
| Role · `participant_decisions[2].role` | provider |
| Component verdict · `participant_decisions[2].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[3].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[3].party_id` | COORDINATOR |
| Role · `participant_decisions[3].role` | coordinator |
| Component verdict · `participant_decisions[3].verdict` | Rejected (`REJECTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 0 |
| Proposal identity · `proposal_id` | proposal-006 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 3300 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 2000 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 5800 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 500 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-006 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2550 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Failed (`FAILED`) |
| Recorded status · `status` | Rejected (`REJECTED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-007`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids` | No entries |
| Agreement identity · `agreement_id` | Not recorded |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Failed (`FAILED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 0 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 7800 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 5800 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 1150 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 2300 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 2400 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | BACKUP |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 2400 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 1150 |
| Units · `independent_terms.providers[0].units` | 500 |
| Base production cost (synthetic SMU) · `independent_terms.providers[1].base_cost_minor` | 1500 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[1].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 3000 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[1].minimum_payment_minor` | 3100 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[1].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[1].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[1].promised_payment_minor` | 3100 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[1].rework_cost_minor` | 1500 |
| Units · `independent_terms.providers[1].units` | 1400 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2650 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | PROPOSAL |
| Stable code · `participant_decisions[0].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[1].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[2].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[2].party_id` | BACKUP |
| Role · `participant_decisions[2].role` | provider |
| Component verdict · `participant_decisions[2].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[3].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[3].party_id` | COORDINATOR |
| Role · `participant_decisions[3].role` | coordinator |
| Component verdict · `participant_decisions[3].verdict` | Rejected (`REJECTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 0 |
| Proposal identity · `proposal_id` | proposal-007 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 2400 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 3100 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 6000 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 500 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-007 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2650 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Failed (`FAILED`) |
| Recorded status · `status` | Rejected (`REJECTED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-008`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids` | No entries |
| Agreement identity · `agreement_id` | Not recorded |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Failed (`FAILED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 0 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 7800 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 5800 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 1150 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 2300 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 2400 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | BACKUP |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 2400 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 1150 |
| Units · `independent_terms.providers[0].units` | 500 |
| Base production cost (synthetic SMU) · `independent_terms.providers[1].base_cost_minor` | 1500 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[1].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[1].maximum_unpaid_cost_exposure_minor` | 3000 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[1].minimum_payment_minor` | 3100 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[1].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[1].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[1].promised_payment_minor` | 3100 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[1].rework_cost_minor` | 1500 |
| Units · `independent_terms.providers[1].units` | 1400 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2650 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | PROPOSAL |
| Stable code · `participant_decisions[0].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[1].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[2].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[2].party_id` | BACKUP |
| Role · `participant_decisions[2].role` | provider |
| Component verdict · `participant_decisions[2].verdict` | Rejected (`REJECTED`) |
| Stable code · `participant_decisions[3].code` | PROPOSAL_EXPIRED |
| Participant identity · `participant_decisions[3].party_id` | COORDINATOR |
| Role · `participant_decisions[3].role` | coordinator |
| Component verdict · `participant_decisions[3].verdict` | Rejected (`REJECTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 0 |
| Proposal identity · `proposal_id` | proposal-008 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 3100 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 2400 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | BACKUP |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 6000 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 500 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-008 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2650 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Failed (`FAILED`) |
| Recorded status · `status` | Rejected (`REJECTED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.


## Modeled transfers, costs, liabilities and outside options

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

| Field | Recorded value |
| --- | --- |
| Total buyer transfers (synthetic SMU) · `accounting.buyer_total_paid_minor` | 0 |
| Upper bound · `accounting.buyer_utility_interval_minor.maximum` | Not recorded |
| Lower bound · `accounting.buyer_utility_interval_minor.minimum` | Not recorded |
| Final modeled balance (synthetic SMU) · `accounting.campaign[0].final_balance_minor` | 30000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Modeled participation threshold covered · `accounting.campaign[0].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[0].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[0].party_id` | BUYER |
| Purchase transfers (synthetic SMU) · `accounting.campaign[0].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[0].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU) · `accounting.campaign[0].revenue_minor` | 0 |
| Role · `accounting.campaign[0].role` | buyer |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[1].final_balance_minor` | 9800 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[1].incurred_cost_minor` | 200 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Modeled participation threshold covered · `accounting.campaign[1].participation_covered` | No |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[1].participation_threshold_minor` | 100 |
| Participant identity · `accounting.campaign[1].party_id` | COORDINATOR |
| Purchase transfers (synthetic SMU) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[1].realized_profit_minor` | -200 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[1].revenue_minor` | 0 |
| Role · `accounting.campaign[1].role` | coordinator |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Modeled participation threshold covered · `accounting.campaign[2].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[2].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Purchase transfers (synthetic SMU) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[2].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU) · `accounting.campaign[2].revenue_minor` | 0 |
| Role · `accounting.campaign[2].role` | technical_sponsor |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[3].final_balance_minor` | 39400 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[3].incurred_cost_minor` | 600 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[3].participation_covered` | No |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[3].participation_threshold_minor` | 100 |
| Participant identity · `accounting.campaign[3].party_id` | PRIMARY |
| Purchase transfers (synthetic SMU) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[3].realized_profit_minor` | -600 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[3].revenue_minor` | 0 |
| Role · `accounting.campaign[3].role` | provider |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[4].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[4].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[4].party_id` | BACKUP |
| Purchase transfers (synthetic SMU) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[4].revenue_minor` | 0 |
| Role · `accounting.campaign[4].role` | provider |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[5].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[5].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[5].party_id` | COMPAT-A |
| Purchase transfers (synthetic SMU) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[5].revenue_minor` | 0 |
| Role · `accounting.campaign[5].role` | provider |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[6].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[6].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[6].party_id` | COMPAT-B |
| Purchase transfers (synthetic SMU) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[6].revenue_minor` | 0 |
| Role · `accounting.campaign[6].role` | provider |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Synthetic accounting unit · `accounting.currency` | SMU |
| Final ledger total (synthetic SMU) · `accounting.final_total_minor` | 260000 |
| Initial ledger total (synthetic SMU) · `accounting.initial_total_minor` | 260000 |
| Real contracts, payments or demand · `accounting.real_contracts_payments_or_demand` | Not established (`NOT_ESTABLISHED`) |
| Realized modeled buyer feasibility · `accounting.realized_buyer` | Not established (`NOT_ESTABLISHED`) |
| Assessment scope · `accounting.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| All correction costs (synthetic SMU) · `accounting.total_correction_cost_minor` | 0 |
| All incurred campaign costs (synthetic SMU) · `accounting.total_incurred_cost_minor` | 800 |
| All modeled settlement transfers (synthetic SMU) · `accounting.total_transfers_minor` | 0 |
| Modeled trade settled · `accounting.trade_settled` | No |
| Accepted obligations · `totals.accepted_obligations` | 0 |
| Accepted quantity within contract · `totals.accepted_quantity` | 0 |
| Delivery attempts · `totals.delivery_attempts` | 1 |
| Duplicate accepted units · `totals.duplicate_acceptances` | 0 |
| Late quantity · `totals.late_quantity` | 0 |
| Missing quantity · `totals.missing_quantity` | 1900 |
| Produced quantity · `totals.produced_quantity` | 500 |
| Durable production attempts · `totals.production_attempts` | 1 |
| Received quantity · `totals.received_quantity` | 500 |
| Units accepted by the recipient component · `totals.recipient_accepted_quantity` | 0 |
| Rejected quantity · `totals.rejected_quantity` | 0 |
| Requested units in rejected deliveries · `totals.rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `totals.rejection_count` | 0 |
| Required active obligations · `totals.required_obligations` | 2 |
| Required quantity · `totals.required_quantity` | 1900 |
| Semantically correct units observed in time · `totals.timely_semantic_quantity` | 0 |
| Unsafe or unsupported commitments · `totals.unsafe_or_unsupported_commitments` | 0 |

## Measured resources and accounting gaps

Measured process resources and configured synthetic amounts have different meanings. Unrecorded preparation, integration, adaptation, verification or intervention effort remains unknown. Missing categories cannot support a complete-cost or cheaper-method conclusion.

| Field | Recorded value |
| --- | --- |
| Accounting gaps · `accounting_gaps[0]` | Preparation labor was not measured (`PREPARATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[1]` | Integration labor was not measured (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[2]` | Adaptation labor was not measured (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[3]` | Human verification labor was not measured (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[4]` | Monetary rates were not measured (`MONETARY_RATES_NOT_MEASURED`) |
| Adaptation labor (seconds; unknown if absent) · `resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `resources.authority_storage_bytes_before_seal` | 30113 |
| Candidate restarts · `resources.candidate_restarts` | 0 |
| Launched child processes · `resources.child_processes` | 8 |
| Controller system CPU (ns) · `resources.controller_cpu_system_ns` | 23325999 |
| Controller user CPU (ns) · `resources.controller_cpu_user_ns` | 109743000 |
| System CPU (ns) · `resources.cpu_system_ns` | 97797000 |
| User CPU (ns) · `resources.cpu_user_ns` | 522381000 |
| Human interventions · `resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `resources.measurement_scope` | Controller and child processes; child CPU accounting on a shared host may include concurrent exercises. |
| Measured real monetary cost · `resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `resources.preparation_labor_seconds` | Not recorded |
| Requests · `resources.requests` | 32 |
| Retries · `resources.retries` | 0 |
| Internal service requests · `resources.service_requests` | 93 |
| Recorded storage (bytes) · `resources.storage_bytes` | 3238475 |
| Human verification labor (seconds; unknown if absent) · `resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `resources.wall_ns` | 907052438 |
| Worker restarts · `resources.worker_restarts` | 0 |
| Process CPU (ns) · `verification_resources.cpu_ns` | 129185658 |
| Evidence files inspected · `verification_resources.evidence_files_read` | 10 |
| Wall duration (ns) · `verification_resources.wall_ns` | 129193517 |

## Observed failures and counterexamples

| Stable code | Scope | Obligation | Arrangement | Interpretation | Original technical locator |
| --- | --- | --- | --- | --- | --- |
| `REALIZED_PARTICIPATION_NOT_COVERED` | economic | Not recorded | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `COORDINATOR` |
| `REALIZED_PARTICIPATION_NOT_COVERED` | economic | Not recorded | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `PRIMARY` |

## Missing evidence and unresolved claims

No additional unresolved entry was recorded. Scope and unknown-cost limits still apply.

## Evidence references and byte integrity

Hashes identify bytes. They do not authenticate real customer instructions, establish source completeness, or replace an externally retained reference pin.

| Field | Recorded value |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json` | 9d0818d5dc29cd3f19a4e7e0ef214732b551617b791250f30d7216141b6e35ce |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 9459c2ee9823fd8f5d2391cf7bd89686eda3daf25d8ec18f0d24aa3c184272e3 |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | 7ec7bb7e7c5b2bf59dc6a78b4154d67583504d98067474794ac4eecc64e29c28 |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | 11b29ea82a113f16bf1d82cfaa3dcb46495270b1df845eb70ae6df44c43c3ea1 |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | 1356a040adab72caaba3cbc8d5b04240d4d9d72d92190ccf7bf175b434b8f80b |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L001.A1.D.json` | 9003418df8cc255b454f60bad5bf8fed5f0f9c4eb66234a90533b25511f679e6 |
| `evidence_sha256.evidence/participants.sqlite` | 55cbb9a0c234d5dd4e223f85f01ee83236c66bc7a1efea0e1212f88c2926e0a5 |
| `evidence_sha256.evidence/producer.sqlite` | f0cc8bd6ae1b70733cd4f154a7a7779eb980d8ce0aa48fb831835dfba402c8d5 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L001.A1.json` | 9003418df8cc255b454f60bad5bf8fed5f0f9c4eb66234a90533b25511f679e6 |
| `evidence_sha256.evidence/receiver.sqlite` | 756409f1d0166e382fc195757bb98986294ac57a40d87ea3fed9ecba94cce0ff |
| Structured result SHA-256 · `structured_result_sha256` | 55fc075d1f3a0857236ff29fa164ce39bbb427d8e98f780a6a43ca5b4afb3573 |

## Recorded execution, faults, commands and provenance

Stable identifiers, exact commands, paths and original machine diagnostics are retained literally. They are data, not additional acceptance evidence. Source and host trust remain explicit in the architecture and threat model.

| Field | Recorded value |
| --- | --- |
| `command[0]` | python |
| `command[1]` | -m |
| `command[2]` | continuity_economy |
| `command[3]` | challenge |
| `command[4]` | --out |
| `command[5]` | /workspace/scratch/b1d5891eb025/economy-verifier-development/attempt-1 |
| Recorded event · `fault_schedule[0].event` | Acceptance beyond the declared deadline (`LATE_ACCEPTANCE`) |
| Trigger occurrence · `fault_schedule[0].occurrence` | 1 |
| Fault target · `fault_schedule[0].target` | ANY |
| Trigger operation · `fault_schedule[0].trigger` | inspect |
| Configured value · `fault_schedule[0].value` | 1 |
| Recorded event · `faults_observed[0].event` | Acceptance beyond the declared deadline (`LATE_ACCEPTANCE`) |
| Trigger occurrence · `faults_observed[0].occurrence` | 1 |
| Fault target · `faults_observed[0].target` | ANY |
| Trigger operation · `faults_observed[0].trigger` | inspect |
| Configured value · `faults_observed[0].value` | 1 |
| Uncommitted source changes present · `implementation.dirty` | Yes |
| Exact process arguments · `implementation.environment.argv[0]` | python |
| Exact process arguments · `implementation.environment.argv[1]` | - |
| Operating platform · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `implementation.environment.sqlite_version` | 3.53.1 |
| Execution directory · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/continuity-economy |
| Actual source commit · `implementation.git_commit` | 0d7892130cf1696202e10fdd85bf8bd126c10fb3 |
| Preserved capacity implementation baseline · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048 |
| `implementation.source_sha256.continuity_economy/candidate.py` | f62fb5ac3421445264c7db9313af33b4d906c7c0026f75aa69b729d68c708320 |
| `implementation.source_sha256.continuity_economy/challenges.py` | f0480ce9f8e315ebbe41f727388c0c7458c18430e06f9a8470284b5d92c7a24f |
| `implementation.source_sha256.continuity_economy/controller.py` | 47caac93a7d431fc0badec2f726f1d508bc003d0281056b33f4616964df456e3 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2 |
| `implementation.source_sha256.continuity_economy/planning.py` | e006e6596794c0d86910cc7b406e317628f888bf912f2e5b31a9a88ab738c3bd |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b |
| `implementation.source_sha256.continuity_economy/producer.py` | e9ec94afc823dbadd9bae631cee7630489399a9038c01ccd48991ad67489b09a |
| `implementation.source_sha256.continuity_economy/receiver.py` | d192329fe254ed04194dc1680ac62e550204362b2da642235d13d607dc5975ff |
| `implementation.source_sha256.continuity_economy/reporting.py` | 653589d591c80d7b680c4ae702817fd1a2248d70ec32e821a08e94d9f945aa19 |
| `implementation.source_sha256.continuity_economy/schema.py` | dbf625ffd5300e7ac82ff5e857a0709647814eb8bd47e3fd9912c74bb78ed77f |
| `implementation.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `implementation.source_sha256.continuity_economy/verifier.py` | 2deff4885c565f7e8508984cd693648ba49c6693d15aa0c71926704daba0c16d |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Implementation version · `implementation.version` | 0.2.0 |
| External reference pin · `reference_sha256` | ac641085abef21c75d9f250ad072dee17e17f7de8b77876ce32739dfd4d0bb0b |
| `registered_case.criterion` | DEADLINE_REFUSAL_PRESERVED |
| Recorded event · `registered_case.fault.event` | Acceptance beyond the declared deadline (`LATE_ACCEPTANCE`) |
| Trigger occurrence · `registered_case.fault.occurrence` | 1 |
| Fault target · `registered_case.fault.target` | ANY |
| Trigger operation · `registered_case.fault.trigger` | inspect |
| Configured value · `registered_case.fault.value` | 1 |
| `registered_case.fixture` | primary-recovery |
| `registered_case.id` | deadline-expiry |
| Arrangement kind · `registered_case.kind` | live |
| `registration_sha256` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| Explicit trust assumptions · `trust_assumptions[0]` | Trusted host, kernel, controller and clock (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Explicit trust assumptions · `trust_assumptions[1]` | Trusted retained synthetic authority (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Explicit trust assumptions · `trust_assumptions[2]` | Shared authorship; no third-party certification (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Explicit trust assumptions · `trust_assumptions[3]` | Semantic digital content only; physical delivery is untested (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Registered faults not triggered · `untriggered_faults` | No entries |

## Adversarial observation and checker qualification

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `assertion.accepted_quantity` | 0 |
| Checker qualification · `assertion.checker_qualification` | NOT_APPLICABLE |
| `assertion.criterion` | DEADLINE_REFUSAL_PRESERVED |
| `assertion.finding_codes[0]` | REALIZED_PARTICIPATION_NOT_COVERED |
| `assertion.observed_outcome` | Failed (`FAILED`) |
| `assertion.observed_safety_status` | Demonstrated in scope (`DEMONSTRATED`) |
| `assertion.observed_service_feasibility` | Failed (`FAILED`) |
| Recorded status · `assertion.status` | Failed (`FAILED`) |
| `criterion` | DEADLINE_REFUSAL_PRESERVED |
| `execution_reused_from` | Not recorded |
| `id` | deadline-expiry |
| Arrangement kind · `kind` | live |
| `observation_wall_ns` | 1055552056 |
| Assessment scope · `scope` | REGISTERED_SYNTHETIC_CHALLENGE |

## Complete structured verification record

The same structured record generates both language versions. Machine keys, enum codes and literal evidence values remain unchanged; the localized sections above explain their meaning. No saved result is reused as fresh proof.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 0,
    "buyer_utility_interval_minor": {
      "maximum": null,
      "minimum": null
    },
    "campaign": [
      {
        "final_balance_minor": 30000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 9800,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 200,
        "initial_balance_minor": 10000,
        "participation_covered": false,
        "participation_threshold_minor": 100,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": -200,
        "revenue_minor": 0,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 39400,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 600,
        "initial_balance_minor": 40000,
        "participation_covered": false,
        "participation_threshold_minor": 100,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": -600,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "NOT_ESTABLISHED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 800,
    "total_transfers_minor": 0,
    "trade_settled": false
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "FAILED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "NOT_ESTABLISHED",
    "test_assertion": "FAILED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "challenge": {
    "assertion": {
      "accepted_quantity": 0,
      "checker_qualification": "NOT_APPLICABLE",
      "criterion": "DEADLINE_REFUSAL_PRESERVED",
      "finding_codes": [
        "REALIZED_PARTICIPATION_NOT_COVERED"
      ],
      "observed_outcome": "FAILED",
      "observed_safety_status": "DEMONSTRATED",
      "observed_service_feasibility": "FAILED",
      "status": "FAILED"
    },
    "criterion": "DEADLINE_REFUSAL_PRESERVED",
    "execution_reused_from": null,
    "id": "deadline-expiry",
    "kind": "live",
    "observation_wall_ns": 1055552056,
    "scope": "REGISTERED_SYNTHETIC_CHALLENGE"
  },
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "FAILED",
    "service_feasibility": "FAILED"
  },
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
  "evidence_sha256": {
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json": "9d0818d5dc29cd3f19a4e7e0ef214732b551617b791250f30d7216141b6e35ce",
    "evidence/capacity/BACKUP.W0.sqlite": "9459c2ee9823fd8f5d2391cf7bd89686eda3daf25d8ec18f0d24aa3c184272e3",
    "evidence/capacity/COMPAT-A.W0.sqlite": "7ec7bb7e7c5b2bf59dc6a78b4154d67583504d98067474794ac4eecc64e29c28",
    "evidence/capacity/COMPAT-B.W0.sqlite": "11b29ea82a113f16bf1d82cfaa3dcb46495270b1df845eb70ae6df44c43c3ea1",
    "evidence/capacity/PRIMARY.W0.sqlite": "1356a040adab72caaba3cbc8d5b04240d4d9d72d92190ccf7bf175b434b8f80b",
    "evidence/inbox/proposal-001.DL-100.L001.A1.D.json": "9003418df8cc255b454f60bad5bf8fed5f0f9c4eb66234a90533b25511f679e6",
    "evidence/participants.sqlite": "55cbb9a0c234d5dd4e223f85f01ee83236c66bc7a1efea0e1212f88c2926e0a5",
    "evidence/producer.sqlite": "f0cc8bd6ae1b70733cd4f154a7a7779eb980d8ce0aa48fb831835dfba402c8d5",
    "evidence/products/proposal-001.DL-100.L001.A1.json": "9003418df8cc255b454f60bad5bf8fed5f0f9c4eb66234a90533b25511f679e6",
    "evidence/receiver.sqlite": "756409f1d0166e382fc195757bb98986294ac57a40d87ea3fed9ecba94cce0ff"
  },
  "failures": [
    {
      "code": "REALIZED_PARTICIPATION_NOT_COVERED",
      "detail": "COORDINATOR",
      "scope": "economic"
    },
    {
      "code": "REALIZED_PARTICIPATION_NOT_COVERED",
      "detail": "PRIMARY",
      "scope": "economic"
    }
  ],
  "fault_schedule": [
    {
      "event": "LATE_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 1
    }
  ],
  "faults_observed": [
    {
      "event": "LATE_ACCEPTANCE",
      "occurrence": 1,
      "target": "ANY",
      "trigger": "inspect",
      "value": 1
    }
  ],
  "implementation": {
    "dirty": true,
    "environment": {
      "argv": [
        "python",
        "-"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/continuity-economy"
    },
    "git_commit": "0d7892130cf1696202e10fdd85bf8bd126c10fb3",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048",
      "continuity_economy/candidate.py": "f62fb5ac3421445264c7db9313af33b4d906c7c0026f75aa69b729d68c708320",
      "continuity_economy/challenges.py": "f0480ce9f8e315ebbe41f727388c0c7458c18430e06f9a8470284b5d92c7a24f",
      "continuity_economy/controller.py": "47caac93a7d431fc0badec2f726f1d508bc003d0281056b33f4616964df456e3",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2",
      "continuity_economy/planning.py": "e006e6596794c0d86910cc7b406e317628f888bf912f2e5b31a9a88ab738c3bd",
      "continuity_economy/policy_schema.py": "b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b",
      "continuity_economy/producer.py": "e9ec94afc823dbadd9bae631cee7630489399a9038c01ccd48991ad67489b09a",
      "continuity_economy/receiver.py": "d192329fe254ed04194dc1680ac62e550204362b2da642235d13d607dc5975ff",
      "continuity_economy/reporting.py": "653589d591c80d7b680c4ae702817fd1a2248d70ec32e821a08e94d9f945aa19",
      "continuity_economy/schema.py": "dbf625ffd5300e7ac82ff5e857a0709647814eb8bd47e3fd9912c74bb78ed77f",
      "continuity_economy/suite.py": "1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3",
      "continuity_economy/verifier.py": "2deff4885c565f7e8508984cd693648ba49c6693d15aa0c71926704daba0c16d",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b"
    },
    "version": "0.2.0"
  },
  "per_arrangement": [
    {
      "acceptance_ids": [],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": 502,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 800,
      "independent_terms": {
        "break_even_value_minor": 6400,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 4400,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 2000,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 4000,
            "minimum_payment_minor": 4100,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 4100,
            "rework_cost_minor": 2000,
            "units": 1900
          }
        ],
        "rework_budget_minor": 2000,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 4100,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 4400,
        "cancellation_fee_minor": 0,
        "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2000,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "settled_tick": null,
      "status": "CANCELLED"
    },
    {
      "acceptance_ids": [],
      "agreement_id": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "FAILED",
      "incurred_cost_minor": 0,
      "independent_terms": {
        "break_even_value_minor": 7000,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5000,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 350,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 700,
            "minimum_payment_minor": 800,
            "participation_profit_minor": 100,
            "party_id": "BACKUP",
            "promised_payment_minor": 800,
            "rework_cost_minor": 350,
            "units": 100
          },
          {
            "base_cost_minor": 1900,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 3800,
            "minimum_payment_minor": 3900,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 3900,
            "rework_cost_minor": 1900,
            "units": 1800
          }
        ],
        "rework_budget_minor": 2250,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "PROPOSAL",
      "participant_decisions": [
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BACKUP",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "REJECTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-002",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 3900,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 800,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 5200,
        "cancellation_fee_minor": 0,
        "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
        "coordinator_fee_minor": 500,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-002",
        "rework_budget_minor": 2250,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "status": "REJECTED"
    },
    {
      "acceptance_ids": [],
      "agreement_id": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "FAILED",
      "incurred_cost_minor": 0,
      "independent_terms": {
        "break_even_value_minor": 7300,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5300,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 500,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 1000,
            "minimum_payment_minor": 1100,
            "participation_profit_minor": 100,
            "party_id": "COMPAT-A",
            "promised_payment_minor": 1100,
            "rework_cost_minor": 500,
            "units": 100
          },
          {
            "base_cost_minor": 1900,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 3800,
            "minimum_payment_minor": 3900,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 3900,
            "rework_cost_minor": 1900,
            "units": 1800
          }
        ],
        "rework_budget_minor": 2400,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "PROPOSAL",
      "participant_decisions": [
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COMPAT-A",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "REJECTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-003",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 3900,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 1100,
            "provider_id": "COMPAT-A",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 5500,
        "cancellation_fee_minor": 0,
        "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
        "coordinator_fee_minor": 500,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-003",
        "rework_budget_minor": 2400,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "status": "REJECTED"
    },
    {
      "acceptance_ids": [],
      "agreement_id": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "FAILED",
      "incurred_cost_minor": 0,
      "independent_terms": {
        "break_even_value_minor": 7400,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5400,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 750,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 1500,
            "minimum_payment_minor": 1600,
            "participation_profit_minor": 100,
            "party_id": "BACKUP",
            "promised_payment_minor": 1600,
            "rework_cost_minor": 750,
            "units": 300
          },
          {
            "base_cost_minor": 1700,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 3400,
            "minimum_payment_minor": 3500,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 3500,
            "rework_cost_minor": 1700,
            "units": 1600
          }
        ],
        "rework_budget_minor": 2450,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "PROPOSAL",
      "participant_decisions": [
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BACKUP",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "REJECTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-004",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 3500,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 1600,
            "provider_id": "BACKUP",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 5600,
        "cancellation_fee_minor": 0,
        "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
        "coordinator_fee_minor": 500,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-004",
        "rework_budget_minor": 2450,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "status": "REJECTED"
    },
    {
      "acceptance_ids": [],
      "agreement_id": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "FAILED",
      "incurred_cost_minor": 0,
      "independent_terms": {
        "break_even_value_minor": 7500,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5500,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 600,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 1200,
            "minimum_payment_minor": 1300,
            "participation_profit_minor": 100,
            "party_id": "COMPAT-B",
            "promised_payment_minor": 1300,
            "rework_cost_minor": 600,
            "units": 100
          },
          {
            "base_cost_minor": 1900,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 3800,
            "minimum_payment_minor": 3900,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 3900,
            "rework_cost_minor": 1900,
            "units": 1800
          }
        ],
        "rework_budget_minor": 2500,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "PROPOSAL",
      "participant_decisions": [
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COMPAT-B",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "REJECTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-005",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 3900,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 1300,
            "provider_id": "COMPAT-B",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 5700,
        "cancellation_fee_minor": 0,
        "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
        "coordinator_fee_minor": 500,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-005",
        "rework_budget_minor": 2500,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "status": "REJECTED"
    },
    {
      "acceptance_ids": [],
      "agreement_id": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "FAILED",
      "incurred_cost_minor": 0,
      "independent_terms": {
        "break_even_value_minor": 7600,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5600,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 950,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 1900,
            "minimum_payment_minor": 2000,
            "participation_profit_minor": 100,
            "party_id": "BACKUP",
            "promised_payment_minor": 2000,
            "rework_cost_minor": 950,
            "units": 400
          },
          {
            "base_cost_minor": 1600,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 3200,
            "minimum_payment_minor": 3300,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 3300,
            "rework_cost_minor": 1600,
            "units": 1500
          }
        ],
        "rework_budget_minor": 2550,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "PROPOSAL",
      "participant_decisions": [
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BACKUP",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "REJECTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-006",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 3300,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 2000,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 5800,
        "cancellation_fee_minor": 0,
        "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
        "coordinator_fee_minor": 500,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-006",
        "rework_budget_minor": 2550,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "status": "REJECTED"
    },
    {
      "acceptance_ids": [],
      "agreement_id": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "FAILED",
      "incurred_cost_minor": 0,
      "independent_terms": {
        "break_even_value_minor": 7800,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5800,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 1150,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 2300,
            "minimum_payment_minor": 2400,
            "participation_profit_minor": 100,
            "party_id": "BACKUP",
            "promised_payment_minor": 2400,
            "rework_cost_minor": 1150,
            "units": 500
          },
          {
            "base_cost_minor": 1500,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 3000,
            "minimum_payment_minor": 3100,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 3100,
            "rework_cost_minor": 1500,
            "units": 1400
          }
        ],
        "rework_budget_minor": 2650,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "PROPOSAL",
      "participant_decisions": [
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BACKUP",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "REJECTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-007",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 2400,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 3100,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 6000,
        "cancellation_fee_minor": 0,
        "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
        "coordinator_fee_minor": 500,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-007",
        "rework_budget_minor": 2650,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "status": "REJECTED"
    },
    {
      "acceptance_ids": [],
      "agreement_id": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "FAILED",
      "incurred_cost_minor": 0,
      "independent_terms": {
        "break_even_value_minor": 7800,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 5800,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 1150,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 2300,
            "minimum_payment_minor": 2400,
            "participation_profit_minor": 100,
            "party_id": "BACKUP",
            "promised_payment_minor": 2400,
            "rework_cost_minor": 1150,
            "units": 500
          },
          {
            "base_cost_minor": 1500,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 3000,
            "minimum_payment_minor": 3100,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 3100,
            "rework_cost_minor": 1500,
            "units": 1400
          }
        ],
        "rework_budget_minor": 2650,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "PROPOSAL",
      "participant_decisions": [
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "BACKUP",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "PROPOSAL_EXPIRED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "REJECTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-008",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 3100,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 2400,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 6000,
        "cancellation_fee_minor": 0,
        "contract_sha256": "6df2b886f683ec5e9495995aeca8ffc230ab239166cfbdb9a42d5a5828a29eb4",
        "coordinator_fee_minor": 500,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-008",
        "rework_budget_minor": 2650,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "status": "REJECTED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 1,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "UNFULFILLED",
      "produced_quantity": 500,
      "production_attempts": 1,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 500,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNFULFILLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 0
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "ac641085abef21c75d9f250ad072dee17e17f7de8b77876ce32739dfd4d0bb0b",
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30113,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 23325999,
    "controller_cpu_user_ns": 109743000,
    "cpu_system_ns": 97797000,
    "cpu_user_ns": 522381000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes; shared-host child CPU may include concurrent exercises",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 32,
    "retries": 0,
    "service_requests": 93,
    "storage_bytes": 3238475,
    "verification_labor_seconds": null,
    "wall_ns": 907052438,
    "worker_restarts": 0
  },
  "run_id": "deadline-expiry.873e1e6512",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 1,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 500,
    "production_attempts": 1,
    "received_quantity": 500,
    "recipient_accepted_quantity": 0,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 0,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 129185658,
    "evidence_files_read": 10,
    "wall_ns": 129193517
  },
  "verification_status": "COMPLETE",
  "verifier_version": "0.2.0"
}
```
