# CONTINUITY Ω Harness — Economy of continuity

**Digital-product experiment · version 0.2.0**

Preserve a promise through a viable, voluntarily accepted continuity arrangement.

**Scope: disposable local processes and a specified digital product. Authored synthetic policies, consent, values, funding and SMU cash flows are model inputs and observations. They do not establish real contracts, demand, payments, sales, printed goods, rendered appearance or print quality.**
**Checker qualification FAILED. A favorable target verdict in this adversarial observation is a challenged component claim, not qualified acceptance.**


This Passport presents the recorded assessment. Fresh verification must inspect retained authority, actual durable output and recipient evidence; this document is never its oracle.

<!-- structured-result-sha256: 9be78beb3be7d9b1e2214a947c7ccad8f672395225334ab5b1a6613118c3c937 -->

## Three distinct claims

| Claim | Recorded status |
| --- | --- |
| Required digital work accepted within the frozen conditions | Failed (`FAILED`) |
| Service feasibility under the authored synthetic model | Failed (`FAILED`) |
| Method advantage over competent alternatives | Not established (`NOT_ESTABLISHED`) |
| Safety within the exercised failure model | Failed (`FAILED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

## Assessment fields kept separate

| Field | Recorded value |
| --- | --- |
| Test assertion | Failed (`FAILED`) |
| Component verdict | Failed (`FAILED`) |
| Evidence stage | TARGETED_VERIFIER_MUTATION |
| Outcome claim status | Failed (`FAILED`) |

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

## Identity, authority and versions

| Field | Recorded value |
| --- | --- |
| Authority evidence status · `authority_status` | Established for the synthetic exercise only (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Real commercial value · `commercial_value` | Not established (`NOT_ESTABLISHED`) |
| Contract identity · `contract_id` | Not recorded |
| Retained contract SHA-256 · `contract_sha256` | 47b4f7037c4c80cd2eb0aba609b39ab9a3cfc3f684b911993616ef4d860f9de1 |
| Real customer authenticity · `real_customer_authenticity` | Not established (`NOT_ESTABLISHED`) |
| External reference pin · `reference_sha256` | bd6944a6f939ad360940ee3c550cdf353cf788fe79fe312c652a878dc5a02ade |
| Run identity · `run_id` | valid-digital-control.93af8c067e |
| Schema · `schema` | continuity-economy/verification/v1 |
| Verification completion status · `verification_status` | Complete verification (`COMPLETE`) |
| Verifier version · `verifier_version` | 0.2.0 |

## Per-obligation execution and acceptance

Counts describe the recorded stage. Rejected and corrected attempts remain distinct. A produced or received unit is not automatically accepted. Missing measurements are not displayed as zero.

| Obligation | Recipient | Revision | Required | Produced | Received | Rejected | Accepted within contract | Outcome |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 1100 | 1100 | 0 | 0 | Incorrect (`INCORRECT`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 800 | 800 | 0 | 0 | Unfulfilled (`UNFULFILLED`) |
| DL-300 | RECIPIENT-C | 1 | 100 | 0 | 0 | 0 | 0 | Cancelled (`CANCELLED`) |

### Obligation `DL-100`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 3 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 1100 |
| Obligation identity · `obligation_id` | DL-100 |
| Outcome · `outcome` | Incorrect (`INCORRECT`) |
| Produced quantity · `produced_quantity` | 1100 |
| Durable production attempts · `production_attempts` | 3 |
| Required quantity · `quantity` | 1100 |
| Reason codes · `reason_codes[0]` | FALSE_RECIPIENT_ACCEPTANCE |
| Reason codes · `reason_codes[1]` | IMPORTED_CONTENT_INCOMPLETE |
| Reason codes · `reason_codes[2]` | IMPORTED_CONTENT_MISMATCH |
| Received quantity · `received_quantity` | 1100 |
| Recipient · `recipient` | RECIPIENT-A |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 600 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 1100 |
| Revision · `revision` | 2 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 600 |

### Obligation `DL-200`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 2 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 800 |
| Obligation identity · `obligation_id` | DL-200 |
| Outcome · `outcome` | Unfulfilled (`UNFULFILLED`) |
| Produced quantity · `produced_quantity` | 800 |
| Durable production attempts · `production_attempts` | 2 |
| Required quantity · `quantity` | 800 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 800 |
| Recipient · `recipient` | RECIPIENT-B |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 800 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 800 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Active (`ACTIVE`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 800 |

### Obligation `DL-300`

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `accepted_quantity` | 0 |
| Logical deadline · `deadline_tick` | 500 |
| Delivery attempts · `delivery_attempts` | 0 |
| Late quantity · `late_quantity` | 0 |
| Missing quantity · `missing_quantity` | 0 |
| Obligation identity · `obligation_id` | DL-300 |
| Outcome · `outcome` | Cancelled (`CANCELLED`) |
| Produced quantity · `produced_quantity` | 0 |
| Durable production attempts · `production_attempts` | 0 |
| Required quantity · `quantity` | 100 |
| Reason codes · `reason_codes` | No entries |
| Received quantity · `received_quantity` | 0 |
| Recipient · `recipient` | RECIPIENT-C |
| Units accepted by the recipient component · `recipient_accepted_quantity` | 0 |
| Rejected quantity · `rejected_quantity` | 0 |
| Requested units in rejected deliveries · `rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `rejection_count` | 0 |
| Required quantity · `required_quantity` | 0 |
| Revision · `revision` | 1 |
| Recorded status · `status` | Cancelled (`CANCELLED`) |
| Semantically correct units observed in time · `timely_semantic_quantity` | 0 |

## Proposals, modeled decisions and arrangements

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

### Arrangement `proposal-001`

| Field | Recorded value |
| --- | --- |
| Acceptance references · `acceptance_ids[0]` | proposal-001.DL-100.L001.A1.D |
| Acceptance references · `acceptance_ids[1]` | proposal-001.DL-100.L002.A1.D |
| Acceptance references · `acceptance_ids[2]` | proposal-001.DL-100.L003.A1.D |
| Acceptance references · `acceptance_ids[3]` | proposal-001.DL-200.L001.A1.D |
| Acceptance references · `acceptance_ids[4]` | proposal-001.DL-200.L002.A1.D |
| Agreement acceptance tick · `accepted_tick` | 3 |
| Agreement identity · `agreement_id` | proposal-001 |
| Cancellation tick · `cancelled_tick` | Not recorded |
| Incurred correction cost (synthetic SMU) · `correction_cost_minor` | 0 |
| Modeled feasibility at agreement · `ex_ante_feasibility` | Demonstrated in scope (`DEMONSTRATED`) |
| Incurred cost (synthetic SMU) · `incurred_cost_minor` | 2200 |
| Break-even buyer value (synthetic SMU) · `independent_terms.break_even_value_minor` | 6400 |
| Buyer price ceiling at the lower value bound (synthetic SMU) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Buyer price ceiling at the upper value bound (synthetic SMU) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Synthetic accounting unit · `independent_terms.currency` | SMU |
| Minimum feasible buyer price (synthetic SMU) · `independent_terms.minimum_buyer_price_minor` | 4400 |
| Minimum coordinator fee (synthetic SMU) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Base production cost (synthetic SMU) · `independent_terms.providers[0].base_cost_minor` | 2000 |
| Modeled profit after maximum specified rework (synthetic SMU) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Maximum unpaid cost exposure (synthetic SMU) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 4000 |
| Minimum provider payment (synthetic SMU) · `independent_terms.providers[0].minimum_payment_minor` | 4100 |
| Required participation profit (synthetic SMU) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Participant identity · `independent_terms.providers[0].party_id` | PRIMARY |
| Promised provider payment (synthetic SMU) · `independent_terms.providers[0].promised_payment_minor` | 4100 |
| Maximum correction cost (synthetic SMU) · `independent_terms.providers[0].rework_cost_minor` | 2000 |
| Units · `independent_terms.providers[0].units` | 1900 |
| Correction reserve (synthetic SMU minor units) · `independent_terms.rework_budget_minor` | 2000 |
| Assessment scope · `independent_terms.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| Arrangement kind · `kind` | Modeled trade agreement (`TRADE`) |
| Stable code · `participant_decisions[0].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[0].party_id` | BUYER |
| Role · `participant_decisions[0].role` | buyer |
| Component verdict · `participant_decisions[0].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[1].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[1].party_id` | PRIMARY |
| Role · `participant_decisions[1].role` | provider |
| Component verdict · `participant_decisions[1].verdict` | Accepted (`ACCEPTED`) |
| Stable code · `participant_decisions[2].code` | Accepted (`ACCEPTED`) |
| Participant identity · `participant_decisions[2].party_id` | COORDINATOR |
| Role · `participant_decisions[2].role` | coordinator |
| Component verdict · `participant_decisions[2].verdict` | Accepted (`ACCEPTED`) |
| Modeled payments (synthetic SMU) · `payments_minor` | 4400 |
| Proposal identity · `proposal_id` | proposal-001 |
| First ordinal, inclusive · `proposed_terms.allocations[0].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[0].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Obligation identity · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[0].pay_minor` | 4100 |
| Provider identity · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[0].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[1].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[1].last_unit` | 1000 |
| Fixed lot identity · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Obligation identity · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[1].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[2].first_unit` | 1001 |
| Last ordinal, inclusive · `proposed_terms.allocations[2].last_unit` | 1100 |
| Fixed lot identity · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Obligation identity · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[2].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[3].first_unit` | 1 |
| Last ordinal, inclusive · `proposed_terms.allocations[3].last_unit` | 500 |
| Fixed lot identity · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Obligation identity · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[3].window_id` | W0 |
| First ordinal, inclusive · `proposed_terms.allocations[4].first_unit` | 501 |
| Last ordinal, inclusive · `proposed_terms.allocations[4].last_unit` | 800 |
| Fixed lot identity · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Obligation identity · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Provider payment (synthetic SMU minor units) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Provider identity · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Capacity-window identity · `proposed_terms.allocations[4].window_id` | W0 |
| Buyer price (synthetic SMU minor units) · `proposed_terms.buyer_price_minor` | 4400 |
| Cancellation liability (synthetic SMU minor units) · `proposed_terms.cancellation_fee_minor` | 0 |
| Retained contract SHA-256 · `proposed_terms.contract_sha256` | 47b4f7037c4c80cd2eb0aba609b39ab9a3cfc3f684b911993616ef4d860f9de1 |
| Coordinator fee (synthetic SMU minor units) · `proposed_terms.coordinator_fee_minor` | 300 |
| Exclusive expiry tick · `proposed_terms.expires_tick` | 500 |
| Policy revision · `proposed_terms.policy_revision` | 1 |
| Proposal identity · `proposed_terms.proposal_id` | proposal-001 |
| Correction reserve (synthetic SMU minor units) · `proposed_terms.rework_budget_minor` | 2000 |
| Schema · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Modeled feasibility after execution · `realized_feasibility` | Not established (`NOT_ESTABLISHED`) |
| Modeled settlement tick · `settled_tick` | 30 |
| Recorded status · `status` | Settled in the synthetic ledger (`SETTLED`) |

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.


## Modeled transfers, costs, liabilities and outside options

Model only: SMU are synthetic monetary minor units. Economic constraints and value intervals are authored assumptions. A positive modeled margin or policy decision does not establish real voluntary demand, payment or commercial advantage.

| Field | Recorded value |
| --- | --- |
| Total buyer transfers (synthetic SMU) · `accounting.buyer_total_paid_minor` | 4400 |
| Upper bound · `accounting.buyer_utility_interval_minor.maximum` | 25600 |
| Lower bound · `accounting.buyer_utility_interval_minor.minimum` | 25600 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[0].final_balance_minor` | 25600 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Modeled participation threshold covered · `accounting.campaign[0].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[0].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[0].party_id` | BUYER |
| Purchase transfers (synthetic SMU) · `accounting.campaign[0].purchase_payments_minor` | 4400 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[0].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU) · `accounting.campaign[0].revenue_minor` | 0 |
| Role · `accounting.campaign[0].role` | buyer |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[1].final_balance_minor` | 10100 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[1].incurred_cost_minor` | 200 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Modeled participation threshold covered · `accounting.campaign[1].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[1].participation_threshold_minor` | 100 |
| Participant identity · `accounting.campaign[1].party_id` | COORDINATOR |
| Purchase transfers (synthetic SMU) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[1].realized_profit_minor` | 100 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[1].revenue_minor` | 300 |
| Role · `accounting.campaign[1].role` | coordinator |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Modeled participation threshold covered · `accounting.campaign[2].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[2].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Purchase transfers (synthetic SMU) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[2].realized_profit_minor` | Not recorded |
| Modeled receipts (synthetic SMU) · `accounting.campaign[2].revenue_minor` | 0 |
| Role · `accounting.campaign[2].role` | technical_sponsor |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[3].final_balance_minor` | 42100 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[3].incurred_cost_minor` | 2000 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[3].participation_covered` | Yes |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[3].participation_threshold_minor` | 100 |
| Participant identity · `accounting.campaign[3].party_id` | PRIMARY |
| Purchase transfers (synthetic SMU) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[3].realized_profit_minor` | 2100 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[3].revenue_minor` | 4100 |
| Role · `accounting.campaign[3].role` | provider |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[4].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[4].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[4].party_id` | BACKUP |
| Purchase transfers (synthetic SMU) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[4].revenue_minor` | 0 |
| Role · `accounting.campaign[4].role` | provider |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[5].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[5].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[5].party_id` | COMPAT-A |
| Purchase transfers (synthetic SMU) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[5].revenue_minor` | 0 |
| Role · `accounting.campaign[5].role` | provider |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Final modeled balance (synthetic SMU) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Funds still encumbered (synthetic SMU) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Incurred cost (synthetic SMU) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Initial modeled balance (synthetic SMU) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Modeled participation threshold covered · `accounting.campaign[6].participation_covered` | Not recorded |
| Applicable participation threshold (synthetic SMU) · `accounting.campaign[6].participation_threshold_minor` | Not recorded |
| Participant identity · `accounting.campaign[6].party_id` | COMPAT-B |
| Purchase transfers (synthetic SMU) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Realized modeled profit (synthetic SMU) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Modeled receipts (synthetic SMU) · `accounting.campaign[6].revenue_minor` | 0 |
| Role · `accounting.campaign[6].role` | provider |
| Withdrawals to outside account (synthetic SMU) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Synthetic accounting unit · `accounting.currency` | SMU |
| Final ledger total (synthetic SMU) · `accounting.final_total_minor` | 260000 |
| Initial ledger total (synthetic SMU) · `accounting.initial_total_minor` | 260000 |
| Real contracts, payments or demand · `accounting.real_contracts_payments_or_demand` | Not established (`NOT_ESTABLISHED`) |
| Realized modeled buyer feasibility · `accounting.realized_buyer` | Demonstrated in scope (`DEMONSTRATED`) |
| Assessment scope · `accounting.scope` | Authored synthetic model (`AUTHORED_SYNTHETIC_MODEL`) |
| All correction costs (synthetic SMU) · `accounting.total_correction_cost_minor` | 0 |
| All incurred campaign costs (synthetic SMU) · `accounting.total_incurred_cost_minor` | 2200 |
| All modeled settlement transfers (synthetic SMU) · `accounting.total_transfers_minor` | 4400 |
| Modeled trade settled · `accounting.trade_settled` | Yes |
| Accepted obligations · `totals.accepted_obligations` | 0 |
| Accepted quantity within contract · `totals.accepted_quantity` | 0 |
| Delivery attempts · `totals.delivery_attempts` | 5 |
| Duplicate accepted units · `totals.duplicate_acceptances` | 0 |
| Late quantity · `totals.late_quantity` | 0 |
| Missing quantity · `totals.missing_quantity` | 1900 |
| Produced quantity · `totals.produced_quantity` | 1900 |
| Durable production attempts · `totals.production_attempts` | 5 |
| Received quantity · `totals.received_quantity` | 1900 |
| Units accepted by the recipient component · `totals.recipient_accepted_quantity` | 1400 |
| Rejected quantity · `totals.rejected_quantity` | 0 |
| Requested units in rejected deliveries · `totals.rejected_requested_quantity` | 0 |
| Rejected delivery attempts · `totals.rejection_count` | 0 |
| Required active obligations · `totals.required_obligations` | 2 |
| Required quantity · `totals.required_quantity` | 1900 |
| Semantically correct units observed in time · `totals.timely_semantic_quantity` | 1400 |
| Unsafe or unsupported commitments · `totals.unsafe_or_unsupported_commitments` | 3 |

## Measured resources and accounting gaps

Measured process resources and configured synthetic amounts have different meanings. Unrecorded preparation, integration, adaptation, verification or intervention effort remains unknown. Missing categories cannot support a complete-cost or cheaper-method conclusion.

| Field | Recorded value |
| --- | --- |
| Accounting gaps · `accounting_gaps[0]` | Preparation labor was not measured (`PREPARATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[1]` | Integration labor was not measured (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[2]` | Adaptation labor was not measured (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[3]` | Human verification labor was not measured (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Accounting gaps · `accounting_gaps[4]` | Monetary rates were not measured (`MONETARY_RATES_NOT_MEASURED`) |
| Adaptation labor (seconds; unknown if absent) · `resources.adaptation_labor_seconds` | Not recorded |
| Authority storage before sealing (bytes) · `resources.authority_storage_bytes_before_seal` | 30068 |
| Candidate restarts · `resources.candidate_restarts` | 0 |
| Launched child processes · `resources.child_processes` | 8 |
| Controller system CPU (ns) · `resources.controller_cpu_system_ns` | 45719000 |
| Controller user CPU (ns) · `resources.controller_cpu_user_ns` | 119699999 |
| System CPU (ns) · `resources.cpu_system_ns` | 101612000 |
| User CPU (ns) · `resources.cpu_user_ns` | 560075000 |
| Human interventions · `resources.human_interventions` | 0 |
| Integration labor (seconds; unknown if absent) · `resources.integration_labor_seconds` | Not recorded |
| Measurement boundary · `resources.measurement_scope` | Controller and child processes; child CPU accounting on a shared host may include concurrent exercises. |
| Measured real monetary cost · `resources.monetary_cost` | Not recorded |
| Peak resident memory (bytes) · `resources.peak_rss_bytes` | Not recorded |
| Preparation labor (seconds; unknown if absent) · `resources.preparation_labor_seconds` | Not recorded |
| Requests · `resources.requests` | 30 |
| Retries · `resources.retries` | 0 |
| Internal service requests · `resources.service_requests` | 158 |
| Recorded storage (bytes) · `resources.storage_bytes` | 8776610 |
| Human verification labor (seconds; unknown if absent) · `resources.verification_labor_seconds` | Not recorded |
| Wall duration (ns) · `resources.wall_ns` | 954532164 |
| Worker restarts · `resources.worker_restarts` | 0 |
| Process CPU (ns) · `verification_resources.cpu_ns` | 312960195 |
| Evidence files inspected · `verification_resources.evidence_files_read` | 22 |
| Wall duration (ns) · `verification_resources.wall_ns` | 313525495 |

## Observed failures and counterexamples

| Stable code | Scope | Obligation | Arrangement | Interpretation | Original technical locator |
| --- | --- | --- | --- | --- | --- |
| `EVIDENCE_CHANGED` | integrity | Not recorded | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `evidence/inbox/proposal-001.DL-100.L001.A1.D.json` |
| `EVIDENCE_CHANGED` | integrity | Not recorded | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `evidence/producer.sqlite` |
| `EVIDENCE_CHANGED` | integrity | Not recorded | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `evidence/products/proposal-001.DL-100.L001.A1.json` |
| `EVIDENCE_CHANGED` | integrity | Not recorded | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `evidence/receiver.sqlite` |
| `DATABASE_FINALIZATION_CHANGED` | integrity | Not recorded | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `evidence/receiver.sqlite` |
| `DATABASE_FINALIZATION_CHANGED` | integrity | Not recorded | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `evidence/producer.sqlite` |
| `FALSE_RECIPIENT_ACCEPTANCE` | safety | DL-100 | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `proposal-001.DL-100.L001.A1.D` |
| `IMPORTED_CONTENT_MISMATCH` | safety | DL-100 | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `proposal-001.DL-100.L001.A1.D` |
| `IMPORTED_CONTENT_INCOMPLETE` | outcome | DL-100 | Not recorded | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `` |
| `SETTLEMENT_WITHOUT_ACCEPTED_CONTENT` | safety | Not recorded | proposal-001 | The verifier recorded a contradiction for this check. Read the code and retained evidence before interpreting the component verdict. | `proposal-001` |

## Missing evidence and unresolved claims

No additional unresolved entry was recorded. Scope and unknown-cost limits still apply.

## Evidence references and byte integrity

Hashes identify bytes. They do not authenticate real customer instructions, establish source completeness, or replace an externally retained reference pin.

| Field | Recorded value |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json` | d37ac308826f095002b42355ccb06f10ebfcc77a8c8b95b6b59ba7f9ddbfcaa4 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L002.A1.json` | a649d317cb13e03f298de68b623fdda5ad77bb907ac0b32efc116b20650a2394 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L003.A1.json` | c097014180412562cb8ca8d2b76cb276fe8f9bf658bd88b4cd2815d536369cde |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-200.L001.A1.json` | 3a769fee21a81ec22dd9ed4cb1ba5624351668beea3745668bdaf6dc4908c0a0 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-200.L002.A1.json` | 7cc7a4a361529072a894d2d3d39c0cf0032544690c366f8313bf9c6663df44c5 |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 7cb825530a8a70dd8ff836ad97ab08906919a896f83267d631d9bd697054649d |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | 634614bf771fe458053d8a74e1e87dc72070b16e4a9888204e49bca8d41384ce |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | b79bbd01c11f81d18c8d3c2d2c1df6634cd3782409bd6e7de1ba2adb754a98cb |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | 7f88964dda5a947924424aa2faa8c762c8a59fef8a508586aba9a37ae3765be7 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L001.A1.D.json` | 119d6357f0fdfc3a20db56ef5d7efc67a92f26217100c49b919b8c9836f167cc |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L002.A1.D.json` | 04afff1b22a562a3bc05b3418874116a8a0475f374dcd8863ebc646cb49f18cc |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L003.A1.D.json` | 1387426d71abd76fa556c75fc654e6af112c7b859b9f67b8fe5e1050baa828be |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L001.A1.D.json` | 44e6ab429985bac30e4c2b9ea95589f69a7d68c835f93d14469ccdf8b6d28800 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L002.A1.D.json` | 938472eeddce19d0027e3efde3a7edabe086a2499c9c30f7449716e4f4690440 |
| `evidence_sha256.evidence/participants.sqlite` | 69f3b8dd1b2497d038e3fa9c745ab053b3746f0440558fb94b11786939a66109 |
| `evidence_sha256.evidence/producer.sqlite` | 63ef1bd33143a65b98174ef10df8e01dfbb922026df6490868fe84363a1cd6e2 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L001.A1.json` | 119d6357f0fdfc3a20db56ef5d7efc67a92f26217100c49b919b8c9836f167cc |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L002.A1.json` | 04afff1b22a562a3bc05b3418874116a8a0475f374dcd8863ebc646cb49f18cc |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L003.A1.json` | 1387426d71abd76fa556c75fc654e6af112c7b859b9f67b8fe5e1050baa828be |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L001.A1.json` | 44e6ab429985bac30e4c2b9ea95589f69a7d68c835f93d14469ccdf8b6d28800 |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L002.A1.json` | 938472eeddce19d0027e3efde3a7edabe086a2499c9c30f7449716e4f4690440 |
| `evidence_sha256.evidence/receiver.sqlite` | 3c62c8d349987c4a9028f5b78ca9ecb346cb1312e2ba84d47d1a0399df687b22 |
| Structured result SHA-256 · `structured_result_sha256` | 9be78beb3be7d9b1e2214a947c7ccad8f672395225334ab5b1a6613118c3c937 |

## Recorded execution, faults, commands and provenance

Stable identifiers, exact commands, paths and original machine diagnostics are retained literally. They are data, not additional acceptance evidence. Source and host trust remain explicit in the architecture and threat model.

| Field | Recorded value |
| --- | --- |
| `command[0]` | python |
| `command[1]` | -m |
| `command[2]` | continuity_economy |
| `command[3]` | challenge |
| `command[4]` | --out |
| `command[5]` | /workspace/scratch/b1d5891eb025/economy-verifier-development/attempt-1 |
| Registered fault schedule · `fault_schedule` | No entries |
| Actually observed faults · `faults_observed` | No entries |
| Uncommitted source changes present · `implementation.dirty` | Yes |
| Exact process arguments · `implementation.environment.argv[0]` | python |
| Exact process arguments · `implementation.environment.argv[1]` | - |
| Operating platform · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Python interpreter · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| SQLite version · `implementation.environment.sqlite_version` | 3.53.1 |
| Execution directory · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/continuity-economy |
| Actual source commit · `implementation.git_commit` | 0d7892130cf1696202e10fdd85bf8bd126c10fb3 |
| Preserved capacity implementation baseline · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048 |
| `implementation.source_sha256.continuity_economy/candidate.py` | f62fb5ac3421445264c7db9313af33b4d906c7c0026f75aa69b729d68c708320 |
| `implementation.source_sha256.continuity_economy/challenges.py` | f0480ce9f8e315ebbe41f727388c0c7458c18430e06f9a8470284b5d92c7a24f |
| `implementation.source_sha256.continuity_economy/controller.py` | 47caac93a7d431fc0badec2f726f1d508bc003d0281056b33f4616964df456e3 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2 |
| `implementation.source_sha256.continuity_economy/planning.py` | e006e6596794c0d86910cc7b406e317628f888bf912f2e5b31a9a88ab738c3bd |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b |
| `implementation.source_sha256.continuity_economy/producer.py` | e9ec94afc823dbadd9bae631cee7630489399a9038c01ccd48991ad67489b09a |
| `implementation.source_sha256.continuity_economy/receiver.py` | d192329fe254ed04194dc1680ac62e550204362b2da642235d13d607dc5975ff |
| `implementation.source_sha256.continuity_economy/reporting.py` | 653589d591c80d7b680c4ae702817fd1a2248d70ec32e821a08e94d9f945aa19 |
| `implementation.source_sha256.continuity_economy/schema.py` | dbf625ffd5300e7ac82ff5e857a0709647814eb8bd47e3fd9912c74bb78ed77f |
| `implementation.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `implementation.source_sha256.continuity_economy/verifier.py` | 2deff4885c565f7e8508984cd693648ba49c6693d15aa0c71926704daba0c16d |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Implementation version · `implementation.version` | 0.2.0 |
| External reference pin · `reference_sha256` | bd6944a6f939ad360940ee3c550cdf353cf788fe79fe312c652a878dc5a02ade |
| `registered_case.criterion` | FALSE_POSITIVE_MUTANT_EXPOSED |
| `registered_case.id` | mutant-ignores-semantic-content |
| Arrangement kind · `registered_case.kind` | verifier_mutation |
| `registered_case.mutation` | ignore_wrong_content |
| `registered_case.source` | wrong-content-resealed |
| `registration_sha256` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| Explicit trust assumptions · `trust_assumptions[0]` | Trusted host, kernel, controller and clock (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Explicit trust assumptions · `trust_assumptions[1]` | Trusted retained synthetic authority (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Explicit trust assumptions · `trust_assumptions[2]` | Shared authorship; no third-party certification (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Explicit trust assumptions · `trust_assumptions[3]` | Semantic digital content only; physical delivery is untested (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Registered faults not triggered · `untriggered_faults` | No entries |

## Adversarial observation and checker qualification

A passing test can correctly observe refusal, failure or insufficient evidence. It does not convert partial work into a complete promise. A passing adversarial test can expose a defective checker; its qualification must remain separate.

| Field | Recorded value |
| --- | --- |
| Accepted quantity within contract · `assertion.accepted_quantity` | 0 |
| Checker qualification · `assertion.checker_qualification` | Failed (`FAILED`) |
| `assertion.criterion` | FALSE_POSITIVE_MUTANT_EXPOSED |
| `assertion.finding_codes[0]` | DATABASE_FINALIZATION_CHANGED |
| `assertion.finding_codes[1]` | EVIDENCE_CHANGED |
| `assertion.finding_codes[2]` | FALSE_RECIPIENT_ACCEPTANCE |
| `assertion.finding_codes[3]` | IMPORTED_CONTENT_INCOMPLETE |
| `assertion.finding_codes[4]` | IMPORTED_CONTENT_MISMATCH |
| `assertion.finding_codes[5]` | SETTLEMENT_WITHOUT_ACCEPTED_CONTENT |
| `assertion.observed_outcome` | Failed (`FAILED`) |
| `assertion.observed_safety_status` | Failed (`FAILED`) |
| `assertion.observed_service_feasibility` | Failed (`FAILED`) |
| Recorded status · `assertion.status` | Failed (`FAILED`) |
| `assessed_claim` | CHECKER_QUALIFICATION |
| Checker qualification · `checker_qualification` | Failed (`FAILED`) |
| `criterion` | FALSE_POSITIVE_MUTANT_EXPOSED |
| `execution_reused_from` | wrong-content-resealed |
| `id` | mutant-ignores-semantic-content |
| Arrangement kind · `kind` | verifier_mutation |
| `observation_wall_ns` | 613596157 |
| Reference verdict · `reference_verdict` | Failed (`FAILED`) |
| Assessment scope · `scope` | REGISTERED_SYNTHETIC_CHALLENGE |
| Target verdict · `target_verdict` | Failed (`FAILED`) |

## Complete structured verification record

The same structured record generates both language versions. Machine keys, enum codes and literal evidence values remain unchanged; the localized sections above explain their meaning. No saved result is reused as fresh proof.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 4400,
    "buyer_utility_interval_minor": {
      "maximum": 25600,
      "minimum": 25600
    },
    "campaign": [
      {
        "final_balance_minor": 25600,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 4400,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 200,
        "initial_balance_minor": 10000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 100,
        "revenue_minor": 300,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 42100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 2000,
        "initial_balance_minor": 40000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 2100,
        "revenue_minor": 4100,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 2200,
    "total_transfers_minor": 4400,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "FAILED",
    "evidence_stage": "TARGETED_VERIFIER_MUTATION",
    "target_verdict": "FAILED",
    "test_assertion": "FAILED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "challenge": {
    "assertion": {
      "accepted_quantity": 0,
      "checker_qualification": "FAILED",
      "criterion": "FALSE_POSITIVE_MUTANT_EXPOSED",
      "finding_codes": [
        "DATABASE_FINALIZATION_CHANGED",
        "EVIDENCE_CHANGED",
        "FALSE_RECIPIENT_ACCEPTANCE",
        "IMPORTED_CONTENT_INCOMPLETE",
        "IMPORTED_CONTENT_MISMATCH",
        "SETTLEMENT_WITHOUT_ACCEPTED_CONTENT"
      ],
      "observed_outcome": "FAILED",
      "observed_safety_status": "FAILED",
      "observed_service_feasibility": "FAILED",
      "status": "FAILED"
    },
    "assessed_claim": "CHECKER_QUALIFICATION",
    "checker_qualification": "FAILED",
    "criterion": "FALSE_POSITIVE_MUTANT_EXPOSED",
    "execution_reused_from": "wrong-content-resealed",
    "id": "mutant-ignores-semantic-content",
    "kind": "verifier_mutation",
    "observation_wall_ns": 613596157,
    "reference_verdict": "FAILED",
    "scope": "REGISTERED_SYNTHETIC_CHALLENGE",
    "target_verdict": "FAILED"
  },
  "claims": {
    "checker_qualification": "FAILED",
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "FAILED",
    "service_feasibility": "FAILED"
  },
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "47b4f7037c4c80cd2eb0aba609b39ab9a3cfc3f684b911993616ef4d860f9de1",
  "evidence_sha256": {
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json": "d37ac308826f095002b42355ccb06f10ebfcc77a8c8b95b6b59ba7f9ddbfcaa4",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L002.A1.json": "a649d317cb13e03f298de68b623fdda5ad77bb907ac0b32efc116b20650a2394",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L003.A1.json": "c097014180412562cb8ca8d2b76cb276fe8f9bf658bd88b4cd2815d536369cde",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-200.L001.A1.json": "3a769fee21a81ec22dd9ed4cb1ba5624351668beea3745668bdaf6dc4908c0a0",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-200.L002.A1.json": "7cc7a4a361529072a894d2d3d39c0cf0032544690c366f8313bf9c6663df44c5",
    "evidence/capacity/BACKUP.W0.sqlite": "7cb825530a8a70dd8ff836ad97ab08906919a896f83267d631d9bd697054649d",
    "evidence/capacity/COMPAT-A.W0.sqlite": "634614bf771fe458053d8a74e1e87dc72070b16e4a9888204e49bca8d41384ce",
    "evidence/capacity/COMPAT-B.W0.sqlite": "b79bbd01c11f81d18c8d3c2d2c1df6634cd3782409bd6e7de1ba2adb754a98cb",
    "evidence/capacity/PRIMARY.W0.sqlite": "7f88964dda5a947924424aa2faa8c762c8a59fef8a508586aba9a37ae3765be7",
    "evidence/inbox/proposal-001.DL-100.L001.A1.D.json": "119d6357f0fdfc3a20db56ef5d7efc67a92f26217100c49b919b8c9836f167cc",
    "evidence/inbox/proposal-001.DL-100.L002.A1.D.json": "04afff1b22a562a3bc05b3418874116a8a0475f374dcd8863ebc646cb49f18cc",
    "evidence/inbox/proposal-001.DL-100.L003.A1.D.json": "1387426d71abd76fa556c75fc654e6af112c7b859b9f67b8fe5e1050baa828be",
    "evidence/inbox/proposal-001.DL-200.L001.A1.D.json": "44e6ab429985bac30e4c2b9ea95589f69a7d68c835f93d14469ccdf8b6d28800",
    "evidence/inbox/proposal-001.DL-200.L002.A1.D.json": "938472eeddce19d0027e3efde3a7edabe086a2499c9c30f7449716e4f4690440",
    "evidence/participants.sqlite": "69f3b8dd1b2497d038e3fa9c745ab053b3746f0440558fb94b11786939a66109",
    "evidence/producer.sqlite": "63ef1bd33143a65b98174ef10df8e01dfbb922026df6490868fe84363a1cd6e2",
    "evidence/products/proposal-001.DL-100.L001.A1.json": "119d6357f0fdfc3a20db56ef5d7efc67a92f26217100c49b919b8c9836f167cc",
    "evidence/products/proposal-001.DL-100.L002.A1.json": "04afff1b22a562a3bc05b3418874116a8a0475f374dcd8863ebc646cb49f18cc",
    "evidence/products/proposal-001.DL-100.L003.A1.json": "1387426d71abd76fa556c75fc654e6af112c7b859b9f67b8fe5e1050baa828be",
    "evidence/products/proposal-001.DL-200.L001.A1.json": "44e6ab429985bac30e4c2b9ea95589f69a7d68c835f93d14469ccdf8b6d28800",
    "evidence/products/proposal-001.DL-200.L002.A1.json": "938472eeddce19d0027e3efde3a7edabe086a2499c9c30f7449716e4f4690440",
    "evidence/receiver.sqlite": "3c62c8d349987c4a9028f5b78ca9ecb346cb1312e2ba84d47d1a0399df687b22"
  },
  "failures": [
    {
      "code": "EVIDENCE_CHANGED",
      "detail": "evidence/inbox/proposal-001.DL-100.L001.A1.D.json",
      "scope": "integrity"
    },
    {
      "code": "EVIDENCE_CHANGED",
      "detail": "evidence/producer.sqlite",
      "scope": "integrity"
    },
    {
      "code": "EVIDENCE_CHANGED",
      "detail": "evidence/products/proposal-001.DL-100.L001.A1.json",
      "scope": "integrity"
    },
    {
      "code": "EVIDENCE_CHANGED",
      "detail": "evidence/receiver.sqlite",
      "scope": "integrity"
    },
    {
      "code": "DATABASE_FINALIZATION_CHANGED",
      "detail": "evidence/receiver.sqlite",
      "scope": "integrity"
    },
    {
      "code": "DATABASE_FINALIZATION_CHANGED",
      "detail": "evidence/producer.sqlite",
      "scope": "integrity"
    },
    {
      "code": "FALSE_RECIPIENT_ACCEPTANCE",
      "detail": "proposal-001.DL-100.L001.A1.D",
      "obligation_id": "DL-100",
      "scope": "safety"
    },
    {
      "code": "IMPORTED_CONTENT_MISMATCH",
      "detail": "proposal-001.DL-100.L001.A1.D",
      "obligation_id": "DL-100",
      "scope": "safety"
    },
    {
      "code": "IMPORTED_CONTENT_INCOMPLETE",
      "detail": "",
      "obligation_id": "DL-100",
      "scope": "outcome"
    },
    {
      "arrangement_id": "proposal-001",
      "code": "SETTLEMENT_WITHOUT_ACCEPTED_CONTENT",
      "detail": "proposal-001",
      "scope": "safety"
    }
  ],
  "fault_schedule": [],
  "faults_observed": [],
  "implementation": {
    "dirty": true,
    "environment": {
      "argv": [
        "python",
        "-"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/continuity-economy"
    },
    "git_commit": "0d7892130cf1696202e10fdd85bf8bd126c10fb3",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048",
      "continuity_economy/candidate.py": "f62fb5ac3421445264c7db9313af33b4d906c7c0026f75aa69b729d68c708320",
      "continuity_economy/challenges.py": "f0480ce9f8e315ebbe41f727388c0c7458c18430e06f9a8470284b5d92c7a24f",
      "continuity_economy/controller.py": "47caac93a7d431fc0badec2f726f1d508bc003d0281056b33f4616964df456e3",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2",
      "continuity_economy/planning.py": "e006e6596794c0d86910cc7b406e317628f888bf912f2e5b31a9a88ab738c3bd",
      "continuity_economy/policy_schema.py": "b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b",
      "continuity_economy/producer.py": "e9ec94afc823dbadd9bae631cee7630489399a9038c01ccd48991ad67489b09a",
      "continuity_economy/receiver.py": "d192329fe254ed04194dc1680ac62e550204362b2da642235d13d607dc5975ff",
      "continuity_economy/reporting.py": "653589d591c80d7b680c4ae702817fd1a2248d70ec32e821a08e94d9f945aa19",
      "continuity_economy/schema.py": "dbf625ffd5300e7ac82ff5e857a0709647814eb8bd47e3fd9912c74bb78ed77f",
      "continuity_economy/suite.py": "1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3",
      "continuity_economy/verifier.py": "2deff4885c565f7e8508984cd693648ba49c6693d15aa0c71926704daba0c16d",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b"
    },
    "version": "0.2.0"
  },
  "per_arrangement": [
    {
      "acceptance_ids": [
        "proposal-001.DL-100.L001.A1.D",
        "proposal-001.DL-100.L002.A1.D",
        "proposal-001.DL-100.L003.A1.D",
        "proposal-001.DL-200.L001.A1.D",
        "proposal-001.DL-200.L002.A1.D"
      ],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 2200,
      "independent_terms": {
        "break_even_value_minor": 6400,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 4400,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 2000,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 4000,
            "minimum_payment_minor": 4100,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 4100,
            "rework_cost_minor": 2000,
            "units": 1900
          }
        ],
        "rework_budget_minor": 2000,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 4400,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 4100,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 4400,
        "cancellation_fee_minor": 0,
        "contract_sha256": "47b4f7037c4c80cd2eb0aba609b39ab9a3cfc3f684b911993616ef4d860f9de1",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2000,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "NOT_ESTABLISHED",
      "settled_tick": 30,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "INCORRECT",
      "produced_quantity": 1100,
      "production_attempts": 3,
      "quantity": 1100,
      "reason_codes": [
        "FALSE_RECIPIENT_ACCEPTANCE",
        "IMPORTED_CONTENT_INCOMPLETE",
        "IMPORTED_CONTENT_MISMATCH"
      ],
      "received_quantity": 1100,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 600,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 600
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNFULFILLED",
      "produced_quantity": 800,
      "production_attempts": 2,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 800,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 800,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 800
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "bd6944a6f939ad360940ee3c550cdf353cf788fe79fe312c652a878dc5a02ade",
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30068,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 45719000,
    "controller_cpu_user_ns": 119699999,
    "cpu_system_ns": 101612000,
    "cpu_user_ns": 560075000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes; shared-host child CPU may include concurrent exercises",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 30,
    "retries": 0,
    "service_requests": 158,
    "storage_bytes": 8776610,
    "verification_labor_seconds": null,
    "wall_ns": 954532164,
    "worker_restarts": 0
  },
  "run_id": "valid-digital-control.93af8c067e",
  "safety_status": "FAILED",
  "schema": "continuity-economy/verification/v1",
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 5,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 1900,
    "production_attempts": 5,
    "received_quantity": 1900,
    "recipient_accepted_quantity": 1400,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 1400,
    "unsafe_or_unsupported_commitments": 3
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 312960195,
    "evidence_files_read": 22,
    "wall_ns": 313525495
  },
  "verification_status": "COMPLETE",
  "verifier_version": "0.2.0"
}
```
