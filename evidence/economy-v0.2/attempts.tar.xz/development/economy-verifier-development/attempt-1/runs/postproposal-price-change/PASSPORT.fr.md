# CONTINUITÉ Ω — Économie de la continuité

**Expérience de produit numérique · version 0.2.0**

Préserver un engagement grâce à une solution de continuité viable et volontairement acceptée.

**Portée : processus locaux jetables et produit numérique spécifié. Les politiques, consentements, valeurs, financements et flux SMU synthétiques sont des hypothèses et observations du modèle. Ils n’établissent ni contrats réels, ni demande, paiements, ventes, biens imprimés, apparence rendue ou qualité d’impression.**

Ce passeport présente l’évaluation consignée. Une vérification fraîche doit inspecter l’autorité conservée, le résultat durable réel et les preuves du destinataire ; ce document ne constitue jamais son oracle.

<!-- structured-result-sha256: 734ab8904eef009929215d2080d1172910686cf1ad1dd579c74ed7cdca2cf4b1 -->

## Trois affirmations distinctes

| Affirmation | État consigné |
| --- | --- |
| Travail numérique requis accepté dans les conditions figées | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Faisabilité du service selon le modèle synthétique défini | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Avantage de méthode face à des solutions compétentes | Non établi (`NOT_ESTABLISHED`) |
| Sûreté dans le modèle de défaillance éprouvé | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

## Champs d’évaluation distincts

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | Réussi (`PASSED`) |
| Verdict du composant | Réalisé (`COMPLETED`) |
| Stade de preuve | Exécution locale d’un produit numérique (`LOCAL_DIGITAL_PRODUCT_EXECUTION`) |
| État de l’affirmation de résultat | Démontré dans la portée déclarée (`DEMONSTRATED`) |

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

## Identité, autorité et versions

| Champ | Valeur consignée |
| --- | --- |
| État des preuves d’autorité · `authority_status` | Établi uniquement pour l’exercice synthétique (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Valeur commerciale réelle · `commercial_value` | Non établi (`NOT_ESTABLISHED`) |
| Identité du contrat · `contract_id` | Non consigné |
| SHA-256 du contrat conservé · `contract_sha256` | 1376f84b392ab2a63faee55fe97fa47641f8dd2c64264197ffd8e220c5bba6e6 |
| Authenticité d’un client réel · `real_customer_authenticity` | Non établi (`NOT_ESTABLISHED`) |
| Empreinte externe de référence · `reference_sha256` | 26e9ff9a7de8bdbedae39556a52ee40ac2a815b420894fd95d0ade962d7ddc23 |
| Identité de l’exécution · `run_id` | postproposal-price-change.b7419f39c4 |
| Schéma · `schema` | continuity-economy/verification/v1 |
| État d’achèvement de la vérification · `verification_status` | Vérification complète (`COMPLETE`) |
| Version du vérificateur · `verifier_version` | 0.2.0 |

## Exécution et acceptation par obligation

Les quantités décrivent le stade consigné. Les tentatives refusées et corrigées restent distinctes. Une unité produite ou reçue n’est pas automatiquement acceptée. Les mesures absentes ne sont pas présentées comme nulles.

| Obligation | Destinataire | Révision | Requis | Produit | Reçu | Refusé | Accepté selon le contrat | Résultat |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 1100 | 1100 | 0 | 1100 | Réalisé (`COMPLETED`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 800 | 800 | 0 | 800 | Réalisé (`COMPLETED`) |
| DL-300 | RECIPIENT-C | 1 | 100 | 0 | 0 | 0 | 0 | Annulé (`CANCELLED`) |

### Obligation `DL-100`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 1100 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 3 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-100 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 1100 |
| Tentatives de production durables · `production_attempts` | 3 |
| Quantité requise · `quantity` | 1100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 1100 |
| Destinataire · `recipient` | RECIPIENT-A |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 1100 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 1100 |
| Révision · `revision` | 2 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 1100 |

### Obligation `DL-200`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 800 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 2 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-200 |
| Résultat · `outcome` | Réalisé (`COMPLETED`) |
| Quantité produite · `produced_quantity` | 800 |
| Tentatives de production durables · `production_attempts` | 2 |
| Quantité requise · `quantity` | 800 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 800 |
| Destinataire · `recipient` | RECIPIENT-B |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 800 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 800 |
| Révision · `revision` | 1 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 800 |

### Obligation `DL-300`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-300 |
| Résultat · `outcome` | Annulé (`CANCELLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-C |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 0 |
| Révision · `revision` | 1 |
| État consigné · `status` | Annulé (`CANCELLED`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

## Propositions, décisions modélisées et solutions

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

### Solution `proposal-001`

| Champ | Valeur consignée |
| --- | --- |
| Références d’acceptation · `acceptance_ids` | Aucune entrée |
| Identité de l’accord · `agreement_id` | Non consigné |
| Coût de correction engagé (SMU synthétiques) · `correction_cost_minor` | 0 |
| Faisabilité modélisée au moment de l’accord · `ex_ante_feasibility` | Échec (`FAILED`) |
| Coût engagé (SMU synthétiques) · `incurred_cost_minor` | 0 |
| Valeur d’équilibre de l’acheteur (SMU synthétiques) · `independent_terms.break_even_value_minor` | 192600 |
| Plafond acheteur à la borne de valeur inférieure (SMU synthétiques) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Plafond acheteur à la borne de valeur supérieure (SMU synthétiques) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Unité de compte synthétique · `independent_terms.currency` | SMU |
| Prix acheteur minimal réalisable (SMU synthétiques) · `independent_terms.minimum_buyer_price_minor` | 190600 |
| Rémunération minimale du coordonnateur (SMU synthétiques) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Coût de production initiale (SMU synthétiques) · `independent_terms.providers[0].base_cost_minor` | 188200 |
| Profit modélisé après correction maximale spécifiée (SMU synthétiques) · `independent_terms.providers[0].guaranteed_profit_minor` | -186100 |
| Exposition maximale aux coûts impayés (SMU synthétiques) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 190200 |
| Paiement minimal au fournisseur (SMU synthétiques) · `independent_terms.providers[0].minimum_payment_minor` | 190300 |
| Profit requis de participation (SMU synthétiques) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Identité du participant · `independent_terms.providers[0].party_id` | PRIMARY |
| Paiement promis au fournisseur (SMU synthétiques) · `independent_terms.providers[0].promised_payment_minor` | 4100 |
| Coût maximal de correction (SMU synthétiques) · `independent_terms.providers[0].rework_cost_minor` | 2000 |
| Unités · `independent_terms.providers[0].units` | 1900 |
| Réserve de correction (unités mineures SMU synthétiques) · `independent_terms.rework_budget_minor` | 2000 |
| Portée de l’évaluation · `independent_terms.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Nature de la solution · `kind` | PROPOSAL |
| Code stable · `participant_decisions[0].code` | POLICY_REVISION_MISMATCH |
| Identité du participant · `participant_decisions[0].party_id` | BUYER |
| Rôle · `participant_decisions[0].role` | buyer |
| Verdict du composant · `participant_decisions[0].verdict` | Refusé (`REJECTED`) |
| Code stable · `participant_decisions[1].code` | POLICY_REVISION_MISMATCH |
| Identité du participant · `participant_decisions[1].party_id` | PRIMARY |
| Rôle · `participant_decisions[1].role` | provider |
| Verdict du composant · `participant_decisions[1].verdict` | Refusé (`REJECTED`) |
| Code stable · `participant_decisions[2].code` | POLICY_REVISION_MISMATCH |
| Identité du participant · `participant_decisions[2].party_id` | COORDINATOR |
| Rôle · `participant_decisions[2].role` | coordinator |
| Verdict du composant · `participant_decisions[2].verdict` | Refusé (`REJECTED`) |
| Paiements modélisés (SMU synthétiques) · `payments_minor` | 0 |
| Identité de la proposition · `proposal_id` | proposal-001 |
| Premier ordinal inclus · `proposed_terms.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[0].last_unit` | 500 |
| Identité du lot fixe · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[0].pay_minor` | 4100 |
| Identité du fournisseur · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[1].first_unit` | 501 |
| Dernier ordinal inclus · `proposed_terms.allocations[1].last_unit` | 1000 |
| Identité du lot fixe · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[2].first_unit` | 1001 |
| Dernier ordinal inclus · `proposed_terms.allocations[2].last_unit` | 1100 |
| Identité du lot fixe · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Identité de l’obligation · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[3].last_unit` | 500 |
| Identité du lot fixe · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Identité de l’obligation · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[3].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[4].first_unit` | 501 |
| Dernier ordinal inclus · `proposed_terms.allocations[4].last_unit` | 800 |
| Identité du lot fixe · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Identité de l’obligation · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[4].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `proposed_terms.buyer_price_minor` | 4400 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `proposed_terms.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `proposed_terms.contract_sha256` | 1376f84b392ab2a63faee55fe97fa47641f8dd2c64264197ffd8e220c5bba6e6 |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `proposed_terms.coordinator_fee_minor` | 300 |
| Instant exclusif d’expiration · `proposed_terms.expires_tick` | 500 |
| Révision des politiques · `proposed_terms.policy_revision` | 1 |
| Identité de la proposition · `proposed_terms.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `proposed_terms.rework_budget_minor` | 2000 |
| Schéma · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Faisabilité modélisée après exécution · `realized_feasibility` | Échec (`FAILED`) |
| État consigné · `status` | Refusé (`REJECTED`) |

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

### Solution `proposal-002`

| Champ | Valeur consignée |
| --- | --- |
| Références d’acceptation · `acceptance_ids[0]` | proposal-002.DL-100.L001.A1.D |
| Références d’acceptation · `acceptance_ids[1]` | proposal-002.DL-100.L002.A1.D |
| Références d’acceptation · `acceptance_ids[2]` | proposal-002.DL-100.L003.A1.D |
| Références d’acceptation · `acceptance_ids[3]` | proposal-002.DL-200.L001.A1.D |
| Références d’acceptation · `acceptance_ids[4]` | proposal-002.DL-200.L002.A1.D |
| Instant d’acceptation de l’accord · `accepted_tick` | 7 |
| Identité de l’accord · `agreement_id` | proposal-002 |
| Instant d’annulation · `cancelled_tick` | Non consigné |
| Coût de correction engagé (SMU synthétiques) · `correction_cost_minor` | 0 |
| Faisabilité modélisée au moment de l’accord · `ex_ante_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Coût engagé (SMU synthétiques) · `incurred_cost_minor` | 4150 |
| Valeur d’équilibre de l’acheteur (SMU synthétiques) · `independent_terms.break_even_value_minor` | 10300 |
| Plafond acheteur à la borne de valeur inférieure (SMU synthétiques) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Plafond acheteur à la borne de valeur supérieure (SMU synthétiques) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Unité de compte synthétique · `independent_terms.currency` | SMU |
| Prix acheteur minimal réalisable (SMU synthétiques) · `independent_terms.minimum_buyer_price_minor` | 8300 |
| Rémunération minimale du coordonnateur (SMU synthétiques) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Coût de production initiale (SMU synthétiques) · `independent_terms.providers[0].base_cost_minor` | 3950 |
| Profit modélisé après correction maximale spécifiée (SMU synthétiques) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Exposition maximale aux coûts impayés (SMU synthétiques) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 7900 |
| Paiement minimal au fournisseur (SMU synthétiques) · `independent_terms.providers[0].minimum_payment_minor` | 8000 |
| Profit requis de participation (SMU synthétiques) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Identité du participant · `independent_terms.providers[0].party_id` | BACKUP |
| Paiement promis au fournisseur (SMU synthétiques) · `independent_terms.providers[0].promised_payment_minor` | 8000 |
| Coût maximal de correction (SMU synthétiques) · `independent_terms.providers[0].rework_cost_minor` | 3950 |
| Unités · `independent_terms.providers[0].units` | 1900 |
| Réserve de correction (unités mineures SMU synthétiques) · `independent_terms.rework_budget_minor` | 3950 |
| Portée de l’évaluation · `independent_terms.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Nature de la solution · `kind` | Accord d’échange modélisé (`TRADE`) |
| Code stable · `participant_decisions[0].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[0].party_id` | BUYER |
| Rôle · `participant_decisions[0].role` | buyer |
| Verdict du composant · `participant_decisions[0].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[1].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[1].party_id` | BACKUP |
| Rôle · `participant_decisions[1].role` | provider |
| Verdict du composant · `participant_decisions[1].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[2].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[2].party_id` | COORDINATOR |
| Rôle · `participant_decisions[2].role` | coordinator |
| Verdict du composant · `participant_decisions[2].verdict` | Accepté (`ACCEPTED`) |
| Paiements modélisés (SMU synthétiques) · `payments_minor` | 8300 |
| Identité de la proposition · `proposal_id` | proposal-002 |
| Premier ordinal inclus · `proposed_terms.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[0].last_unit` | 500 |
| Identité du lot fixe · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[0].pay_minor` | 8000 |
| Identité du fournisseur · `proposed_terms.allocations[0].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[1].first_unit` | 501 |
| Dernier ordinal inclus · `proposed_terms.allocations[1].last_unit` | 1000 |
| Identité du lot fixe · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[1].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[2].first_unit` | 1001 |
| Dernier ordinal inclus · `proposed_terms.allocations[2].last_unit` | 1100 |
| Identité du lot fixe · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Identité de l’obligation · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[2].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[3].last_unit` | 500 |
| Identité du lot fixe · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Identité de l’obligation · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[3].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[3].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[4].first_unit` | 501 |
| Dernier ordinal inclus · `proposed_terms.allocations[4].last_unit` | 800 |
| Identité du lot fixe · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Identité de l’obligation · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[4].provider_id` | BACKUP |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[4].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `proposed_terms.buyer_price_minor` | 8300 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `proposed_terms.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `proposed_terms.contract_sha256` | 1376f84b392ab2a63faee55fe97fa47641f8dd2c64264197ffd8e220c5bba6e6 |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `proposed_terms.coordinator_fee_minor` | 300 |
| Instant exclusif d’expiration · `proposed_terms.expires_tick` | 500 |
| Révision des politiques · `proposed_terms.policy_revision` | 2 |
| Identité de la proposition · `proposed_terms.proposal_id` | proposal-002 |
| Réserve de correction (unités mineures SMU synthétiques) · `proposed_terms.rework_budget_minor` | 3950 |
| Schéma · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Faisabilité modélisée après exécution · `realized_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Instant de règlement modélisé · `settled_tick` | 33 |
| État consigné · `status` | Réglé dans le registre synthétique (`SETTLED`) |

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.


## Transferts, coûts, responsabilités et options externes modélisés

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

| Champ | Valeur consignée |
| --- | --- |
| Total des transferts acheteur (SMU synthétiques) · `accounting.buyer_total_paid_minor` | 8300 |
| Borne supérieure · `accounting.buyer_utility_interval_minor.maximum` | 21700 |
| Borne inférieure · `accounting.buyer_utility_interval_minor.minimum` | 21700 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[0].final_balance_minor` | 21700 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Seuil de participation modélisé couvert · `accounting.campaign[0].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[0].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[0].party_id` | BUYER |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[0].purchase_payments_minor` | 8300 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[0].realized_profit_minor` | Non consigné |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[0].revenue_minor` | 0 |
| Rôle · `accounting.campaign[0].role` | buyer |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[1].final_balance_minor` | 10100 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[1].incurred_cost_minor` | 200 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Seuil de participation modélisé couvert · `accounting.campaign[1].participation_covered` | Oui |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[1].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[1].party_id` | COORDINATOR |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[1].realized_profit_minor` | 100 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[1].revenue_minor` | 300 |
| Rôle · `accounting.campaign[1].role` | coordinator |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Seuil de participation modélisé couvert · `accounting.campaign[2].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[2].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[2].realized_profit_minor` | Non consigné |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[2].revenue_minor` | 0 |
| Rôle · `accounting.campaign[2].role` | technical_sponsor |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[3].final_balance_minor` | 40000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[3].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[3].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[3].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[3].party_id` | PRIMARY |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[3].realized_profit_minor` | 0 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[3].revenue_minor` | 0 |
| Rôle · `accounting.campaign[3].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[4].final_balance_minor` | 44050 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[4].incurred_cost_minor` | 3950 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[4].participation_covered` | Oui |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[4].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[4].party_id` | BACKUP |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[4].realized_profit_minor` | 4050 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[4].revenue_minor` | 8000 |
| Rôle · `accounting.campaign[4].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[5].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[5].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[5].party_id` | COMPAT-A |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[5].revenue_minor` | 0 |
| Rôle · `accounting.campaign[5].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[6].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[6].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[6].party_id` | COMPAT-B |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[6].revenue_minor` | 0 |
| Rôle · `accounting.campaign[6].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Unité de compte synthétique · `accounting.currency` | SMU |
| Total final du registre (SMU synthétiques) · `accounting.final_total_minor` | 260000 |
| Total initial du registre (SMU synthétiques) · `accounting.initial_total_minor` | 260000 |
| Contrats, paiements ou demande réels · `accounting.real_contracts_payments_or_demand` | Non établi (`NOT_ESTABLISHED`) |
| Faisabilité modélisée réalisée pour l’acheteur · `accounting.realized_buyer` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Portée de l’évaluation · `accounting.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Tous les coûts de correction (SMU synthétiques) · `accounting.total_correction_cost_minor` | 0 |
| Tous les coûts engagés de campagne (SMU synthétiques) · `accounting.total_incurred_cost_minor` | 4150 |
| Tous les transferts de règlement modélisés (SMU synthétiques) · `accounting.total_transfers_minor` | 8300 |
| Transaction modélisée réglée · `accounting.trade_settled` | Oui |
| Obligations acceptées · `totals.accepted_obligations` | 2 |
| Quantité acceptée selon le contrat · `totals.accepted_quantity` | 1900 |
| Tentatives de livraison · `totals.delivery_attempts` | 5 |
| Unités acceptées en double · `totals.duplicate_acceptances` | 0 |
| Quantité tardive · `totals.late_quantity` | 0 |
| Quantité manquante · `totals.missing_quantity` | 0 |
| Quantité produite · `totals.produced_quantity` | 1900 |
| Tentatives de production durables · `totals.production_attempts` | 5 |
| Quantité reçue · `totals.received_quantity` | 1900 |
| Unités acceptées par le composant destinataire · `totals.recipient_accepted_quantity` | 1900 |
| Quantité refusée · `totals.rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `totals.rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `totals.rejection_count` | 0 |
| Obligations actives requises · `totals.required_obligations` | 2 |
| Quantité requise · `totals.required_quantity` | 1900 |
| Unités sémantiquement correctes observées à temps · `totals.timely_semantic_quantity` | 1900 |
| Engagements non sûrs ou non autorisés · `totals.unsafe_or_unsupported_commitments` | 0 |

## Ressources mesurées et lacunes de comptabilisation

Les ressources de processus mesurées et les montants synthétiques configurés ont des significations différentes. Les efforts de préparation, d’intégration, d’adaptation, de vérification ou d’intervention non consignés restent inconnus. Les catégories absentes ne permettent aucune conclusion de coût complet ou de méthode moins coûteuse.

| Champ | Valeur consignée |
| --- | --- |
| Lacunes de comptabilisation · `accounting_gaps[0]` | Le travail de préparation n’a pas été mesuré (`PREPARATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[1]` | Le travail d’intégration n’a pas été mesuré (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[2]` | Le travail d’adaptation n’a pas été mesuré (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[3]` | Le travail humain de vérification n’a pas été mesuré (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[4]` | Les tarifs monétaires n’ont pas été mesurés (`MONETARY_RATES_NOT_MEASURED`) |
| Travail d’adaptation (secondes ; inconnu si absent) · `resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `resources.authority_storage_bytes_before_seal` | 30200 |
| Redémarrages du candidat · `resources.candidate_restarts` | 0 |
| Processus enfants lancés · `resources.child_processes` | 8 |
| Processeur système du contrôleur (ns) · `resources.controller_cpu_system_ns` | 23273999 |
| Processeur utilisateur du contrôleur (ns) · `resources.controller_cpu_user_ns` | 145185000 |
| Processeur système (ns) · `resources.cpu_system_ns` | 96413000 |
| Processeur utilisateur (ns) · `resources.cpu_user_ns` | 619957999 |
| Interventions humaines · `resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `resources.measurement_scope` | Contrôleur et processus enfants ; leur mesure processeur sur un hôte partagé peut inclure des exercices concurrents. |
| Coût monétaire réel mesuré · `resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `resources.requests` | 32 |
| Nouvelles tentatives · `resources.retries` | 0 |
| Requêtes internes aux services · `resources.service_requests` | 162 |
| Stockage consigné (octets) · `resources.storage_bytes` | 8780852 |
| Travail humain de vérification (secondes ; inconnu si absent) · `resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `resources.wall_ns` | 1068377427 |
| Redémarrages des services · `resources.worker_restarts` | 0 |
| Temps processeur (ns) · `verification_resources.cpu_ns` | 208354426 |
| Fichiers de preuve examinés · `verification_resources.evidence_files_read` | 22 |
| Durée écoulée (ns) · `verification_resources.wall_ns` | 208385118 |

## Échecs et contre-exemples observés

Aucune entrée d’échec n’a été consignée dans cette évaluation. Il s’agit de preuves bornées, non d’une démonstration générale.

## Preuves absentes et affirmations non établies

Aucune entrée non résolue supplémentaire n’a été consignée. Les limites de portée et de coûts inconnus restent applicables.

## Références des preuves et intégrité des octets

Les empreintes identifient les octets. Elles n’authentifient pas les instructions réelles d’un client, n’établissent pas l’exhaustivité des sources et ne remplacent pas une empreinte de référence conservée séparément.

| Champ | Valeur consignée |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-100.L001.A1.json` | e8b6e49241b5256cd6dfea5b95e111b6937c6da9a54399579efd79e067560ebc |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-100.L002.A1.json` | a1a6bdc52cace95fab9e86663684bcc24eec5fa05bb8e2ea66dd6d1759c394cf |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-100.L003.A1.json` | ffb3e14bf5f179ef3270cfb0b7b793d20147ffa0c145047c92ebfa68cb7194bc |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-200.L001.A1.json` | 988511b6571ff9655454239feec8595556c61c53477292e2aa253a189d4dc017 |
| `evidence_sha256.evidence/capacity-artifacts/BACKUP.W0/DL-200.L002.A1.json` | 70222909210935330c6acb31eeffda8efc7e6512a7e4fec882a40d878ee6bfa3 |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 5e3dd3d7cba8a51d27477a68e3c13b220233a3c71bd2cc95060b41e1f44e0811 |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | ca1161cf60d087441fa831836050fc5c1f09faa5a4f174e5a51b924dca3da1f4 |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | 0db6cea8796451b754ec014c592b33292afcb92f8529f996f9903f451c0193ba |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | faf537078a70d2f46568ff821faf9045ec9d9cabcd13fdc03d8a4fc331a99637 |
| `evidence_sha256.evidence/inbox/proposal-002.DL-100.L001.A1.D.json` | c521c4c1edb37c628508aa0f3d434fc0db8af959bcfc261fb6bf318a39cce307 |
| `evidence_sha256.evidence/inbox/proposal-002.DL-100.L002.A1.D.json` | 2e2eb5597ed96f2721c750cecfb46467e8ffa4b88e3c36d5b0b09c7754ce22ec |
| `evidence_sha256.evidence/inbox/proposal-002.DL-100.L003.A1.D.json` | 51aa6fe6b479a16d0f22a3c9f4d8ba328ff292a8c7647689fbbdcf622b98e95c |
| `evidence_sha256.evidence/inbox/proposal-002.DL-200.L001.A1.D.json` | ee0efa27fa502b0e13beb870dce063f9f3aed084b8acb55ab1bb014ff3949c35 |
| `evidence_sha256.evidence/inbox/proposal-002.DL-200.L002.A1.D.json` | ba2d6b65dc1545d678fa266bbcc3676e65ca944f76cd4e11a79456f2665b3fa0 |
| `evidence_sha256.evidence/participants.sqlite` | a3f352d451be542c2cbae14568cdb226013a881f8f364a5c1d72d2816625f6d6 |
| `evidence_sha256.evidence/producer.sqlite` | 722262809442d2174effdc5910d979e56a31b84defa2c50d0414202becaaedf9 |
| `evidence_sha256.evidence/products/proposal-002.DL-100.L001.A1.json` | c521c4c1edb37c628508aa0f3d434fc0db8af959bcfc261fb6bf318a39cce307 |
| `evidence_sha256.evidence/products/proposal-002.DL-100.L002.A1.json` | 2e2eb5597ed96f2721c750cecfb46467e8ffa4b88e3c36d5b0b09c7754ce22ec |
| `evidence_sha256.evidence/products/proposal-002.DL-100.L003.A1.json` | 51aa6fe6b479a16d0f22a3c9f4d8ba328ff292a8c7647689fbbdcf622b98e95c |
| `evidence_sha256.evidence/products/proposal-002.DL-200.L001.A1.json` | ee0efa27fa502b0e13beb870dce063f9f3aed084b8acb55ab1bb014ff3949c35 |
| `evidence_sha256.evidence/products/proposal-002.DL-200.L002.A1.json` | ba2d6b65dc1545d678fa266bbcc3676e65ca944f76cd4e11a79456f2665b3fa0 |
| `evidence_sha256.evidence/receiver.sqlite` | 6c6772371e1b626f8df2297a1e9b741aadd4af3849b860c267ccc328fdf73d22 |
| SHA-256 du résultat structuré · `structured_result_sha256` | 734ab8904eef009929215d2080d1172910686cf1ad1dd579c74ed7cdca2cf4b1 |

## Exécution, pannes, commandes et provenance consignées

Les identifiants stables, commandes exactes, chemins et diagnostics machine originaux sont conservés littéralement. Ce sont des données, non des preuves d’acceptation supplémentaires. La confiance dans les sources et l’hôte est explicitée dans l’architecture et le modèle de menace.

| Champ | Valeur consignée |
| --- | --- |
| `command[0]` | python |
| `command[1]` | -m |
| `command[2]` | continuity_economy |
| `command[3]` | challenge |
| `command[4]` | --out |
| `command[5]` | /workspace/scratch/b1d5891eb025/economy-verifier-development/attempt-1 |
| Événement consigné · `fault_schedule[0].event` | Modification de politique après proposition (`POLICY_CHANGE_AFTER_PROPOSE`) |
| Occurrence déclenchante · `fault_schedule[0].occurrence` | 1 |
| Cible de la panne · `fault_schedule[0].target` | PRIMARY |
| Opération déclenchante · `fault_schedule[0].trigger` | propose |
| Valeur configurée · `fault_schedule[0].value` | 99 |
| Événement consigné · `faults_observed[0].event` | Modification de politique après proposition (`POLICY_CHANGE_AFTER_PROPOSE`) |
| Occurrence déclenchante · `faults_observed[0].occurrence` | 1 |
| Cible de la panne · `faults_observed[0].target` | PRIMARY |
| Opération déclenchante · `faults_observed[0].trigger` | propose |
| Valeur configurée · `faults_observed[0].value` | 99 |
| Modifications sources non consignées présentes · `implementation.dirty` | Oui |
| Arguments exacts du processus · `implementation.environment.argv[0]` | python |
| Arguments exacts du processus · `implementation.environment.argv[1]` | - |
| Plateforme d’exécution · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/continuity-economy |
| Commit source effectif · `implementation.git_commit` | 0d7892130cf1696202e10fdd85bf8bd126c10fb3 |
| Base conservée de l’implémentation de capacité · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048 |
| `implementation.source_sha256.continuity_economy/candidate.py` | f62fb5ac3421445264c7db9313af33b4d906c7c0026f75aa69b729d68c708320 |
| `implementation.source_sha256.continuity_economy/challenges.py` | f0480ce9f8e315ebbe41f727388c0c7458c18430e06f9a8470284b5d92c7a24f |
| `implementation.source_sha256.continuity_economy/controller.py` | 47caac93a7d431fc0badec2f726f1d508bc003d0281056b33f4616964df456e3 |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2 |
| `implementation.source_sha256.continuity_economy/planning.py` | e006e6596794c0d86910cc7b406e317628f888bf912f2e5b31a9a88ab738c3bd |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b |
| `implementation.source_sha256.continuity_economy/producer.py` | e9ec94afc823dbadd9bae631cee7630489399a9038c01ccd48991ad67489b09a |
| `implementation.source_sha256.continuity_economy/receiver.py` | d192329fe254ed04194dc1680ac62e550204362b2da642235d13d607dc5975ff |
| `implementation.source_sha256.continuity_economy/reporting.py` | 653589d591c80d7b680c4ae702817fd1a2248d70ec32e821a08e94d9f945aa19 |
| `implementation.source_sha256.continuity_economy/schema.py` | dbf625ffd5300e7ac82ff5e857a0709647814eb8bd47e3fd9912c74bb78ed77f |
| `implementation.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `implementation.source_sha256.continuity_economy/verifier.py` | 2deff4885c565f7e8508984cd693648ba49c6693d15aa0c71926704daba0c16d |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Version d’implémentation · `implementation.version` | 0.2.0 |
| Empreinte externe de référence · `reference_sha256` | 26e9ff9a7de8bdbedae39556a52ee40ac2a815b420894fd95d0ade962d7ddc23 |
| `registered_case.criterion` | POLICY_REVISION_RECHECKED |
| Événement consigné · `registered_case.fault.event` | Modification de politique après proposition (`POLICY_CHANGE_AFTER_PROPOSE`) |
| Occurrence déclenchante · `registered_case.fault.occurrence` | 1 |
| Cible de la panne · `registered_case.fault.target` | PRIMARY |
| Opération déclenchante · `registered_case.fault.trigger` | propose |
| Valeur configurée · `registered_case.fault.value` | 99 |
| `registered_case.fixture` | primary-recovery |
| `registered_case.id` | postproposal-price-change |
| Nature de la solution · `registered_case.kind` | live |
| `registration_sha256` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| Hypothèses de confiance explicites · `trust_assumptions[0]` | Hôte, noyau, contrôleur et horloge de confiance (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Hypothèses de confiance explicites · `trust_assumptions[1]` | Autorité synthétique conservée de confiance (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Hypothèses de confiance explicites · `trust_assumptions[2]` | Auteur commun ; aucune certification par un tiers (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Hypothèses de confiance explicites · `trust_assumptions[3]` | Contenu numérique sémantique uniquement ; livraison physique non éprouvée (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Pannes préenregistrées non déclenchées · `untriggered_faults` | Aucune entrée |

## Observation contradictoire et qualification du vérificateur

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `assertion.accepted_quantity` | 1900 |
| Qualification du vérificateur · `assertion.checker_qualification` | NOT_APPLICABLE |
| `assertion.criterion` | POLICY_REVISION_RECHECKED |
| `assertion.finding_codes` | Aucune entrée |
| `assertion.observed_outcome` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `assertion.observed_safety_status` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| `assertion.observed_service_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| État consigné · `assertion.status` | Réussi (`PASSED`) |
| `criterion` | POLICY_REVISION_RECHECKED |
| `execution_reused_from` | Non consigné |
| `id` | postproposal-price-change |
| Nature de la solution · `kind` | live |
| `observation_wall_ns` | 1296347759 |
| Portée de l’évaluation · `scope` | REGISTERED_SYNTHETIC_CHALLENGE |

## Enregistrement structuré complet de vérification

Le même enregistrement structuré génère les deux versions linguistiques. Les clés machine, codes d’état et valeurs littérales des preuves restent inchangés ; les sections localisées ci-dessus expliquent leur sens. Aucun résultat sauvegardé n’est réutilisé comme preuve fraîche.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 8300,
    "buyer_utility_interval_minor": {
      "maximum": 21700,
      "minimum": 21700
    },
    "campaign": [
      {
        "final_balance_minor": 21700,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 8300,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 200,
        "initial_balance_minor": 10000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 100,
        "revenue_minor": 300,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 44050,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 3950,
        "initial_balance_minor": 40000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 4050,
        "revenue_minor": 8000,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 4150,
    "total_transfers_minor": 8300,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "DEMONSTRATED",
    "evidence_stage": "LOCAL_DIGITAL_PRODUCT_EXECUTION",
    "target_verdict": "COMPLETED",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "challenge": {
    "assertion": {
      "accepted_quantity": 1900,
      "checker_qualification": "NOT_APPLICABLE",
      "criterion": "POLICY_REVISION_RECHECKED",
      "finding_codes": [],
      "observed_outcome": "DEMONSTRATED",
      "observed_safety_status": "DEMONSTRATED",
      "observed_service_feasibility": "DEMONSTRATED",
      "status": "PASSED"
    },
    "criterion": "POLICY_REVISION_RECHECKED",
    "execution_reused_from": null,
    "id": "postproposal-price-change",
    "kind": "live",
    "observation_wall_ns": 1296347759,
    "scope": "REGISTERED_SYNTHETIC_CHALLENGE"
  },
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "DEMONSTRATED",
    "service_feasibility": "DEMONSTRATED"
  },
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "1376f84b392ab2a63faee55fe97fa47641f8dd2c64264197ffd8e220c5bba6e6",
  "evidence_sha256": {
    "evidence/capacity-artifacts/BACKUP.W0/DL-100.L001.A1.json": "e8b6e49241b5256cd6dfea5b95e111b6937c6da9a54399579efd79e067560ebc",
    "evidence/capacity-artifacts/BACKUP.W0/DL-100.L002.A1.json": "a1a6bdc52cace95fab9e86663684bcc24eec5fa05bb8e2ea66dd6d1759c394cf",
    "evidence/capacity-artifacts/BACKUP.W0/DL-100.L003.A1.json": "ffb3e14bf5f179ef3270cfb0b7b793d20147ffa0c145047c92ebfa68cb7194bc",
    "evidence/capacity-artifacts/BACKUP.W0/DL-200.L001.A1.json": "988511b6571ff9655454239feec8595556c61c53477292e2aa253a189d4dc017",
    "evidence/capacity-artifacts/BACKUP.W0/DL-200.L002.A1.json": "70222909210935330c6acb31eeffda8efc7e6512a7e4fec882a40d878ee6bfa3",
    "evidence/capacity/BACKUP.W0.sqlite": "5e3dd3d7cba8a51d27477a68e3c13b220233a3c71bd2cc95060b41e1f44e0811",
    "evidence/capacity/COMPAT-A.W0.sqlite": "ca1161cf60d087441fa831836050fc5c1f09faa5a4f174e5a51b924dca3da1f4",
    "evidence/capacity/COMPAT-B.W0.sqlite": "0db6cea8796451b754ec014c592b33292afcb92f8529f996f9903f451c0193ba",
    "evidence/capacity/PRIMARY.W0.sqlite": "faf537078a70d2f46568ff821faf9045ec9d9cabcd13fdc03d8a4fc331a99637",
    "evidence/inbox/proposal-002.DL-100.L001.A1.D.json": "c521c4c1edb37c628508aa0f3d434fc0db8af959bcfc261fb6bf318a39cce307",
    "evidence/inbox/proposal-002.DL-100.L002.A1.D.json": "2e2eb5597ed96f2721c750cecfb46467e8ffa4b88e3c36d5b0b09c7754ce22ec",
    "evidence/inbox/proposal-002.DL-100.L003.A1.D.json": "51aa6fe6b479a16d0f22a3c9f4d8ba328ff292a8c7647689fbbdcf622b98e95c",
    "evidence/inbox/proposal-002.DL-200.L001.A1.D.json": "ee0efa27fa502b0e13beb870dce063f9f3aed084b8acb55ab1bb014ff3949c35",
    "evidence/inbox/proposal-002.DL-200.L002.A1.D.json": "ba2d6b65dc1545d678fa266bbcc3676e65ca944f76cd4e11a79456f2665b3fa0",
    "evidence/participants.sqlite": "a3f352d451be542c2cbae14568cdb226013a881f8f364a5c1d72d2816625f6d6",
    "evidence/producer.sqlite": "722262809442d2174effdc5910d979e56a31b84defa2c50d0414202becaaedf9",
    "evidence/products/proposal-002.DL-100.L001.A1.json": "c521c4c1edb37c628508aa0f3d434fc0db8af959bcfc261fb6bf318a39cce307",
    "evidence/products/proposal-002.DL-100.L002.A1.json": "2e2eb5597ed96f2721c750cecfb46467e8ffa4b88e3c36d5b0b09c7754ce22ec",
    "evidence/products/proposal-002.DL-100.L003.A1.json": "51aa6fe6b479a16d0f22a3c9f4d8ba328ff292a8c7647689fbbdcf622b98e95c",
    "evidence/products/proposal-002.DL-200.L001.A1.json": "ee0efa27fa502b0e13beb870dce063f9f3aed084b8acb55ab1bb014ff3949c35",
    "evidence/products/proposal-002.DL-200.L002.A1.json": "ba2d6b65dc1545d678fa266bbcc3676e65ca944f76cd4e11a79456f2665b3fa0",
    "evidence/receiver.sqlite": "6c6772371e1b626f8df2297a1e9b741aadd4af3849b860c267ccc328fdf73d22"
  },
  "failures": [],
  "fault_schedule": [
    {
      "event": "POLICY_CHANGE_AFTER_PROPOSE",
      "occurrence": 1,
      "target": "PRIMARY",
      "trigger": "propose",
      "value": 99
    }
  ],
  "faults_observed": [
    {
      "event": "POLICY_CHANGE_AFTER_PROPOSE",
      "occurrence": 1,
      "target": "PRIMARY",
      "trigger": "propose",
      "value": 99
    }
  ],
  "implementation": {
    "dirty": true,
    "environment": {
      "argv": [
        "python",
        "-"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/continuity-economy"
    },
    "git_commit": "0d7892130cf1696202e10fdd85bf8bd126c10fb3",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048",
      "continuity_economy/candidate.py": "f62fb5ac3421445264c7db9313af33b4d906c7c0026f75aa69b729d68c708320",
      "continuity_economy/challenges.py": "f0480ce9f8e315ebbe41f727388c0c7458c18430e06f9a8470284b5d92c7a24f",
      "continuity_economy/controller.py": "47caac93a7d431fc0badec2f726f1d508bc003d0281056b33f4616964df456e3",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2",
      "continuity_economy/planning.py": "e006e6596794c0d86910cc7b406e317628f888bf912f2e5b31a9a88ab738c3bd",
      "continuity_economy/policy_schema.py": "b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b",
      "continuity_economy/producer.py": "e9ec94afc823dbadd9bae631cee7630489399a9038c01ccd48991ad67489b09a",
      "continuity_economy/receiver.py": "d192329fe254ed04194dc1680ac62e550204362b2da642235d13d607dc5975ff",
      "continuity_economy/reporting.py": "653589d591c80d7b680c4ae702817fd1a2248d70ec32e821a08e94d9f945aa19",
      "continuity_economy/schema.py": "dbf625ffd5300e7ac82ff5e857a0709647814eb8bd47e3fd9912c74bb78ed77f",
      "continuity_economy/suite.py": "1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3",
      "continuity_economy/verifier.py": "2deff4885c565f7e8508984cd693648ba49c6693d15aa0c71926704daba0c16d",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b"
    },
    "version": "0.2.0"
  },
  "per_arrangement": [
    {
      "acceptance_ids": [],
      "agreement_id": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "FAILED",
      "incurred_cost_minor": 0,
      "independent_terms": {
        "break_even_value_minor": 192600,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 190600,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 188200,
            "guaranteed_profit_minor": -186100,
            "maximum_unpaid_cost_exposure_minor": 190200,
            "minimum_payment_minor": 190300,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 4100,
            "rework_cost_minor": 2000,
            "units": 1900
          }
        ],
        "rework_budget_minor": 2000,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "PROPOSAL",
      "participant_decisions": [
        {
          "code": "POLICY_REVISION_MISMATCH",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "REJECTED"
        },
        {
          "code": "POLICY_REVISION_MISMATCH",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "REJECTED"
        },
        {
          "code": "POLICY_REVISION_MISMATCH",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "REJECTED"
        }
      ],
      "payments_minor": 0,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 4100,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 4400,
        "cancellation_fee_minor": 0,
        "contract_sha256": "1376f84b392ab2a63faee55fe97fa47641f8dd2c64264197ffd8e220c5bba6e6",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2000,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "FAILED",
      "status": "REJECTED"
    },
    {
      "acceptance_ids": [
        "proposal-002.DL-100.L001.A1.D",
        "proposal-002.DL-100.L002.A1.D",
        "proposal-002.DL-100.L003.A1.D",
        "proposal-002.DL-200.L001.A1.D",
        "proposal-002.DL-200.L002.A1.D"
      ],
      "accepted_tick": 7,
      "agreement_id": "proposal-002",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 4150,
      "independent_terms": {
        "break_even_value_minor": 10300,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 8300,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 3950,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 7900,
            "minimum_payment_minor": 8000,
            "participation_profit_minor": 100,
            "party_id": "BACKUP",
            "promised_payment_minor": 8000,
            "rework_cost_minor": 3950,
            "units": 1900
          }
        ],
        "rework_budget_minor": 3950,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "BACKUP",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 8300,
      "proposal_id": "proposal-002",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 8000,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "BACKUP",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 8300,
        "cancellation_fee_minor": 0,
        "contract_sha256": "1376f84b392ab2a63faee55fe97fa47641f8dd2c64264197ffd8e220c5bba6e6",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 2,
        "proposal_id": "proposal-002",
        "rework_budget_minor": 3950,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "DEMONSTRATED",
      "settled_tick": 33,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 1100,
      "deadline_tick": 500,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-100",
      "outcome": "COMPLETED",
      "produced_quantity": 1100,
      "production_attempts": 3,
      "quantity": 1100,
      "reason_codes": [],
      "received_quantity": 1100,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 1100,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 1100
    },
    {
      "accepted_quantity": 800,
      "deadline_tick": 500,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-200",
      "outcome": "COMPLETED",
      "produced_quantity": 800,
      "production_attempts": 2,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 800,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 800,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 800
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "26e9ff9a7de8bdbedae39556a52ee40ac2a815b420894fd95d0ade962d7ddc23",
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30200,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 23273999,
    "controller_cpu_user_ns": 145185000,
    "cpu_system_ns": 96413000,
    "cpu_user_ns": 619957999,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes; shared-host child CPU may include concurrent exercises",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 32,
    "retries": 0,
    "service_requests": 162,
    "storage_bytes": 8780852,
    "verification_labor_seconds": null,
    "wall_ns": 1068377427,
    "worker_restarts": 0
  },
  "run_id": "postproposal-price-change.b7419f39c4",
  "safety_status": "DEMONSTRATED",
  "schema": "continuity-economy/verification/v1",
  "totals": {
    "accepted_obligations": 2,
    "accepted_quantity": 1900,
    "delivery_attempts": 5,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 0,
    "produced_quantity": 1900,
    "production_attempts": 5,
    "received_quantity": 1900,
    "recipient_accepted_quantity": 1900,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 1900,
    "unsafe_or_unsupported_commitments": 0
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 208354426,
    "evidence_files_read": 22,
    "wall_ns": 208385118
  },
  "verification_status": "COMPLETE",
  "verifier_version": "0.2.0"
}
```
