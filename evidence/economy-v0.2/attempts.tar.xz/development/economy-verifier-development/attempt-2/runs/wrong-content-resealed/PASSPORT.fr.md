# CONTINUITÉ Ω — Économie de la continuité

**Expérience de produit numérique · version 0.2.0**

Préserver un engagement grâce à une solution de continuité viable et volontairement acceptée.

**Portée : processus locaux jetables et produit numérique spécifié. Les politiques, consentements, valeurs, financements et flux SMU synthétiques sont des hypothèses et observations du modèle. Ils n’établissent ni contrats réels, ni demande, paiements, ventes, biens imprimés, apparence rendue ou qualité d’impression.**

Ce passeport présente l’évaluation consignée. Une vérification fraîche doit inspecter l’autorité conservée, le résultat durable réel et les preuves du destinataire ; ce document ne constitue jamais son oracle.

<!-- structured-result-sha256: dc8038a8f8e588a05b35ccf4f7dacc7199e60d92a38dfa92bb1805f3c6656bac -->

## Trois affirmations distinctes

| Affirmation | État consigné |
| --- | --- |
| Travail numérique requis accepté dans les conditions figées | Échec (`FAILED`) |
| Faisabilité du service selon le modèle synthétique défini | Échec (`FAILED`) |
| Avantage de méthode face à des solutions compétentes | Non établi (`NOT_ESTABLISHED`) |
| Sûreté dans le modèle de défaillance éprouvé | Échec (`FAILED`) |

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

## Champs d’évaluation distincts

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | Réussi (`PASSED`) |
| Verdict du composant | Réalisé (`COMPLETED`) |
| Stade de preuve | EVIDENCE_INTEGRITY_CHALLENGE |
| État de l’affirmation de résultat | Échec (`FAILED`) |

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

## Identité, autorité et versions

| Champ | Valeur consignée |
| --- | --- |
| État des preuves d’autorité · `authority_status` | Établi uniquement pour l’exercice synthétique (`ESTABLISHED_FOR_SYNTHETIC_EXERCISE`) |
| Valeur commerciale réelle · `commercial_value` | Non établi (`NOT_ESTABLISHED`) |
| Identité du contrat · `contract_id` | Non consigné |
| SHA-256 du contrat conservé · `contract_sha256` | d13ae681bd7294bf00b6f379885f6c507bb1dc5eb52cc6ee742616de39c7cd0f |
| Authenticité d’un client réel · `real_customer_authenticity` | Non établi (`NOT_ESTABLISHED`) |
| Empreinte externe de référence · `reference_sha256` | c37a14b818a0a333bba5947e247eebd2169b86bdb5455b41a46d3c7c996f0e6d |
| Identité de l’exécution · `run_id` | valid-digital-control.cf541410a8 |
| Schéma · `schema` | continuity-economy/verification/v1 |
| État d’achèvement de la vérification · `verification_status` | Vérification complète (`COMPLETE`) |
| Version du vérificateur · `verifier_version` | 0.2.0 |

## Exécution et acceptation par obligation

Les quantités décrivent le stade consigné. Les tentatives refusées et corrigées restent distinctes. Une unité produite ou reçue n’est pas automatiquement acceptée. Les mesures absentes ne sont pas présentées comme nulles.

| Obligation | Destinataire | Révision | Requis | Produit | Reçu | Refusé | Accepté selon le contrat | Résultat |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| DL-100 | RECIPIENT-A | 2 | 1100 | 1100 | 1100 | 0 | 0 | Incorrect (`INCORRECT`) |
| DL-200 | RECIPIENT-B | 1 | 800 | 800 | 800 | 0 | 0 | Non réalisé (`UNFULFILLED`) |
| DL-300 | RECIPIENT-C | 1 | 0 | 0 | 0 | 0 | 0 | Annulé (`CANCELLED`) |

### Obligation `DL-100`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 3 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 1100 |
| Identité de l’obligation · `obligation_id` | DL-100 |
| Résultat · `outcome` | Incorrect (`INCORRECT`) |
| Quantité produite · `produced_quantity` | 1100 |
| Tentatives de production durables · `production_attempts` | 3 |
| Quantité requise · `quantity` | 1100 |
| Codes de justification · `reason_codes[0]` | FALSE_RECIPIENT_ACCEPTANCE |
| Codes de justification · `reason_codes[1]` | IMPORTED_CONTENT_INCOMPLETE |
| Codes de justification · `reason_codes[2]` | IMPORTED_CONTENT_MISMATCH |
| Quantité reçue · `received_quantity` | 1100 |
| Destinataire · `recipient` | RECIPIENT-A |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 600 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 1100 |
| Révision · `revision` | 2 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 600 |

### Obligation `DL-200`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 2 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 800 |
| Identité de l’obligation · `obligation_id` | DL-200 |
| Résultat · `outcome` | Non réalisé (`UNFULFILLED`) |
| Quantité produite · `produced_quantity` | 800 |
| Tentatives de production durables · `production_attempts` | 2 |
| Quantité requise · `quantity` | 800 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 800 |
| Destinataire · `recipient` | RECIPIENT-B |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 800 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 800 |
| Révision · `revision` | 1 |
| État consigné · `status` | Actif (`ACTIVE`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 800 |

### Obligation `DL-300`

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `accepted_quantity` | 0 |
| Échéance logique · `deadline_tick` | 500 |
| Tentatives de livraison · `delivery_attempts` | 0 |
| Quantité tardive · `late_quantity` | 0 |
| Quantité manquante · `missing_quantity` | 0 |
| Identité de l’obligation · `obligation_id` | DL-300 |
| Résultat · `outcome` | Annulé (`CANCELLED`) |
| Quantité produite · `produced_quantity` | 0 |
| Tentatives de production durables · `production_attempts` | 0 |
| Quantité requise · `quantity` | 100 |
| Codes de justification · `reason_codes` | Aucune entrée |
| Quantité reçue · `received_quantity` | 0 |
| Destinataire · `recipient` | RECIPIENT-C |
| Unités acceptées par le composant destinataire · `recipient_accepted_quantity` | 0 |
| Quantité refusée · `rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `rejection_count` | 0 |
| Quantité requise · `required_quantity` | 0 |
| Révision · `revision` | 1 |
| État consigné · `status` | Annulé (`CANCELLED`) |
| Unités sémantiquement correctes observées à temps · `timely_semantic_quantity` | 0 |

## Propositions, décisions modélisées et solutions

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

### Solution `proposal-001`

| Champ | Valeur consignée |
| --- | --- |
| Références d’acceptation · `acceptance_ids[0]` | proposal-001.DL-100.L001.A1.D |
| Références d’acceptation · `acceptance_ids[1]` | proposal-001.DL-100.L002.A1.D |
| Références d’acceptation · `acceptance_ids[2]` | proposal-001.DL-100.L003.A1.D |
| Références d’acceptation · `acceptance_ids[3]` | proposal-001.DL-200.L001.A1.D |
| Références d’acceptation · `acceptance_ids[4]` | proposal-001.DL-200.L002.A1.D |
| Instant d’acceptation de l’accord · `accepted_tick` | 3 |
| Identité de l’accord · `agreement_id` | proposal-001 |
| Instant d’annulation · `cancelled_tick` | Non consigné |
| Coût de correction engagé (SMU synthétiques) · `correction_cost_minor` | 0 |
| Faisabilité modélisée au moment de l’accord · `ex_ante_feasibility` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Coût engagé (SMU synthétiques) · `incurred_cost_minor` | 2200 |
| Valeur d’équilibre de l’acheteur (SMU synthétiques) · `independent_terms.break_even_value_minor` | 6400 |
| Plafond acheteur à la borne de valeur inférieure (SMU synthétiques) · `independent_terms.buyer_definite_max_price_minor` | 25000 |
| Plafond acheteur à la borne de valeur supérieure (SMU synthétiques) · `independent_terms.buyer_possible_max_price_minor` | 25000 |
| Unité de compte synthétique · `independent_terms.currency` | SMU |
| Prix acheteur minimal réalisable (SMU synthétiques) · `independent_terms.minimum_buyer_price_minor` | 4400 |
| Rémunération minimale du coordonnateur (SMU synthétiques) · `independent_terms.minimum_coordinator_fee_minor` | 300 |
| Coût de production initiale (SMU synthétiques) · `independent_terms.providers[0].base_cost_minor` | 2000 |
| Profit modélisé après correction maximale spécifiée (SMU synthétiques) · `independent_terms.providers[0].guaranteed_profit_minor` | 100 |
| Exposition maximale aux coûts impayés (SMU synthétiques) · `independent_terms.providers[0].maximum_unpaid_cost_exposure_minor` | 4000 |
| Paiement minimal au fournisseur (SMU synthétiques) · `independent_terms.providers[0].minimum_payment_minor` | 4100 |
| Profit requis de participation (SMU synthétiques) · `independent_terms.providers[0].participation_profit_minor` | 100 |
| Identité du participant · `independent_terms.providers[0].party_id` | PRIMARY |
| Paiement promis au fournisseur (SMU synthétiques) · `independent_terms.providers[0].promised_payment_minor` | 4100 |
| Coût maximal de correction (SMU synthétiques) · `independent_terms.providers[0].rework_cost_minor` | 2000 |
| Unités · `independent_terms.providers[0].units` | 1900 |
| Réserve de correction (unités mineures SMU synthétiques) · `independent_terms.rework_budget_minor` | 2000 |
| Portée de l’évaluation · `independent_terms.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Nature de la solution · `kind` | Accord d’échange modélisé (`TRADE`) |
| Code stable · `participant_decisions[0].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[0].party_id` | BUYER |
| Rôle · `participant_decisions[0].role` | buyer |
| Verdict du composant · `participant_decisions[0].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[1].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[1].party_id` | PRIMARY |
| Rôle · `participant_decisions[1].role` | provider |
| Verdict du composant · `participant_decisions[1].verdict` | Accepté (`ACCEPTED`) |
| Code stable · `participant_decisions[2].code` | Accepté (`ACCEPTED`) |
| Identité du participant · `participant_decisions[2].party_id` | COORDINATOR |
| Rôle · `participant_decisions[2].role` | coordinator |
| Verdict du composant · `participant_decisions[2].verdict` | Accepté (`ACCEPTED`) |
| Paiements modélisés (SMU synthétiques) · `payments_minor` | 4400 |
| Identité de la proposition · `proposal_id` | proposal-001 |
| Premier ordinal inclus · `proposed_terms.allocations[0].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[0].last_unit` | 500 |
| Identité du lot fixe · `proposed_terms.allocations[0].lot_id` | DL-100.L001 |
| Identité de l’obligation · `proposed_terms.allocations[0].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[0].pay_minor` | 4100 |
| Identité du fournisseur · `proposed_terms.allocations[0].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[0].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[1].first_unit` | 501 |
| Dernier ordinal inclus · `proposed_terms.allocations[1].last_unit` | 1000 |
| Identité du lot fixe · `proposed_terms.allocations[1].lot_id` | DL-100.L002 |
| Identité de l’obligation · `proposed_terms.allocations[1].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[1].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[1].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[1].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[2].first_unit` | 1001 |
| Dernier ordinal inclus · `proposed_terms.allocations[2].last_unit` | 1100 |
| Identité du lot fixe · `proposed_terms.allocations[2].lot_id` | DL-100.L003 |
| Identité de l’obligation · `proposed_terms.allocations[2].obligation_id` | DL-100 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[2].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[2].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[2].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[3].first_unit` | 1 |
| Dernier ordinal inclus · `proposed_terms.allocations[3].last_unit` | 500 |
| Identité du lot fixe · `proposed_terms.allocations[3].lot_id` | DL-200.L001 |
| Identité de l’obligation · `proposed_terms.allocations[3].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[3].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[3].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[3].window_id` | W0 |
| Premier ordinal inclus · `proposed_terms.allocations[4].first_unit` | 501 |
| Dernier ordinal inclus · `proposed_terms.allocations[4].last_unit` | 800 |
| Identité du lot fixe · `proposed_terms.allocations[4].lot_id` | DL-200.L002 |
| Identité de l’obligation · `proposed_terms.allocations[4].obligation_id` | DL-200 |
| Paiement fournisseur (unités mineures SMU synthétiques) · `proposed_terms.allocations[4].pay_minor` | 0 |
| Identité du fournisseur · `proposed_terms.allocations[4].provider_id` | PRIMARY |
| Identité de la fenêtre de capacité · `proposed_terms.allocations[4].window_id` | W0 |
| Prix acheteur (unités mineures SMU synthétiques) · `proposed_terms.buyer_price_minor` | 4400 |
| Responsabilité d’annulation (unités mineures SMU synthétiques) · `proposed_terms.cancellation_fee_minor` | 0 |
| SHA-256 du contrat conservé · `proposed_terms.contract_sha256` | d13ae681bd7294bf00b6f379885f6c507bb1dc5eb52cc6ee742616de39c7cd0f |
| Rémunération du coordonnateur (unités mineures SMU synthétiques) · `proposed_terms.coordinator_fee_minor` | 300 |
| Instant exclusif d’expiration · `proposed_terms.expires_tick` | 500 |
| Révision des politiques · `proposed_terms.policy_revision` | 1 |
| Identité de la proposition · `proposed_terms.proposal_id` | proposal-001 |
| Réserve de correction (unités mineures SMU synthétiques) · `proposed_terms.rework_budget_minor` | 2000 |
| Schéma · `proposed_terms.schema` | continuity-economy/proposal/v1 |
| Faisabilité modélisée après exécution · `realized_feasibility` | Non établi (`NOT_ESTABLISHED`) |
| Instant de règlement modélisé · `settled_tick` | 30 |
| État consigné · `status` | Réglé dans le registre synthétique (`SETTLED`) |

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.


## Transferts, coûts, responsabilités et options externes modélisés

Modèle uniquement : les SMU sont des unités monétaires mineures synthétiques. Les contraintes économiques et intervalles de valeur sont des hypothèses définies pour l’exercice. Une marge ou décision favorable dans le modèle n’établit ni demande volontaire réelle, ni paiement, ni avantage commercial.

| Champ | Valeur consignée |
| --- | --- |
| Total des transferts acheteur (SMU synthétiques) · `accounting.buyer_total_paid_minor` | 4400 |
| Borne supérieure · `accounting.buyer_utility_interval_minor.maximum` | 25600 |
| Borne inférieure · `accounting.buyer_utility_interval_minor.minimum` | 25600 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[0].final_balance_minor` | 25600 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[0].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[0].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[0].initial_balance_minor` | 30000 |
| Seuil de participation modélisé couvert · `accounting.campaign[0].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[0].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[0].party_id` | BUYER |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[0].purchase_payments_minor` | 4400 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[0].realized_profit_minor` | Non consigné |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[0].revenue_minor` | 0 |
| Rôle · `accounting.campaign[0].role` | buyer |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[0].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[1].final_balance_minor` | 10100 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[1].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[1].incurred_cost_minor` | 200 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[1].initial_balance_minor` | 10000 |
| Seuil de participation modélisé couvert · `accounting.campaign[1].participation_covered` | Oui |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[1].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[1].party_id` | COORDINATOR |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[1].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[1].realized_profit_minor` | 100 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[1].revenue_minor` | 300 |
| Rôle · `accounting.campaign[1].role` | coordinator |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[1].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[2].final_balance_minor` | 60000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[2].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[2].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[2].initial_balance_minor` | 60000 |
| Seuil de participation modélisé couvert · `accounting.campaign[2].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[2].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[2].party_id` | TECHNICAL-SPONSOR |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[2].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[2].realized_profit_minor` | Non consigné |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[2].revenue_minor` | 0 |
| Rôle · `accounting.campaign[2].role` | technical_sponsor |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[2].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[3].final_balance_minor` | 42100 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[3].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[3].incurred_cost_minor` | 2000 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[3].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[3].participation_covered` | Oui |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[3].participation_threshold_minor` | 100 |
| Identité du participant · `accounting.campaign[3].party_id` | PRIMARY |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[3].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[3].realized_profit_minor` | 2100 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[3].revenue_minor` | 4100 |
| Rôle · `accounting.campaign[3].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[3].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[4].final_balance_minor` | 40000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[4].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[4].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[4].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[4].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[4].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[4].party_id` | BACKUP |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[4].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[4].realized_profit_minor` | 0 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[4].revenue_minor` | 0 |
| Rôle · `accounting.campaign[4].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[4].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[5].final_balance_minor` | 40000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[5].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[5].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[5].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[5].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[5].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[5].party_id` | COMPAT-A |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[5].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[5].realized_profit_minor` | 0 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[5].revenue_minor` | 0 |
| Rôle · `accounting.campaign[5].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[5].withdrawn_minor` | 0 |
| Solde modélisé final (SMU synthétiques) · `accounting.campaign[6].final_balance_minor` | 40000 |
| Fonds encore retenus (SMU synthétiques) · `accounting.campaign[6].funds_still_held_minor` | 0 |
| Coût engagé (SMU synthétiques) · `accounting.campaign[6].incurred_cost_minor` | 0 |
| Solde modélisé initial (SMU synthétiques) · `accounting.campaign[6].initial_balance_minor` | 40000 |
| Seuil de participation modélisé couvert · `accounting.campaign[6].participation_covered` | Non consigné |
| Seuil de participation applicable (SMU synthétiques) · `accounting.campaign[6].participation_threshold_minor` | Non consigné |
| Identité du participant · `accounting.campaign[6].party_id` | COMPAT-B |
| Transferts d’achat (SMU synthétiques) · `accounting.campaign[6].purchase_payments_minor` | 0 |
| Profit modélisé réalisé (SMU synthétiques) · `accounting.campaign[6].realized_profit_minor` | 0 |
| Encaissements modélisés (SMU synthétiques) · `accounting.campaign[6].revenue_minor` | 0 |
| Rôle · `accounting.campaign[6].role` | provider |
| Retraits vers le compte extérieur (SMU synthétiques) · `accounting.campaign[6].withdrawn_minor` | 0 |
| Unité de compte synthétique · `accounting.currency` | SMU |
| Total final du registre (SMU synthétiques) · `accounting.final_total_minor` | 260000 |
| Total initial du registre (SMU synthétiques) · `accounting.initial_total_minor` | 260000 |
| Contrats, paiements ou demande réels · `accounting.real_contracts_payments_or_demand` | Non établi (`NOT_ESTABLISHED`) |
| Faisabilité modélisée réalisée pour l’acheteur · `accounting.realized_buyer` | Démontré dans la portée déclarée (`DEMONSTRATED`) |
| Portée de l’évaluation · `accounting.scope` | Modèle synthétique défini pour l’exercice (`AUTHORED_SYNTHETIC_MODEL`) |
| Tous les coûts de correction (SMU synthétiques) · `accounting.total_correction_cost_minor` | 0 |
| Tous les coûts engagés de campagne (SMU synthétiques) · `accounting.total_incurred_cost_minor` | 2200 |
| Tous les transferts de règlement modélisés (SMU synthétiques) · `accounting.total_transfers_minor` | 4400 |
| Transaction modélisée réglée · `accounting.trade_settled` | Oui |
| Obligations acceptées · `totals.accepted_obligations` | 0 |
| Quantité acceptée selon le contrat · `totals.accepted_quantity` | 0 |
| Tentatives de livraison · `totals.delivery_attempts` | 5 |
| Unités acceptées en double · `totals.duplicate_acceptances` | 0 |
| Quantité tardive · `totals.late_quantity` | 0 |
| Quantité manquante · `totals.missing_quantity` | 1900 |
| Quantité produite · `totals.produced_quantity` | 1900 |
| Tentatives de production durables · `totals.production_attempts` | 5 |
| Quantité reçue · `totals.received_quantity` | 1900 |
| Unités acceptées par le composant destinataire · `totals.recipient_accepted_quantity` | 1400 |
| Quantité refusée · `totals.rejected_quantity` | 0 |
| Unités demandées dans les livraisons refusées · `totals.rejected_requested_quantity` | 0 |
| Tentatives de livraison refusées · `totals.rejection_count` | 0 |
| Obligations actives requises · `totals.required_obligations` | 2 |
| Quantité requise · `totals.required_quantity` | 1900 |
| Unités sémantiquement correctes observées à temps · `totals.timely_semantic_quantity` | 1400 |
| Engagements non sûrs ou non autorisés · `totals.unsafe_or_unsupported_commitments` | 3 |

## Ressources mesurées et lacunes de comptabilisation

Les ressources de processus mesurées et les montants synthétiques configurés ont des significations différentes. Les efforts de préparation, d’intégration, d’adaptation, de vérification ou d’intervention non consignés restent inconnus. Les catégories absentes ne permettent aucune conclusion de coût complet ou de méthode moins coûteuse.

| Champ | Valeur consignée |
| --- | --- |
| Lacunes de comptabilisation · `accounting_gaps[0]` | Le travail de préparation n’a pas été mesuré (`PREPARATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[1]` | Le travail d’intégration n’a pas été mesuré (`INTEGRATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[2]` | Le travail d’adaptation n’a pas été mesuré (`ADAPTATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[3]` | Le travail humain de vérification n’a pas été mesuré (`VERIFICATION_LABOR_NOT_MEASURED`) |
| Lacunes de comptabilisation · `accounting_gaps[4]` | Les tarifs monétaires n’ont pas été mesurés (`MONETARY_RATES_NOT_MEASURED`) |
| Travail d’adaptation (secondes ; inconnu si absent) · `resources.adaptation_labor_seconds` | Non consigné |
| Stockage de l’autorité avant scellement (octets) · `resources.authority_storage_bytes_before_seal` | 30068 |
| Redémarrages du candidat · `resources.candidate_restarts` | 0 |
| Processus enfants lancés · `resources.child_processes` | 8 |
| Processeur système du contrôleur (ns) · `resources.controller_cpu_system_ns` | 30994000 |
| Processeur utilisateur du contrôleur (ns) · `resources.controller_cpu_user_ns` | 140987999 |
| Processeur système (ns) · `resources.cpu_system_ns` | 106881999 |
| Processeur utilisateur (ns) · `resources.cpu_user_ns` | 614089000 |
| Interventions humaines · `resources.human_interventions` | 0 |
| Travail d’intégration (secondes ; inconnu si absent) · `resources.integration_labor_seconds` | Non consigné |
| Périmètre de mesure · `resources.measurement_scope` | Contrôleur et processus enfants ; leur mesure processeur sur un hôte partagé peut inclure des exercices concurrents. |
| Coût monétaire réel mesuré · `resources.monetary_cost` | Non consigné |
| Pic de mémoire résidente (octets) · `resources.peak_rss_bytes` | Non consigné |
| Travail de préparation (secondes ; inconnu si absent) · `resources.preparation_labor_seconds` | Non consigné |
| Requêtes · `resources.requests` | 30 |
| Nouvelles tentatives · `resources.retries` | 0 |
| Requêtes internes aux services · `resources.service_requests` | 158 |
| Stockage consigné (octets) · `resources.storage_bytes` | 8776610 |
| Travail humain de vérification (secondes ; inconnu si absent) · `resources.verification_labor_seconds` | Non consigné |
| Durée écoulée (ns) · `resources.wall_ns` | 1066360962 |
| Redémarrages des services · `resources.worker_restarts` | 0 |
| Temps processeur (ns) · `verification_resources.cpu_ns` | 208760810 |
| Fichiers de preuve examinés · `verification_resources.evidence_files_read` | 22 |
| Durée écoulée (ns) · `verification_resources.wall_ns` | 208798802 |

## Échecs et contre-exemples observés

| Code stable | Portée | Obligation | Solution | Interprétation | Repère technique original |
| --- | --- | --- | --- | --- | --- |
| `FALSE_RECIPIENT_ACCEPTANCE` | safety | DL-100 | Non consigné | Le vérificateur a consigné une contradiction pour ce contrôle. Lire le code et les preuves conservées avant d’interpréter le verdict du composant. | `proposal-001.DL-100.L001.A1.D` |
| `IMPORTED_CONTENT_MISMATCH` | safety | DL-100 | Non consigné | Le vérificateur a consigné une contradiction pour ce contrôle. Lire le code et les preuves conservées avant d’interpréter le verdict du composant. | `proposal-001.DL-100.L001.A1.D` |
| `IMPORTED_CONTENT_INCOMPLETE` | outcome | DL-100 | Non consigné | Le vérificateur a consigné une contradiction pour ce contrôle. Lire le code et les preuves conservées avant d’interpréter le verdict du composant. | `` |
| `SETTLEMENT_WITHOUT_ACCEPTED_CONTENT` | safety | Non consigné | proposal-001 | Le vérificateur a consigné une contradiction pour ce contrôle. Lire le code et les preuves conservées avant d’interpréter le verdict du composant. | `proposal-001` |

## Preuves absentes et affirmations non établies

Aucune entrée non résolue supplémentaire n’a été consignée. Les limites de portée et de coûts inconnus restent applicables.

## Références des preuves et intégrité des octets

Les empreintes identifient les octets. Elles n’authentifient pas les instructions réelles d’un client, n’établissent pas l’exhaustivité des sources et ne remplacent pas une empreinte de référence conservée séparément.

| Champ | Valeur consignée |
| --- | --- |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json` | ae058d5d4fddeaf5f127ea92d13a83d3eeb3c364a746beb4f42c949117971947 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L002.A1.json` | 04621fe9d73e2c4eeb34d9151bcf1a3a9e7dab79c56ccdee90985ceeda73ebfb |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-100.L003.A1.json` | 05a284b9219d71fc853e1211f7efc1290990876eb42f570371c8faf753d99337 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-200.L001.A1.json` | c825144b6d54f8a42cd47fe4ce437f98f79c758dda00f9f93f1d5a6183edf7c6 |
| `evidence_sha256.evidence/capacity-artifacts/PRIMARY.W0/DL-200.L002.A1.json` | f131a805c04269e1df8cec4a747ef0672cd283382dfe1d9d906845609b05b815 |
| `evidence_sha256.evidence/capacity/BACKUP.W0.sqlite` | 9b03d99e3e57bcbc863e8ef094933a05d5c57118196f6eb0efa9a347d43f09c5 |
| `evidence_sha256.evidence/capacity/COMPAT-A.W0.sqlite` | 79be1c093329ac312291fcf4679fc39e2b8e676dfd58454a597f9afef6f7a74a |
| `evidence_sha256.evidence/capacity/COMPAT-B.W0.sqlite` | 85ffca9256987f7b96236db95d08ab132aca59e43bcfcc11a9a569d013c76393 |
| `evidence_sha256.evidence/capacity/PRIMARY.W0.sqlite` | 0ca40649f428d70d56040ba35fdf28f304122416d61e80b790d35f7670dadc73 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L001.A1.D.json` | 078464ebd555cfd75df8133f680ccbd4ecd3b88f7be81f3479d964b4a5a17567 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L002.A1.D.json` | 33a86843c4d72ebceea5e2f093a0f7f1d739a1b263b856697b8059024e5ee4cd |
| `evidence_sha256.evidence/inbox/proposal-001.DL-100.L003.A1.D.json` | 0d643f0bbb9dc0d40974dd091a280a00cb899063282109694415b605eb9284cd |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L001.A1.D.json` | 2dedd55b72b9e92aa389dfc7a5b4cefc61631e8fdb50243f2dd39b92bea81935 |
| `evidence_sha256.evidence/inbox/proposal-001.DL-200.L002.A1.D.json` | bddee0ca19ef5451f0fe9977db9e0de74540cfc7752e6783e297d65a2b3a4a13 |
| `evidence_sha256.evidence/participants.sqlite` | b62ab314bdf69644a684642e5139225c94bec41b7d5df43cab253aa2b2c09101 |
| `evidence_sha256.evidence/producer.sqlite` | 9aba53d11c67ac13a3c847411aae4ac77ebb0d49c920e08072f53b0d7fc50491 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L001.A1.json` | 078464ebd555cfd75df8133f680ccbd4ecd3b88f7be81f3479d964b4a5a17567 |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L002.A1.json` | 33a86843c4d72ebceea5e2f093a0f7f1d739a1b263b856697b8059024e5ee4cd |
| `evidence_sha256.evidence/products/proposal-001.DL-100.L003.A1.json` | 0d643f0bbb9dc0d40974dd091a280a00cb899063282109694415b605eb9284cd |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L001.A1.json` | 2dedd55b72b9e92aa389dfc7a5b4cefc61631e8fdb50243f2dd39b92bea81935 |
| `evidence_sha256.evidence/products/proposal-001.DL-200.L002.A1.json` | bddee0ca19ef5451f0fe9977db9e0de74540cfc7752e6783e297d65a2b3a4a13 |
| `evidence_sha256.evidence/receiver.sqlite` | 075234387dbc71132e5d5d524efc62b9d266b4bfc75021717d6a8c4badc8aa9e |
| SHA-256 du résultat structuré · `structured_result_sha256` | dc8038a8f8e588a05b35ccf4f7dacc7199e60d92a38dfa92bb1805f3c6656bac |

## Exécution, pannes, commandes et provenance consignées

Les identifiants stables, commandes exactes, chemins et diagnostics machine originaux sont conservés littéralement. Ce sont des données, non des preuves d’acceptation supplémentaires. La confiance dans les sources et l’hôte est explicitée dans l’architecture et le modèle de menace.

| Champ | Valeur consignée |
| --- | --- |
| `command[0]` | python |
| `command[1]` | -m |
| `command[2]` | continuity_economy |
| `command[3]` | challenge |
| `command[4]` | --out |
| `command[5]` | /workspace/scratch/b1d5891eb025/economy-verifier-development/attempt-2 |
| Programme de pannes préenregistré · `fault_schedule` | Aucune entrée |
| Pannes effectivement observées · `faults_observed` | Aucune entrée |
| Modifications sources non consignées présentes · `implementation.dirty` | Oui |
| Arguments exacts du processus · `implementation.environment.argv[0]` | python |
| Arguments exacts du processus · `implementation.environment.argv[1]` | - |
| Plateforme d’exécution · `implementation.environment.platform` | Linux-6.18.57-x86_64-with-glibc2.39 |
| Interpréteur Python · `implementation.environment.python` | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Version de SQLite · `implementation.environment.sqlite_version` | 3.53.1 |
| Répertoire d’exécution · `implementation.environment.working_directory` | /workspace/scratch/b1d5891eb025/continuity-economy |
| Commit source effectif · `implementation.git_commit` | 0d7892130cf1696202e10fdd85bf8bd126c10fb3 |
| Base conservée de l’implémentation de capacité · `implementation.reused_capacity_baseline` | 396227d8da2f55f674f479de16089c7ce28ef290 |
| `implementation.source_sha256.continuity_economy/__init__.py` | d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72 |
| `implementation.source_sha256.continuity_economy/__main__.py` | e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf |
| `implementation.source_sha256.continuity_economy/adapters.py` | 9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048 |
| `implementation.source_sha256.continuity_economy/candidate.py` | ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee |
| `implementation.source_sha256.continuity_economy/challenges.py` | 559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85 |
| `implementation.source_sha256.continuity_economy/controller.py` | 5003c746b49368061d0e77567ed5d82f02e9d5eaa336108f5fee837a09adb8fc |
| `implementation.source_sha256.continuity_economy/fixtures.py` | e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71 |
| `implementation.source_sha256.continuity_economy/participants.py` | 6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2 |
| `implementation.source_sha256.continuity_economy/planning.py` | 61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc |
| `implementation.source_sha256.continuity_economy/policy_schema.py` | b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b |
| `implementation.source_sha256.continuity_economy/producer.py` | e9ec94afc823dbadd9bae631cee7630489399a9038c01ccd48991ad67489b09a |
| `implementation.source_sha256.continuity_economy/receiver.py` | d192329fe254ed04194dc1680ac62e550204362b2da642235d13d607dc5975ff |
| `implementation.source_sha256.continuity_economy/reporting.py` | 6e9dc284ec8b2d3407a9df3dc8aaf0049f99255bb05a104c72649d0f4d702e97 |
| `implementation.source_sha256.continuity_economy/schema.py` | dbf625ffd5300e7ac82ff5e857a0709647814eb8bd47e3fd9912c74bb78ed77f |
| `implementation.source_sha256.continuity_economy/suite.py` | 1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3 |
| `implementation.source_sha256.continuity_economy/verifier.py` | 2deff4885c565f7e8508984cd693648ba49c6693d15aa0c71926704daba0c16d |
| `implementation.source_sha256.continuity_harness/__init__.py` | 577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e |
| `implementation.source_sha256.continuity_harness/__main__.py` | c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8 |
| `implementation.source_sha256.continuity_harness/adapters.py` | ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0 |
| `implementation.source_sha256.continuity_harness/candidate.py` | f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9 |
| `implementation.source_sha256.continuity_harness/challenges.py` | d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d |
| `implementation.source_sha256.continuity_harness/controller.py` | 6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4 |
| `implementation.source_sha256.continuity_harness/fixtures.py` | 4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e |
| `implementation.source_sha256.continuity_harness/reporting.py` | e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645 |
| `implementation.source_sha256.continuity_harness/rpc.py` | 36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745 |
| `implementation.source_sha256.continuity_harness/sandbox.py` | 7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f |
| `implementation.source_sha256.continuity_harness/schema.py` | 4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c |
| `implementation.source_sha256.continuity_harness/service.py` | 6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c |
| `implementation.source_sha256.continuity_harness/suite.py` | bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc |
| `implementation.source_sha256.continuity_harness/verifier.py` | 2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38 |
| `implementation.source_sha256.experiments/economy-v0.2/PROVENANCE.json` | 705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214 |
| `implementation.source_sha256.experiments/economy-v0.2/challenges.json` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/constructed-continuity.json` | 020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/conventional-better.json` | 8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/no-deal.json` | 2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/primary-recovery.json` | 8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/repair-after-rejection.json` | 0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/technical-no-trade.json` | f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196 |
| `implementation.source_sha256.experiments/economy-v0.2/fixtures/uncertain-value.json` | 8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2 |
| `implementation.source_sha256.experiments/economy-v0.2/spec.json` | e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b |
| Version d’implémentation · `implementation.version` | 0.2.0 |
| Empreinte externe de référence · `reference_sha256` | c37a14b818a0a333bba5947e247eebd2169b86bdb5455b41a46d3c7c996f0e6d |
| `registered_case.criterion` | FALSE_ACCEPTANCE_DETECTED |
| `registered_case.id` | wrong-content-resealed |
| Nature de la solution · `registered_case.kind` | evidence_intervention |
| `registered_case.mutation` | wrong_content |
| `registered_case.source` | valid-digital-control |
| `registration_sha256` | 791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9 |
| Hypothèses de confiance explicites · `trust_assumptions[0]` | Hôte, noyau, contrôleur et horloge de confiance (`TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK`) |
| Hypothèses de confiance explicites · `trust_assumptions[1]` | Autorité synthétique conservée de confiance (`TRUSTED_RETAINED_SYNTHETIC_AUTHORITY`) |
| Hypothèses de confiance explicites · `trust_assumptions[2]` | Auteur commun ; aucune certification par un tiers (`SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION`) |
| Hypothèses de confiance explicites · `trust_assumptions[3]` | Contenu numérique sémantique uniquement ; livraison physique non éprouvée (`SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY`) |
| Pannes préenregistrées non déclenchées · `untriggered_faults` | Aucune entrée |

## Observation contradictoire et qualification du vérificateur

Un test réussi peut constater correctement un refus, un échec ou des preuves insuffisantes. Il ne transforme pas un travail partiel en engagement complet. Un test contradictoire réussi peut révéler un vérificateur défectueux ; sa qualification doit rester distincte.

| Champ | Valeur consignée |
| --- | --- |
| Quantité acceptée selon le contrat · `assertion.accepted_quantity` | 0 |
| Qualification du vérificateur · `assertion.checker_qualification` | NOT_APPLICABLE |
| `assertion.criterion` | FALSE_ACCEPTANCE_DETECTED |
| `assertion.finding_codes[0]` | FALSE_RECIPIENT_ACCEPTANCE |
| `assertion.finding_codes[1]` | IMPORTED_CONTENT_INCOMPLETE |
| `assertion.finding_codes[2]` | IMPORTED_CONTENT_MISMATCH |
| `assertion.finding_codes[3]` | SETTLEMENT_WITHOUT_ACCEPTED_CONTENT |
| `assertion.observed_outcome` | Échec (`FAILED`) |
| `assertion.observed_safety_status` | Échec (`FAILED`) |
| `assertion.observed_service_feasibility` | Échec (`FAILED`) |
| État consigné · `assertion.status` | Réussi (`PASSED`) |
| `criterion` | FALSE_ACCEPTANCE_DETECTED |
| `execution_reused_from` | valid-digital-control |
| `id` | wrong-content-resealed |
| Nature de la solution · `kind` | evidence_intervention |
| `observation_wall_ns` | 275997748 |
| Portée de l’évaluation · `scope` | REGISTERED_SYNTHETIC_CHALLENGE |

## Enregistrement structuré complet de vérification

Le même enregistrement structuré génère les deux versions linguistiques. Les clés machine, codes d’état et valeurs littérales des preuves restent inchangés ; les sections localisées ci-dessus expliquent leur sens. Aucun résultat sauvegardé n’est réutilisé comme preuve fraîche.

```json
{
  "accounting": {
    "buyer_total_paid_minor": 4400,
    "buyer_utility_interval_minor": {
      "maximum": 25600,
      "minimum": 25600
    },
    "campaign": [
      {
        "final_balance_minor": 25600,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 30000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BUYER",
        "purchase_payments_minor": 4400,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "buyer",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 10100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 200,
        "initial_balance_minor": 10000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "COORDINATOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 100,
        "revenue_minor": 300,
        "role": "coordinator",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 60000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 60000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "TECHNICAL-SPONSOR",
        "purchase_payments_minor": 0,
        "realized_profit_minor": null,
        "revenue_minor": 0,
        "role": "technical_sponsor",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 42100,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 2000,
        "initial_balance_minor": 40000,
        "participation_covered": true,
        "participation_threshold_minor": 100,
        "party_id": "PRIMARY",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 2100,
        "revenue_minor": 4100,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "BACKUP",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-A",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      },
      {
        "final_balance_minor": 40000,
        "funds_still_held_minor": 0,
        "incurred_cost_minor": 0,
        "initial_balance_minor": 40000,
        "participation_covered": null,
        "participation_threshold_minor": null,
        "party_id": "COMPAT-B",
        "purchase_payments_minor": 0,
        "realized_profit_minor": 0,
        "revenue_minor": 0,
        "role": "provider",
        "withdrawn_minor": 0
      }
    ],
    "currency": "SMU",
    "final_total_minor": 260000,
    "initial_total_minor": 260000,
    "real_contracts_payments_or_demand": "NOT_ESTABLISHED",
    "realized_buyer": "DEMONSTRATED",
    "scope": "AUTHORED_SYNTHETIC_MODEL",
    "total_correction_cost_minor": 0,
    "total_incurred_cost_minor": 2200,
    "total_transfers_minor": 4400,
    "trade_settled": true
  },
  "accounting_gaps": [
    "PREPARATION_LABOR_NOT_MEASURED",
    "INTEGRATION_LABOR_NOT_MEASURED",
    "ADAPTATION_LABOR_NOT_MEASURED",
    "VERIFICATION_LABOR_NOT_MEASURED",
    "MONETARY_RATES_NOT_MEASURED"
  ],
  "assessment": {
    "claim_status": "FAILED",
    "evidence_stage": "EVIDENCE_INTEGRITY_CHALLENGE",
    "target_verdict": "COMPLETED",
    "test_assertion": "PASSED"
  },
  "authority_status": "ESTABLISHED_FOR_SYNTHETIC_EXERCISE",
  "challenge": {
    "assertion": {
      "accepted_quantity": 0,
      "checker_qualification": "NOT_APPLICABLE",
      "criterion": "FALSE_ACCEPTANCE_DETECTED",
      "finding_codes": [
        "FALSE_RECIPIENT_ACCEPTANCE",
        "IMPORTED_CONTENT_INCOMPLETE",
        "IMPORTED_CONTENT_MISMATCH",
        "SETTLEMENT_WITHOUT_ACCEPTED_CONTENT"
      ],
      "observed_outcome": "FAILED",
      "observed_safety_status": "FAILED",
      "observed_service_feasibility": "FAILED",
      "status": "PASSED"
    },
    "criterion": "FALSE_ACCEPTANCE_DETECTED",
    "execution_reused_from": "valid-digital-control",
    "id": "wrong-content-resealed",
    "kind": "evidence_intervention",
    "observation_wall_ns": 275997748,
    "scope": "REGISTERED_SYNTHETIC_CHALLENGE"
  },
  "claims": {
    "method_advantage": "NOT_ESTABLISHED",
    "outcome": "FAILED",
    "service_feasibility": "FAILED"
  },
  "commercial_value": "NOT_ESTABLISHED",
  "contract_sha256": "d13ae681bd7294bf00b6f379885f6c507bb1dc5eb52cc6ee742616de39c7cd0f",
  "evidence_sha256": {
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L001.A1.json": "ae058d5d4fddeaf5f127ea92d13a83d3eeb3c364a746beb4f42c949117971947",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L002.A1.json": "04621fe9d73e2c4eeb34d9151bcf1a3a9e7dab79c56ccdee90985ceeda73ebfb",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-100.L003.A1.json": "05a284b9219d71fc853e1211f7efc1290990876eb42f570371c8faf753d99337",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-200.L001.A1.json": "c825144b6d54f8a42cd47fe4ce437f98f79c758dda00f9f93f1d5a6183edf7c6",
    "evidence/capacity-artifacts/PRIMARY.W0/DL-200.L002.A1.json": "f131a805c04269e1df8cec4a747ef0672cd283382dfe1d9d906845609b05b815",
    "evidence/capacity/BACKUP.W0.sqlite": "9b03d99e3e57bcbc863e8ef094933a05d5c57118196f6eb0efa9a347d43f09c5",
    "evidence/capacity/COMPAT-A.W0.sqlite": "79be1c093329ac312291fcf4679fc39e2b8e676dfd58454a597f9afef6f7a74a",
    "evidence/capacity/COMPAT-B.W0.sqlite": "85ffca9256987f7b96236db95d08ab132aca59e43bcfcc11a9a569d013c76393",
    "evidence/capacity/PRIMARY.W0.sqlite": "0ca40649f428d70d56040ba35fdf28f304122416d61e80b790d35f7670dadc73",
    "evidence/inbox/proposal-001.DL-100.L001.A1.D.json": "078464ebd555cfd75df8133f680ccbd4ecd3b88f7be81f3479d964b4a5a17567",
    "evidence/inbox/proposal-001.DL-100.L002.A1.D.json": "33a86843c4d72ebceea5e2f093a0f7f1d739a1b263b856697b8059024e5ee4cd",
    "evidence/inbox/proposal-001.DL-100.L003.A1.D.json": "0d643f0bbb9dc0d40974dd091a280a00cb899063282109694415b605eb9284cd",
    "evidence/inbox/proposal-001.DL-200.L001.A1.D.json": "2dedd55b72b9e92aa389dfc7a5b4cefc61631e8fdb50243f2dd39b92bea81935",
    "evidence/inbox/proposal-001.DL-200.L002.A1.D.json": "bddee0ca19ef5451f0fe9977db9e0de74540cfc7752e6783e297d65a2b3a4a13",
    "evidence/participants.sqlite": "b62ab314bdf69644a684642e5139225c94bec41b7d5df43cab253aa2b2c09101",
    "evidence/producer.sqlite": "9aba53d11c67ac13a3c847411aae4ac77ebb0d49c920e08072f53b0d7fc50491",
    "evidence/products/proposal-001.DL-100.L001.A1.json": "078464ebd555cfd75df8133f680ccbd4ecd3b88f7be81f3479d964b4a5a17567",
    "evidence/products/proposal-001.DL-100.L002.A1.json": "33a86843c4d72ebceea5e2f093a0f7f1d739a1b263b856697b8059024e5ee4cd",
    "evidence/products/proposal-001.DL-100.L003.A1.json": "0d643f0bbb9dc0d40974dd091a280a00cb899063282109694415b605eb9284cd",
    "evidence/products/proposal-001.DL-200.L001.A1.json": "2dedd55b72b9e92aa389dfc7a5b4cefc61631e8fdb50243f2dd39b92bea81935",
    "evidence/products/proposal-001.DL-200.L002.A1.json": "bddee0ca19ef5451f0fe9977db9e0de74540cfc7752e6783e297d65a2b3a4a13",
    "evidence/receiver.sqlite": "075234387dbc71132e5d5d524efc62b9d266b4bfc75021717d6a8c4badc8aa9e"
  },
  "failures": [
    {
      "code": "FALSE_RECIPIENT_ACCEPTANCE",
      "detail": "proposal-001.DL-100.L001.A1.D",
      "obligation_id": "DL-100",
      "scope": "safety"
    },
    {
      "code": "IMPORTED_CONTENT_MISMATCH",
      "detail": "proposal-001.DL-100.L001.A1.D",
      "obligation_id": "DL-100",
      "scope": "safety"
    },
    {
      "code": "IMPORTED_CONTENT_INCOMPLETE",
      "detail": "",
      "obligation_id": "DL-100",
      "scope": "outcome"
    },
    {
      "arrangement_id": "proposal-001",
      "code": "SETTLEMENT_WITHOUT_ACCEPTED_CONTENT",
      "detail": "proposal-001",
      "scope": "safety"
    }
  ],
  "fault_schedule": [],
  "faults_observed": [],
  "implementation": {
    "dirty": true,
    "environment": {
      "argv": [
        "python",
        "-"
      ],
      "platform": "Linux-6.18.57-x86_64-with-glibc2.39",
      "python": "3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]",
      "sqlite_version": "3.53.1",
      "working_directory": "/workspace/scratch/b1d5891eb025/continuity-economy"
    },
    "git_commit": "0d7892130cf1696202e10fdd85bf8bd126c10fb3",
    "reused_capacity_baseline": "396227d8da2f55f674f479de16089c7ce28ef290",
    "source_sha256": {
      "continuity_economy/__init__.py": "d5cfaccc245c8493d1de11e260ca35436bda8e20145487d7ddf9beabab69bb72",
      "continuity_economy/__main__.py": "e46ca0167c2eb914cac9bb03028708b98f7f49896809893c18f77ac7023fabaf",
      "continuity_economy/adapters.py": "9e9c80a30d0e0eb1bc181eacd485d018596b22225950344c75ec9fefe7c2b048",
      "continuity_economy/candidate.py": "ca0f6a1bb5a3ef8e8c2ba7971d4bd668c726c55d556aad7edbee94d3b4f038ee",
      "continuity_economy/challenges.py": "559d75beb55a5e14c84fd63ed6187114f629363342bbec84db9f1f79659a6e85",
      "continuity_economy/controller.py": "5003c746b49368061d0e77567ed5d82f02e9d5eaa336108f5fee837a09adb8fc",
      "continuity_economy/fixtures.py": "e71d4177550e8653c1609f7e48e4840e1d0e1116e7c4586c496269ef17452c71",
      "continuity_economy/participants.py": "6dc6b278aa4196649ba8d2314509a840fd70692c452e2277771b1d622d713ea2",
      "continuity_economy/planning.py": "61f1cef3848b0a69ef793254aedab5625febcd245d912e4a9efa8ae8e00fadbc",
      "continuity_economy/policy_schema.py": "b27b20baed247198eb689e8c8f61aab8eb0e50df7af257e0f86875ce78d6ca7b",
      "continuity_economy/producer.py": "e9ec94afc823dbadd9bae631cee7630489399a9038c01ccd48991ad67489b09a",
      "continuity_economy/receiver.py": "d192329fe254ed04194dc1680ac62e550204362b2da642235d13d607dc5975ff",
      "continuity_economy/reporting.py": "6e9dc284ec8b2d3407a9df3dc8aaf0049f99255bb05a104c72649d0f4d702e97",
      "continuity_economy/schema.py": "dbf625ffd5300e7ac82ff5e857a0709647814eb8bd47e3fd9912c74bb78ed77f",
      "continuity_economy/suite.py": "1661bc015fef9569cacdbbea36aedddc94adee3b2e9b15ecda5a32d4a477e0c3",
      "continuity_economy/verifier.py": "2deff4885c565f7e8508984cd693648ba49c6693d15aa0c71926704daba0c16d",
      "continuity_harness/__init__.py": "577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e",
      "continuity_harness/__main__.py": "c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8",
      "continuity_harness/adapters.py": "ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0",
      "continuity_harness/candidate.py": "f473520ad15f71642f461b9e373fa32e524937bd041c9e8279f99101b04e9fe9",
      "continuity_harness/challenges.py": "d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d",
      "continuity_harness/controller.py": "6586232940b9a0ec7ae1044d24ece90be87859188884fbbb2f465ca1fa1857d4",
      "continuity_harness/fixtures.py": "4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e",
      "continuity_harness/reporting.py": "e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645",
      "continuity_harness/rpc.py": "36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745",
      "continuity_harness/sandbox.py": "7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f",
      "continuity_harness/schema.py": "4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c",
      "continuity_harness/service.py": "6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c",
      "continuity_harness/suite.py": "bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc",
      "continuity_harness/verifier.py": "2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38",
      "experiments/economy-v0.2/PROVENANCE.json": "705ad3f9484d29481dda48c6732c43ec01251be580655609c3a9788933e17214",
      "experiments/economy-v0.2/challenges.json": "791f23291620d55f181c62cb9c919ea28c93f1c68dbbe75c17f42f536b9a6ec9",
      "experiments/economy-v0.2/fixtures/constructed-continuity.json": "020c9256ec0a5ee9f174ee15ada0ae40b847f25659104ebcb0cca7036635dcbd",
      "experiments/economy-v0.2/fixtures/conventional-better.json": "8eefc45227fde4ac098e292260ac1cb286cc1d49e1e6fae5b9ce40ba4cc791aa",
      "experiments/economy-v0.2/fixtures/no-deal.json": "2f3e44a1817960268ee9b42c9339df9fd92792a44f385a5f74de6be2f0a4145d",
      "experiments/economy-v0.2/fixtures/primary-recovery.json": "8c1d01e404d62f2d9de930a747a0588684b0933e730d634dd4d7ac7b010305f3",
      "experiments/economy-v0.2/fixtures/repair-after-rejection.json": "0f2f2e0ae5456a1269822b2806a70268231749168b1e73f5b304c799a362a3b8",
      "experiments/economy-v0.2/fixtures/technical-no-trade.json": "f7ccfe3d9832198dcdec9ea31f0a9fe5c3fb58f8cd14dd3c9879ced089fec196",
      "experiments/economy-v0.2/fixtures/uncertain-value.json": "8569c2e1a4544ad4dba1877a072b99dfb10a487506c362da18e0b7b1214eede2",
      "experiments/economy-v0.2/spec.json": "e6e55cc986de1e64794dd62399252f5626ff45e4d27857af614f33908ad2bd7b"
    },
    "version": "0.2.0"
  },
  "per_arrangement": [
    {
      "acceptance_ids": [
        "proposal-001.DL-100.L001.A1.D",
        "proposal-001.DL-100.L002.A1.D",
        "proposal-001.DL-100.L003.A1.D",
        "proposal-001.DL-200.L001.A1.D",
        "proposal-001.DL-200.L002.A1.D"
      ],
      "accepted_tick": 3,
      "agreement_id": "proposal-001",
      "cancelled_tick": null,
      "correction_cost_minor": 0,
      "ex_ante_feasibility": "DEMONSTRATED",
      "incurred_cost_minor": 2200,
      "independent_terms": {
        "break_even_value_minor": 6400,
        "buyer_definite_max_price_minor": 25000,
        "buyer_possible_max_price_minor": 25000,
        "currency": "SMU",
        "minimum_buyer_price_minor": 4400,
        "minimum_coordinator_fee_minor": 300,
        "providers": [
          {
            "base_cost_minor": 2000,
            "guaranteed_profit_minor": 100,
            "maximum_unpaid_cost_exposure_minor": 4000,
            "minimum_payment_minor": 4100,
            "participation_profit_minor": 100,
            "party_id": "PRIMARY",
            "promised_payment_minor": 4100,
            "rework_cost_minor": 2000,
            "units": 1900
          }
        ],
        "rework_budget_minor": 2000,
        "scope": "AUTHORED_SYNTHETIC_MODEL"
      },
      "kind": "TRADE",
      "participant_decisions": [
        {
          "code": "ACCEPTED",
          "party_id": "BUYER",
          "role": "buyer",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "PRIMARY",
          "role": "provider",
          "verdict": "ACCEPTED"
        },
        {
          "code": "ACCEPTED",
          "party_id": "COORDINATOR",
          "role": "coordinator",
          "verdict": "ACCEPTED"
        }
      ],
      "payments_minor": 4400,
      "proposal_id": "proposal-001",
      "proposed_terms": {
        "allocations": [
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-100.L001",
            "obligation_id": "DL-100",
            "pay_minor": 4100,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 1000,
            "lot_id": "DL-100.L002",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1001,
            "last_unit": 1100,
            "lot_id": "DL-100.L003",
            "obligation_id": "DL-100",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 1,
            "last_unit": 500,
            "lot_id": "DL-200.L001",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          },
          {
            "first_unit": 501,
            "last_unit": 800,
            "lot_id": "DL-200.L002",
            "obligation_id": "DL-200",
            "pay_minor": 0,
            "provider_id": "PRIMARY",
            "window_id": "W0"
          }
        ],
        "buyer_price_minor": 4400,
        "cancellation_fee_minor": 0,
        "contract_sha256": "d13ae681bd7294bf00b6f379885f6c507bb1dc5eb52cc6ee742616de39c7cd0f",
        "coordinator_fee_minor": 300,
        "expires_tick": 500,
        "policy_revision": 1,
        "proposal_id": "proposal-001",
        "rework_budget_minor": 2000,
        "schema": "continuity-economy/proposal/v1"
      },
      "realized_feasibility": "NOT_ESTABLISHED",
      "settled_tick": 30,
      "status": "SETTLED"
    }
  ],
  "per_obligation": [
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 3,
      "late_quantity": 0,
      "missing_quantity": 1100,
      "obligation_id": "DL-100",
      "outcome": "INCORRECT",
      "produced_quantity": 1100,
      "production_attempts": 3,
      "quantity": 1100,
      "reason_codes": [
        "FALSE_RECIPIENT_ACCEPTANCE",
        "IMPORTED_CONTENT_INCOMPLETE",
        "IMPORTED_CONTENT_MISMATCH"
      ],
      "received_quantity": 1100,
      "recipient": "RECIPIENT-A",
      "recipient_accepted_quantity": 600,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 1100,
      "revision": 2,
      "status": "ACTIVE",
      "timely_semantic_quantity": 600
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 2,
      "late_quantity": 0,
      "missing_quantity": 800,
      "obligation_id": "DL-200",
      "outcome": "UNFULFILLED",
      "produced_quantity": 800,
      "production_attempts": 2,
      "quantity": 800,
      "reason_codes": [],
      "received_quantity": 800,
      "recipient": "RECIPIENT-B",
      "recipient_accepted_quantity": 800,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 800,
      "revision": 1,
      "status": "ACTIVE",
      "timely_semantic_quantity": 800
    },
    {
      "accepted_quantity": 0,
      "deadline_tick": 500,
      "delivery_attempts": 0,
      "late_quantity": 0,
      "missing_quantity": 0,
      "obligation_id": "DL-300",
      "outcome": "CANCELLED",
      "produced_quantity": 0,
      "production_attempts": 0,
      "quantity": 100,
      "reason_codes": [],
      "received_quantity": 0,
      "recipient": "RECIPIENT-C",
      "recipient_accepted_quantity": 0,
      "rejected_quantity": 0,
      "rejected_requested_quantity": 0,
      "rejection_count": 0,
      "required_quantity": 0,
      "revision": 1,
      "status": "CANCELLED",
      "timely_semantic_quantity": 0
    }
  ],
  "real_customer_authenticity": "NOT_ESTABLISHED",
  "reference_sha256": "c37a14b818a0a333bba5947e247eebd2169b86bdb5455b41a46d3c7c996f0e6d",
  "resources": {
    "adaptation_labor_seconds": null,
    "authority_storage_bytes_before_seal": 30068,
    "candidate_restarts": 0,
    "child_processes": 8,
    "controller_cpu_system_ns": 30994000,
    "controller_cpu_user_ns": 140987999,
    "cpu_system_ns": 106881999,
    "cpu_user_ns": 614089000,
    "human_interventions": 0,
    "integration_labor_seconds": null,
    "measurement_scope": "controller and child processes; shared-host child CPU may include concurrent exercises",
    "monetary_cost": null,
    "peak_rss_bytes": null,
    "preparation_labor_seconds": null,
    "requests": 30,
    "retries": 0,
    "service_requests": 158,
    "storage_bytes": 8776610,
    "verification_labor_seconds": null,
    "wall_ns": 1066360962,
    "worker_restarts": 0
  },
  "run_id": "valid-digital-control.cf541410a8",
  "safety_status": "FAILED",
  "schema": "continuity-economy/verification/v1",
  "totals": {
    "accepted_obligations": 0,
    "accepted_quantity": 0,
    "delivery_attempts": 5,
    "duplicate_acceptances": 0,
    "late_quantity": 0,
    "missing_quantity": 1900,
    "produced_quantity": 1900,
    "production_attempts": 5,
    "received_quantity": 1900,
    "recipient_accepted_quantity": 1400,
    "rejected_quantity": 0,
    "rejected_requested_quantity": 0,
    "rejection_count": 0,
    "required_obligations": 2,
    "required_quantity": 1900,
    "timely_semantic_quantity": 1400,
    "unsafe_or_unsupported_commitments": 3
  },
  "trust_assumptions": [
    "TRUSTED_HOST_KERNEL_CONTROLLER_CLOCK",
    "TRUSTED_RETAINED_SYNTHETIC_AUTHORITY",
    "SHARED_AUTHORSHIP_NOT_THIRD_PARTY_CERTIFICATION",
    "SEMANTIC_CONTENT_ONLY_NOT_PHYSICAL_DELIVERY"
  ],
  "unresolved": [],
  "untriggered_faults": [],
  "verification_resources": {
    "cpu_ns": 208760810,
    "evidence_files_read": 22,
    "wall_ns": 208798802
  },
  "verification_status": "COMPLETE",
  "verifier_version": "0.2.0"
}
```
