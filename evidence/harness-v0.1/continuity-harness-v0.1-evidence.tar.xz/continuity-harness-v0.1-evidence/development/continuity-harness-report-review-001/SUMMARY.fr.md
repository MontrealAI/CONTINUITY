# CONTINUITÉ Ω — Résultats du banc d’essai

## Périmètre

Exécution réelle de logiciels locaux avec des données synthétiques. Les fichiers JSON produits ne sont pas des étiquettes imprimées et n’établissent aucune livraison client ni valeur commerciale.

**Exécutions:** 3 · **Non exécutées:** 0
**Contrôle de publication:** `PASSED`

| Cas | Méthode | Test | Promesse complète | Unités acceptées / attendues | Temps réel (ns) | Sûreté |
|---|---|---|---|---|---:|---|
| labels-base / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 121938239 | `DEMONSTRATED` |
| labels-base / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 121932931 | `DEMONSTRATED` |
| labels-base / constrained | `harness` | `PASSED` | `FAILED` | 1100 / 1900 | 276824107 | `DEMONSTRATED` |

## Comparaison et coûts

Les codes machines sont identiques dans les deux langues. PASSED : comportement attendu observé ; DEMONSTRATED : affirmation établie dans le périmètre local ; FAILED : affirmation non satisfaite ; NOT_ESTABLISHED : preuves insuffisantes ; NOT_RUN : non exécuté.

Une seule exécution par méthode et condition : les durées sont descriptives, sans preuve d’un avantage de vitesse. Les services transactionnels et le vérificateur sont communs. La comparaison n’isole aucun gain général attribuable à l’IA.

Les temps processeur et réel, octets d’exécution, requêtes, reprises et redémarrages sont mesurés. Effort de préparation, intégration, mémoire maximale et coûts monétaires : INCONNUS. Aucun tarif, budget commercial ou économie n’est inventé. Zéro intervention humaine concerne seulement l’exécution automatique.

IA : NON EXÉCUTÉE. Aucun modèle local déjà autorisé n’a été fourni ; l’adaptateur de protocole ne constitue pas un résultat de performance de modèle.

**Avantage comparatif:** `NOT_ESTABLISHED`
**Valeur commerciale:** `NOT_ESTABLISHED`

## Échecs critiques et incertitudes

Exécutions avec sûreté non établie: []
Tests attendus non réussis: []

Consulter chaque PASSPORT.fr.md et RESULT.json pour les obligations individuelles, refus, preuves, conditions et commandes de vérification fraîche. Les résultats incomplets et défavorables sont conservés.
