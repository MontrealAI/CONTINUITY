# CONTINUITY Ω Harness — Results

## Scope

Actual local software execution with synthetic data. Completed JSON artifacts are not printed labels and establish neither customer delivery nor commercial value.

**Executed runs:** 3 · **Not run:** 0
**Release gate:** `PASSED`

| Case | Method | Test | Complete promise | Accepted / expected units | Wall time (ns) | Safety |
|---|---|---|---|---|---:|---|
| labels-base / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 121938239 | `DEMONSTRATED` |
| labels-base / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 121932931 | `DEMONSTRATED` |
| labels-base / constrained | `harness` | `PASSED` | `FAILED` | 1100 / 1900 | 276824107 | `DEMONSTRATED` |

## Comparison and costs

Machine codes are shared between languages. PASSED means the expected test behavior was observed; DEMONSTRATED establishes the scoped local claim; FAILED means the claim was not satisfied; NOT_ESTABLISHED means insufficient evidence; NOT_RUN means not executed.

One execution per method and condition: timings are descriptive, not evidence of a speed advantage. Transactional services and the verifier are shared. The comparison isolates no general AI contribution.

Child CPU and wall time, execution bytes, requests, retries and restarts are observed. Preparation, integration, peak memory and monetary costs are UNKNOWN. No rate, business budget or saving is invented. Zero human intervention applies only to autonomous execution.

AI: NOT RUN. No already-authorized local model was supplied; protocol adapter plumbing is not a model performance result.

**Comparative advantage:** `NOT_ESTABLISHED`
**Commercial value:** `NOT_ESTABLISHED`

## Critical failures and uncertainty

Runs without established safety: []
Unmet test assertions: []

Read each PASSPORT.en.md and RESULT.json for individual obligations, refusals, evidence, conditions and fresh-verification commands. Incomplete and unfavorable outcomes are preserved.
