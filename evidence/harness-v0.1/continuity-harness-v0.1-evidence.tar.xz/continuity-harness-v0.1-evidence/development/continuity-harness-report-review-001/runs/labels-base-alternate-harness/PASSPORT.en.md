# CONTINUITY Ω Harness v0.1 — Continuity Passport

[English](PASSPORT.en.md) · [Français](PASSPORT.fr.md)

**Local software execution · synthetic business data**

This Passport presents the supplied fresh assessment. It is a saved report of that assessment; use the verification command below to inspect the current evidence again.

A completed artifact is a durable local JSON software output. It is not printed goods, customer acceptance, a real supplier reservation, revenue, or external certification.

## Assessment

| Field | Recorded value |
| --- | --- |
| Test assertion | `PASSED` — Expected test behavior observed |
| Target verdict | `COMPLETED` — Completed |
| Evidence stage | `LOCAL_SOFTWARE_EXECUTION` — Local software execution with synthetic data |
| Complete-promise claim | `DEMONSTRATED` — Demonstrated within the declared stage |
| Safety within the tested model | `DEMONSTRATED` — Demonstrated within the declared stage |
| Authority binding | `DEMONSTRATED` — Demonstrated within the declared stage |
| Fresh verification status | `COMPLETE` — Completed record |
| Every obligation completed | Yes |
| Commercial value | `NOT_ESTABLISHED` — Not established |
| Authenticity of real customer instructions | `NOT_ESTABLISHED` — Not established |

Test behavior, target output, evidence stage, and the business claim are separate. A correctly refused request can satisfy a safety test while leaving an obligation unfulfilled. A passing test that exposes a false acceptance does not qualify the defective checker.

## Per-obligation outcomes

| Order | Recipient | Required units | Observed units | Accepted units | Outcome | Route |
| --- | --- | --- | --- | --- | --- | --- |
| LBL-100 | CUSTOMER-A | 1100 | 1100 | 1100 | `COMPLETED` — Completed | `backup` — Backup route |
| LBL-200 | CUSTOMER-B | 800 | 800 | 800 | `COMPLETED` — Completed | `backup` — Backup route |

### Order `LBL-100`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | 1b590fba52dad5b09041ead75f1b3057b233d8b1ac35d9d9d37905696fc9675c |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | 5 |

**Measured time to this output:** 90.902 ms (90902275 ns)

**Recorded reasons:**

None recorded.

### Order `LBL-200`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | a813e867578702ddec11b49ace3a5fd745ff391a2f5c95e7fe8af1c1f6b6c0e2 |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | 8 |

**Measured time to this output:** 95.592 ms (95591608 ns)

**Recorded reasons:**

None recorded.

## Totals for the retained promise

| Field | Recorded value |
| --- | --- |
| Required obligations | 2 |
| Accepted obligations | 2 |
| Required units | 1900 |
| Observed output units | 1900 |
| Accepted units | 1900 |
| Units not accepted | 0 |
| Late obligations | 0 |
| Incorrect obligations | 0 |
| Duplicated obligations | 0 |
| Unsupported completed obligations | 0 |

## Observed failures

None recorded.

## Unresolved evidence and claims

None recorded.

## Frozen conditions

| Field | Recorded value |
| --- | --- |
| Contract identifier | CONTRACT-labels-base-alternate |
| Contract version | 1 |
| Source events SHA-256 | 1f5119db7e2bd8f280a98b97ae72aecf3cc859750cbe6ced7710d48608eb2bca |
| Source observation cutoff | 5 |
| Authored source-completeness declaration | Yes |
| Logical deadline (ticks) | 100 |
| Configured wall deadline (ms) | 30000 |
| Configured recovery objective (ms) | 15000 |
| Capacity window [start, end) | {"end":100,"start":0} |
| Reservation lease (ticks) | 20 |
| Declared route capacities (units) | {"backup":2100,"primary":3000} |
| Allowed routes | ["primary","backup"] |
| Declared permissions | {"activation":true,"sharing":true} |
| Declared route dependencies | {"backup":"GRID-A-INDEPENDENT","primary":"GRID-A"} |
| Unavailable dependencies | ["GRID-A"] |

Ticks are controller-owned logical schedule positions, not measured hours. Milliseconds and nanoseconds below refer to monotonic local measurements. The configured wall deadline and recovery objective are acceptance limits, not achieved durations.

## Fault schedule and observations

| Machine code | Action | Target | Observed |
| --- | --- | --- | --- |
| `PRIMARY_UNAVAILABLE` — Primary route disabled | DISABLE | primary | Yes |

The complete event and intervention record is in controller.json. A listed schedule is not evidence that its faults occurred; the observed column records exact matches in the supplied controller record.

## Measurements and accounting gaps

| Field | Recorded value |
| --- | --- |
| Measured execution wall time | 121.933 ms (121932931 ns) |
| Observed child CPU: user | 87.398 ms (87397999 ns) |
| Observed child CPU: system | 9.120 ms (9119999 ns) |
| Peak resident memory (bytes) | NOT RECORDED / UNKNOWN |
| Measured run storage before final reports (bytes) | 81049 |
| Candidate broker requests | 8 |
| Recorded retries | 0 |
| Recorded worker restarts | 0 |
| Human interventions during this run | 0 |
| Recorded preparation labor (seconds) | NOT RECORDED / UNKNOWN |
| Recorded integration labor (seconds) | NOT RECORDED / UNKNOWN |
| Complete monetary cost | NOT RECORDED / UNKNOWN |
| Measured recovery/readiness time (ms) | NOT RECORDED / UNKNOWN |

Wall time is measured for the controller's local execution interval. CPU values are child-process usage deltas; they do not include all controller or development work. Storage is the measured run content before final controller/report files, excluding separately retained authority. Broker requests count candidate requests; internal controller operations remain in the event record. Zero human interventions concerns this autonomous run only.

Preparation and integration labor, unmeasured memory use, monetary rates, and complete business costs remain unknown when not recorded. No price or savings is inferred. One bounded observation per method and fixture does not establish a stable performance advantage.

| Field | Recorded value |
| --- | --- |
| Maximum simultaneous allocation by route | {"backup":1900,"primary":0} |
| Verified durable history transitions | 8 |
| Primary reconstruction verified | No |

## Identity, versions, and environment

| Field | Recorded value |
| --- | --- |
| Run identifier | labels-base-alternate-harness |
| Candidate method | `harness` — Harness-supported procedure |
| Scenario | `alternate` — Feasible alternate fulfillment |
| Recorded seed | 101 |
| Controller state | `COMPLETE` — Completed record |
| Execution start (UTC) | 2026-11-06T20:00:40.177652+00:00 |
| Retained contract SHA-256 | e93a1f0c5d258ba31c636305e6ab166db4aeaf611237f6b0297129f409dd5481 |
| Observed reference SHA-256 | fd8eacf9d48e21f2e8961eaa67e8a9e85868d60772733354f67ee2cc9a16b220 |
| Fresh verifier version | 0.1.0 |
| Independently supplied reference pin | fd8eacf9d48e21f2e8961eaa67e8a9e85868d60772733354f67ee2cc9a16b220 |
| Canonical structured-result SHA-256 | 83af80aabf6e6269cb305b8e491b6f46faeb496c5b91416e59c23da5a3bca1b2 |
| Implementation version | 0.1.0 |
| Recorded Git commit | 318f6d76868fa63ce3e25805e1c11bbfc057f981 |
| Working tree had uncommitted changes | Yes |
| Recorded Python runtime | NOT RECORDED / UNKNOWN |
| Recorded platform and kernel | NOT RECORDED / UNKNOWN |
| Recorded SQLite version | NOT RECORDED / UNKNOWN |

### Implementation source identities

| Path | SHA-256 |
| --- | --- |
| continuity_harness/__init__.py | `577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e` |
| continuity_harness/__main__.py | `abc2642c1258c4cd2a05461a9b287e1c7c3e729a8a8ea35a593283ac5c204d67` |
| continuity_harness/adapters.py | `ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0` |
| continuity_harness/candidate.py | `d5438f268c8a0d7004b9502ea075ecc177fe20d851c6d30c4c3e0e9e609a81d4` |
| continuity_harness/controller.py | `90d6e569ddb443a34cca2d7318068712a66eacb153d6c51907eefb0b5dc35ff9` |
| continuity_harness/fixtures.py | `4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e` |
| continuity_harness/reporting.py | `f5493961db3d8c06b79eaf969f31190eb70a6a818802a48646428977bee52e67` |
| continuity_harness/rpc.py | `f92e75d723cc61104c9a39eb3f1b3a949cae623889f9ec08f043827c66c5e595` |
| continuity_harness/sandbox.py | `7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f` |
| continuity_harness/schema.py | `4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c` |
| continuity_harness/service.py | `64ada485e99beb7e4eb6a81b52da0d33b0fd99beb9a49424e9ca27e28cc18262` |
| continuity_harness/suite.py | `5095c7dea8a7791c4f1af849a2056cd36eda460935c277090db1f152a6b04ac3` |
| continuity_harness/verifier.py | `f438d6146bcfcf7dda26f541577dc43f03bbbd88a6b48a65e6c759419a28b7c1` |
| experiments/harness-v0.1/spec.json | `8f08c8d524ab4aab9528728725d528eaa5f7e701403c9e176e8dff9b17380880` |

## Current evidence identities

| Path | SHA-256 |
| --- | --- |
| evidence/artifacts/LBL-100.json | `8976a57a419dccba306a293749fc2ed5937c6919f0b6945eebc637ec6ced72de` |
| evidence/artifacts/LBL-200.json | `2f8d20fb088bfd126c1b1c8e010d0da4e9f2ecbb0e0360a1b2c8335c36737a52` |
| evidence/service.sqlite | `7ddcdcd343e67f912c0c201ffacf8352f184898fc74c71dd7870546613c01ee0` |

The verifier compares current file bytes with the separately retained execution seal. These hashes identify bytes; they do not authenticate a real customer instruction or prove real-world completeness.

## Fresh verification and recorded commands

```sh
python3 -m continuity_harness --language en verify --run /tmp/continuity-harness-report-review-001/runs/labels-base-alternate-harness --authority /tmp/continuity-harness-report-review-001/authority/labels-base-alternate-harness --reference-sha256 fd8eacf9d48e21f2e8961eaa67e8a9e85868d60772733354f67ee2cc9a16b220
```

Run from the recorded implementation checkout. Supply the independently retained reference pin from the suite index; do not derive a replacement pin from candidate-controlled data. Verification does not overwrite this saved Passport.

## Trust assumptions and remaining limits

| Field | Recorded value |
| --- | --- |
| Candidate-isolation mechanism | SECCOMP_BPF |
| Isolation applied | Yes |
| Isolation probe observations | {"authority_open_denied":true,"network_denied":true,"process_inspection_denied":true,"spawn_denied":true,"workspace_open_denied":true} |
| Declared trust scope | TRUSTED_HOST_CONTROLLER_CLOCK_AND_VERIFIER_AUTHORED_SYNTHETIC_SOURCE |

The host, controller, authored journal, local services, clock, and acceptance verifier are trusted within the declared failure model. Shipped candidate code and imports are trusted before seccomp activation; no arbitrary third-party plugin is supported. The candidate receives bounded data after filtering and performs effects only through the allowlisted broker. This does not protect against a malicious host administrator.

Source identity, custody, completeness, and byte integrity are different properties. A finite set of local tests is not a general proof, universal exactly-once delivery, independent external certification, or commercial validation. A synthetic transfer establishes only the measured transfer under its recorded conditions.

No AI performance is established by an unavailable model, a mock, or a recorded response. The AI arm is NOT RUN unless an actual authorized local capability was executed and measured.

Structured records: [RESULT.json](RESULT.json) · [controller.json](controller.json). Both language Passports are derived from the same structured result.
