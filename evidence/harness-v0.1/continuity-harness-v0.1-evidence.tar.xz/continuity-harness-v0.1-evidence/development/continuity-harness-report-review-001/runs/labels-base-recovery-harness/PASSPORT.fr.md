# CONTINUITÉ Ω — Banc d’essai et de vérification v0.1 — Passeport de continuité

[English](PASSPORT.en.md) · [Français](PASSPORT.fr.md)

**Exécution logicielle locale · données commerciales synthétiques**

Ce Passeport présente l’évaluation fraîche fournie. Il en constitue un rapport enregistré ; utiliser la commande ci-dessous pour examiner de nouveau les preuves actuelles.

Un artefact terminé est une sortie logicielle JSON locale durable. Il ne constitue ni bien imprimé, ni acceptation client, ni réservation réelle de fournisseur, ni revenu, ni certification externe.

## Évaluation

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | `PASSED` — Comportement attendu du test observé |
| Verdict du composant testé | `COMPLETED` — Terminé |
| Stade des preuves | `LOCAL_SOFTWARE_EXECUTION` — Exécution logicielle locale avec données synthétiques |
| Affirmation sur la promesse complète | `DEMONSTRATED` — Démontré dans le stade déclaré |
| Sûreté dans le modèle testé | `DEMONSTRATED` — Démontré dans le stade déclaré |
| Liaison à l’autorité | `DEMONSTRATED` — Démontré dans le stade déclaré |
| État de la vérification fraîche | `COMPLETE` — Enregistrement terminé |
| Toutes les obligations terminées | Oui |
| Valeur commerciale | `NOT_ESTABLISHED` — Non établi |
| Authenticité d’instructions clients réelles | `NOT_ESTABLISHED` — Non établi |

Le comportement du test, la sortie du composant, le stade des preuves et l’affirmation métier sont distincts. Un refus correct peut satisfaire un test de sûreté tout en laissant une obligation inexécutée. Un test réussi révélant une acceptation indue ne qualifie pas le vérificateur défectueux.

## Résultats par obligation

| Commande | Destinataire | Unités requises | Unités observées | Unités acceptées | Résultat | Voie |
| --- | --- | --- | --- | --- | --- | --- |
| LBL-100 | CUSTOMER-A | 1100 | 1100 | 1100 | `COMPLETED` — Terminé | `primary` — Voie principale |
| LBL-200 | CUSTOMER-B | 800 | 800 | 800 | `COMPLETED` — Terminé | `primary` — Voie principale |

### Commande `LBL-100`

| Champ | Valeur consignée |
| --- | --- |
| Produit | LABEL-A |
| SHA-256 de la spécification finale | 1b590fba52dad5b09041ead75f1b3057b233d8b1ac35d9d9d37905696fc9675c |
| Échéance logique (unités) | 100 |
| Position d’achèvement (unités) | 6 |

**Durée mesurée jusqu’à cette sortie:** 98,381 ms (98380614 ns)

**Motifs consignés:**

Aucun élément consigné.

### Commande `LBL-200`

| Champ | Valeur consignée |
| --- | --- |
| Produit | LABEL-A |
| SHA-256 de la spécification finale | a813e867578702ddec11b49ace3a5fd745ff391a2f5c95e7fe8af1c1f6b6c0e2 |
| Échéance logique (unités) | 100 |
| Position d’achèvement (unités) | 9 |

**Durée mesurée jusqu’à cette sortie:** 103,347 ms (103346971 ns)

**Motifs consignés:**

Aucun élément consigné.

## Totaux de la promesse conservée

| Champ | Valeur consignée |
| --- | --- |
| Obligations requises | 2 |
| Obligations acceptées | 2 |
| Unités requises | 1900 |
| Unités de sortie observées | 1900 |
| Unités acceptées | 1900 |
| Unités non acceptées | 0 |
| Obligations tardives | 0 |
| Obligations incorrectes | 0 |
| Obligations dupliquées | 0 |
| Obligations terminées sans justification | 0 |

## Échecs observés

Aucun élément consigné.

## Preuves et affirmations non résolues

Aucun élément consigné.

## Conditions figées

| Champ | Valeur consignée |
| --- | --- |
| Identifiant du contrat | CONTRACT-labels-base-recovery |
| Version du contrat | 1 |
| SHA-256 des événements sources | 1f5119db7e2bd8f280a98b97ae72aecf3cc859750cbe6ced7710d48608eb2bca |
| Borne d’observation de la source | 5 |
| Déclaration de complétude de la source rédigée | Oui |
| Échéance logique (unités) | 100 |
| Échéance réelle configurée (ms) | 30000 |
| Objectif de reprise configuré (ms) | 15000 |
| Fenêtre de capacité [début, fin) | {"end":100,"start":0} |
| Durée de réservation (unités logiques) | 20 |
| Capacités déclarées des voies (unités) | {"backup":2100,"primary":3000} |
| Voies autorisées | ["primary","backup"] |
| Permissions déclarées | {"activation":true,"sharing":true} |
| Dépendances déclarées des voies | {"backup":"GRID-A-INDEPENDENT","primary":"GRID-A"} |
| Dépendances indisponibles | [] |

Les unités logiques appartiennent au calendrier du contrôleur ; ce ne sont pas des heures mesurées. Les millisecondes et nanosecondes ci-dessous représentent des mesures locales monotones. L’échéance réelle et l’objectif de reprise configurés sont des limites d’acceptation, pas des durées atteintes.

## Calendrier des pannes et observations

Aucun élément consigné.

Le journal complet des événements et interventions se trouve dans controller.json. Un calendrier ne prouve pas à lui seul que les pannes ont eu lieu ; la colonne d’observation indique les correspondances exactes dans l’enregistrement fourni du contrôleur.

## Mesures et lacunes comptables

| Champ | Valeur consignée |
| --- | --- |
| Durée réelle d’exécution mesurée | 121,938 ms (121938239 ns) |
| Processeur des enfants observé : utilisateur | 72,597 ms (72597000 ns) |
| Processeur des enfants observé : système | 26,656 ms (26656000 ns) |
| Mémoire résidente maximale (octets) | NON CONSIGNÉ / INCONNU |
| Stockage mesuré avant rapports finaux (octets) | 80969 |
| Demandes du candidat au relais | 9 |
| Nouvelles tentatives consignées | 0 |
| Redémarrages de processus consignés | 0 |
| Interventions humaines pendant cette exécution | 0 |
| Travail de préparation consigné (secondes) | NON CONSIGNÉ / INCONNU |
| Travail d’intégration consigné (secondes) | NON CONSIGNÉ / INCONNU |
| Coût monétaire complet | NON CONSIGNÉ / INCONNU |
| Durée mesurée de reprise/préparation (ms) | 91 |

Le temps réel mesure l’intervalle d’exécution locale du contrôleur. Les valeurs processeur sont les différences d’utilisation des processus enfants ; elles n’incluent pas tout le travail du contrôleur ou du développement. Le stockage mesure le contenu de l’exécution avant les fichiers finaux de contrôle/rapport, sans l’autorité conservée séparément. Les demandes au relais comptent celles du candidat ; les opérations internes du contrôleur restent dans le journal. Zéro intervention humaine ne concerne que cette exécution autonome.

Le travail de préparation et d’intégration, la mémoire non mesurée, les taux monétaires et les coûts commerciaux complets restent inconnus lorsqu’ils ne sont pas consignés. Aucun prix ni économie n’est déduit. Une observation bornée par méthode et par cas n’établit pas un avantage stable de performance.

| Champ | Valeur consignée |
| --- | --- |
| Allocation simultanée maximale par voie | {"backup":0,"primary":1900} |
| Transitions durables vérifiées | 8 |
| Reconstruction principale vérifiée | Oui |

## Identité, versions et environnement

| Champ | Valeur consignée |
| --- | --- |
| Identifiant de l’exécution | labels-base-recovery-harness |
| Méthode candidate | `harness` — Procédure accompagnée par le banc d’essai |
| Scénario | `recovery` — Reprise principale réalisable |
| Graine consignée | 101 |
| État du contrôleur | `COMPLETE` — Enregistrement terminé |
| Début d’exécution (UTC) | 2026-11-06T20:00:40.021329+00:00 |
| SHA-256 du contrat conservé | 91d531b785af853760d5bd43f3f9e8afc5e3c79ab1aa579c6d8b7b40d536f9c6 |
| SHA-256 de la référence observée | 7bfb6af4cbff7dcdc6da1b78561e22e0eb47c53436f14decaa5790195ced92aa |
| Version du vérificateur frais | 0.1.0 |
| Empreinte de référence fournie indépendamment | 7bfb6af4cbff7dcdc6da1b78561e22e0eb47c53436f14decaa5790195ced92aa |
| SHA-256 du résultat structuré canonique | 5d69649a741c2f28432ec198ef58e2d4a8a819e5976f9149d0286657153ab6f7 |
| Version de l’implémentation | 0.1.0 |
| Commit Git consigné | 318f6d76868fa63ce3e25805e1c11bbfc057f981 |
| Arbre de travail avec modifications non commises | Oui |
| Environnement Python consigné | NON CONSIGNÉ / INCONNU |
| Plateforme et noyau consignés | NON CONSIGNÉ / INCONNU |
| Version de SQLite consignée | NON CONSIGNÉ / INCONNU |

### Identités des sources d’implémentation

| Chemin | SHA-256 |
| --- | --- |
| continuity_harness/__init__.py | `577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e` |
| continuity_harness/__main__.py | `abc2642c1258c4cd2a05461a9b287e1c7c3e729a8a8ea35a593283ac5c204d67` |
| continuity_harness/adapters.py | `ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0` |
| continuity_harness/candidate.py | `d5438f268c8a0d7004b9502ea075ecc177fe20d851c6d30c4c3e0e9e609a81d4` |
| continuity_harness/controller.py | `90d6e569ddb443a34cca2d7318068712a66eacb153d6c51907eefb0b5dc35ff9` |
| continuity_harness/fixtures.py | `4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e` |
| continuity_harness/reporting.py | `f5493961db3d8c06b79eaf969f31190eb70a6a818802a48646428977bee52e67` |
| continuity_harness/rpc.py | `f92e75d723cc61104c9a39eb3f1b3a949cae623889f9ec08f043827c66c5e595` |
| continuity_harness/sandbox.py | `7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f` |
| continuity_harness/schema.py | `4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c` |
| continuity_harness/service.py | `64ada485e99beb7e4eb6a81b52da0d33b0fd99beb9a49424e9ca27e28cc18262` |
| continuity_harness/suite.py | `5095c7dea8a7791c4f1af849a2056cd36eda460935c277090db1f152a6b04ac3` |
| continuity_harness/verifier.py | `f438d6146bcfcf7dda26f541577dc43f03bbbd88a6b48a65e6c759419a28b7c1` |
| experiments/harness-v0.1/spec.json | `8f08c8d524ab4aab9528728725d528eaa5f7e701403c9e176e8dff9b17380880` |

## Identités des preuves actuelles

| Chemin | SHA-256 |
| --- | --- |
| evidence/artifacts/LBL-100.json | `311d8f852ac2bdf3d05195fb84aaf0ef644e864396e67f633655f7494c4583fa` |
| evidence/artifacts/LBL-200.json | `849c4ba589b09bb9e1ccc0046d974736ffa0c78cb08a00d18a0a7e6ddb316f32` |
| evidence/service.sqlite | `9e7571f6353f2d94667d2dd7065702005795d5536641b0b2d81583aca30eee1a` |

Le vérificateur compare les octets actuels au sceau d’exécution conservé séparément. Ces empreintes identifient des octets ; elles n’authentifient pas une instruction client réelle et ne prouvent pas la complétude du monde réel.

## Vérification fraîche et commandes consignées

```sh
python3 -m continuity_harness --language fr verify --run /tmp/continuity-harness-report-review-001/runs/labels-base-recovery-harness --authority /tmp/continuity-harness-report-review-001/authority/labels-base-recovery-harness --reference-sha256 7bfb6af4cbff7dcdc6da1b78561e22e0eb47c53436f14decaa5790195ced92aa
```

Exécuter depuis la copie de l’implémentation consignée. Fournir l’empreinte de référence conservée indépendamment dans l’index de la suite ; ne pas la remplacer par une valeur dérivée des données candidates. La vérification n’écrase pas ce Passeport enregistré.

## Hypothèses de confiance et limites restantes

| Champ | Valeur consignée |
| --- | --- |
| Mécanisme d’isolement du candidat | SECCOMP_BPF |
| Isolement appliqué | Oui |
| Observations des tests d’isolement | {"authority_open_denied":true,"network_denied":true,"process_inspection_denied":true,"spawn_denied":true,"workspace_open_denied":true} |
| Périmètre de confiance déclaré | TRUSTED_HOST_CONTROLLER_CLOCK_AND_VERIFIER_AUTHORED_SYNTHETIC_SOURCE |

L’hôte, le contrôleur, le journal rédigé, les services locaux, l’horloge et le vérificateur d’acceptation sont de confiance dans le modèle de panne déclaré. Le code candidat fourni et ses imports sont de confiance avant l’activation de seccomp ; aucun module tiers arbitraire n’est pris en charge. Le candidat reçoit des données bornées après filtrage et agit uniquement par le relais autorisé. Cela ne protège pas contre un administrateur malveillant de l’hôte.

L’identité, la garde, la complétude des sources et l’intégrité des octets sont des propriétés différentes. Des tests locaux finis ne constituent ni preuve générale, ni garantie universelle d’exécution exactement une fois, ni certification externe indépendante, ni validation commerciale. Un transfert synthétique n’établit que le transfert mesuré dans les conditions consignées.

Un modèle indisponible, un substitut ou une réponse enregistrée n’établissent aucune performance d’IA. Le groupe IA est NON EXÉCUTÉ à moins qu’une véritable capacité locale autorisée ait été exécutée et mesurée.

Enregistrements structurés : [RESULT.json](RESULT.json) · [controller.json](controller.json). Les deux Passeports linguistiques dérivent du même résultat structuré.
