# CONTINUITY Ω Harness v0.1 — Continuity Passport

[English](PASSPORT.en.md) · [Français](PASSPORT.fr.md)

**Local software execution · synthetic business data**

This Passport presents the supplied fresh assessment. It is a saved report of that assessment; use the verification command below to inspect the current evidence again.

A completed artifact is a durable local JSON software output. It is not printed goods, customer acceptance, a real supplier reservation, revenue, or external certification.

## Challenge and assessment subject

**Mutant checker ignores permission revocation**

| Field | Recorded value |
| --- | --- |
| Challenge identifier | mutant-ignores-revocation |
| Assessed component | `MUTATED_VERIFIER` — Deliberately mutated verifier |
| Declared claim | The mutated checker rejects completion after a recorded permission revocation. |
| Expected observation | A copied controller record receives an explicitly synthetic revocation and a test-authority reseal. The correct checker rejects it; the mutant falsely accepts it. |
| Recorded observation | Reference full-promise claim: FAILED; tested target: DEMONSTRATED; accepted reference quantity: 0 / 1900. The checker defect was exposed; a passing outer test does not qualify this mutant. |
| Reference full-promise claim | `FAILED` — Failed |
| Tested component's assessment record | TARGET_RESULT.json |
| Independent reference assessment record | REFERENCE_RESULT.json |
| Source execution evidence | run |

**Deliberate mutation configuration:** {"controller_after_sha256":"11ee47a72629643db64dfb6a94fdeb6f9da353de6362c9dbab7b547c7e866b49","controller_before_sha256":"a87b44f0da5855911a18b1801b72bed1f68e93bf178541b9931139ef980fc3f5","event":{"detail":{"permission":"activation"},"event":"PERMISSION_REVOKED","monotonic_ns":24501268718967,"tick":0},"execution_seal_after_sha256":"51810e6230df5f697657a5fb2fbc01ba3424e4d99787c3a538f33f3bc801cc4e","execution_seal_before_sha256":"a2f426ab07064e249a58ccfdca3add739a52b03c639f187a80c9c5fe9ef44cc2","hook":"continuity_harness.verifier._revoked","kind":"SYNTHETIC_RECORDED_REVOCATION","live_revocation_was_executed":false,"replacement":"Always return None.","test_authority_resealed_copy":true}

The outer assertion, target verdict and claim status assess the named checker or procedure property. Per-obligation outcomes, totals and underlying claim status reproduce the independent reference assessment of the exact challenged evidence. A test that successfully exposes a defective checker does not qualify that checker. TARGET_RESULT.json and REFERENCE_RESULT.json remain distinct records.

## Assessment

| Field | Recorded value |
| --- | --- |
| Test assertion | `PASSED` — Expected test behavior observed |
| Target verdict | `DEMONSTRATED` — Demonstrated within the declared stage |
| Evidence stage | `CHECKER_MUTATION_EXERCISE` — Deliberately mutated checker exercise |
| Declared checker or procedure claim | `FAILED` — Failed |
| Safety within the tested model | `FAILED` — Failed |
| Authority binding | `DEMONSTRATED` — Demonstrated within the declared stage |
| Fresh verification status | `COMPLETE` — Completed record |
| Every obligation completed | No |
| Commercial value | `NOT_ESTABLISHED` — Not established |
| Authenticity of real customer instructions | `NOT_ESTABLISHED` — Not established |

Test behavior, target output, evidence stage, and the business claim are separate. A correctly refused request can satisfy a safety test while leaving an obligation unfulfilled. A passing test that exposes a false acceptance does not qualify the defective checker.

## Per-obligation outcomes

These obligation facts are the reference verifier's assessment, not the tested checker's claimed verdict.

| Order | Recipient | Required units | Observed units | Accepted units | Outcome | Route |
| --- | --- | --- | --- | --- | --- | --- |
| LBL-100 | CUSTOMER-A | 1100 | 1100 | 0 | `INCORRECT` — Incorrect | `primary` — Primary route |
| LBL-200 | CUSTOMER-B | 800 | 800 | 0 | `INCORRECT` — Incorrect | `primary` — Primary route |

### Order `LBL-100`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | 1b590fba52dad5b09041ead75f1b3057b233d8b1ac35d9d9d37905696fc9675c |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | 6 |
| Post-export monotonic observation (ns) | 24501371724479 |

**Durable completion observed no later than:** 103.006 ms (103005513 ns)

**Producer transition before commit (elapsed):** 100.023 ms (100022865 ns)

**Recorded reasons:**

- `UNAUTHORIZED_ACTIVATION`: Execution occurred without activation permission.

### Order `LBL-200`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | a813e867578702ddec11b49ace3a5fd745ff391a2f5c95e7fe8af1c1f6b6c0e2 |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | 9 |
| Post-export monotonic observation (ns) | 24501376370170 |

**Durable completion observed no later than:** 107.651 ms (107651204 ns)

**Producer transition before commit (elapsed):** 105.573 ms (105572602 ns)

**Recorded reasons:**

- `UNAUTHORIZED_ACTIVATION`: Execution occurred without activation permission.

## Totals for the retained promise

| Field | Recorded value |
| --- | --- |
| Required obligations | 2 |
| Accepted obligations | 0 |
| Required units | 1900 |
| Observed output units | 1900 |
| Accepted units | 0 |
| Units not accepted | 1900 |
| Late obligations | 0 |
| Incorrect obligations | 2 |
| Duplicated obligations | 0 |
| Unsupported completed obligations | 0 |

## Observed failures

| Machine code | Explanation | Order | Original technical detail |
| --- | --- | --- | --- |
| `UNAUTHORIZED_ACTIVATION` | Execution occurred without activation permission. | LBL-100 | revoked |
| `UNAUTHORIZED_ACTIVATION` | Execution occurred without activation permission. | LBL-200 | revoked |
| `ALL_OBLIGATIONS_NOT_COMPLETED` | The complete customer promise was not fulfilled. | NOT RECORDED / UNKNOWN |  |

## Unresolved evidence and claims

None recorded.

## Frozen conditions

| Field | Recorded value |
| --- | --- |
| Contract identifier | CONTRACT-labels-base-recovery |
| Contract schema | continuity-harness/contract/v1 |
| Contract version | 1 |
| Declared exercise mode | SYNTHETIC_LOCAL_EXECUTION |
| Source events SHA-256 | 1f5119db7e2bd8f280a98b97ae72aecf3cc859750cbe6ced7710d48608eb2bca |
| Source observation cutoff | 5 |
| Authored source-completeness declaration | Yes |
| Logical deadline (ticks) | 100 |
| Configured wall deadline (ms) | 30000 |
| Configured recovery objective (ms) | 15000 |
| Capacity window [start, end) | {"end":100,"start":0} |
| Reservation lease (ticks) | 20 |
| Declared route capacities (units) | {"backup":2100,"primary":3000} |
| Allowed routes | ["primary","backup"] |
| Declared permissions | {"activation":true,"sharing":true} |
| Declared route dependencies | {"backup":"GRID-A-INDEPENDENT","primary":"GRID-A"} |
| Unavailable dependencies | [] |
| Configured fixture currency | USD |
| Configured fixture budget (minor units) | 0 |
| Frozen comparison conditions | {"fixture_id":"labels-base","held_out":false,"information":"EQUAL","resource_policy":"SHARED_SERVICES","suite_id":"CONTINUITY-HARNESS-001"} |

Ticks are controller-owned logical schedule positions, not measured hours. Milliseconds and nanoseconds below refer to monotonic local measurements. Durable completion uses the trusted post-export observation as a conservative upper bound, distinct from the producer's precommit transition timestamp. Observation delay can reject a late bound even if persistence actually occurred earlier. The configured wall deadline and recovery objective are acceptance limits, not achieved durations.

## Fault schedule and observations

None recorded.

The complete event and intervention record is in controller.json. A listed schedule is not evidence that its faults occurred; the observed column records exact matches in the supplied controller record.

## Measurements and accounting gaps

| Field | Recorded value |
| --- | --- |
| Origin of execution-resource observations | `COPIED_POSITIVE_CONTROL_EXECUTION` — Reused observations from the positive control |

| Field | Recorded value |
| --- | --- |
| Measured reference-verification duration | 8.339 ms (8338544 ns) |
| Additional target-verification duration | 7.804 ms (7803986 ns) |
| Measured challenge duration before reporting | 25.317 ms (25317367 ns) |

Execution resources below belong to the recorded source execution. If resource_origin is COPIED_POSITIVE_CONTROL_EXECUTION, those observations are reused evidence, not another measured execution to add to a total. The challenge's fresh verification durations are recorded separately; they do not establish a comparative performance advantage.

| Field | Recorded value |
| --- | --- |
| Measured execution wall time | 124.106 ms (124105896 ns) |
| Observed child CPU: user | 86.459 ms (86459000 ns) |
| Observed child CPU: system | 19.385 ms (19385000 ns) |
| Observed controller CPU: user | 6.112 ms (6111999 ns) |
| Observed controller CPU: system | 0.678 ms (678000 ns) |
| Peak resident memory (bytes) | NOT RECORDED / UNKNOWN |
| Measured run storage before final reports (bytes) | 80978 |
| Candidate broker requests | 9 |
| Recorded retries | 0 |
| Recorded worker restarts | 0 |
| Human interventions during this run | 0 |
| Recorded preparation labor (seconds) | NOT RECORDED / UNKNOWN |
| Recorded integration labor (seconds) | NOT RECORDED / UNKNOWN |
| Complete monetary cost | NOT RECORDED / UNKNOWN |
| Measured recovery/readiness time (ms) | 94 |

Wall time is measured for the controller's local execution interval. Child and controller CPU values are separate process-usage deltas where recorded. Verification/reporting CPU and development work are not included. Storage is the measured run content before final controller/report files and suite-index metadata, excluding separately retained authority. Broker requests count candidate requests; internal controller operations remain in the event record. Zero human interventions concerns this autonomous run only.

Preparation and integration labor, unmeasured memory use, monetary rates, and complete business costs remain unknown when not recorded. The configured currency and budget are fixture inputs, not measured spending or a customer's budget. No price or savings is inferred. One bounded observation per method and fixture does not establish a stable performance advantage.

| Field | Recorded value |
| --- | --- |
| Maximum simultaneous allocation by route | {"backup":0,"primary":1900} |
| Verified durable history transitions | 8 |
| Primary reconstruction verified | Yes |

## Identity, versions, and environment

| Field | Recorded value |
| --- | --- |
| Run identifier | challenge-positive-d75eed3e71f5 |
| Candidate method | `harness` — Harness-supported procedure |
| Scenario | `recovery` — Feasible primary recovery |
| Recorded seed | 101 |
| Controller state | `COMPLETE` — Completed record |
| Execution start (UTC) | 2026-11-06T20:25:03.370440+00:00 |
| Retained contract SHA-256 | 779949bde03a0c361b7c832f6cd5572eb86c342f3597e5e0d324ffce734feba1 |
| Observed reference SHA-256 | d581fed4cc7b28ae320b0d6b0a417cacbbe82d818dd700bae8c7a0bbb09c7718 |
| Fresh verifier version | 0.1.0 |
| Verification-result schema | continuity-harness/challenge/v1 |
| Retained-reference schema | continuity-harness/reference/v1 |
| Independently supplied reference pin | d581fed4cc7b28ae320b0d6b0a417cacbbe82d818dd700bae8c7a0bbb09c7718 |
| Canonical structured-result SHA-256 | 9a3697c9e649db42fa78ea820267937041d990ce545dca240125c8bb59688594 |
| Implementation version | 0.1.0 |
| Recorded Git commit | 5c92fd03a258a3f4845c50a5b37e7a14cd2aa40c |
| Working tree had uncommitted changes | No |
| Recorded Python runtime | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Recorded platform and kernel | Linux-6.18.57-x86_64-with-glibc2.39 |
| Recorded SQLite version | 3.53.1 |
| Recorded working directory | /workspace/scratch/b1d5891eb025/continuity-harness-qualified |

### Implementation source identities

| Path | SHA-256 |
| --- | --- |
| continuity_harness/__init__.py | `577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e` |
| continuity_harness/__main__.py | `c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8` |
| continuity_harness/adapters.py | `ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0` |
| continuity_harness/candidate.py | `938d73f546c774452b22823639beda4b0f89d911abe429da48039bf1808e3141` |
| continuity_harness/challenges.py | `d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d` |
| continuity_harness/controller.py | `acf262f8385213188aefba5ed357cde2506117cd9a04237bb4fdc7d1a666a83a` |
| continuity_harness/fixtures.py | `4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e` |
| continuity_harness/reporting.py | `08e11beb3680f2f4ffb1808faec37e132aeecad281acc6cb6c4ad06dfe36960b` |
| continuity_harness/rpc.py | `36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745` |
| continuity_harness/sandbox.py | `7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f` |
| continuity_harness/schema.py | `4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c` |
| continuity_harness/service.py | `587e6227e3d98d6af942fbabff19f49e0e2f47bda0288fbe6616d73bc56367f5` |
| continuity_harness/suite.py | `bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc` |
| continuity_harness/verifier.py | `2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38` |
| experiments/harness-v0.1/PROVENANCE.json | `0c8697da8cd4eb8635cf5413c0f3e0b4c2dc82ea6cd7d8bc6cac194bed7f5f32` |
| experiments/harness-v0.1/spec.json | `8f08c8d524ab4aab9528728725d528eaa5f7e701403c9e176e8dff9b17380880` |

## Current evidence identities

| Path | SHA-256 |
| --- | --- |
| evidence/artifacts/LBL-100.json | `78f4c844857b3ef5e8d77f795882858088deeb26d45c408b3d2627c6f9155c47` |
| evidence/artifacts/LBL-200.json | `00306e5e80d82098c63f152128ccf1833012c62d45b51f24467f6dd2b0a78f81` |
| evidence/service.sqlite | `06d976ddecc2ec930167c5d029abf49a7a379450b72bf39eeb42ace960f78e19` |

The verifier compares current file bytes with the separately retained execution seal. These hashes identify bytes; they do not authenticate a real customer instruction or prove real-world completeness.

## Fresh verification and recorded commands

```sh
python3 -m continuity_harness --language en verify --run /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/challenges/cases/mutant-ignores-revocation/run --authority /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/challenges/cases/mutant-ignores-revocation/authority --reference-sha256 d581fed4cc7b28ae320b0d6b0a417cacbbe82d818dd700bae8c7a0bbb09c7718
```

Run from the recorded implementation checkout. Supply the independently retained reference pin from the suite index; do not derive a replacement pin from candidate-controlled data. Verification does not overwrite this saved Passport.

### Other commands recorded for this execution

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m continuity_harness --language fr challenge --out /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/challenges
```


## Trust assumptions and remaining limits

| Field | Recorded value |
| --- | --- |
| Candidate-isolation mechanism | SECCOMP_BPF |
| Isolation applied | Yes |
| Isolation probe observations | {"authority_open_denied":true,"network_denied":true,"process_inspection_denied":true,"spawn_denied":true,"workspace_open_denied":true} |
| Declared trust scope | TRUSTED_HOST_CONTROLLER_CLOCK_AND_VERIFIER_AUTHORED_SYNTHETIC_SOURCE |

The host, controller, authored journal, local services, clock, and acceptance verifier are trusted within the declared failure model. Shipped candidate code and imports are trusted before seccomp activation; no arbitrary third-party plugin is supported. The candidate receives bounded data after filtering and performs effects only through the allowlisted broker. This does not protect against a malicious host administrator.

Source identity, custody, completeness, and byte integrity are different properties. A finite set of local tests is not a general proof, universal exactly-once delivery, independent external certification, or commercial validation. A synthetic transfer establishes only the measured transfer under its recorded conditions.

No AI performance is established by an unavailable model, a mock, or a recorded response. The AI arm is NOT RUN unless an actual authorized local capability was executed and measured.

Structured records: [CHALLENGE.json](CHALLENGE.json) · [TARGET_RESULT.json](TARGET_RESULT.json) · [REFERENCE_RESULT.json](REFERENCE_RESULT.json) · [controller.json](run/controller.json). Both language Passports are derived from the same outer challenge record; the target and reference assessments remain separate.
