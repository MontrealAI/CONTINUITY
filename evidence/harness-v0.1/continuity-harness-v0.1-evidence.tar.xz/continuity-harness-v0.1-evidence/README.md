# CONTINUITY Ω Harness v0.1 / CONTINUITÉ Ω — Banc d’essai et de vérification

## English

This package preserves actual local synthetic execution evidence, including an unsuccessful qualification attempt. The qualified implementation is `fa9da1f54acfaa82510a4b6b805c2980d3e5b31d` in https://github.com/MontrealAI/CONTINUITY. The code uses Linux x86_64, Python 3.10+ and available seccomp BPF; no external Python dependencies or model are required.

`RESULTS.json` is the release record. The accepted second attempt is under `attempt-2/`: its demonstration, 24 executed conventional/Harness comparison cells, 12 explicit AI NOT RUN entries, eight adversarial observations, retained authority, durable databases, artifacts and full English/French Passports are included. Both comparison methods preserve the same per-obligation outcomes; no general speed, cost, AI or commercial advantage is established.

The first attempt remains at the package root (`comparison/`, `demonstration/`, `challenges/`, `QUALIFICATION.json`). Its saved comparison summary initially passed, but separate fresh verification failed because one run acquired visible unsealed SQLite sidecars. `validation/compare-fresh-diagnostic.json` and `validation/sqlite-sidecar-diagnosis/` preserve that disagreement and investigation. Do not treat the old favorable summary as current acceptance. The reappearance mechanism remains unestablished. The corrected implementation seals a standalone database only after state agreement, worker shutdown, integrity checks and synchronization; fresh journal checks remain strict.

From a checkout of the qualified code, after extracting this package into a new directory:

```sh
python3 -m continuity_harness --language en verify-suite --in-dir /PATH/continuity-harness-v0.1-evidence/attempt-2/comparison
python3 -m continuity_harness --language fr verify-suite --in-dir /PATH/continuity-harness-v0.1-evidence/attempt-2/demonstration
```

The first attempt's `comparison/` is expected to fail fresh qualification. Individual constrained runs correctly return exit code 3 for the unfulfilled whole promise, even when the suite's expected-partial assertion passes. Challenge directories retain separate target, reference and outer results; a deliberately defective checker can report DEMONSTRATED while its qualification is FAILED. To reproduce mutations, run `python3 -m continuity_harness challenge --out NEW_DIRECTORY`; ordinary fresh verification does not activate a mutant.

Keep the original reference pins in each suite INDEX or challenge record outside candidate control. Matching hashes bind bytes; they do not authenticate real customers. `MANIFEST.json` inventories package bytes; it is not a customer signature. Historical development observations and captured failed test logs remain under `development/` and `validation/` and are not qualified comparative trials.

These artifacts are software outputs, not printed goods or deliveries. Host, controller, service, verifier, journal and clock remain trusted. Full preparation/integration labor, peak memory, monetary rates and business costs are unknown. The first and second comparisons must not be pooled as independent favorable observations.

## Français

Ce paquet conserve les preuves d’exécutions synthétiques locales réelles, y compris une tentative de qualification infructueuse. L’implémentation qualifiée est `fa9da1f54acfaa82510a4b6b805c2980d3e5b31d` dans https://github.com/MontrealAI/CONTINUITY. Le code exige Linux x86_64, Python 3.10 ou ultérieur et seccomp BPF disponible ; aucun paquet Python externe ni modèle n’est requis.

`RESULTS.json` constitue le registre de publication. La deuxième tentative qualifiée réside sous `attempt-2/` : démonstration, 24 cellules comparatives conventionnelles/banc d’essai réellement exécutées, 12 entrées IA explicitement NON EXÉCUTÉES, huit observations contradictoires, autorités conservées, bases durables, pièces et passeports complets français/anglais. Les deux méthodes préservent les mêmes obligations ; aucun avantage général de vitesse, de coût, d’IA ou de valeur commerciale n’est établi.

La première tentative reste à la racine (`comparison/`, `demonstration/`, `challenges/`, `QUALIFICATION.json`). Son résumé comparatif enregistré annonçait initialement une réussite, mais une vérification fraîche distincte a échoué : des fichiers auxiliaires SQLite non scellés sont devenus visibles pour une exécution. `validation/compare-fresh-diagnostic.json` et `validation/sqlite-sidecar-diagnosis/` conservent cette divergence et l’enquête. L’ancien résumé favorable ne vaut pas acceptation actuelle. Le mécanisme de réapparition reste non établi. L’implémentation corrigée ne scelle une base autonome qu’après accord des états, arrêt des processus, contrôles d’intégrité et synchronisation ; les contrôles des journaux restent stricts.

Depuis une copie du code qualifié, après extraction dans un nouveau répertoire :

```sh
python3 -m continuity_harness --language fr verify-suite --in-dir /CHEMIN/continuity-harness-v0.1-evidence/attempt-2/comparison
python3 -m continuity_harness --language fr verify-suite --in-dir /CHEMIN/continuity-harness-v0.1-evidence/attempt-2/demonstration
```

La première `comparison/` doit échouer à la qualification fraîche. Une exécution contrainte individuelle renvoie correctement le code 3 pour la promesse globale non tenue, même lorsque l’assertion de réalisation partielle attendue réussit. Les épreuves conservent séparément les résultats du composant, de référence et de l’évaluation externe ; un vérificateur délibérément défectueux peut annoncer DEMONSTRATED alors que sa qualification échoue. Pour reproduire les mutations, exécuter `python3 -m continuity_harness challenge --out NOUVEAU_REPERTOIRE` ; une vérification fraîche ordinaire n’active aucun mutant.

Conserver les empreintes originales des références dans l’INDEX de chaque suite ou le registre contradictoire, hors du contrôle du candidat. Les empreintes fixent des octets ; elles n’authentifient pas de vrais clients. `MANIFEST.json` inventorie les octets du paquet, sans constituer une signature client. Les observations de développement et journaux d’échecs capturés restent sous `development/` et `validation/` ; ils ne sont pas des essais comparatifs qualifiés.

Ces pièces sont des résultats logiciels, pas des biens imprimés ni des livraisons. L’hôte, le contrôleur, le service, le vérificateur, le journal et l’horloge restent de confiance. Travail complet de préparation/intégration, mémoire maximale, tarifs et coûts métier restent inconnus. Les deux comparaisons ne doivent pas être regroupées comme observations favorables indépendantes.
