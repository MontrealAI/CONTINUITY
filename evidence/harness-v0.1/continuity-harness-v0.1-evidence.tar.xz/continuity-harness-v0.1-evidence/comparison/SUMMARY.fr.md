# CONTINUITÉ Ω — Résultats du banc d’essai

## Périmètre

Exécution réelle de logiciels locaux avec des données synthétiques. Les fichiers JSON produits ne sont pas des étiquettes imprimées et n’établissent aucune livraison client ni valeur commerciale.

**Exécutions:** 24 · **Non exécutées:** 12
**Contrôle de publication:** `PASSED`

| Cas | Méthode | Test | Promesse complète | Unités acceptées / attendues | Temps réel (ns) | Sûreté |
|---|---|---|---|---|---:|---|
| labels-base / recovery | `conventional` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 118557630 | `DEMONSTRATED` |
| labels-base / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 117414852 | `DEMONSTRATED` |
| labels-base / recovery | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-base / alternate | `conventional` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 112295303 | `DEMONSTRATED` |
| labels-base / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 115126097 | `DEMONSTRATED` |
| labels-base / alternate | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-base / constrained | `conventional` | `PASSED` | `FAILED` | 1100 / 1900 | 313570951 | `DEMONSTRATED` |
| labels-base / constrained | `harness` | `PASSED` | `FAILED` | 1100 / 1900 | 262213692 | `DEMONSTRATED` |
| labels-base / constrained | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-a / recovery | `conventional` | `PASSED` | `DEMONSTRATED` | 1600 / 1600 | 117578309 | `DEMONSTRATED` |
| labels-transfer-a / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 1600 / 1600 | 113520030 | `DEMONSTRATED` |
| labels-transfer-a / recovery | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-a / alternate | `conventional` | `PASSED` | `DEMONSTRATED` | 1600 / 1600 | 118504459 | `DEMONSTRATED` |
| labels-transfer-a / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 1600 / 1600 | 125666286 | `DEMONSTRATED` |
| labels-transfer-a / alternate | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-a / constrained | `conventional` | `PASSED` | `FAILED` | 700 / 1600 | 280480972 | `DEMONSTRATED` |
| labels-transfer-a / constrained | `harness` | `PASSED` | `FAILED` | 700 / 1600 | 304302319 | `DEMONSTRATED` |
| labels-transfer-a / constrained | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-b / recovery | `conventional` | `PASSED` | `DEMONSTRATED` | 1100 / 1100 | 134391121 | `DEMONSTRATED` |
| labels-transfer-b / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 1100 / 1100 | 125266657 | `DEMONSTRATED` |
| labels-transfer-b / recovery | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-b / alternate | `conventional` | `PASSED` | `DEMONSTRATED` | 1100 / 1100 | 132594034 | `DEMONSTRATED` |
| labels-transfer-b / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 1100 / 1100 | 169564860 | `DEMONSTRATED` |
| labels-transfer-b / alternate | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-b / constrained | `conventional` | `PASSED` | `FAILED` | 600 / 1100 | 274762953 | `DEMONSTRATED` |
| labels-transfer-b / constrained | `harness` | `PASSED` | `FAILED` | 600 / 1100 | 276702390 | `DEMONSTRATED` |
| labels-transfer-b / constrained | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-c / recovery | `conventional` | `PASSED` | `DEMONSTRATED` | 2200 / 2200 | 133524111 | `DEMONSTRATED` |
| labels-transfer-c / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 2200 / 2200 | 126042300 | `DEMONSTRATED` |
| labels-transfer-c / recovery | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-c / alternate | `conventional` | `PASSED` | `DEMONSTRATED` | 2200 / 2200 | 119542944 | `DEMONSTRATED` |
| labels-transfer-c / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 2200 / 2200 | 108428323 | `DEMONSTRATED` |
| labels-transfer-c / alternate | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-c / constrained | `conventional` | `PASSED` | `FAILED` | 1200 / 2200 | 266168535 | `DEMONSTRATED` |
| labels-transfer-c / constrained | `harness` | `PASSED` | `FAILED` | 1200 / 2200 | 281009658 | `DEMONSTRATED` |
| labels-transfer-c / constrained | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |

## Comparaison et coûts

Les codes machines sont identiques dans les deux langues. PASSED : comportement attendu observé ; DEMONSTRATED : affirmation établie dans le périmètre local ; FAILED : affirmation non satisfaite ; NOT_ESTABLISHED : preuves insuffisantes ; NOT_RUN : non exécuté.

Une seule exécution par méthode et condition : les durées sont descriptives, sans preuve d’un avantage de vitesse. Les services transactionnels et le vérificateur sont communs. La comparaison n’isole aucun gain général attribuable à l’IA.

Les temps processeur du contrôleur et des processus enfants, le temps réel, les octets d’exécution, requêtes, reprises et redémarrages sont mesurés. Les octets excluent les rapports et métadonnées finaux. Effort de préparation, intégration, vérification et présentation séparées, mémoire maximale et coûts monétaires : INCONNUS. Aucun tarif, budget commercial ou économie n’est inventé. Zéro intervention humaine concerne seulement l’exécution automatique.

IA : NON EXÉCUTÉE. Aucun modèle local déjà autorisé n’a été fourni ; l’adaptateur de protocole ne constitue pas un résultat de performance de modèle.

**Avantage comparatif:** `NOT_ESTABLISHED`
**Valeur commerciale:** `NOT_ESTABLISHED`

## Échecs critiques et incertitudes

Exécutions avec sûreté non établie: []
Tests attendus non réussis: []

Consulter chaque PASSPORT.fr.md et RESULT.json pour les obligations individuelles, refus, preuves, conditions et commandes de vérification fraîche. Les résultats incomplets et défavorables sont conservés.
