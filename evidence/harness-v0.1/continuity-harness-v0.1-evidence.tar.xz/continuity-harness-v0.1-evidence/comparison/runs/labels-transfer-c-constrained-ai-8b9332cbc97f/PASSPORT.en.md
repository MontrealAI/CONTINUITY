# CONTINUITY Ω Harness v0.1 — Continuity Passport

[English](PASSPORT.en.md) · [Français](PASSPORT.fr.md)

**Local software execution · synthetic business data**

This Passport presents the supplied fresh assessment. It is a saved report of that assessment; use the verification command below to inspect the current evidence again.

A completed artifact is a durable local JSON software output. It is not printed goods, customer acceptance, a real supplier reservation, revenue, or external certification.

## Assessment

| Field | Recorded value |
| --- | --- |
| Test assertion | `NOT_RUN` — Not run |
| Target verdict | `NOT_RUN` — Not run |
| Evidence stage | `NOT_RUN` — Not run |
| Complete-promise claim | `NOT_ESTABLISHED` — Not established |
| Safety within the tested model | `NOT_ESTABLISHED` — Not established |
| Authority binding | `DEMONSTRATED` — Demonstrated within the declared stage |
| Fresh verification status | `COMPLETE` — Completed record |
| Every obligation completed | No |
| Commercial value | `NOT_ESTABLISHED` — Not established |
| Authenticity of real customer instructions | `NOT_ESTABLISHED` — Not established |

Test behavior, target output, evidence stage, and the business claim are separate. A correctly refused request can satisfy a safety test while leaving an obligation unfulfilled. A passing test that exposes a false acceptance does not qualify the defective checker.

## Per-obligation outcomes

| Order | Recipient | Required units | Observed units | Accepted units | Outcome | Route |
| --- | --- | --- | --- | --- | --- | --- |
| LBL-100 | CUSTOMER-A | 1200 | 0 | 0 | `UNRESOLVED` — Unresolved | NOT RECORDED / UNKNOWN |
| LBL-200 | CUSTOMER-B | 1000 | 0 | 0 | `UNRESOLVED` — Unresolved | NOT RECORDED / UNKNOWN |

### Order `LBL-100`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | 121355b3f8e9b911720e9c2ebe87dc6078fb67861652c1bfb95096077e481a1a |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | NOT RECORDED / UNKNOWN |
| Post-export monotonic observation (ns) | NOT RECORDED / UNKNOWN |

**Durable completion observed no later than:** NOT RECORDED / UNKNOWN

**Producer transition before commit (elapsed):** NOT RECORDED / UNKNOWN

**Recorded reasons:**

- `NO_DURABLE_OUTPUT`: No accepted durable output exists for this obligation.

### Order `LBL-200`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | 121355b3f8e9b911720e9c2ebe87dc6078fb67861652c1bfb95096077e481a1a |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | NOT RECORDED / UNKNOWN |
| Post-export monotonic observation (ns) | NOT RECORDED / UNKNOWN |

**Durable completion observed no later than:** NOT RECORDED / UNKNOWN

**Producer transition before commit (elapsed):** NOT RECORDED / UNKNOWN

**Recorded reasons:**

- `NO_DURABLE_OUTPUT`: No accepted durable output exists for this obligation.

## Totals for the retained promise

| Field | Recorded value |
| --- | --- |
| Required obligations | 2 |
| Accepted obligations | 0 |
| Required units | 2200 |
| Observed output units | 0 |
| Accepted units | 0 |
| Units not accepted | 2200 |
| Late obligations | 0 |
| Incorrect obligations | 0 |
| Duplicated obligations | 0 |
| Unsupported completed obligations | 0 |

## Observed failures

None recorded.

## Unresolved evidence and claims

| Machine code | Explanation | Order | Original technical detail |
| --- | --- | --- | --- |
| `NOT_RUN` | This method was not run. | NOT RECORDED / UNKNOWN |  |

## Frozen conditions

| Field | Recorded value |
| --- | --- |
| Contract identifier | CONTRACT-labels-transfer-c-constrained |
| Contract schema | continuity-harness/contract/v1 |
| Contract version | 1 |
| Declared exercise mode | SYNTHETIC_LOCAL_EXECUTION |
| Source events SHA-256 | bcd522a59943bfcc986742d60f600a9d10f5a0f0ba7f5ff4270552cf2ed7dde3 |
| Source observation cutoff | 6 |
| Authored source-completeness declaration | Yes |
| Logical deadline (ticks) | 100 |
| Configured wall deadline (ms) | 30000 |
| Configured recovery objective (ms) | 15000 |
| Capacity window [start, end) | {"end":100,"start":0} |
| Reservation lease (ticks) | 20 |
| Declared route capacities (units) | {"backup":1300,"primary":2600} |
| Allowed routes | ["primary","backup"] |
| Declared permissions | {"activation":true,"sharing":true} |
| Declared route dependencies | {"backup":"GRID-404-INDEPENDENT","primary":"GRID-404"} |
| Unavailable dependencies | ["GRID-404"] |
| Configured fixture currency | USD |
| Configured fixture budget (minor units) | 0 |
| Frozen comparison conditions | {"fixture_id":"labels-transfer-c","held_out":true,"information":"EQUAL","resource_policy":"SHARED_SERVICES","suite_id":"CONTINUITY-HARNESS-001"} |

Ticks are controller-owned logical schedule positions, not measured hours. Milliseconds and nanoseconds below refer to monotonic local measurements. Durable completion uses the trusted post-export observation as a conservative upper bound, distinct from the producer's precommit transition timestamp. Observation delay can reject a late bound even if persistence actually occurred earlier. The configured wall deadline and recovery objective are acceptance limits, not achieved durations.

## Fault schedule and observations

| Machine code | Action | Target | Observed |
| --- | --- | --- | --- |
| `PRIMARY_UNAVAILABLE` — Primary route disabled | DISABLE | primary | No |
| `CONCURRENT_FINAL_CAPACITY` — Concurrent competition for final capacity | RACE | backup | No |
| `ACK_LOST_AFTER_DURABLE_FULFILLMENT` — Acknowledgment lost after durable fulfillment | DROP_ACK | service | No |
| `RETRY_WHILE_OUTCOME_UNKNOWN` — Retry while the original outcome remains unknown | RETRY | service | No |
| `SERVICE_KILLED_AFTER_COMMIT` — Service process terminated after commit | KILL | service | No |
| `CANDIDATE_KILLED_AFTER_REQUEST` — Candidate process terminated after its request | KILL | candidate | No |
| `RESTART_RECONCILIATION` — Restart and reconcile durable state | RESTART | candidate | No |

The complete event and intervention record is in controller.json. A listed schedule is not evidence that its faults occurred; the observed column records exact matches in the supplied controller record.

| Machine code | Explanation | Order | Original technical detail |
| --- | --- | --- | --- |
| `LOCAL_AI_UNAVAILABLE` | No suitable authorized local model was executed; AI performance was not measured. | NOT RECORDED / UNKNOWN | No authorized local model command was supplied; no API or model download was used. |

## Measurements and accounting gaps

| Field | Recorded value |
| --- | --- |
| Measured execution wall time | 0.015 ms (15003 ns) |
| Observed child CPU: user | 0.000 ms (0 ns) |
| Observed child CPU: system | 0.000 ms (0 ns) |
| Observed controller CPU: user | 0.016 ms (16000 ns) |
| Observed controller CPU: system | 0.002 ms (2000 ns) |
| Peak resident memory (bytes) | NOT RECORDED / UNKNOWN |
| Measured run storage before final reports (bytes) | 2856 |
| Candidate broker requests | 0 |
| Recorded retries | 0 |
| Recorded worker restarts | 0 |
| Human interventions during this run | 0 |
| Recorded preparation labor (seconds) | NOT RECORDED / UNKNOWN |
| Recorded integration labor (seconds) | NOT RECORDED / UNKNOWN |
| Complete monetary cost | NOT RECORDED / UNKNOWN |
| Measured recovery/readiness time (ms) | NOT RECORDED / UNKNOWN |

Wall time is measured for the controller's local execution interval. Child and controller CPU values are separate process-usage deltas where recorded. Verification/reporting CPU and development work are not included. Storage is the measured run content before final controller/report files and suite-index metadata, excluding separately retained authority. Broker requests count candidate requests; internal controller operations remain in the event record. Zero human interventions concerns this autonomous run only.

Preparation and integration labor, unmeasured memory use, monetary rates, and complete business costs remain unknown when not recorded. The configured currency and budget are fixture inputs, not measured spending or a customer's budget. No price or savings is inferred. One bounded observation per method and fixture does not establish a stable performance advantage.

| Field | Recorded value |
| --- | --- |
| Maximum simultaneous allocation by route | NOT RECORDED / UNKNOWN |
| Verified durable history transitions | NOT RECORDED / UNKNOWN |
| Primary reconstruction verified | NOT RECORDED / UNKNOWN |

## Identity, versions, and environment

| Field | Recorded value |
| --- | --- |
| Run identifier | labels-transfer-c-constrained-ai-8b9332cbc97f |
| Candidate method | `ai` — AI-assisted procedure |
| Scenario | `constrained` — Constrained disruption and recovery |
| Recorded seed | 404 |
| Controller state | `NOT_RUN` — Not run |
| Execution start (UTC) | 2026-11-06T20:25:02.808690+00:00 |
| Retained contract SHA-256 | 1854e4ccbdd7e6358e97473b0ab5284ed33aea7181987c200ba707e2b2626444 |
| Observed reference SHA-256 | 009932e7442ca12cc82c6b352b9b5a85024b40c514ba2b52d84596f27d352da8 |
| Fresh verifier version | 0.1.0 |
| Verification-result schema | continuity-harness/verification/v1 |
| Retained-reference schema | continuity-harness/reference/v1 |
| Independently supplied reference pin | 009932e7442ca12cc82c6b352b9b5a85024b40c514ba2b52d84596f27d352da8 |
| Canonical structured-result SHA-256 | e6b34609bbf2a3188c24d2163dacd11a353eb779ef29a9a1e6d4b5e569d8a63f |
| Implementation version | 0.1.0 |
| Recorded Git commit | 5c92fd03a258a3f4845c50a5b37e7a14cd2aa40c |
| Working tree had uncommitted changes | No |
| Recorded Python runtime | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Recorded platform and kernel | Linux-6.18.57-x86_64-with-glibc2.39 |
| Recorded SQLite version | 3.53.1 |
| Recorded working directory | /workspace/scratch/b1d5891eb025/continuity-harness-qualified |

### Implementation source identities

| Path | SHA-256 |
| --- | --- |
| continuity_harness/__init__.py | `577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e` |
| continuity_harness/__main__.py | `c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8` |
| continuity_harness/adapters.py | `ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0` |
| continuity_harness/candidate.py | `938d73f546c774452b22823639beda4b0f89d911abe429da48039bf1808e3141` |
| continuity_harness/challenges.py | `d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d` |
| continuity_harness/controller.py | `acf262f8385213188aefba5ed357cde2506117cd9a04237bb4fdc7d1a666a83a` |
| continuity_harness/fixtures.py | `4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e` |
| continuity_harness/reporting.py | `08e11beb3680f2f4ffb1808faec37e132aeecad281acc6cb6c4ad06dfe36960b` |
| continuity_harness/rpc.py | `36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745` |
| continuity_harness/sandbox.py | `7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f` |
| continuity_harness/schema.py | `4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c` |
| continuity_harness/service.py | `587e6227e3d98d6af942fbabff19f49e0e2f47bda0288fbe6616d73bc56367f5` |
| continuity_harness/suite.py | `bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc` |
| continuity_harness/verifier.py | `2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38` |
| experiments/harness-v0.1/PROVENANCE.json | `0c8697da8cd4eb8635cf5413c0f3e0b4c2dc82ea6cd7d8bc6cac194bed7f5f32` |
| experiments/harness-v0.1/spec.json | `8f08c8d524ab4aab9528728725d528eaa5f7e701403c9e176e8dff9b17380880` |

## Current evidence identities

NOT RECORDED / UNKNOWN

The verifier compares current file bytes with the separately retained execution seal. These hashes identify bytes; they do not authenticate a real customer instruction or prove real-world completeness.

## Fresh verification and recorded commands

```sh
python3 -m continuity_harness --language en verify --run /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/comparison/runs/labels-transfer-c-constrained-ai-8b9332cbc97f --authority /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/comparison/authority/labels-transfer-c-constrained-ai-8b9332cbc97f --reference-sha256 009932e7442ca12cc82c6b352b9b5a85024b40c514ba2b52d84596f27d352da8
```

Run from the recorded implementation checkout. Supply the independently retained reference pin from the suite index; do not derive a replacement pin from candidate-controlled data. Verification does not overwrite this saved Passport.

### Other commands recorded for this execution

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m continuity_harness --language en compare --out /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/comparison
```


## Trust assumptions and remaining limits

| Field | Recorded value |
| --- | --- |
| Candidate-isolation mechanism | SECCOMP_BPF |
| Isolation applied | No |
| Isolation probe observations | {} |
| Declared trust scope | TRUSTED_HOST_CONTROLLER_CLOCK_AND_VERIFIER_AUTHORED_SYNTHETIC_SOURCE |

The host, controller, authored journal, local services, clock, and acceptance verifier are trusted within the declared failure model. Shipped candidate code and imports are trusted before seccomp activation; no arbitrary third-party plugin is supported. The candidate receives bounded data after filtering and performs effects only through the allowlisted broker. This does not protect against a malicious host administrator.

Source identity, custody, completeness, and byte integrity are different properties. A finite set of local tests is not a general proof, universal exactly-once delivery, independent external certification, or commercial validation. A synthetic transfer establishes only the measured transfer under its recorded conditions.

No AI performance is established by an unavailable model, a mock, or a recorded response. The AI arm is NOT RUN unless an actual authorized local capability was executed and measured.

Structured records: [RESULT.json](RESULT.json) · [controller.json](controller.json). Both language Passports are derived from the same structured result.
