# CONTINUITY Ω Harness v0.1 — Continuity Passport

[English](PASSPORT.en.md) · [Français](PASSPORT.fr.md)

**Local software execution · synthetic business data**

This Passport presents the supplied fresh assessment. It is a saved report of that assessment; use the verification command below to inspect the current evidence again.

A completed artifact is a durable local JSON software output. It is not printed goods, customer acceptance, a real supplier reservation, revenue, or external certification.

## Assessment

| Field | Recorded value |
| --- | --- |
| Test assertion | `PASSED` — Expected test behavior observed |
| Target verdict | `COMPLETED` — Completed |
| Evidence stage | `LOCAL_SOFTWARE_EXECUTION` — Local software execution with synthetic data |
| Complete-promise claim | `DEMONSTRATED` — Demonstrated within the declared stage |
| Safety within the tested model | `DEMONSTRATED` — Demonstrated within the declared stage |
| Authority binding | `DEMONSTRATED` — Demonstrated within the declared stage |
| Fresh verification status | `COMPLETE` — Completed record |
| Every obligation completed | Yes |
| Commercial value | `NOT_ESTABLISHED` — Not established |
| Authenticity of real customer instructions | `NOT_ESTABLISHED` — Not established |

Test behavior, target output, evidence stage, and the business claim are separate. A correctly refused request can satisfy a safety test while leaving an obligation unfulfilled. A passing test that exposes a false acceptance does not qualify the defective checker.

## Per-obligation outcomes

| Order | Recipient | Required units | Observed units | Accepted units | Outcome | Route |
| --- | --- | --- | --- | --- | --- | --- |
| LBL-100 | CUSTOMER-A | 600 | 600 | 600 | `COMPLETED` — Completed | `backup` — Backup route |
| LBL-200 | CUSTOMER-B | 500 | 500 | 500 | `COMPLETED` — Completed | `backup` — Backup route |

### Order `LBL-100`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | f9271c9d9356a066ed1d7a185da96ddca841fa058ed6151d52fbda742ca70077 |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | 5 |
| Post-export monotonic observation (ns) | 24498739379473 |

**Durable completion observed no later than:** 139.904 ms (139903809 ns)

**Producer transition before commit (elapsed):** 135.766 ms (135766109 ns)

**Recorded reasons:**

None recorded.

### Order `LBL-200`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | f9271c9d9356a066ed1d7a185da96ddca841fa058ed6151d52fbda742ca70077 |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | 8 |
| Post-export monotonic observation (ns) | 24498744538443 |

**Durable completion observed no later than:** 145.063 ms (145062779 ns)

**Producer transition before commit (elapsed):** 142.909 ms (142908938 ns)

**Recorded reasons:**

None recorded.

## Totals for the retained promise

| Field | Recorded value |
| --- | --- |
| Required obligations | 2 |
| Accepted obligations | 2 |
| Required units | 1100 |
| Observed output units | 1100 |
| Accepted units | 1100 |
| Units not accepted | 0 |
| Late obligations | 0 |
| Incorrect obligations | 0 |
| Duplicated obligations | 0 |
| Unsupported completed obligations | 0 |

## Observed failures

None recorded.

## Unresolved evidence and claims

None recorded.

## Frozen conditions

| Field | Recorded value |
| --- | --- |
| Contract identifier | CONTRACT-labels-transfer-b-alternate |
| Contract schema | continuity-harness/contract/v1 |
| Contract version | 1 |
| Declared exercise mode | SYNTHETIC_LOCAL_EXECUTION |
| Source events SHA-256 | 49f4c61669bd43fc4e93f433957eb720a07fe0998c033f08de9dba6d98c78d6d |
| Source observation cutoff | 6 |
| Authored source-completeness declaration | Yes |
| Logical deadline (ticks) | 100 |
| Configured wall deadline (ms) | 30000 |
| Configured recovery objective (ms) | 15000 |
| Capacity window [start, end) | {"end":100,"start":0} |
| Reservation lease (ticks) | 20 |
| Declared route capacities (units) | {"backup":1200,"primary":1800} |
| Allowed routes | ["primary","backup"] |
| Declared permissions | {"activation":true,"sharing":true} |
| Declared route dependencies | {"backup":"GRID-303-INDEPENDENT","primary":"GRID-303"} |
| Unavailable dependencies | ["GRID-303"] |
| Configured fixture currency | USD |
| Configured fixture budget (minor units) | 0 |
| Frozen comparison conditions | {"fixture_id":"labels-transfer-b","held_out":true,"information":"EQUAL","resource_policy":"SHARED_SERVICES","suite_id":"CONTINUITY-HARNESS-001"} |

Ticks are controller-owned logical schedule positions, not measured hours. Milliseconds and nanoseconds below refer to monotonic local measurements. Durable completion uses the trusted post-export observation as a conservative upper bound, distinct from the producer's precommit transition timestamp. Observation delay can reject a late bound even if persistence actually occurred earlier. The configured wall deadline and recovery objective are acceptance limits, not achieved durations.

## Fault schedule and observations

| Machine code | Action | Target | Observed |
| --- | --- | --- | --- |
| `PRIMARY_UNAVAILABLE` — Primary route disabled | DISABLE | primary | Yes |

The complete event and intervention record is in controller.json. A listed schedule is not evidence that its faults occurred; the observed column records exact matches in the supplied controller record.

## Measurements and accounting gaps

| Field | Recorded value |
| --- | --- |
| Measured execution wall time | 169.565 ms (169564860 ns) |
| Observed child CPU: user | 102.186 ms (102186000 ns) |
| Observed child CPU: system | 40.594 ms (40594000 ns) |
| Observed controller CPU: user | 4.055 ms (4055000 ns) |
| Observed controller CPU: system | 4.117 ms (4117000 ns) |
| Peak resident memory (bytes) | NOT RECORDED / UNKNOWN |
| Measured run storage before final reports (bytes) | 81251 |
| Candidate broker requests | 8 |
| Recorded retries | 0 |
| Recorded worker restarts | 0 |
| Human interventions during this run | 0 |
| Recorded preparation labor (seconds) | NOT RECORDED / UNKNOWN |
| Recorded integration labor (seconds) | NOT RECORDED / UNKNOWN |
| Complete monetary cost | NOT RECORDED / UNKNOWN |
| Measured recovery/readiness time (ms) | NOT RECORDED / UNKNOWN |

Wall time is measured for the controller's local execution interval. Child and controller CPU values are separate process-usage deltas where recorded. Verification/reporting CPU and development work are not included. Storage is the measured run content before final controller/report files and suite-index metadata, excluding separately retained authority. Broker requests count candidate requests; internal controller operations remain in the event record. Zero human interventions concerns this autonomous run only.

Preparation and integration labor, unmeasured memory use, monetary rates, and complete business costs remain unknown when not recorded. The configured currency and budget are fixture inputs, not measured spending or a customer's budget. No price or savings is inferred. One bounded observation per method and fixture does not establish a stable performance advantage.

| Field | Recorded value |
| --- | --- |
| Maximum simultaneous allocation by route | {"backup":1100,"primary":0} |
| Verified durable history transitions | 8 |
| Primary reconstruction verified | No |

## Identity, versions, and environment

| Field | Recorded value |
| --- | --- |
| Run identifier | labels-transfer-b-alternate-harness-8b9332cbc97f |
| Candidate method | `harness` — Harness-supported procedure |
| Scenario | `alternate` — Feasible alternate fulfillment |
| Recorded seed | 303 |
| Controller state | `COMPLETE` — Completed record |
| Execution start (UTC) | 2026-11-06T20:25:00.701191+00:00 |
| Retained contract SHA-256 | 971f12d4befb412ae4cbce962c62e6401b773d0373424891ad60e8b68803015c |
| Observed reference SHA-256 | 2251f0210bf1d365ef27c4d6f57db1c08a5f5bc0d82a5a6ba4877631da52626f |
| Fresh verifier version | 0.1.0 |
| Verification-result schema | continuity-harness/verification/v1 |
| Retained-reference schema | continuity-harness/reference/v1 |
| Independently supplied reference pin | 2251f0210bf1d365ef27c4d6f57db1c08a5f5bc0d82a5a6ba4877631da52626f |
| Canonical structured-result SHA-256 | b35f750e3c4fb417c6fbe5dcfea537a19be68e4f24dda517818b5a55231d3614 |
| Implementation version | 0.1.0 |
| Recorded Git commit | 5c92fd03a258a3f4845c50a5b37e7a14cd2aa40c |
| Working tree had uncommitted changes | No |
| Recorded Python runtime | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Recorded platform and kernel | Linux-6.18.57-x86_64-with-glibc2.39 |
| Recorded SQLite version | 3.53.1 |
| Recorded working directory | /workspace/scratch/b1d5891eb025/continuity-harness-qualified |

### Implementation source identities

| Path | SHA-256 |
| --- | --- |
| continuity_harness/__init__.py | `577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e` |
| continuity_harness/__main__.py | `c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8` |
| continuity_harness/adapters.py | `ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0` |
| continuity_harness/candidate.py | `938d73f546c774452b22823639beda4b0f89d911abe429da48039bf1808e3141` |
| continuity_harness/challenges.py | `d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d` |
| continuity_harness/controller.py | `acf262f8385213188aefba5ed357cde2506117cd9a04237bb4fdc7d1a666a83a` |
| continuity_harness/fixtures.py | `4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e` |
| continuity_harness/reporting.py | `08e11beb3680f2f4ffb1808faec37e132aeecad281acc6cb6c4ad06dfe36960b` |
| continuity_harness/rpc.py | `36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745` |
| continuity_harness/sandbox.py | `7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f` |
| continuity_harness/schema.py | `4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c` |
| continuity_harness/service.py | `587e6227e3d98d6af942fbabff19f49e0e2f47bda0288fbe6616d73bc56367f5` |
| continuity_harness/suite.py | `bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc` |
| continuity_harness/verifier.py | `2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38` |
| experiments/harness-v0.1/PROVENANCE.json | `0c8697da8cd4eb8635cf5413c0f3e0b4c2dc82ea6cd7d8bc6cac194bed7f5f32` |
| experiments/harness-v0.1/spec.json | `8f08c8d524ab4aab9528728725d528eaa5f7e701403c9e176e8dff9b17380880` |

## Current evidence identities

| Path | SHA-256 |
| --- | --- |
| evidence/artifacts/LBL-100.json | `a35be8c8bc0511339d74dbb665ab117924dc8bb9fee0cf09f7d6a57c715cc5db` |
| evidence/artifacts/LBL-200.json | `b31353483f02d301e58a5e5830d93269cce9924da697ba4594ede8414d064042` |
| evidence/service.sqlite | `4564a2b3208193ad45effa7a07221a531da9b67a23dd7b0f7de6ffb6f10e7d98` |

The verifier compares current file bytes with the separately retained execution seal. These hashes identify bytes; they do not authenticate a real customer instruction or prove real-world completeness.

## Fresh verification and recorded commands

```sh
python3 -m continuity_harness --language en verify --run /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/comparison/runs/labels-transfer-b-alternate-harness-8b9332cbc97f --authority /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/comparison/authority/labels-transfer-b-alternate-harness-8b9332cbc97f --reference-sha256 2251f0210bf1d365ef27c4d6f57db1c08a5f5bc0d82a5a6ba4877631da52626f
```

Run from the recorded implementation checkout. Supply the independently retained reference pin from the suite index; do not derive a replacement pin from candidate-controlled data. Verification does not overwrite this saved Passport.

### Other commands recorded for this execution

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m continuity_harness --language en compare --out /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/comparison
```


## Trust assumptions and remaining limits

| Field | Recorded value |
| --- | --- |
| Candidate-isolation mechanism | SECCOMP_BPF |
| Isolation applied | Yes |
| Isolation probe observations | {"authority_open_denied":true,"network_denied":true,"process_inspection_denied":true,"spawn_denied":true,"workspace_open_denied":true} |
| Declared trust scope | TRUSTED_HOST_CONTROLLER_CLOCK_AND_VERIFIER_AUTHORED_SYNTHETIC_SOURCE |

The host, controller, authored journal, local services, clock, and acceptance verifier are trusted within the declared failure model. Shipped candidate code and imports are trusted before seccomp activation; no arbitrary third-party plugin is supported. The candidate receives bounded data after filtering and performs effects only through the allowlisted broker. This does not protect against a malicious host administrator.

Source identity, custody, completeness, and byte integrity are different properties. A finite set of local tests is not a general proof, universal exactly-once delivery, independent external certification, or commercial validation. A synthetic transfer establishes only the measured transfer under its recorded conditions.

No AI performance is established by an unavailable model, a mock, or a recorded response. The AI arm is NOT RUN unless an actual authorized local capability was executed and measured.

Structured records: [RESULT.json](RESULT.json) · [controller.json](controller.json). Both language Passports are derived from the same structured result.
