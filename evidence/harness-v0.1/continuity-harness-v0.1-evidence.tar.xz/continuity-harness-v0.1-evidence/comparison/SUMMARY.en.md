# CONTINUITY Ω Harness — Results

## Scope

Actual local software execution with synthetic data. Completed JSON artifacts are not printed labels and establish neither customer delivery nor commercial value.

**Executed runs:** 24 · **Not run:** 12
**Release gate:** `PASSED`

| Case | Method | Test | Complete promise | Accepted / expected units | Wall time (ns) | Safety |
|---|---|---|---|---|---:|---|
| labels-base / recovery | `conventional` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 118557630 | `DEMONSTRATED` |
| labels-base / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 117414852 | `DEMONSTRATED` |
| labels-base / recovery | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-base / alternate | `conventional` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 112295303 | `DEMONSTRATED` |
| labels-base / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 1900 / 1900 | 115126097 | `DEMONSTRATED` |
| labels-base / alternate | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-base / constrained | `conventional` | `PASSED` | `FAILED` | 1100 / 1900 | 313570951 | `DEMONSTRATED` |
| labels-base / constrained | `harness` | `PASSED` | `FAILED` | 1100 / 1900 | 262213692 | `DEMONSTRATED` |
| labels-base / constrained | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-a / recovery | `conventional` | `PASSED` | `DEMONSTRATED` | 1600 / 1600 | 117578309 | `DEMONSTRATED` |
| labels-transfer-a / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 1600 / 1600 | 113520030 | `DEMONSTRATED` |
| labels-transfer-a / recovery | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-a / alternate | `conventional` | `PASSED` | `DEMONSTRATED` | 1600 / 1600 | 118504459 | `DEMONSTRATED` |
| labels-transfer-a / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 1600 / 1600 | 125666286 | `DEMONSTRATED` |
| labels-transfer-a / alternate | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-a / constrained | `conventional` | `PASSED` | `FAILED` | 700 / 1600 | 280480972 | `DEMONSTRATED` |
| labels-transfer-a / constrained | `harness` | `PASSED` | `FAILED` | 700 / 1600 | 304302319 | `DEMONSTRATED` |
| labels-transfer-a / constrained | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-b / recovery | `conventional` | `PASSED` | `DEMONSTRATED` | 1100 / 1100 | 134391121 | `DEMONSTRATED` |
| labels-transfer-b / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 1100 / 1100 | 125266657 | `DEMONSTRATED` |
| labels-transfer-b / recovery | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-b / alternate | `conventional` | `PASSED` | `DEMONSTRATED` | 1100 / 1100 | 132594034 | `DEMONSTRATED` |
| labels-transfer-b / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 1100 / 1100 | 169564860 | `DEMONSTRATED` |
| labels-transfer-b / alternate | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-b / constrained | `conventional` | `PASSED` | `FAILED` | 600 / 1100 | 274762953 | `DEMONSTRATED` |
| labels-transfer-b / constrained | `harness` | `PASSED` | `FAILED` | 600 / 1100 | 276702390 | `DEMONSTRATED` |
| labels-transfer-b / constrained | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-c / recovery | `conventional` | `PASSED` | `DEMONSTRATED` | 2200 / 2200 | 133524111 | `DEMONSTRATED` |
| labels-transfer-c / recovery | `harness` | `PASSED` | `DEMONSTRATED` | 2200 / 2200 | 126042300 | `DEMONSTRATED` |
| labels-transfer-c / recovery | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-c / alternate | `conventional` | `PASSED` | `DEMONSTRATED` | 2200 / 2200 | 119542944 | `DEMONSTRATED` |
| labels-transfer-c / alternate | `harness` | `PASSED` | `DEMONSTRATED` | 2200 / 2200 | 108428323 | `DEMONSTRATED` |
| labels-transfer-c / alternate | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |
| labels-transfer-c / constrained | `conventional` | `PASSED` | `FAILED` | 1200 / 2200 | 266168535 | `DEMONSTRATED` |
| labels-transfer-c / constrained | `harness` | `PASSED` | `FAILED` | 1200 / 2200 | 281009658 | `DEMONSTRATED` |
| labels-transfer-c / constrained | `ai` | `NOT_RUN` | `NOT_ESTABLISHED` | — | — | `NOT_ESTABLISHED` |

## Comparison and costs

Machine codes are shared between languages. PASSED means the expected test behavior was observed; DEMONSTRATED establishes the scoped local claim; FAILED means the claim was not satisfied; NOT_ESTABLISHED means insufficient evidence; NOT_RUN means not executed.

One execution per method and condition: timings are descriptive, not evidence of a speed advantage. Transactional services and the verifier are shared. The comparison isolates no general AI contribution.

Controller and child CPU, wall time, execution bytes, requests, retries and restarts are observed. Bytes exclude final reports and metadata. Preparation, integration, separate verification/reporting, peak memory and monetary costs are UNKNOWN. No rate, business budget or saving is invented. Zero human intervention applies only to autonomous execution.

AI: NOT RUN. No already-authorized local model was supplied; protocol adapter plumbing is not a model performance result.

**Comparative advantage:** `NOT_ESTABLISHED`
**Commercial value:** `NOT_ESTABLISHED`

## Critical failures and uncertainty

Runs without established safety: []
Unmet test assertions: []

Read each PASSPORT.en.md and RESULT.json for individual obligations, refusals, evidence, conditions and fresh-verification commands. Incomplete and unfavorable outcomes are preserved.
