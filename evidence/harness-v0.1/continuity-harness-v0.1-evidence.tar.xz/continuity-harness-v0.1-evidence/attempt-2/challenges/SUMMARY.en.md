# CONTINUITY Ω — Retained adversarial challenges

[English](SUMMARY.en.md) · [Français](SUMMARY.fr.md)

This suite does not compare method performance. It retains every original verdict and a separate outer assessment. A passing test that exposes false acceptance does not qualify the defective checker.

**Suite gate:** `PASSED` · **New local executions:** 4

| Challenge | Outer assertion | Tested verdict | Stage | Scoped claim | Reference full promise |
|---|---|---|---|---|---|
| [no-journal-ablation](cases/no-journal-ablation/PASSPORT.en.md) | `PASSED` | `PARTIAL` | `LOCAL_SOFTWARE_EXECUTION` | `FAILED` | `FAILED` |
| [rewritten-1850](cases/rewritten-1850/PASSPORT.en.md) | `PASSED` | `PARTIAL` | `LOCAL_SOFTWARE_EXECUTION` | `DEMONSTRATED` | `FAILED` |
| [missing-reference-pin](cases/missing-reference-pin/PASSPORT.en.md) | `PASSED` | `NOT_ESTABLISHED` | `FRESH_VERIFICATION_CHALLENGE` | `DEMONSTRATED` | `NOT_ESTABLISHED` |
| [changed-artifact](cases/changed-artifact/PASSPORT.en.md) | `PASSED` | `FAILED` | `FRESH_VERIFICATION_CHALLENGE` | `DEMONSTRATED` | `FAILED` |
| [shared-failed-dependency](cases/shared-failed-dependency/PASSPORT.en.md) | `PASSED` | `REFUSED` | `LOCAL_SOFTWARE_EXECUTION` | `DEMONSTRATED` | `FAILED` |
| [mutant-ignores-byte-integrity](cases/mutant-ignores-byte-integrity/PASSPORT.en.md) | `PASSED` | `DEMONSTRATED` | `CHECKER_MUTATION_EXERCISE` | `FAILED` | `FAILED` |
| [mutant-ignores-revocation](cases/mutant-ignores-revocation/PASSPORT.en.md) | `PASSED` | `DEMONSTRATED` | `CHECKER_MUTATION_EXERCISE` | `FAILED` | `FAILED` |
| [mutant-rejects-valid-recovery](cases/mutant-rejects-valid-recovery/PASSPORT.en.md) | `PASSED` | `FAILED` | `CHECKER_MUTATION_EXERCISE` | `FAILED` | `DEMONSTRATED` |

Mutations reuse copies of a positive control, retaining its old Passports. The copied execution times are not new measurements to add together. Verification durations are measured separately in CHALLENGE.json. Preparation, integration, peak memory and monetary costs remain unknown.

The ablation removes journal reconciliation while keeping ordinary service safeguards; its failure establishes no general AI advantage. The mutant revocation is an explicitly synthetic modification of copied evidence, not a permission withdrawal actually executed by the service.

Every case contains CHALLENGE.json, TARGET_RESULT.json and REFERENCE_RESULT.json, durable evidence, and both complete Passports. Mutations are scoped to the test invocation and do not alter the installed verifier.
