# CONTINUITY Ω Harness v0.1 — Continuity Passport

[English](PASSPORT.en.md) · [Français](PASSPORT.fr.md)

**Local software execution · synthetic business data**

This Passport presents the supplied fresh assessment. It is a saved report of that assessment; use the verification command below to inspect the current evidence again.

A completed artifact is a durable local JSON software output. It is not printed goods, customer acceptance, a real supplier reservation, revenue, or external certification.

## Challenge and assessment subject

**Coherently resealed 1,850-unit candidate package**

| Field | Recorded value |
| --- | --- |
| Challenge identifier | rewritten-1850 |
| Assessed component | `CANDIDATE_PROCEDURE` — Candidate procedure |
| Declared claim | A candidate-side rewrite cannot redefine verified success against the separately retained 1,900-unit promise. |
| Expected observation | Candidate-side source, contract and view seals are recomputed; the retained contract still requires 1,900 units and cannot be fully accepted. |
| Recorded observation | Reference full-promise claim: FAILED; tested target: PARTIAL; accepted reference quantity: 1100 / 1900. These are scoped observations from synthetic local evidence. |
| Reference full-promise claim | `FAILED` — Failed |
| Tested component's assessment record | TARGET_RESULT.json |
| Independent reference assessment record | REFERENCE_RESULT.json |
| Source execution evidence | run |

**Deliberate mutation configuration:** {"candidate_seals":{"contract_sha256":"771a0f508aa9f225d81cce6d060ef927c4cd1165602ab60ff2176701f1b3395d","source_sha256":"e4a0eec739852a528ba04a781b3d63668614f9962a265cbc7fe87833aa839eac","view_sha256":"f278342478864a9ab20c1718ba9b85d11c11f52e0aa69e7a962c4e94550ad777"},"kind":"CANDIDATE_ONLY_RESEAL","original_units":1900,"retained_original_changed":false,"rewritten_units":1850}

The outer assertion, target verdict and claim status assess the named checker or procedure property. Per-obligation outcomes, totals and underlying claim status reproduce the independent reference assessment of the exact challenged evidence. A test that successfully exposes a defective checker does not qualify that checker. TARGET_RESULT.json and REFERENCE_RESULT.json remain distinct records.

## Assessment

| Field | Recorded value |
| --- | --- |
| Test assertion | `PASSED` — Expected test behavior observed |
| Target verdict | `PARTIAL` — Partial result |
| Evidence stage | `LOCAL_SOFTWARE_EXECUTION` — Local software execution with synthetic data |
| Declared checker or procedure claim | `DEMONSTRATED` — Demonstrated within the declared stage |
| Safety within the tested model | `DEMONSTRATED` — Demonstrated within the declared stage |
| Authority binding | `DEMONSTRATED` — Demonstrated within the declared stage |
| Fresh verification status | `COMPLETE` — Completed record |
| Every obligation completed | No |
| Commercial value | `NOT_ESTABLISHED` — Not established |
| Authenticity of real customer instructions | `NOT_ESTABLISHED` — Not established |

Test behavior, target output, evidence stage, and the business claim are separate. A correctly refused request can satisfy a safety test while leaving an obligation unfulfilled. A passing test that exposes a false acceptance does not qualify the defective checker.

## Per-obligation outcomes

These obligation facts are the reference verifier's assessment, not the tested checker's claimed verdict.

| Order | Recipient | Required units | Observed units | Accepted units | Outcome | Route |
| --- | --- | --- | --- | --- | --- | --- |
| LBL-100 | CUSTOMER-A | 1100 | 1100 | 1100 | `COMPLETED` — Completed | `backup` — Backup route |
| LBL-200 | CUSTOMER-B | 800 | 0 | 0 | `REFUSED` — Refused | NOT RECORDED / UNKNOWN |

### Order `LBL-100`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | 1b590fba52dad5b09041ead75f1b3057b233d8b1ac35d9d9d37905696fc9675c |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | 5 |
| Post-export monotonic observation (ns) | 25310330320761 |

**Durable completion observed no later than:** 87.165 ms (87164960 ns)

**Producer transition before commit (elapsed):** 84.397 ms (84397066 ns)

**Recorded reasons:**

None recorded.

### Order `LBL-200`

| Field | Recorded value |
| --- | --- |
| Product | LABEL-A |
| Final specification SHA-256 | a813e867578702ddec11b49ace3a5fd745ff391a2f5c95e7fe8af1c1f6b6c0e2 |
| Logical deadline (ticks) | 100 |
| Completion position (ticks) | NOT RECORDED / UNKNOWN |
| Post-export monotonic observation (ns) | NOT RECORDED / UNKNOWN |

**Durable completion observed no later than:** NOT RECORDED / UNKNOWN

**Producer transition before commit (elapsed):** NOT RECORDED / UNKNOWN

**Recorded reasons:**

- `NO_DURABLE_OUTPUT`: No accepted durable output exists for this obligation.
- `UNAUTHORIZED_OBLIGATION`: The request differs from the obligation admitted by the service.

## Totals for the retained promise

| Field | Recorded value |
| --- | --- |
| Required obligations | 2 |
| Accepted obligations | 1 |
| Required units | 1900 |
| Observed output units | 1100 |
| Accepted units | 1100 |
| Units not accepted | 800 |
| Late obligations | 0 |
| Incorrect obligations | 0 |
| Duplicated obligations | 0 |
| Unsupported completed obligations | 0 |

## Observed failures

| Machine code | Explanation | Order | Original technical detail |
| --- | --- | --- | --- |
| `ALL_OBLIGATIONS_NOT_COMPLETED` | The complete customer promise was not fulfilled. | NOT RECORDED / UNKNOWN |  |

## Unresolved evidence and claims

None recorded.

## Frozen conditions

| Field | Recorded value |
| --- | --- |
| Contract identifier | CONTRACT-labels-base-alternate |
| Contract schema | continuity-harness/contract/v1 |
| Contract version | 1 |
| Declared exercise mode | SYNTHETIC_LOCAL_EXECUTION |
| Source events SHA-256 | 1f5119db7e2bd8f280a98b97ae72aecf3cc859750cbe6ced7710d48608eb2bca |
| Source observation cutoff | 5 |
| Authored source-completeness declaration | Yes |
| Logical deadline (ticks) | 100 |
| Configured wall deadline (ms) | 30000 |
| Configured recovery objective (ms) | 15000 |
| Capacity window [start, end) | {"end":100,"start":0} |
| Reservation lease (ticks) | 20 |
| Declared route capacities (units) | {"backup":2100,"primary":3000} |
| Allowed routes | ["primary","backup"] |
| Declared permissions | {"activation":true,"sharing":true} |
| Declared route dependencies | {"backup":"GRID-A-INDEPENDENT","primary":"GRID-A"} |
| Unavailable dependencies | ["GRID-A"] |
| Configured fixture currency | USD |
| Configured fixture budget (minor units) | 0 |
| Frozen comparison conditions | {"fixture_id":"labels-base","held_out":false,"information":"EQUAL","resource_policy":"SHARED_SERVICES","suite_id":"CONTINUITY-HARNESS-001"} |

Ticks are controller-owned logical schedule positions, not measured hours. Milliseconds and nanoseconds below refer to monotonic local measurements. Durable completion uses the trusted post-export observation as a conservative upper bound, distinct from the producer's precommit transition timestamp. Observation delay can reject a late bound even if persistence actually occurred earlier. The configured wall deadline and recovery objective are acceptance limits, not achieved durations.

## Fault schedule and observations

| Machine code | Action | Target | Observed |
| --- | --- | --- | --- |
| `PRIMARY_UNAVAILABLE` — Primary route disabled | DISABLE | primary | Yes |

The complete event and intervention record is in controller.json. A listed schedule is not evidence that its faults occurred; the observed column records exact matches in the supplied controller record.

## Measurements and accounting gaps

| Field | Recorded value |
| --- | --- |
| Origin of execution-resource observations | `NEW_LOCAL_EXECUTION` — New local execution for this case |

| Field | Recorded value |
| --- | --- |
| Measured reference-verification duration | 6.865 ms (6864756 ns) |
| Additional target-verification duration | 0.000 ms (0 ns) |
| Measured challenge duration before reporting | 132.946 ms (132945644 ns) |

Execution resources below belong to the recorded source execution. If resource_origin is COPIED_POSITIVE_CONTROL_EXECUTION, those observations are reused evidence, not another measured execution to add to a total. The challenge's fresh verification durations are recorded separately; they do not establish a comparative performance advantage.

| Field | Recorded value |
| --- | --- |
| Measured execution wall time | 112.133 ms (112133080 ns) |
| Observed child CPU: user | 64.620 ms (64620000 ns) |
| Observed child CPU: system | 26.227 ms (26227000 ns) |
| Observed controller CPU: user | 9.796 ms (9796000 ns) |
| Observed controller CPU: system | 0.000 ms (0 ns) |
| Peak resident memory (bytes) | NOT RECORDED / UNKNOWN |
| Measured run storage before final reports (bytes) | 180547 |
| Candidate broker requests | 5 |
| Recorded retries | 0 |
| Recorded worker restarts | 0 |
| Human interventions during this run | 0 |
| Recorded preparation labor (seconds) | NOT RECORDED / UNKNOWN |
| Recorded integration labor (seconds) | NOT RECORDED / UNKNOWN |
| Complete monetary cost | NOT RECORDED / UNKNOWN |
| Measured recovery/readiness time (ms) | NOT RECORDED / UNKNOWN |

Wall time is measured for the controller's local execution interval. Child and controller CPU values are separate process-usage deltas where recorded. Verification/reporting CPU and development work are not included. Storage is the measured run content before final controller/report files and suite-index metadata, excluding separately retained authority. Broker requests count candidate requests; internal controller operations remain in the event record. Zero human interventions concerns this autonomous run only.

Preparation and integration labor, unmeasured memory use, monetary rates, and complete business costs remain unknown when not recorded. The configured currency and budget are fixture inputs, not measured spending or a customer's budget. No price or savings is inferred. One bounded observation per method and fixture does not establish a stable performance advantage.

| Field | Recorded value |
| --- | --- |
| Maximum simultaneous allocation by route | {"backup":1100,"primary":0} |
| Verified durable history transitions | 5 |
| Primary reconstruction verified | No |

## Identity, versions, and environment

| Field | Recorded value |
| --- | --- |
| Run identifier | rewritten-1850-84f2ef2e69ed |
| Candidate method | `harness` — Harness-supported procedure |
| Scenario | `alternate` — Feasible alternate fulfillment |
| Recorded seed | 101 |
| Controller state | `COMPLETE` — Completed record |
| Execution start (UTC) | 2026-11-06T20:38:32.344870+00:00 |
| Retained contract SHA-256 | d9c956b89b136a69c017ad068821fee12ca9d6c1b519f22808689931d97c10dd |
| Observed reference SHA-256 | 4ab93204498e95e1fc8542884bc276a629b845b6825b8765e9ccd18f348b4876 |
| Fresh verifier version | 0.1.0 |
| Verification-result schema | continuity-harness/challenge/v1 |
| Retained-reference schema | continuity-harness/reference/v1 |
| Independently supplied reference pin | 4ab93204498e95e1fc8542884bc276a629b845b6825b8765e9ccd18f348b4876 |
| Canonical structured-result SHA-256 | 58e7db1df296df03c358d891ac93d72e4c2306659f612cb85f07e5ae4a08ba3d |
| Implementation version | 0.1.0 |
| Recorded Git commit | fa9da1f54acfaa82510a4b6b805c2980d3e5b31d |
| Working tree had uncommitted changes | No |
| Recorded Python runtime | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Recorded platform and kernel | Linux-6.18.57-x86_64-with-glibc2.39 |
| Recorded SQLite version | 3.53.1 |
| Recorded working directory | /workspace/scratch/b1d5891eb025/continuity-harness-qualified-v2 |

### Implementation source identities

| Path | SHA-256 |
| --- | --- |
| continuity_harness/__init__.py | `577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e` |
| continuity_harness/__main__.py | `c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8` |
| continuity_harness/adapters.py | `ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0` |
| continuity_harness/candidate.py | `938d73f546c774452b22823639beda4b0f89d911abe429da48039bf1808e3141` |
| continuity_harness/challenges.py | `d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d` |
| continuity_harness/controller.py | `7bbc8a87d34b64d8e9e621de5a907f3b123a3a0e973745c73385b73f3a52d1fd` |
| continuity_harness/fixtures.py | `4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e` |
| continuity_harness/reporting.py | `e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645` |
| continuity_harness/rpc.py | `36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745` |
| continuity_harness/sandbox.py | `7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f` |
| continuity_harness/schema.py | `4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c` |
| continuity_harness/service.py | `6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c` |
| continuity_harness/suite.py | `bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc` |
| continuity_harness/verifier.py | `2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38` |
| experiments/harness-v0.1/PROVENANCE.json | `0c8697da8cd4eb8635cf5413c0f3e0b4c2dc82ea6cd7d8bc6cac194bed7f5f32` |
| experiments/harness-v0.1/spec.json | `8f08c8d524ab4aab9528728725d528eaa5f7e701403c9e176e8dff9b17380880` |

## Current evidence identities

| Path | SHA-256 |
| --- | --- |
| evidence/artifacts/LBL-100.json | `bd2a76f14a6ba096db89d0aa3857b09e1c69a30ac6181a78aa712c790353cae6` |
| evidence/service.sqlite | `058de84cfeca20dd5d2ec04b16c1fdfa7584fd7b223f933a3359d3ffbf9e8b83` |

The verifier compares current file bytes with the separately retained execution seal. These hashes identify bytes; they do not authenticate a real customer instruction or prove real-world completeness.

## Fresh verification and recorded commands

```sh
python3 -m continuity_harness --language en verify --run /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/attempt-2/challenges/cases/rewritten-1850/run --authority /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/attempt-2/challenges/cases/rewritten-1850/authority --reference-sha256 4ab93204498e95e1fc8542884bc276a629b845b6825b8765e9ccd18f348b4876
```

Run from the recorded implementation checkout. Supply the independently retained reference pin from the suite index; do not derive a replacement pin from candidate-controlled data. Verification does not overwrite this saved Passport.

### Other commands recorded for this execution

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m continuity_harness --language fr challenge --out /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/attempt-2/challenges
```


## Trust assumptions and remaining limits

| Field | Recorded value |
| --- | --- |
| Candidate-isolation mechanism | SECCOMP_BPF |
| Isolation applied | Yes |
| Isolation probe observations | {"authority_open_denied":true,"network_denied":true,"process_inspection_denied":true,"spawn_denied":true,"workspace_open_denied":true} |
| Declared trust scope | TRUSTED_HOST_CONTROLLER_CLOCK_AND_VERIFIER_AUTHORED_SYNTHETIC_SOURCE |

The host, controller, authored journal, local services, clock, and acceptance verifier are trusted within the declared failure model. Shipped candidate code and imports are trusted before seccomp activation; no arbitrary third-party plugin is supported. The candidate receives bounded data after filtering and performs effects only through the allowlisted broker. This does not protect against a malicious host administrator.

Source identity, custody, completeness, and byte integrity are different properties. A finite set of local tests is not a general proof, universal exactly-once delivery, independent external certification, or commercial validation. A synthetic transfer establishes only the measured transfer under its recorded conditions.

No AI performance is established by an unavailable model, a mock, or a recorded response. The AI arm is NOT RUN unless an actual authorized local capability was executed and measured.

Structured records: [CHALLENGE.json](CHALLENGE.json) · [TARGET_RESULT.json](TARGET_RESULT.json) · [REFERENCE_RESULT.json](REFERENCE_RESULT.json) · [controller.json](run/controller.json). Both language Passports are derived from the same outer challenge record; the target and reference assessments remain separate.
