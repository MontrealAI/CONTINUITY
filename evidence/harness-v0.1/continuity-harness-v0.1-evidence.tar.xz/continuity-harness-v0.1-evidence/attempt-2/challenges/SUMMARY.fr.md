# CONTINUITÉ Ω — Épreuves contradictoires conservées

[English](SUMMARY.en.md) · [Français](SUMMARY.fr.md)

Cette suite ne compare pas les performances des méthodes. Elle conserve chaque verdict original et une évaluation externe distincte. La réussite d’un test révélant une acceptation indue ne qualifie pas le vérificateur défectueux.

**Contrôle de la suite:** `PASSED` · **Exécutions locales nouvelles:** 4

| Épreuve | Assertion externe | Verdict testé | Stade | Affirmation limitée | Promesse complète de référence |
|---|---|---|---|---|---|
| [no-journal-ablation](cases/no-journal-ablation/PASSPORT.fr.md) | `PASSED` | `PARTIAL` | `LOCAL_SOFTWARE_EXECUTION` | `FAILED` | `FAILED` |
| [rewritten-1850](cases/rewritten-1850/PASSPORT.fr.md) | `PASSED` | `PARTIAL` | `LOCAL_SOFTWARE_EXECUTION` | `DEMONSTRATED` | `FAILED` |
| [missing-reference-pin](cases/missing-reference-pin/PASSPORT.fr.md) | `PASSED` | `NOT_ESTABLISHED` | `FRESH_VERIFICATION_CHALLENGE` | `DEMONSTRATED` | `NOT_ESTABLISHED` |
| [changed-artifact](cases/changed-artifact/PASSPORT.fr.md) | `PASSED` | `FAILED` | `FRESH_VERIFICATION_CHALLENGE` | `DEMONSTRATED` | `FAILED` |
| [shared-failed-dependency](cases/shared-failed-dependency/PASSPORT.fr.md) | `PASSED` | `REFUSED` | `LOCAL_SOFTWARE_EXECUTION` | `DEMONSTRATED` | `FAILED` |
| [mutant-ignores-byte-integrity](cases/mutant-ignores-byte-integrity/PASSPORT.fr.md) | `PASSED` | `DEMONSTRATED` | `CHECKER_MUTATION_EXERCISE` | `FAILED` | `FAILED` |
| [mutant-ignores-revocation](cases/mutant-ignores-revocation/PASSPORT.fr.md) | `PASSED` | `DEMONSTRATED` | `CHECKER_MUTATION_EXERCISE` | `FAILED` | `FAILED` |
| [mutant-rejects-valid-recovery](cases/mutant-rejects-valid-recovery/PASSPORT.fr.md) | `PASSED` | `FAILED` | `CHECKER_MUTATION_EXERCISE` | `FAILED` | `DEMONSTRATED` |

Les mutations réutilisent des copies d’un contrôle positif, avec ses anciens Passeports conservés. Les temps d’exécution de ces copies ne constituent pas de nouvelles mesures à additionner. Les durées des vérifications sont mesurées séparément dans CHALLENGE.json. Travail de préparation, intégration, mémoire maximale et coûts monétaires : inconnus.

L’ablation retire le rapprochement du journal tout en conservant les protections ordinaires des services ; son échec n’établit aucun avantage général de l’IA. Le retrait d’autorisation du cas mutant est une modification synthétique explicite d’une copie de preuve, pas un retrait réellement exécuté par le service.

Chaque dossier contient CHALLENGE.json, TARGET_RESULT.json et REFERENCE_RESULT.json, les preuves durables, et les deux Passeports complets. Les mutations sont limitées à l’appel de test et ne modifient pas le vérificateur installé.
