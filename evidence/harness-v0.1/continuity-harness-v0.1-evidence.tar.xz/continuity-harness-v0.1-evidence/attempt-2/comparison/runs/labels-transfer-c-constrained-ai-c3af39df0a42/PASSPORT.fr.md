# CONTINUITÉ Ω — Banc d’essai et de vérification v0.1 — Passeport de continuité

[English](PASSPORT.en.md) · [Français](PASSPORT.fr.md)

**Exécution logicielle locale · données commerciales synthétiques**

Ce Passeport présente l’évaluation fraîche fournie. Il en constitue un rapport enregistré ; utiliser la commande ci-dessous pour examiner de nouveau les preuves actuelles.

Un artefact terminé est une sortie logicielle JSON locale durable. Il ne constitue ni bien imprimé, ni acceptation client, ni réservation réelle de fournisseur, ni revenu, ni certification externe.

## Évaluation

| Champ | Valeur consignée |
| --- | --- |
| Assertion du test | `NOT_RUN` — Non exécuté |
| Verdict du composant testé | `NOT_RUN` — Non exécuté |
| Stade des preuves | `NOT_RUN` — Non exécuté |
| Affirmation sur la promesse complète | `NOT_ESTABLISHED` — Non établi |
| Sûreté dans le modèle testé | `NOT_ESTABLISHED` — Non établi |
| Liaison à l’autorité | `DEMONSTRATED` — Démontré dans le stade déclaré |
| État de la vérification fraîche | `COMPLETE` — Enregistrement terminé |
| Toutes les obligations terminées | Non |
| Valeur commerciale | `NOT_ESTABLISHED` — Non établi |
| Authenticité d’instructions clients réelles | `NOT_ESTABLISHED` — Non établi |

Le comportement du test, la sortie du composant, le stade des preuves et l’affirmation métier sont distincts. Un refus correct peut satisfaire un test de sûreté tout en laissant une obligation inexécutée. Un test réussi révélant une acceptation indue ne qualifie pas le vérificateur défectueux.

## Résultats par obligation

| Commande | Destinataire | Unités requises | Unités observées | Unités acceptées | Résultat | Voie |
| --- | --- | --- | --- | --- | --- | --- |
| LBL-100 | CUSTOMER-A | 1200 | 0 | 0 | `UNRESOLVED` — Non résolu | NON CONSIGNÉ / INCONNU |
| LBL-200 | CUSTOMER-B | 1000 | 0 | 0 | `UNRESOLVED` — Non résolu | NON CONSIGNÉ / INCONNU |

### Commande `LBL-100`

| Champ | Valeur consignée |
| --- | --- |
| Produit | LABEL-A |
| SHA-256 de la spécification finale | 121355b3f8e9b911720e9c2ebe87dc6078fb67861652c1bfb95096077e481a1a |
| Échéance logique (unités) | 100 |
| Position d’achèvement (unités) | NON CONSIGNÉ / INCONNU |
| Observation monotone après export (ns) | NON CONSIGNÉ / INCONNU |

**Achèvement durable observé au plus tard après:** NON CONSIGNÉ / INCONNU

**Transition du producteur avant validation (durée écoulée):** NON CONSIGNÉ / INCONNU

**Motifs consignés:**

- `NO_DURABLE_OUTPUT`: Aucun résultat durable accepté n’existe pour cette obligation.

### Commande `LBL-200`

| Champ | Valeur consignée |
| --- | --- |
| Produit | LABEL-A |
| SHA-256 de la spécification finale | 121355b3f8e9b911720e9c2ebe87dc6078fb67861652c1bfb95096077e481a1a |
| Échéance logique (unités) | 100 |
| Position d’achèvement (unités) | NON CONSIGNÉ / INCONNU |
| Observation monotone après export (ns) | NON CONSIGNÉ / INCONNU |

**Achèvement durable observé au plus tard après:** NON CONSIGNÉ / INCONNU

**Transition du producteur avant validation (durée écoulée):** NON CONSIGNÉ / INCONNU

**Motifs consignés:**

- `NO_DURABLE_OUTPUT`: Aucun résultat durable accepté n’existe pour cette obligation.

## Totaux de la promesse conservée

| Champ | Valeur consignée |
| --- | --- |
| Obligations requises | 2 |
| Obligations acceptées | 0 |
| Unités requises | 2200 |
| Unités de sortie observées | 0 |
| Unités acceptées | 0 |
| Unités non acceptées | 2200 |
| Obligations tardives | 0 |
| Obligations incorrectes | 0 |
| Obligations dupliquées | 0 |
| Obligations terminées sans justification | 0 |

## Échecs observés

Aucun élément consigné.

## Preuves et affirmations non résolues

| Code technique | Explication | Commande | Diagnostic technique original |
| --- | --- | --- | --- |
| `NOT_RUN` | Cette méthode n’a pas été exécutée. | NON CONSIGNÉ / INCONNU |  |

## Conditions figées

| Champ | Valeur consignée |
| --- | --- |
| Identifiant du contrat | CONTRACT-labels-transfer-c-constrained |
| Schéma du contrat | continuity-harness/contract/v1 |
| Version du contrat | 1 |
| Mode d’exercice déclaré | SYNTHETIC_LOCAL_EXECUTION |
| SHA-256 des événements sources | bcd522a59943bfcc986742d60f600a9d10f5a0f0ba7f5ff4270552cf2ed7dde3 |
| Borne d’observation de la source | 6 |
| Déclaration de complétude de la source rédigée | Oui |
| Échéance logique (unités) | 100 |
| Échéance réelle configurée (ms) | 30000 |
| Objectif de reprise configuré (ms) | 15000 |
| Fenêtre de capacité [début, fin) | {"end":100,"start":0} |
| Durée de réservation (unités logiques) | 20 |
| Capacités déclarées des voies (unités) | {"backup":1300,"primary":2600} |
| Voies autorisées | ["primary","backup"] |
| Permissions déclarées | {"activation":true,"sharing":true} |
| Dépendances déclarées des voies | {"backup":"GRID-404-INDEPENDENT","primary":"GRID-404"} |
| Dépendances indisponibles | ["GRID-404"] |
| Devise configurée du cas synthétique | USD |
| Budget configuré du cas synthétique (unités mineures) | 0 |
| Conditions figées de comparaison | {"fixture_id":"labels-transfer-c","held_out":true,"information":"EQUAL","resource_policy":"SHARED_SERVICES","suite_id":"CONTINUITY-HARNESS-001"} |

Les unités logiques appartiennent au calendrier du contrôleur ; ce ne sont pas des heures mesurées. Les millisecondes et nanosecondes ci-dessous représentent des mesures locales monotones. L’achèvement durable utilise l’observation de confiance après export comme borne supérieure prudente, distincte de l’horodatage de transition du producteur avant validation. Un retard d’observation peut faire rejeter une borne tardive même si la persistance a eu lieu plus tôt. L’échéance réelle et l’objectif de reprise configurés sont des limites d’acceptation, pas des durées atteintes.

## Calendrier des pannes et observations

| Code technique | Action | Cible | Observé |
| --- | --- | --- | --- |
| `PRIMARY_UNAVAILABLE` — Voie principale désactivée | DISABLE | primary | Non |
| `CONCURRENT_FINAL_CAPACITY` — Concurrence sur la capacité restante | RACE | backup | Non |
| `ACK_LOST_AFTER_DURABLE_FULFILLMENT` — Accusé perdu après réalisation durable | DROP_ACK | service | Non |
| `RETRY_WHILE_OUTCOME_UNKNOWN` — Nouvelle tentative pendant l’incertitude du résultat initial | RETRY | service | Non |
| `SERVICE_KILLED_AFTER_COMMIT` — Processus de service arrêté après validation | KILL | service | Non |
| `CANDIDATE_KILLED_AFTER_REQUEST` — Processus candidat arrêté après sa demande | KILL | candidate | Non |
| `RESTART_RECONCILIATION` — Redémarrer et rapprocher l’état durable | RESTART | candidate | Non |

Le journal complet des événements et interventions se trouve dans controller.json. Un calendrier ne prouve pas à lui seul que les pannes ont eu lieu ; la colonne d’observation indique les correspondances exactes dans l’enregistrement fourni du contrôleur.

| Code technique | Explication | Commande | Diagnostic technique original |
| --- | --- | --- | --- |
| `LOCAL_AI_UNAVAILABLE` | Aucun modèle local approprié et autorisé n’a été exécuté ; la performance d’IA n’a pas été mesurée. | NON CONSIGNÉ / INCONNU | No authorized local model command was supplied; no API or model download was used. |

## Mesures et lacunes comptables

| Champ | Valeur consignée |
| --- | --- |
| Durée réelle d’exécution mesurée | 0,015 ms (14872 ns) |
| Processeur des enfants observé : utilisateur | 0,000 ms (0 ns) |
| Processeur des enfants observé : système | 0,000 ms (0 ns) |
| Processeur du contrôleur observé : utilisateur | 0,015 ms (14999 ns) |
| Processeur du contrôleur observé : système | 0,003 ms (3000 ns) |
| Mémoire résidente maximale (octets) | NON CONSIGNÉ / INCONNU |
| Stockage mesuré avant rapports finaux (octets) | 2856 |
| Demandes du candidat au relais | 0 |
| Nouvelles tentatives consignées | 0 |
| Redémarrages de processus consignés | 0 |
| Interventions humaines pendant cette exécution | 0 |
| Travail de préparation consigné (secondes) | NON CONSIGNÉ / INCONNU |
| Travail d’intégration consigné (secondes) | NON CONSIGNÉ / INCONNU |
| Coût monétaire complet | NON CONSIGNÉ / INCONNU |
| Durée mesurée de reprise/préparation (ms) | NON CONSIGNÉ / INCONNU |

Le temps réel mesure l’intervalle d’exécution locale du contrôleur. Les valeurs processeur des enfants et du contrôleur sont des différences distinctes d’utilisation des processus lorsqu’elles sont consignées. Le processeur de vérification/rapport et le développement n’y sont pas inclus. Le stockage mesure le contenu de l’exécution avant les fichiers finaux de contrôle/rapport et les métadonnées d’index, sans l’autorité conservée séparément. Les demandes au relais comptent celles du candidat ; les opérations internes du contrôleur restent dans le journal. Zéro intervention humaine ne concerne que cette exécution autonome.

Le travail de préparation et d’intégration, la mémoire non mesurée, les taux monétaires et les coûts commerciaux complets restent inconnus lorsqu’ils ne sont pas consignés. La devise et le budget configurés sont des données du cas synthétique, pas des dépenses mesurées ni un budget client. Aucun prix ni économie n’est déduit. Une observation bornée par méthode et par cas n’établit pas un avantage stable de performance.

| Champ | Valeur consignée |
| --- | --- |
| Allocation simultanée maximale par voie | NON CONSIGNÉ / INCONNU |
| Transitions durables vérifiées | NON CONSIGNÉ / INCONNU |
| Reconstruction principale vérifiée | NON CONSIGNÉ / INCONNU |

## Identité, versions et environnement

| Champ | Valeur consignée |
| --- | --- |
| Identifiant de l’exécution | labels-transfer-c-constrained-ai-c3af39df0a42 |
| Méthode candidate | `ai` — Procédure assistée par IA |
| Scénario | `constrained` — Perturbation contrainte et reprise |
| Graine consignée | 404 |
| État du contrôleur | `NOT_RUN` — Non exécuté |
| Début d’exécution (UTC) | 2026-11-06T20:38:31.575850+00:00 |
| SHA-256 du contrat conservé | 23cd61d5b68726fdaa26363d7dbddf5a902c397e0f7175f631a62f74d722e4c4 |
| SHA-256 de la référence observée | 5fe9eed73f4ee032ad5b9947ad93224145a08ebeb35df416342bab57170cdd5a |
| Version du vérificateur frais | 0.1.0 |
| Schéma du résultat de vérification | continuity-harness/verification/v1 |
| Schéma de la référence conservée | continuity-harness/reference/v1 |
| Empreinte de référence fournie indépendamment | 5fe9eed73f4ee032ad5b9947ad93224145a08ebeb35df416342bab57170cdd5a |
| SHA-256 du résultat structuré canonique | 052fa2a1807b8c2b62393ab95aa276d769431684ac0b52c6a4a23ab49d1b1f08 |
| Version de l’implémentation | 0.1.0 |
| Commit Git consigné | fa9da1f54acfaa82510a4b6b805c2980d3e5b31d |
| Arbre de travail avec modifications non commises | Non |
| Environnement Python consigné | 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ] |
| Plateforme et noyau consignés | Linux-6.18.57-x86_64-with-glibc2.39 |
| Version de SQLite consignée | 3.53.1 |
| Répertoire de travail consigné | /workspace/scratch/b1d5891eb025/continuity-harness-qualified-v2 |

### Identités des sources d’implémentation

| Chemin | SHA-256 |
| --- | --- |
| continuity_harness/__init__.py | `577ece33903d70ce17189e594370916b485efec1e66ee07f099b4f62ebd4219e` |
| continuity_harness/__main__.py | `c89523d1e0bbfc47bdcef086a06fabefacde32b7aca6be132e79d78b11e003c8` |
| continuity_harness/adapters.py | `ba0be575481384b74dfbc407c4e575bb8f561c50f1235fdf51f0b4b9c19865b0` |
| continuity_harness/candidate.py | `938d73f546c774452b22823639beda4b0f89d911abe429da48039bf1808e3141` |
| continuity_harness/challenges.py | `d14ec02a127eaab94bf440ccb76b38aa735983f393d6ccae80eb6fcdb1215a5d` |
| continuity_harness/controller.py | `7bbc8a87d34b64d8e9e621de5a907f3b123a3a0e973745c73385b73f3a52d1fd` |
| continuity_harness/fixtures.py | `4464f7c9b151300858703f2332049f83c2df429684326b5be3f4e45e7da11b9e` |
| continuity_harness/reporting.py | `e89eee75a923f9489112e243f140f17adba916627d3c02ff6ac2b58e9a1f8645` |
| continuity_harness/rpc.py | `36e48a53bd6c99a51f85fe1183f6e6e3ff9b0c3f3501c3d8c080ab1ff099b745` |
| continuity_harness/sandbox.py | `7ae5423afd96847b1c38c746a7c417f938624e32acf97273c27757b46e3d556f` |
| continuity_harness/schema.py | `4ad738e4b1ef001d039d92ffad897241be7605189b579abd69e38cfe3660427c` |
| continuity_harness/service.py | `6b2c1816e71b6d0768024ed2a2273d98929fd42c223853eff7f7ccd63108055c` |
| continuity_harness/suite.py | `bac676e2886e2ca434b775fe58a0f87b33c4c97f32badd5d2c63659323a5c4dc` |
| continuity_harness/verifier.py | `2177652f986f9a305d7d3c90e808ba15651a58280c4a6bfd3f37da028542df38` |
| experiments/harness-v0.1/PROVENANCE.json | `0c8697da8cd4eb8635cf5413c0f3e0b4c2dc82ea6cd7d8bc6cac194bed7f5f32` |
| experiments/harness-v0.1/spec.json | `8f08c8d524ab4aab9528728725d528eaa5f7e701403c9e176e8dff9b17380880` |

## Identités des preuves actuelles

NON CONSIGNÉ / INCONNU

Le vérificateur compare les octets actuels au sceau d’exécution conservé séparément. Ces empreintes identifient des octets ; elles n’authentifient pas une instruction client réelle et ne prouvent pas la complétude du monde réel.

## Vérification fraîche et commandes consignées

```sh
python3 -m continuity_harness --language fr verify --run /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/attempt-2/comparison/runs/labels-transfer-c-constrained-ai-c3af39df0a42 --authority /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/attempt-2/comparison/authority/labels-transfer-c-constrained-ai-c3af39df0a42 --reference-sha256 5fe9eed73f4ee032ad5b9947ad93224145a08ebeb35df416342bab57170cdd5a
```

Exécuter depuis la copie de l’implémentation consignée. Fournir l’empreinte de référence conservée indépendamment dans l’index de la suite ; ne pas la remplacer par une valeur dérivée des données candidates. La vérification n’écrase pas ce Passeport enregistré.

### Autres commandes consignées pour cette exécution

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m continuity_harness --language en compare --out /workspace/scratch/b1d5891eb025/harness-delivery-v0.1/attempt-2/comparison
```


## Hypothèses de confiance et limites restantes

| Champ | Valeur consignée |
| --- | --- |
| Mécanisme d’isolement du candidat | SECCOMP_BPF |
| Isolement appliqué | Non |
| Observations des tests d’isolement | {} |
| Périmètre de confiance déclaré | TRUSTED_HOST_CONTROLLER_CLOCK_AND_VERIFIER_AUTHORED_SYNTHETIC_SOURCE |

L’hôte, le contrôleur, le journal rédigé, les services locaux, l’horloge et le vérificateur d’acceptation sont de confiance dans le modèle de panne déclaré. Le code candidat fourni et ses imports sont de confiance avant l’activation de seccomp ; aucun module tiers arbitraire n’est pris en charge. Le candidat reçoit des données bornées après filtrage et agit uniquement par le relais autorisé. Cela ne protège pas contre un administrateur malveillant de l’hôte.

L’identité, la garde, la complétude des sources et l’intégrité des octets sont des propriétés différentes. Des tests locaux finis ne constituent ni preuve générale, ni garantie universelle d’exécution exactement une fois, ni certification externe indépendante, ni validation commerciale. Un transfert synthétique n’établit que le transfert mesuré dans les conditions consignées.

Un modèle indisponible, un substitut ou une réponse enregistrée n’établissent aucune performance d’IA. Le groupe IA est NON EXÉCUTÉ à moins qu’une véritable capacité locale autorisée ait été exécutée et mesurée.

Enregistrements structurés : [RESULT.json](RESULT.json) · [controller.json](controller.json). Les deux Passeports linguistiques dérivent du même résultat structuré.
